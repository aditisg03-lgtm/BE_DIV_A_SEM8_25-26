import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import Loading from "./components/common/Loading";

// Public Pages
import LandingPage from "./pages/LandingPage";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";

// Student Pages
import StudentDashboard from "./pages/student/Dashboard";
import BrowseJobs from "./pages/student/BrowseJobs";
import StudentJobDetails from "./pages/student/JobDetails"; // ✅ RENAMED with alias
import SavedJobs from "./pages/student/SavedJobs";
import JobComparison from "./pages/student/JobComparison";
import MockInterview from "./pages/student/MockInterview";
import MyApplications from "./pages/student/MyApplications";
import MyResumes from "./pages/student/MyResumes";
import StudentProfile from "./pages/student/Profile";
import Analytics from "./pages/student/Analytics";
import ActivityHistory from "./pages/student/ActivityHistory";

// HR Pages
import HRDashboard from "./pages/hr/Dashboard";
import Jobs from "./pages/hr/Jobs";
import CreateJob from "./pages/hr/CreateJob";
import HRJobDetails from "./pages/hr/JobDetails"; // ✅ UNCOMMENTED and renamed
import EditJob from "./pages/hr/EditJob";
import Applications from "./pages/hr/Applications";
import HRProfile from "./pages/hr/Profile";
import BulkUpload from "./pages/hr/BulkUpload";
import ApplicationDetails from "./pages/hr/ApplicationDetails";

const ProtectedRoute = ({ children, allowedRole }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <Loading />;
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (allowedRole && user.role !== allowedRole) {
    return (
      <Navigate
        to={user.role === "student" ? "/student/dashboard" : "/hr/dashboard"}
      />
    );
  }

  return children;
};

function App() {
  const { loading } = useAuth();

  if (loading) {
    return <Loading />;
  }

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Student Routes */}
      <Route
        path="/student/dashboard"
        element={
          <ProtectedRoute allowedRole="student">
            <StudentDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/jobs"
        element={
          <ProtectedRoute allowedRole="student">
            <BrowseJobs />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/jobs/:jobId"
        element={
          <ProtectedRoute allowedRole="student">
            <StudentJobDetails /> {/* ✅ USE STUDENT VERSION */}
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/jobs/saved"
        element={
          <ProtectedRoute allowedRole="student">
            <SavedJobs />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/job-comparison"
        element={
          <ProtectedRoute allowedRole="student">
            <JobComparison />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/mock-interview/:interviewId"
        element={
          <ProtectedRoute allowedRole="student">
            <MockInterview />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/applications"
        element={
          <ProtectedRoute allowedRole="student">
            <MyApplications />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/resumes"
        element={
          <ProtectedRoute allowedRole="student">
            <MyResumes />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/profile"
        element={
          <ProtectedRoute allowedRole="student">
            <StudentProfile />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/analytics"
        element={
          <ProtectedRoute allowedRole="student">
            <Analytics />
          </ProtectedRoute>
        }
      />
      <Route
        path="/student/activity-history"
        element={
          <ProtectedRoute allowedRole="student">
            <ActivityHistory />
          </ProtectedRoute>
        }
      />

      {/* HR Routes */}
      <Route
        path="/hr/dashboard"
        element={
          <ProtectedRoute allowedRole="hr">
            <HRDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/hr/jobs"
        element={
          <ProtectedRoute allowedRole="hr">
            <Jobs />
          </ProtectedRoute>
        }
      />
      <Route
        path="/hr/jobs/new"
        element={
          <ProtectedRoute allowedRole="hr">
            <CreateJob />
          </ProtectedRoute>
        }
      />
      <Route
        path="/hr/jobs/:jobId"
        element={
          <ProtectedRoute allowedRole="hr">
            <HRJobDetails /> {/* ✅ USE HR VERSION */}
          </ProtectedRoute>
        }
      />
      <Route
        path="/hr/jobs/:jobId/edit"
        element={
          <ProtectedRoute allowedRole="hr">
            <EditJob />
          </ProtectedRoute>
        }
      />
      <Route
        path="/hr/applications"
        element={
          <ProtectedRoute allowedRole="hr">
            <Applications />
          </ProtectedRoute>
        }
      />
      <Route
        path="/hr/bulk-upload"
        element={
          <ProtectedRoute allowedRole="hr">
            <BulkUpload />
          </ProtectedRoute>
        }
      />
      <Route
        path="/hr/profile"
        element={
          <ProtectedRoute allowedRole="hr">
            <HRProfile />
          </ProtectedRoute>
        }
      />
      <Route
        path="/hr/applications/:applicationId"
        element={
          <ProtectedRoute allowedRole="hr">
            <ApplicationDetails />
          </ProtectedRoute>
        }
      />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}

export default App;
