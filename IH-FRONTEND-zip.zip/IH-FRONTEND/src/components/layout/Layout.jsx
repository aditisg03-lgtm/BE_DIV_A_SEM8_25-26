import { Box, Flex } from "@chakra-ui/react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";

const Layout = ({ children }) => {
  return (
    <Box minH="100vh" bg="bg.weak">
      <Sidebar />

      {/* Main content with left margin for sidebar */}
      <Box ml={{ base: 0, lg: "272px" }}>
        <Box maxW="1400px" mx="auto" w="full">
          <Navbar />

          <Box px={{ base: 4, lg: 8 }} pb={8}>
            {children}
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Layout;
