import {
  Box,
  Flex,
  HStack,
  Text,
  Icon,
  IconButton,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  MenuDivider,
  Avatar,
  Badge,
  VStack,
  Input,
  InputGroup,
  InputLeftElement,
  useDisclosure,
  Collapse,
  Container,
} from "@chakra-ui/react";
import {
  RiSearchLine,
  RiNotification2Line,
  RiLogoutBoxLine,
  RiUserLine,
  RiSettings4Line,
  RiMenuLine,
} from "react-icons/ri";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

const Navbar = () => {
  const { user, logout, isStudent } = useAuth();
  const navigate = useNavigate();
  const { isOpen: isSearchOpen, onToggle: toggleSearch } = useDisclosure();
  const [searchQuery, setSearchQuery] = useState("");

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <Box
      position="sticky"
      top={0}
      zIndex={100}
      bg="rgba(255, 255, 255, 0.8)"
      backdropFilter="blur(20px)"
      borderBottom="1px solid"
      borderColor="rgba(229, 231, 235, 0.5)"
      shadow="0 4px 16px rgba(0, 0, 0, 0.02)"
    >
      <Container maxW="100%" px={{ base: 4, md: 6, lg: 8 }}>
        <Flex
          h="72px" // Increased height for better spacing
          align="center"
          justify="space-between"
          gap={4} // Add gap between sections
        >
          {/* Mobile Menu Button */}
          <IconButton
            display={{ base: "flex", lg: "none" }}
            aria-label="Menu"
            icon={<Icon as={RiMenuLine} boxSize={5} />}
            size="sm"
            h={10}
            w={10}
            variant="ghost"
            borderRadius="10px"
            color="text.sub"
            bg="rgba(248, 249, 250, 0.5)"
            _hover={{
              bg: "rgba(125, 82, 244, 0.1)",
              color: "primary.base",
            }}
          />

          {/* Left Section - Greeting */}
          <VStack
            align="start"
            spacing={0.5}
            flex={1}
            minW={0} // Allow text truncation
          >
            <Text
              fontSize="label-sm"
              fontWeight={600}
              color="text.strong"
              fontFamily="'Inter', sans-serif"
              letterSpacing="-0.01em"
            >
              Welcome back 👋
            </Text>
            <Text
              fontSize="paragraph-xs"
              color="text.sub"
              fontFamily="'Inter', sans-serif"
              noOfLines={1}
            >
              {user?.email}
            </Text>
          </VStack>

          {/* Right Section - Actions */}
          <HStack spacing={3} flexShrink={0}>
            {/* Search Button/Input */}
            <Box display={{ base: "none", md: "block" }}>
              {isSearchOpen ? (
                <InputGroup size="sm" w="260px">
                  <InputLeftElement h="40px" pointerEvents="none">
                    <Icon as={RiSearchLine} color="text.soft" boxSize={4} />
                  </InputLeftElement>
                  <Input
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onBlur={() => {
                      if (!searchQuery) toggleSearch();
                    }}
                    autoFocus
                    h="40px"
                    pl={10}
                    bg="rgba(255, 255, 255, 0.6)"
                    backdropFilter="blur(10px)"
                    border="1px solid"
                    borderColor="rgba(229, 231, 235, 0.8)"
                    borderRadius="10px"
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                    _hover={{
                      borderColor: "primary.lighter",
                      bg: "rgba(255, 255, 255, 0.8)",
                    }}
                    _focus={{
                      borderColor: "primary.base",
                      boxShadow: "0 0 0 3px rgba(125, 82, 244, 0.08)",
                      bg: "rgba(255, 255, 255, 0.9)",
                    }}
                  />
                </InputGroup>
              ) : (
                <IconButton
                  aria-label="Search"
                  icon={<Icon as={RiSearchLine} boxSize={4.5} />}
                  onClick={toggleSearch}
                  size="sm"
                  h={10}
                  w={10}
                  variant="ghost"
                  borderRadius="10px"
                  color="text.sub"
                  bg="rgba(248, 249, 250, 0.5)"
                  _hover={{
                    bg: "rgba(125, 82, 244, 0.1)",
                    color: "primary.base",
                    transform: "scale(1.05)",
                  }}
                  transition="all 0.2s"
                />
              )}
            </Box>

            {/* Notifications */}
            <Menu placement="bottom-end">
              <MenuButton
                as={IconButton}
                aria-label="Notifications"
                icon={<Icon as={RiNotification2Line} boxSize={4.5} />}
                size="sm"
                h={10}
                w={10}
                variant="ghost"
                borderRadius="10px"
                color="text.sub"
                bg="rgba(248, 249, 250, 0.5)"
                position="relative"
                _hover={{
                  bg: "rgba(125, 82, 244, 0.1)",
                  color: "primary.base",
                  transform: "scale(1.05)",
                }}
                _active={{
                  bg: "rgba(125, 82, 244, 0.15)",
                }}
                transition="all 0.2s"
              >
                <Box
                  position="absolute"
                  top="7px"
                  right="7px"
                  w={2}
                  h={2}
                  bg="error.base"
                  borderRadius="full"
                  border="2px solid"
                  borderColor="white"
                  shadow="0 2px 8px rgba(239, 68, 68, 0.4)"
                  animation="pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite"
                  sx={{
                    "@keyframes pulse": {
                      "0%, 100%": { opacity: 1 },
                      "50%": { opacity: 0.5 },
                    },
                  }}
                />
              </MenuButton>
              <MenuList
                mt={2}
                borderRadius="14px"
                shadow="0 8px 32px rgba(0, 0, 0, 0.12)"
                border="1px solid"
                borderColor="rgba(229, 231, 235, 0.8)"
                bg="rgba(255, 255, 255, 0.98)"
                backdropFilter="blur(20px)"
                py={3}
                minW="320px"
                maxW="320px"
              >
                <Box px={4} pb={2}>
                  <HStack justify="space-between">
                    <Text
                      fontSize="label-sm"
                      fontWeight={600}
                      fontFamily="'Inter', sans-serif"
                    >
                      Notifications
                    </Text>
                    <Badge
                      colorScheme="purple"
                      fontSize="subheading-2xs"
                      borderRadius="full"
                    >
                      2 New
                    </Badge>
                  </HStack>
                </Box>
                <Box maxH="280px" overflowY="auto" px={2}>
                  <MenuItem
                    borderRadius="10px"
                    px={3}
                    py={3}
                    mb={1}
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                    _hover={{ bg: "rgba(125, 82, 244, 0.05)" }}
                  >
                    <VStack align="start" spacing={1} flex={1}>
                      <Text fontSize="label-xs" fontWeight={500}>
                        New job match found
                      </Text>
                      <Text fontSize="paragraph-xs" color="text.sub">
                        Senior Developer at TechCorp
                      </Text>
                      <Text fontSize="subheading-xs" color="text.soft">
                        2 minutes ago
                      </Text>
                    </VStack>
                  </MenuItem>
                  <MenuItem
                    borderRadius="10px"
                    px={3}
                    py={3}
                    mb={1}
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                    _hover={{ bg: "rgba(125, 82, 244, 0.05)" }}
                  >
                    <VStack align="start" spacing={1} flex={1}>
                      <Text fontSize="label-xs" fontWeight={500}>
                        Resume analysis complete
                      </Text>
                      <Text fontSize="paragraph-xs" color="text.sub">
                        ATS Score: 85%
                      </Text>
                      <Text fontSize="subheading-xs" color="text.soft">
                        1 hour ago
                      </Text>
                    </VStack>
                  </MenuItem>
                </Box>
                <MenuDivider my={2} />
                <MenuItem
                  borderRadius="10px"
                  mx={2}
                  fontSize="label-xs"
                  fontFamily="'Inter', sans-serif"
                  color="primary.base"
                  fontWeight={500}
                  justifyContent="center"
                  py={2}
                  _hover={{ bg: "rgba(125, 82, 244, 0.05)" }}
                >
                  View all notifications
                </MenuItem>
              </MenuList>
            </Menu>

            {/* User Menu */}
            <Menu placement="bottom-end">
              <MenuButton>
                <HStack
                  spacing={2.5}
                  px={2.5}
                  py={1.5}
                  h={10}
                  borderRadius="10px"
                  bg="rgba(248, 249, 250, 0.5)"
                  border="1px solid"
                  borderColor="rgba(229, 231, 235, 0.3)"
                  transition="all 0.2s"
                  cursor="pointer"
                  _hover={{
                    bg: "rgba(125, 82, 244, 0.1)",
                    borderColor: "rgba(125, 82, 244, 0.2)",
                    transform: "scale(1.02)",
                  }}
                >
                  <Avatar
                    size="sm"
                    name={user?.email}
                    bg="linear-gradient(135deg, #7d52f4, #8B5CF6)"
                    color="white"
                    fontFamily="'Inter', sans-serif"
                    fontSize="label-xs"
                    w={8}
                    h={8}
                  />
                  <Box display={{ base: "none", lg: "block" }} pr={1}>
                    <VStack align="start" spacing={0}>
                      <Text
                        fontSize="label-xs"
                        fontWeight={600}
                        fontFamily="'Inter', sans-serif"
                        color="text.strong"
                        letterSpacing="-0.01em"
                      >
                        {user?.email?.split("@")[0]}
                      </Text>
                      <Badge
                        fontSize="subheading-2xs"
                        colorScheme="purple"
                        variant="subtle"
                        px={1.5}
                        py={0.5}
                        borderRadius="full"
                      >
                        {isStudent ? "Student" : "HR"}
                      </Badge>
                    </VStack>
                  </Box>
                </HStack>
              </MenuButton>
              <MenuList
                mt={2}
                borderRadius="14px"
                shadow="0 8px 32px rgba(0, 0, 0, 0.12)"
                border="1px solid"
                borderColor="rgba(229, 231, 235, 0.8)"
                bg="rgba(255, 255, 255, 0.98)"
                backdropFilter="blur(20px)"
                py={3}
                minW="240px"
              >
                {/* User Info Header */}
                <Box
                  px={4}
                  pb={3}
                  mb={2}
                  borderBottom="1px solid"
                  borderColor="stroke.soft"
                >
                  <VStack align="start" spacing={2}>
                    <HStack spacing={3}>
                      <Avatar
                        size="md"
                        name={user?.email}
                        bg="linear-gradient(135deg, #7d52f4, #8B5CF6)"
                        color="white"
                        fontFamily="'Inter', sans-serif"
                      />
                      <VStack align="start" spacing={0}>
                        <Text
                          fontSize="label-sm"
                          fontWeight={600}
                          fontFamily="'Inter', sans-serif"
                          noOfLines={1}
                        >
                          {user?.email?.split("@")[0]}
                        </Text>
                        <Text
                          fontSize="paragraph-xs"
                          color="text.sub"
                          fontFamily="'Inter', sans-serif"
                          noOfLines={1}
                        >
                          {user?.email}
                        </Text>
                      </VStack>
                    </HStack>
                    <Badge
                      fontSize="subheading-xs"
                      colorScheme="purple"
                      variant="subtle"
                      alignSelf="start"
                    >
                      {isStudent ? "Student Account" : "HR Account"}
                    </Badge>
                  </VStack>
                </Box>

                {/* Menu Items */}
                <Box px={2}>
                  <MenuItem
                    icon={<Icon as={RiUserLine} boxSize={4} />}
                    onClick={() =>
                      navigate(isStudent ? "/student/profile" : "/hr/profile")
                    }
                    borderRadius="10px"
                    py={2.5}
                    mb={1}
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _hover={{ bg: "rgba(125, 82, 244, 0.05)" }}
                  >
                    My Profile
                  </MenuItem>
                  <MenuItem
                    icon={<Icon as={RiSettings4Line} boxSize={4} />}
                    borderRadius="10px"
                    py={2.5}
                    mb={1}
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _hover={{ bg: "rgba(125, 82, 244, 0.05)" }}
                  >
                    Settings
                  </MenuItem>
                </Box>
                <MenuDivider my={2} />
                <Box px={2}>
                  <MenuItem
                    icon={<Icon as={RiLogoutBoxLine} boxSize={4} />}
                    onClick={handleLogout}
                    color="error.base"
                    borderRadius="10px"
                    py={2.5}
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _hover={{ bg: "rgba(239, 68, 68, 0.05)" }}
                  >
                    Logout
                  </MenuItem>
                </Box>
              </MenuList>
            </Menu>
          </HStack>
        </Flex>
      </Container>

      {/* Mobile Search Collapse */}
      <Collapse in={isSearchOpen} animateOpacity>
        <Container maxW="100%" px={{ base: 4, md: 6, lg: 8 }} pb={4}>
          <InputGroup size="sm">
            <InputLeftElement h="40px" pointerEvents="none">
              <Icon as={RiSearchLine} color="text.soft" boxSize={4} />
            </InputLeftElement>
            <Input
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              h="40px"
              pl={10}
              bg="rgba(255, 255, 255, 0.6)"
              backdropFilter="blur(10px)"
              border="1px solid"
              borderColor="rgba(229, 231, 235, 0.8)"
              borderRadius="10px"
              fontSize="paragraph-sm"
              fontFamily="'Inter', sans-serif"
              _focus={{
                borderColor: "primary.base",
                boxShadow: "0 0 0 3px rgba(125, 82, 244, 0.08)",
              }}
            />
          </InputGroup>
        </Container>
      </Collapse>
    </Box>
  );
};

export default Navbar;
