import {
  Box,
  VStack,
  HStack,
  Text,
  Icon,
  Button,
  Divider,
  Flex,
  Avatar,
} from "@chakra-ui/react";
import { NavLink } from "react-router-dom";
import {
  RiDashboardLine,
  RiBriefcaseLine,
  RiBookmarkLine,
  // RiTargetLine,
  RiFileListLine,
  RiFileTextLine,
  RiUserLine,
  RiTimeLine,
  RiTeamLine,
  RiUploadLine,
  RiSettings3Line,
  RiArrowDownSLine,
} from "react-icons/ri";
import { useAuth } from "../../context/AuthContext";
import { FaLine } from "react-icons/fa";

const SidebarLink = ({ to, icon, children, badge }) => {
  return (
    <NavLink to={to} style={{ width: "100%" }}>
      {({ isActive }) => (
        <Button
          w="full"
          justifyContent="flex-start"
          variant="ghost"
          px={3}
          h={10}
          position="relative"
          color="text.sub"
          bg={isActive ? "bg.weak" : "transparent"}
          _hover={{ bg: "bg.weak" }}
          fontSize="label-sm"
        >
          {isActive && (
            <Box
              position="absolute"
              left="-20px"
              w="4px"
              h="20px"
              bg="primary.base"
              borderRadius="0 999px 999px 0"
            />
          )}
          <HStack spacing={2} w="full" justify="flex-start">
            <Icon
              as={icon}
              boxSize={5}
              color={isActive ? "primary.base" : "text.sub"}
            />
            <Text flex={1} textAlign="left">
              {children}
            </Text>
            {badge && (
              <Flex
                h={5}
                px={2}
                align="center"
                bg="primary.alpha.10"
                borderRadius="md"
                fontSize="subheading-xs"
                fontWeight={600}
                color="primary.base"
              >
                {badge}
              </Flex>
            )}
          </HStack>
        </Button>
      )}
    </NavLink>
  );
};

const Sidebar = () => {
  const { user, isStudent, isHR } = useAuth();

  return (
    <Box
      position="fixed"
      left={0}
      top={0}
      h="full"
      w="272px"
      bg="bg.white"
      borderRight="1px"
      borderColor="stroke.soft"
      display={{ base: "none", lg: "block" }}
      overflowY="auto"
      zIndex={10}
    >
      <VStack spacing={0} align="stretch" h="full">
        {/* Logo */}
        <Box p={5}>
          <HStack spacing={3} align="center">
            <Flex
              w={10}
              h={10}
              align="center"
              justify="center"
              borderRadius="xl"
              bg="primary.base"
              color="white"
              fontWeight="bold"
              fontSize="xl"
              flexShrink={0}
            >
              IH
            </Flex>
            <VStack align="flex-start" spacing={0} flex={1}>
              <Text fontSize="label-md" fontWeight={600} textAlign="left">
                IntelizenHire
              </Text>
              <Text fontSize="paragraph-xs" color="text.soft" textAlign="left">
                Career Platform
              </Text>
            </VStack>
          </HStack>
        </Box>

        <Divider />

        {/* Navigation */}
        <VStack spacing={5} p={5} flex={1} align="stretch">
          {isStudent && (
            <>
              <Box w="full">
                <Text
                  fontSize="subheading-xs"
                  textTransform="uppercase"
                  color="text.soft"
                  px={1}
                  mb={2}
                  fontWeight={600}
                  letterSpacing="wider"
                  textAlign="left"
                >
                  Main
                </Text>
                <VStack spacing={1} align="stretch">
                  <SidebarLink to="/student/dashboard" icon={RiDashboardLine}>
                    Dashboard
                  </SidebarLink>
                  <SidebarLink to="/student/jobs" icon={RiBriefcaseLine}>
                    Discover Jobs
                  </SidebarLink>
                  <SidebarLink to="/student/jobs/saved" icon={RiBookmarkLine}>
                    Saved Jobs
                  </SidebarLink>
                  <SidebarLink to="/student/job-comparison" icon={FaLine}>
                    Job Match Analyzer
                  </SidebarLink>
                </VStack>
              </Box>

              <Box w="full">
                <Text
                  fontSize="subheading-xs"
                  textTransform="uppercase"
                  color="text.soft"
                  px={1}
                  mb={2}
                  fontWeight={600}
                  letterSpacing="wider"
                  textAlign="left"
                >
                  My Content
                </Text>
                <VStack spacing={1} align="stretch">
                  <SidebarLink to="/student/applications" icon={RiFileListLine}>
                    My Applications
                  </SidebarLink>
                  <SidebarLink to="/student/resumes" icon={RiFileTextLine}>
                    My Resumes
                  </SidebarLink>
                  <SidebarLink to="/student/profile" icon={RiUserLine}>
                    Profile
                  </SidebarLink>
                  <SidebarLink to="/student/activity-history" icon={RiTimeLine}>
                    Activity History
                  </SidebarLink>
                </VStack>
              </Box>
            </>
          )}

          {isHR && (
            <>
              <Box w="full">
                <Text
                  fontSize="subheading-xs"
                  textTransform="uppercase"
                  color="text.soft"
                  px={1}
                  mb={2}
                  fontWeight={600}
                  letterSpacing="wider"
                  textAlign="left"
                >
                  Main
                </Text>
                <VStack spacing={1} align="stretch">
                  <SidebarLink to="/hr/dashboard" icon={RiDashboardLine}>
                    Dashboard
                  </SidebarLink>
                  <SidebarLink to="/hr/jobs" icon={RiBriefcaseLine}>
                    My Jobs
                  </SidebarLink>
                  <SidebarLink to="/hr/applications" icon={RiTeamLine}>
                    Applications
                  </SidebarLink>
                  <SidebarLink to="/hr/bulk-upload" icon={RiUploadLine}>
                    Bulk Upload
                  </SidebarLink>
                  <SidebarLink to="/hr/profile" icon={RiUserLine}>
                    Profile
                  </SidebarLink>
                </VStack>
              </Box>
            </>
          )}

          {/* Settings at bottom */}
          <VStack spacing={1} align="stretch" mt="auto">
            <SidebarLink to="/settings" icon={RiSettings3Line}>
              Settings
            </SidebarLink>
          </VStack>
        </VStack>

        <Divider />

        {/* User Profile */}
        <Box p={3}>
          <Button
            w="full"
            justifyContent="space-between"
            variant="ghost"
            px={3}
            h="auto"
            py={3}
            borderRadius="10px"
          >
            <HStack spacing={3} flex={1} align="center">
              <Avatar
                size="sm"
                name={user?.email}
                bg="primary.base"
                flexShrink={0}
              />
              <VStack align="flex-start" spacing={0} flex={1} overflow="hidden">
                <Text
                  fontSize="label-sm"
                  fontWeight={500}
                  noOfLines={1}
                  textAlign="left"
                  w="full"
                >
                  {user?.email?.split("@")[0] || "User"}
                </Text>
                <Text
                  fontSize="paragraph-xs"
                  color="text.sub"
                  textAlign="left"
                  w="full"
                >
                  {isStudent ? "Student" : isHR ? "HR Manager" : "User"}
                </Text>
              </VStack>
            </HStack>
            <Icon
              as={RiArrowDownSLine}
              boxSize={5}
              color="text.sub"
              flexShrink={0}
            />
          </Button>
        </Box>
      </VStack>
    </Box>
  );
};

export default Sidebar;
