import {
  VStack,
  FormControl,
  FormLabel,
  Input,
  Button,
  SimpleGrid,
  useToast,
  Box,
  HStack,
  Text,
  Icon,
  Select,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  IconButton,
  Flex,
  Divider,
  Badge,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import {
  RiDeleteBinLine,
  RiAddLine,
  RiStarLine,
  RiStarFill,
} from "react-icons/ri";
import { studentAPI } from "../../api/student";
import { SKILL_CATEGORIES } from "../../utils/constants";

const SkillCard = ({ skill, onDelete }) => {
  const getProficiencyColor = (level) => {
    if (level >= 4) return "success.base";
    if (level >= 3) return "information.base";
    return "warning.base";
  };

  const getProficiencyLabel = (level) => {
    const labels = [
      "Beginner",
      "Elementary",
      "Intermediate",
      "Advanced",
      "Expert",
    ];
    return labels[level - 1] || "Intermediate";
  };

  return (
    <Box
      bg="bg.white"
      p={4}
      borderRadius="xl"
      border="1px"
      borderColor="stroke.soft"
      transition="all 0.2s"
      _hover={{ shadow: "md", borderColor: "primary.lighter" }}
    >
      <HStack justify="space-between" align="start" mb={3}>
        <VStack align="start" spacing={1} flex={1}>
          <Text fontSize="label-md" fontWeight={600}>
            {skill.skill_name}
          </Text>
          <Badge
            colorScheme={
              skill.skill_category === "technical" ? "purple" : "blue"
            }
            fontSize="subheading-xs"
            textTransform="capitalize"
          >
            {skill.skill_category}
          </Badge>
        </VStack>
        <IconButton
          icon={<Icon as={RiDeleteBinLine} />}
          variant="ghost"
          colorScheme="red"
          size="sm"
          onClick={onDelete}
          aria-label="Delete"
        />
      </HStack>

      <VStack spacing={2} align="stretch">
        <HStack justify="space-between">
          <Text fontSize="paragraph-sm" color="text.sub">
            Proficiency
          </Text>
          <HStack spacing={1}>
            {[1, 2, 3, 4, 5].map((level) => (
              <Icon
                key={level}
                as={level <= skill.proficiency_level ? RiStarFill : RiStarLine}
                color={
                  level <= skill.proficiency_level
                    ? getProficiencyColor(skill.proficiency_level)
                    : "stroke.soft"
                }
                boxSize={4}
              />
            ))}
          </HStack>
        </HStack>

        <Text
          fontSize="paragraph-xs"
          color={getProficiencyColor(skill.proficiency_level)}
          fontWeight={500}
        >
          {getProficiencyLabel(skill.proficiency_level)}
        </Text>

        {skill.years_of_experience && (
          <Text fontSize="paragraph-xs" color="text.soft">
            {skill.years_of_experience} years experience
          </Text>
        )}
      </VStack>
    </Box>
  );
};

const SkillForm = () => {
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    skill_name: "",
    skill_category: "technical",
    proficiency_level: 3,
    years_of_experience: "",
  });
  const toast = useToast();

  useEffect(() => {
    fetchSkills();
  }, []);

  const fetchSkills = async () => {
    try {
      const data = await studentAPI.getSkills();
      setSkills(data);
    } catch (error) {
      console.error("Failed to fetch skills:", error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await studentAPI.createSkill(formData);
      toast({
        title: "Skill added successfully",
        status: "success",
        duration: 2000,
      });
      setFormData({
        skill_name: "",
        skill_category: "technical",
        proficiency_level: 3,
        years_of_experience: "",
      });
      setShowForm(false);
      fetchSkills();
    } catch (error) {
      toast({
        title: "Failed to add skill",
        description: error.response?.data?.detail || "Please try again",
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await studentAPI.deleteSkill(id);
      toast({
        title: "Skill deleted",
        status: "success",
        duration: 2000,
      });
      fetchSkills();
    } catch (error) {
      toast({
        title: "Delete failed",
        status: "error",
        duration: 2000,
      });
    }
  };

  const getProficiencyLabel = (level) => {
    const labels = [
      "Beginner",
      "Elementary",
      "Intermediate",
      "Advanced",
      "Expert",
    ];
    return labels[level - 1] || "Intermediate";
  };

  return (
    <VStack spacing={5} align="stretch">
      {skills.length > 0 && (
        <VStack spacing={3} align="stretch">
          <Text fontSize="label-sm" color="text.sub" fontWeight={500}>
            Your Skills ({skills.length})
          </Text>
          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={4}>
            {skills.map((skill) => (
              <SkillCard
                key={skill.id}
                skill={skill}
                onDelete={() => handleDelete(skill.id)}
              />
            ))}
          </SimpleGrid>
        </VStack>
      )}

      {skills.length > 0 && <Divider />}

      {!showForm ? (
        <Button
          leftIcon={<Icon as={RiAddLine} />}
          onClick={() => setShowForm(true)}
          variant="outline"
          borderStyle="dashed"
          borderWidth={2}
          h={12}
          borderColor="stroke.soft"
          color="text.sub"
          _hover={{
            borderColor: "primary.base",
            color: "primary.base",
            bg: "primary.alpha.10",
          }}
        >
          Add Skill
        </Button>
      ) : (
        <Box
          p={6}
          borderRadius="xl"
          border="1px"
          borderColor="stroke.soft"
          bg="bg.white"
        >
          <VStack spacing={4} align="stretch">
            <HStack justify="space-between">
              <Text fontSize="label-md" fontWeight={600}>
                Add New Skill
              </Text>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setShowForm(false)}
              >
                Cancel
              </Button>
            </HStack>

            <form onSubmit={handleSubmit}>
              <VStack spacing={4}>
                <FormControl isRequired>
                  <FormLabel fontSize="label-sm">Skill Name</FormLabel>
                  <Input
                    name="skill_name"
                    value={formData.skill_name}
                    onChange={handleChange}
                    placeholder="e.g., JavaScript, Leadership, Communication"
                    bg="bg.weak"
                  />
                </FormControl>

                <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4} w="100%">
                  <FormControl isRequired>
                    <FormLabel fontSize="label-sm">Category</FormLabel>
                    <Select
                      name="skill_category"
                      value={formData.skill_category}
                      onChange={handleChange}
                      bg="bg.weak"
                    >
                      {SKILL_CATEGORIES.map((category) => (
                        <option key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </option>
                      ))}
                    </Select>
                  </FormControl>

                  <FormControl>
                    <FormLabel fontSize="label-sm">
                      Years of Experience
                    </FormLabel>
                    <Input
                      name="years_of_experience"
                      type="number"
                      step="0.5"
                      value={formData.years_of_experience}
                      onChange={handleChange}
                      placeholder="2.5"
                      bg="bg.weak"
                    />
                  </FormControl>
                </SimpleGrid>

                <FormControl>
                  <FormLabel fontSize="label-sm">
                    Proficiency Level:{" "}
                    {getProficiencyLabel(formData.proficiency_level)}
                  </FormLabel>
                  <Slider
                    value={formData.proficiency_level}
                    onChange={(value) =>
                      setFormData({ ...formData, proficiency_level: value })
                    }
                    min={1}
                    max={5}
                    step={1}
                    colorScheme="primary"
                  >
                    <SliderTrack bg="bg.soft">
                      <SliderFilledTrack bg="primary.base" />
                    </SliderTrack>
                    <SliderThumb boxSize={6} bg="primary.base" />
                  </Slider>
                  <HStack
                    justify="space-between"
                    mt={2}
                    fontSize="paragraph-xs"
                    color="text.soft"
                  >
                    <Text>Beginner</Text>
                    <Text>Expert</Text>
                  </HStack>
                </FormControl>

                <Button
                  type="submit"
                  bg="primary.base"
                  color="white"
                  w="100%"
                  isLoading={loading}
                  leftIcon={<Icon as={RiAddLine} />}
                >
                  Add Skill
                </Button>
              </VStack>
            </form>
          </VStack>
        </Box>
      )}
    </VStack>
  );
};

export default SkillForm;
