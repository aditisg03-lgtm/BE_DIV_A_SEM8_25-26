import { Box, Text, VStack, Icon, Button } from "@chakra-ui/react";
import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { RiUploadCloudLine, RiFileTextLine } from "react-icons/ri";
import { resumeAPI } from "../../api/resume";
import { useToast } from "@chakra-ui/react";

const ResumeUpload = ({ onUploadSuccess }) => {
  const [uploading, setUploading] = useState(false);
  const toast = useToast();

  const onDrop = useCallback(
    async (acceptedFiles) => {
      if (acceptedFiles.length === 0) return;

      const file = acceptedFiles[0];

      if (file.type !== "application/pdf") {
        toast({
          title: "Invalid file type",
          description: "Please upload a PDF file",
          status: "error",
          duration: 3000,
        });
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "File size must be less than 5MB",
          status: "error",
          duration: 3000,
        });
        return;
      }

      setUploading(true);
      try {
        const response = await resumeAPI.upload(file);
        toast({
          title: "Resume uploaded successfully",
          status: "success",
          duration: 3000,
        });
        if (onUploadSuccess) {
          onUploadSuccess(response);
        }
      } catch (error) {
        toast({
          title: "Upload failed",
          description:
            error.response?.data?.detail || "Failed to upload resume",
          status: "error",
          duration: 3000,
        });
      } finally {
        setUploading(false);
      }
    },
    [onUploadSuccess, toast]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
    },
    multiple: false,
    disabled: uploading,
  });

  return (
    <Box
      {...getRootProps()}
      border="2px dashed"
      borderColor={isDragActive ? "primary.base" : "stroke.soft"}
      borderRadius="2xl"
      p={10}
      textAlign="center"
      cursor="pointer"
      bg={isDragActive ? "primary.alpha.10" : "bg.white"}
      transition="all 0.2s"
      _hover={{
        borderColor: "primary.base",
        bg: "primary.alpha.10",
        transform: "translateY(-2px)",
      }}
    >
      <input {...getInputProps()} />
      <VStack spacing={4}>
        <Icon
          as={uploading ? RiFileTextLine : RiUploadCloudLine}
          boxSize={16}
          color="primary.base"
        />
        {uploading ? (
          <Text fontSize="label-md" color="text.sub">
            Uploading your resume...
          </Text>
        ) : (
          <>
            <VStack spacing={2}>
              <Text fontSize="label-lg" fontWeight={600} color="text.strong">
                {isDragActive ? "Drop your resume here" : "Upload your resume"}
              </Text>
              <Text fontSize="paragraph-sm" color="text.sub">
                Drag & drop or click to browse
              </Text>
            </VStack>
            <Button
              bg="primary.base"
              color="white"
              size="md"
              _hover={{ bg: "primary.darker" }}
            >
              Choose File
            </Button>
            <Text fontSize="paragraph-xs" color="text.soft">
              PDF only • Maximum 5MB
            </Text>
          </>
        )}
      </VStack>
    </Box>
  );
};

export default ResumeUpload;
