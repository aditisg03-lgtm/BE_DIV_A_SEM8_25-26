import {
  VStack,
  FormControl,
  FormLabel,
  Input,
  Textarea,
  Button,
  SimpleGrid,
  useToast,
  Select,
  Box,
  Text,
  HStack,
  Icon,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { RiCheckLine } from "react-icons/ri";
import { studentAPI } from "../../api/student";

const ProfileForm = () => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    phone: "",
    date_of_birth: "",
    location: "",
    linkedin_url: "",
    github_url: "",
    portfolio_url: "",
    bio: "",
    preferred_job_types: [],
    expected_salary: "",
    availability: "immediate",
  });
  const toast = useToast();

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const data = await studentAPI.getProfile();
      setFormData({
        ...data,
        expected_salary: data.expected_salary || "",
        date_of_birth: data.date_of_birth || "",
        phone: data.phone || "",
        location: data.location || "",
        linkedin_url: data.linkedin_url || "",
        github_url: data.github_url || "",
        portfolio_url: data.portfolio_url || "",
        bio: data.bio || "",
      });
    } catch (error) {
      console.log("No profile found");
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const submitData = {
        ...formData,
        phone: formData.phone || null,
        date_of_birth: formData.date_of_birth || null,
        location: formData.location || null,
        linkedin_url: formData.linkedin_url || null,
        github_url: formData.github_url || null,
        portfolio_url: formData.portfolio_url || null,
        bio: formData.bio || null,
        expected_salary: formData.expected_salary
          ? parseInt(formData.expected_salary)
          : null,
      };

      try {
        await studentAPI.updateProfile(submitData);
      } catch (error) {
        await studentAPI.createProfile(submitData);
      }

      toast({
        title: "Profile saved successfully",
        status: "success",
        duration: 2000,
        isClosable: true,
      });
    } catch (error) {
      toast({
        title: "Failed to save profile",
        description: error.response?.data?.detail || "Please try again",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <VStack spacing={6} align="stretch">
        <Box>
          <Text fontSize="label-md" fontWeight={600} mb={1}>
            Personal Information
          </Text>
          <Text fontSize="paragraph-sm" color="text.sub">
            Basic details about yourself
          </Text>
        </Box>

        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
          <FormControl isRequired>
            <FormLabel fontSize="label-sm" color="text.sub">
              First Name
            </FormLabel>
            <Input
              name="first_name"
              value={formData.first_name}
              onChange={handleChange}
              placeholder="John"
              bg="bg.white"
              borderColor="stroke.soft"
              _hover={{ borderColor: "primary.lighter" }}
              _focus={{
                borderColor: "primary.base",
                boxShadow: "button-primary-focus",
              }}
            />
          </FormControl>

          <FormControl isRequired>
            <FormLabel fontSize="label-sm" color="text.sub">
              Last Name
            </FormLabel>
            <Input
              name="last_name"
              value={formData.last_name}
              onChange={handleChange}
              placeholder="Doe"
              bg="bg.white"
              borderColor="stroke.soft"
              _hover={{ borderColor: "primary.lighter" }}
              _focus={{
                borderColor: "primary.base",
                boxShadow: "button-primary-focus",
              }}
            />
          </FormControl>
        </SimpleGrid>

        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
          <FormControl>
            <FormLabel fontSize="label-sm" color="text.sub">
              Phone Number
            </FormLabel>
            <Input
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="+1 (555) 000-0000"
              bg="bg.white"
              borderColor="stroke.soft"
            />
          </FormControl>

          <FormControl>
            <FormLabel fontSize="label-sm" color="text.sub">
              Date of Birth
            </FormLabel>
            <Input
              name="date_of_birth"
              type="date"
              value={formData.date_of_birth}
              onChange={handleChange}
              bg="bg.white"
              borderColor="stroke.soft"
            />
          </FormControl>
        </SimpleGrid>

        <FormControl>
          <FormLabel fontSize="label-sm" color="text.sub">
            Location
          </FormLabel>
          <Input
            name="location"
            value={formData.location}
            onChange={handleChange}
            placeholder="San Francisco, CA"
            bg="bg.white"
            borderColor="stroke.soft"
          />
        </FormControl>

        <Box pt={4}>
          <Text fontSize="label-md" fontWeight={600} mb={1}>
            Professional Links
          </Text>
          <Text fontSize="paragraph-sm" color="text.sub">
            Showcase your work and connect
          </Text>
        </Box>

        <FormControl>
          <FormLabel fontSize="label-sm" color="text.sub">
            LinkedIn Profile
          </FormLabel>
          <Input
            name="linkedin_url"
            value={formData.linkedin_url}
            onChange={handleChange}
            placeholder="https://linkedin.com/in/johndoe"
            bg="bg.white"
            borderColor="stroke.soft"
          />
        </FormControl>

        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
          <FormControl>
            <FormLabel fontSize="label-sm" color="text.sub">
              GitHub Profile
            </FormLabel>
            <Input
              name="github_url"
              value={formData.github_url}
              onChange={handleChange}
              placeholder="https://github.com/johndoe"
              bg="bg.white"
              borderColor="stroke.soft"
            />
          </FormControl>

          <FormControl>
            <FormLabel fontSize="label-sm" color="text.sub">
              Portfolio Website
            </FormLabel>
            <Input
              name="portfolio_url"
              value={formData.portfolio_url}
              onChange={handleChange}
              placeholder="https://johndoe.com"
              bg="bg.white"
              borderColor="stroke.soft"
            />
          </FormControl>
        </SimpleGrid>

        <FormControl>
          <FormLabel fontSize="label-sm" color="text.sub">
            About Me
          </FormLabel>
          <Textarea
            name="bio"
            value={formData.bio}
            onChange={handleChange}
            rows={4}
            placeholder="Tell us about yourself, your interests, and career goals..."
            bg="bg.white"
            borderColor="stroke.soft"
            _hover={{ borderColor: "primary.lighter" }}
            _focus={{
              borderColor: "primary.base",
              boxShadow: "button-primary-focus",
            }}
          />
        </FormControl>

        <Box pt={4}>
          <Text fontSize="label-md" fontWeight={600} mb={1}>
            Career Preferences
          </Text>
          <Text fontSize="paragraph-sm" color="text.sub">
            Help us match you with the right opportunities
          </Text>
        </Box>

        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
          <FormControl>
            <FormLabel fontSize="label-sm" color="text.sub">
              Expected Salary (Annual)
            </FormLabel>
            <Input
              name="expected_salary"
              type="number"
              value={formData.expected_salary}
              onChange={handleChange}
              placeholder="75000"
              bg="bg.white"
              borderColor="stroke.soft"
            />
          </FormControl>

          <FormControl>
            <FormLabel fontSize="label-sm" color="text.sub">
              Availability
            </FormLabel>
            <Select
              name="availability"
              value={formData.availability}
              onChange={handleChange}
              bg="bg.white"
              borderColor="stroke.soft"
            >
              <option value="immediate">Immediate</option>
              <option value="2-weeks">2 Weeks Notice</option>
              <option value="1-month">1 Month</option>
              <option value="2-months">2 Months</option>
            </Select>
          </FormControl>
        </SimpleGrid>

        <Button
          type="submit"
          bg="primary.base"
          color="white"
          size="lg"
          h={12}
          fontSize="label-md"
          isLoading={loading}
          loadingText="Saving..."
          leftIcon={<Icon as={RiCheckLine} />}
          _hover={{
            bg: "primary.darker",
            transform: "translateY(-2px)",
            shadow: "md",
          }}
        >
          Save Profile
        </Button>
      </VStack>
    </form>
  );
};

export default ProfileForm;
