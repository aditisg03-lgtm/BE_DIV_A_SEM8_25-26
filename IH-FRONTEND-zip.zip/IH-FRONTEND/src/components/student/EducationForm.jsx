import {
  VStack,
  FormControl,
  FormLabel,
  Input,
  Button,
  SimpleGrid,
  useToast,
  Box,
  HStack,
  Text,
  Icon,
  Checkbox,
  Textarea,
  IconButton,
  Divider,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import {
  RiDeleteBinLine,
  RiAddLine,
  RiGraduationCapLine,
} from "react-icons/ri";
import { studentAPI } from "../../api/student";

const EducationCard = ({ education, onDelete }) => {
  return (
    <Box
      bg="bg.white"
      p={5}
      borderRadius="xl"
      border="1px"
      borderColor="stroke.soft"
      transition="all 0.2s"
      _hover={{ shadow: "md", borderColor: "primary.lighter" }}
    >
      <HStack justify="space-between" align="start">
        <HStack spacing={3} align="start">
          <Box p={2} borderRadius="lg" bg="feature.light">
            <Icon as={RiGraduationCapLine} boxSize={5} color="feature.base" />
          </Box>
          <VStack align="start" spacing={1}>
            <Text fontSize="label-md" fontWeight={600}>
              {education.degree} in {education.field_of_study}
            </Text>
            <Text fontSize="paragraph-sm" color="text.sub">
              {education.institution}
            </Text>
            <HStack fontSize="paragraph-xs" color="text.soft">
              <Text>
                {new Date(education.start_date).getFullYear()} -{" "}
                {education.is_current
                  ? "Present"
                  : new Date(education.end_date).getFullYear()}
              </Text>
              {education.grade && (
                <>
                  <Text>•</Text>
                  <Text>GPA: {education.grade}</Text>
                </>
              )}
            </HStack>
          </VStack>
        </HStack>
        <IconButton
          icon={<Icon as={RiDeleteBinLine} />}
          variant="ghost"
          colorScheme="red"
          size="sm"
          onClick={onDelete}
          aria-label="Delete"
        />
      </HStack>
    </Box>
  );
};

const EducationForm = () => {
  const [education, setEducation] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    institution: "",
    degree: "",
    field_of_study: "",
    start_date: "",
    end_date: "",
    grade: "",
    description: "",
    is_current: false,
  });
  const toast = useToast();

  useEffect(() => {
    fetchEducation();
  }, []);

  const fetchEducation = async () => {
    try {
      const data = await studentAPI.getEducation();
      setEducation(data);
    } catch (error) {
      console.error("Failed to fetch education:", error);
    }
  };

  const handleChange = (e) => {
    const value =
      e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setFormData({
      ...formData,
      [e.target.name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await studentAPI.createEducation(formData);
      toast({
        title: "Education added successfully",
        status: "success",
        duration: 2000,
      });
      setFormData({
        institution: "",
        degree: "",
        field_of_study: "",
        start_date: "",
        end_date: "",
        grade: "",
        description: "",
        is_current: false,
      });
      setShowForm(false);
      fetchEducation();
    } catch (error) {
      toast({
        title: "Failed to add education",
        description: error.response?.data?.detail || "Please try again",
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await studentAPI.deleteEducation(id);
      toast({
        title: "Education deleted",
        status: "success",
        duration: 2000,
      });
      fetchEducation();
    } catch (error) {
      toast({
        title: "Delete failed",
        status: "error",
        duration: 2000,
      });
    }
  };

  return (
    <VStack spacing={5} align="stretch">
      {/* Existing Education */}
      {education.length > 0 && (
        <VStack spacing={3} align="stretch">
          <Text fontSize="label-sm" color="text.sub" fontWeight={500}>
            Your Education ({education.length})
          </Text>
          {education.map((edu) => (
            <EducationCard
              key={edu.id}
              education={edu}
              onDelete={() => handleDelete(edu.id)}
            />
          ))}
        </VStack>
      )}

      {education.length > 0 && <Divider />}

      {/* Add Button or Form */}
      {!showForm ? (
        <Button
          leftIcon={<Icon as={RiAddLine} />}
          onClick={() => setShowForm(true)}
          variant="outline"
          borderStyle="dashed"
          borderWidth={2}
          h={12}
          borderColor="stroke.soft"
          color="text.sub"
          _hover={{
            borderColor: "primary.base",
            color: "primary.base",
            bg: "primary.alpha.10",
          }}
        >
          Add Education
        </Button>
      ) : (
        <Box
          p={6}
          borderRadius="xl"
          border="1px"
          borderColor="stroke.soft"
          bg="bg.white"
        >
          <VStack spacing={4} align="stretch">
            <HStack justify="space-between">
              <Text fontSize="label-md" fontWeight={600}>
                Add New Education
              </Text>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setShowForm(false)}
              >
                Cancel
              </Button>
            </HStack>

            <form onSubmit={handleSubmit}>
              <VStack spacing={4}>
                <FormControl isRequired>
                  <FormLabel fontSize="label-sm">Institution</FormLabel>
                  <Input
                    name="institution"
                    value={formData.institution}
                    onChange={handleChange}
                    placeholder="Harvard University"
                    bg="bg.weak"
                  />
                </FormControl>

                <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4} w="100%">
                  <FormControl isRequired>
                    <FormLabel fontSize="label-sm">Degree</FormLabel>
                    <Input
                      name="degree"
                      value={formData.degree}
                      onChange={handleChange}
                      placeholder="Bachelor's, Master's"
                      bg="bg.weak"
                    />
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel fontSize="label-sm">Field of Study</FormLabel>
                    <Input
                      name="field_of_study"
                      value={formData.field_of_study}
                      onChange={handleChange}
                      placeholder="Computer Science"
                      bg="bg.weak"
                    />
                  </FormControl>
                </SimpleGrid>

                <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4} w="100%">
                  <FormControl isRequired>
                    <FormLabel fontSize="label-sm">Start Date</FormLabel>
                    <Input
                      name="start_date"
                      type="date"
                      value={formData.start_date}
                      onChange={handleChange}
                      bg="bg.weak"
                    />
                  </FormControl>

                  <FormControl isRequired={!formData.is_current}>
                    <FormLabel fontSize="label-sm">End Date</FormLabel>
                    <Input
                      name="end_date"
                      type="date"
                      value={formData.end_date}
                      onChange={handleChange}
                      isDisabled={formData.is_current}
                      bg="bg.weak"
                    />
                  </FormControl>
                </SimpleGrid>

                <FormControl>
                  <Checkbox
                    name="is_current"
                    isChecked={formData.is_current}
                    onChange={handleChange}
                    colorScheme="primary"
                  >
                    <Text fontSize="label-sm">Currently studying here</Text>
                  </Checkbox>
                </FormControl>

                <FormControl>
                  <FormLabel fontSize="label-sm">Grade/GPA</FormLabel>
                  <Input
                    name="grade"
                    value={formData.grade}
                    onChange={handleChange}
                    placeholder="3.8/4.0"
                    bg="bg.weak"
                  />
                </FormControl>

                <FormControl>
                  <FormLabel fontSize="label-sm">Description</FormLabel>
                  <Textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Activities, achievements, coursework..."
                    rows={3}
                    bg="bg.weak"
                  />
                </FormControl>

                <Button
                  type="submit"
                  bg="primary.base"
                  color="white"
                  w="100%"
                  isLoading={loading}
                  leftIcon={<Icon as={RiAddLine} />}
                >
                  Add Education
                </Button>
              </VStack>
            </form>
          </VStack>
        </Box>
      )}
    </VStack>
  );
};

export default EducationForm;
