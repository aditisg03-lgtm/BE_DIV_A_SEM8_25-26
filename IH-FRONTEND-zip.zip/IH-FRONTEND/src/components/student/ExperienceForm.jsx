import {
  VStack,
  FormControl,
  FormLabel,
  Input,
  Button,
  SimpleGrid,
  useToast,
  Box,
  HStack,
  Text,
  Icon,
  Checkbox,
  Textarea,
  IconButton,
  Divider,
  Wrap,
  Tag,
  TagLabel,
  TagCloseButton,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { RiDeleteBinLine, RiAddLine, RiBriefcaseLine } from "react-icons/ri";
import { studentAPI } from "../../api/student";

const ExperienceCard = ({ experience, onDelete }) => {
  return (
    <Box
      bg="bg.white"
      p={5}
      borderRadius="xl"
      border="1px"
      borderColor="stroke.soft"
      transition="all 0.2s"
      _hover={{ shadow: "md", borderColor: "primary.lighter" }}
    >
      <HStack justify="space-between" align="start">
        <HStack spacing={3} align="start">
          <Box p={2} borderRadius="lg" bg="success.lighter">
            <Icon as={RiBriefcaseLine} boxSize={5} color="success.base" />
          </Box>
          <VStack align="start" spacing={1}>
            <Text fontSize="label-md" fontWeight={600}>
              {experience.position}
            </Text>
            <Text fontSize="paragraph-sm" color="text.sub">
              {experience.company}
            </Text>
            <HStack fontSize="paragraph-xs" color="text.soft">
              <Text>
                {new Date(experience.start_date).getFullYear()} -{" "}
                {experience.is_current
                  ? "Present"
                  : new Date(experience.end_date).getFullYear()}
              </Text>
              {experience.location && (
                <>
                  <Text>•</Text>
                  <Text>{experience.location}</Text>
                </>
              )}
            </HStack>
            {experience.description && (
              <Text fontSize="paragraph-sm" color="text.sub" mt={2}>
                {experience.description}
              </Text>
            )}
            {experience.technologies_used?.length > 0 && (
              <Wrap mt={2}>
                {experience.technologies_used.map((tech, idx) => (
                  <Tag key={idx} size="sm" colorScheme="purple">
                    {tech}
                  </Tag>
                ))}
              </Wrap>
            )}
          </VStack>
        </HStack>
        <IconButton
          icon={<Icon as={RiDeleteBinLine} />}
          variant="ghost"
          colorScheme="red"
          size="sm"
          onClick={onDelete}
          aria-label="Delete"
        />
      </HStack>
    </Box>
  );
};

const ExperienceForm = () => {
  const [experiences, setExperiences] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    company: "",
    position: "",
    location: "",
    start_date: "",
    end_date: "",
    is_current: false,
    description: "",
    technologies_used: [],
  });
  const [techInput, setTechInput] = useState("");
  const toast = useToast();

  useEffect(() => {
    fetchExperience();
  }, []);

  const fetchExperience = async () => {
    try {
      const data = await studentAPI.getExperience();
      setExperiences(data);
    } catch (error) {
      console.error("Failed to fetch experience:", error);
    }
  };

  const handleChange = (e) => {
    const value =
      e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setFormData({
      ...formData,
      [e.target.name]: value,
    });
  };

  const handleAddTech = () => {
    if (techInput.trim()) {
      setFormData({
        ...formData,
        technologies_used: [...formData.technologies_used, techInput.trim()],
      });
      setTechInput("");
    }
  };

  const handleRemoveTech = (index) => {
    setFormData({
      ...formData,
      technologies_used: formData.technologies_used.filter(
        (_, i) => i !== index
      ),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await studentAPI.createExperience(formData);
      toast({
        title: "Experience added successfully",
        status: "success",
        duration: 2000,
      });
      setFormData({
        company: "",
        position: "",
        location: "",
        start_date: "",
        end_date: "",
        is_current: false,
        description: "",
        technologies_used: [],
      });
      setShowForm(false);
      fetchExperience();
    } catch (error) {
      toast({
        title: "Failed to add experience",
        description: error.response?.data?.detail || "Please try again",
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await studentAPI.deleteExperience(id);
      toast({
        title: "Experience deleted",
        status: "success",
        duration: 2000,
      });
      fetchExperience();
    } catch (error) {
      toast({
        title: "Delete failed",
        status: "error",
        duration: 2000,
      });
    }
  };

  return (
    <VStack spacing={5} align="stretch">
      {experiences.length > 0 && (
        <VStack spacing={3} align="stretch">
          <Text fontSize="label-sm" color="text.sub" fontWeight={500}>
            Your Experience ({experiences.length})
          </Text>
          {experiences.map((exp) => (
            <ExperienceCard
              key={exp.id}
              experience={exp}
              onDelete={() => handleDelete(exp.id)}
            />
          ))}
        </VStack>
      )}

      {experiences.length > 0 && <Divider />}

      {!showForm ? (
        <Button
          leftIcon={<Icon as={RiAddLine} />}
          onClick={() => setShowForm(true)}
          variant="outline"
          borderStyle="dashed"
          borderWidth={2}
          h={12}
          borderColor="stroke.soft"
          color="text.sub"
          _hover={{
            borderColor: "primary.base",
            color: "primary.base",
            bg: "primary.alpha.10",
          }}
        >
          Add Work Experience
        </Button>
      ) : (
        <Box
          p={6}
          borderRadius="xl"
          border="1px"
          borderColor="stroke.soft"
          bg="bg.white"
        >
          <VStack spacing={4} align="stretch">
            <HStack justify="space-between">
              <Text fontSize="label-md" fontWeight={600}>
                Add New Experience
              </Text>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setShowForm(false)}
              >
                Cancel
              </Button>
            </HStack>

            <form onSubmit={handleSubmit}>
              <VStack spacing={4}>
                <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4} w="100%">
                  <FormControl isRequired>
                    <FormLabel fontSize="label-sm">Company</FormLabel>
                    <Input
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      placeholder="Google"
                      bg="bg.weak"
                    />
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel fontSize="label-sm">Position</FormLabel>
                    <Input
                      name="position"
                      value={formData.position}
                      onChange={handleChange}
                      placeholder="Software Engineer"
                      bg="bg.weak"
                    />
                  </FormControl>
                </SimpleGrid>

                <FormControl>
                  <FormLabel fontSize="label-sm">Location</FormLabel>
                  <Input
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    placeholder="Mountain View, CA"
                    bg="bg.weak"
                  />
                </FormControl>

                <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4} w="100%">
                  <FormControl isRequired>
                    <FormLabel fontSize="label-sm">Start Date</FormLabel>
                    <Input
                      name="start_date"
                      type="date"
                      value={formData.start_date}
                      onChange={handleChange}
                      bg="bg.weak"
                    />
                  </FormControl>

                  <FormControl isRequired={!formData.is_current}>
                    <FormLabel fontSize="label-sm">End Date</FormLabel>
                    <Input
                      name="end_date"
                      type="date"
                      value={formData.end_date}
                      onChange={handleChange}
                      isDisabled={formData.is_current}
                      bg="bg.weak"
                    />
                  </FormControl>
                </SimpleGrid>

                <FormControl>
                  <Checkbox
                    name="is_current"
                    isChecked={formData.is_current}
                    onChange={handleChange}
                    colorScheme="primary"
                  >
                    <Text fontSize="label-sm">Currently working here</Text>
                  </Checkbox>
                </FormControl>

                <FormControl isRequired>
                  <FormLabel fontSize="label-sm">Description</FormLabel>
                  <Textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Describe your responsibilities and achievements..."
                    rows={4}
                    bg="bg.weak"
                  />
                </FormControl>

                <FormControl>
                  <FormLabel fontSize="label-sm">Technologies Used</FormLabel>
                  <HStack>
                    <Input
                      value={techInput}
                      onChange={(e) => setTechInput(e.target.value)}
                      placeholder="Add technology"
                      bg="bg.weak"
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          handleAddTech();
                        }
                      }}
                    />
                    <Button onClick={handleAddTech} type="button">
                      Add
                    </Button>
                  </HStack>
                  <Wrap mt={2}>
                    {formData.technologies_used.map((tech, index) => (
                      <Tag
                        key={index}
                        size="md"
                        borderRadius="full"
                        variant="solid"
                        colorScheme="purple"
                      >
                        <TagLabel>{tech}</TagLabel>
                        <TagCloseButton
                          onClick={() => handleRemoveTech(index)}
                        />
                      </Tag>
                    ))}
                  </Wrap>
                </FormControl>

                <Button
                  type="submit"
                  bg="primary.base"
                  color="white"
                  w="100%"
                  isLoading={loading}
                  leftIcon={<Icon as={RiAddLine} />}
                >
                  Add Experience
                </Button>
              </VStack>
            </form>
          </VStack>
        </Box>
      )}
    </VStack>
  );
};

export default ExperienceForm;
