import {
  Box,
  VStack,
  HStack,
  Text,
  Badge,
  Button,
  Icon,
  IconButton,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Divider,
  Wrap,
  Tag,
} from "@chakra-ui/react";
import {
  RiMapPinLine,
  RiBriefcaseLine,
  RiMoneyDollarCircleLine,
  RiCalendarLine,
  RiMoreFill,
  RiBookmarkLine,
  RiBookmarkFill,
  RiEyeOffLine,
  // RiTargetLine,
  RiExternalLinkLine,
} from "react-icons/ri";
import { useNavigate } from "react-router-dom";
import { formatDate, formatSalary, getStatusLabel } from "../../utils/helpers";
import { FaLine } from "react-icons/fa";

const JobCard = ({
  job,
  onApply,
  onSave,
  onHide,
  onAnalyze,
  isSaved = false,
}) => {
  const navigate = useNavigate();

  return (
    <Box
      bg="bg.white"
      p={6}
      borderRadius="xl"
      border="1px"
      borderColor="stroke.soft"
      shadow="regular-xs"
      transition="all 0.2s"
      _hover={{
        shadow: "md",
        transform: "translateY(-2px)",
        borderColor: "primary.lighter",
      }}
    >
      <VStack align="stretch" spacing={4}>
        {/* Header */}
        <HStack justify="space-between" align="start">
          <VStack align="start" spacing={1} flex={1}>
            <Text
              fontSize="label-lg"
              fontWeight={600}
              color="text.strong"
              noOfLines={2}
            >
              {job.title}
            </Text>
            <HStack spacing={2} fontSize="paragraph-sm" color="text.sub">
              <Icon as={RiMapPinLine} boxSize={4} />
              <Text>{job.location}</Text>
              <Text>•</Text>
              <Text>{getStatusLabel(job.employment_type)}</Text>
            </HStack>
          </VStack>

          <Menu>
            <MenuButton
              as={IconButton}
              icon={<Icon as={RiMoreFill} />}
              variant="ghost"
              size="sm"
              color="text.sub"
            />
            <MenuList borderRadius="xl" shadow="md">
              <MenuItem
                icon={<Icon as={FaLine} />}
                onClick={() => onAnalyze?.(job)}
                fontSize="label-sm"
              >
                Analyze Match
              </MenuItem>
              <MenuItem
                icon={<Icon as={isSaved ? RiBookmarkFill : RiBookmarkLine} />}
                onClick={() => onSave?.(job.id)}
                fontSize="label-sm"
              >
                {isSaved ? "Unsave Job" : "Save Job"}
              </MenuItem>
              <MenuItem
                icon={<Icon as={RiEyeOffLine} />}
                onClick={() => onHide?.(job.id)}
                fontSize="label-sm"
                color="error.base"
              >
                Hide Job
              </MenuItem>
            </MenuList>
          </Menu>
        </HStack>

        {/* Description */}
        <Text fontSize="paragraph-sm" color="text.sub" noOfLines={3}>
          {job.description}
        </Text>

        {/* Skills */}
        {job.required_skills && job.required_skills.length > 0 && (
          <Wrap spacing={2}>
            {job.required_skills.slice(0, 5).map((skill, index) => (
              <Tag
                key={index}
                size="sm"
                borderRadius="full"
                bg="feature.light"
                color="feature.dark"
                fontSize="label-xs"
              >
                {skill.name || skill}
              </Tag>
            ))}
            {job.required_skills.length > 5 && (
              <Text fontSize="paragraph-xs" color="text.soft">
                +{job.required_skills.length - 5} more
              </Text>
            )}
          </Wrap>
        )}

        <Divider />

        {/* Footer */}
        <HStack justify="space-between" fontSize="paragraph-sm">
          <HStack spacing={2} color="text.sub">
            <Icon as={RiMoneyDollarCircleLine} />
            <Text>{formatSalary(job.salary_min, job.salary_max)}</Text>
          </HStack>
          {job.posted_date && (
            <HStack spacing={2} color="text.soft" fontSize="paragraph-xs">
              <Icon as={RiCalendarLine} />
              <Text>{formatDate(job.posted_date)}</Text>
            </HStack>
          )}
        </HStack>

        {/* Actions */}
        <HStack spacing={2}>
          <Button
            flex={1}
            variant="outline"
            size="sm"
            onClick={() => navigate(`/student/jobs/${job.id}`)}
            leftIcon={<Icon as={RiExternalLinkLine} />}
            borderColor="stroke.soft"
            color="text.sub"
            _hover={{
              borderColor: "primary.base",
              color: "primary.base",
              bg: "primary.alpha.10",
            }}
          >
            View Details
          </Button>
          <Button
            flex={1}
            bg="primary.base"
            color="white"
            size="sm"
            onClick={() => onApply?.(job)}
            leftIcon={<Icon as={RiBriefcaseLine} />}
            _hover={{ bg: "primary.darker" }}
          >
            Apply Now
          </Button>
        </HStack>
      </VStack>
    </Box>
  );
};

export default JobCard;
