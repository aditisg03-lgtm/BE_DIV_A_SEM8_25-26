import { Center, VStack, Spinner, Text } from "@chakra-ui/react";

const Loading = ({ message = "Loading..." }) => {
  return (
    <Center minH="60vh">
      <VStack spacing={4}>
        <Spinner
          thickness="4px"
          speed="0.65s"
          emptyColor="bg.soft"
          color="primary.base"
          size="xl"
        />
        <Text fontSize="label-sm" color="text.sub">
          {message}
        </Text>
      </VStack>
    </Center>
  );
};

export default Loading;
