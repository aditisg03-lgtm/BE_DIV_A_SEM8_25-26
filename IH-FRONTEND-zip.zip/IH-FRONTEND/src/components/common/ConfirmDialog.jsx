import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  Text,
  Icon,
  VStack,
} from "@chakra-ui/react";
import { RiAlertLine } from "react-icons/ri";

const ConfirmDialog = ({
  isOpen,
  onClose,
  onConfirm,
  title = "Confirm Action",
  message = "Are you sure you want to proceed?",
  confirmText = "Confirm",
  cancelText = "Cancel",
  colorScheme = "red",
}) => {
  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered>
      <ModalOverlay bg="blackAlpha.600" backdropFilter="blur(4px)" />
      <ModalContent borderRadius="2xl">
        <ModalHeader borderBottomWidth="1px" borderColor="stroke.soft">
          <VStack spacing={3} align="start">
            <Icon as={RiAlertLine} boxSize={6} color={`${colorScheme}.500`} />
            <Text fontSize="label-lg" fontWeight={600}>
              {title}
            </Text>
          </VStack>
        </ModalHeader>
        <ModalCloseButton />

        <ModalBody py={6}>
          <Text fontSize="paragraph-sm" color="text.sub">
            {message}
          </Text>
        </ModalBody>

        <ModalFooter borderTopWidth="1px" borderColor="stroke.soft" gap={3}>
          <Button
            variant="outline"
            onClick={onClose}
            borderColor="stroke.soft"
            color="text.sub"
            _hover={{ bg: "bg.weak" }}
          >
            {cancelText}
          </Button>
          <Button
            colorScheme={colorScheme}
            onClick={() => {
              onConfirm();
              onClose();
            }}
          >
            {confirmText}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default ConfirmDialog;
