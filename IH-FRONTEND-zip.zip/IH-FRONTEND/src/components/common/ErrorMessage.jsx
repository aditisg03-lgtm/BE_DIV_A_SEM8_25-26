import {
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  Box,
} from "@chakra-ui/react";

const ErrorMessage = ({ title = "Error", message, onRetry }) => {
  return (
    <Alert
      status="error"
      variant="subtle"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      textAlign="center"
      minH="200px"
      borderRadius="2xl"
      bg="error.lighter"
      border="1px"
      borderColor="error.base"
    >
      <AlertIcon boxSize="40px" mr={0} color="error.base" />
      <AlertTitle
        mt={4}
        mb={1}
        fontSize="label-lg"
        fontWeight={600}
        color="text.strong"
      >
        {title}
      </AlertTitle>
      <AlertDescription maxWidth="sm" color="text.sub" fontSize="paragraph-sm">
        {message || "Something went wrong. Please try again."}
      </AlertDescription>
      {onRetry && (
        <Box mt={4}>
          <Button onClick={onRetry} colorScheme="red" size="sm">
            Try Again
          </Button>
        </Box>
      )}
    </Alert>
  );
};

export default ErrorMessage;
