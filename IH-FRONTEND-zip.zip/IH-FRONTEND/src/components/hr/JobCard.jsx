import {
  Box,
  Badge,
  Text,
  HStack,
  VStack,
  Button,
  Icon,
  Wrap,
  WrapItem,
  Flex,
} from "@chakra-ui/react";
import {
  FiMapPin,
  FiBriefcase,
  FiClock,
  FiDollarSign,
  FiEye,
  FiSend,
} from "react-icons/fi";
import { formatDate, formatSalary, getStatusLabel } from "../../utils/helpers";
import { STATUS_COLORS } from "../../utils/constants";
import { useNavigate } from "react-router-dom";

const JobCard = ({ job, onApply, showStatus = false, isHR = false }) => {
  const navigate = useNavigate();

  const handleViewDetails = () => {
    if (isHR) {
      navigate(`/hr/jobs/${job.id}`);
    } else {
      navigate(`/student/jobs/${job.id}`);
    }
  };

  return (
    <Box
      bg="rgba(255, 255, 255, 0.7)"
      backdropFilter="blur(20px)"
      p={5}
      borderRadius="14px"
      border="1px solid rgba(255, 255, 255, 0.8)"
      shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
      transition="all 0.3s"
      _hover={{
        transform: "translateY(-4px)",
        shadow: "0 8px 24px rgba(0, 0, 0, 0.08)",
      }}
    >
      <VStack align="stretch" spacing={4}>
        {/* Header */}
        <Flex justify="space-between" align="start">
          <VStack align="start" spacing={1} flex={1}>
            <Text
              fontSize="label-md"
              fontWeight={600}
              fontFamily="'Inter', sans-serif"
              noOfLines={1}
            >
              {job.title}
            </Text>
            {job.department && (
              <Text
                fontSize="paragraph-xs"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                {job.department}
              </Text>
            )}
          </VStack>
          {showStatus && (
            <Badge
              colorScheme={STATUS_COLORS[job.status]}
              fontSize="subheading-xs"
              px={2}
              py={1}
              borderRadius="full"
            >
              {getStatusLabel(job.status)}
            </Badge>
          )}
        </Flex>

        {/* Job Details */}
        <Wrap spacing={3} fontSize="paragraph-xs" color="text.sub">
          <WrapItem>
            <HStack spacing={1.5}>
              <Icon as={FiMapPin} boxSize={3.5} />
              <Text fontFamily="'Inter', sans-serif">{job.location}</Text>
            </HStack>
          </WrapItem>
          <WrapItem>
            <HStack spacing={1.5}>
              <Icon as={FiBriefcase} boxSize={3.5} />
              <Text fontFamily="'Inter', sans-serif">
                {getStatusLabel(job.employment_type)}
              </Text>
            </HStack>
          </WrapItem>
          <WrapItem>
            <HStack spacing={1.5}>
              <Icon as={FiDollarSign} boxSize={3.5} />
              <Text fontFamily="'Inter', sans-serif">
                {formatSalary(job.salary_min, job.salary_max)}
              </Text>
            </HStack>
          </WrapItem>
          {job.posted_date && (
            <WrapItem>
              <HStack spacing={1.5}>
                <Icon as={FiClock} boxSize={3.5} />
                <Text fontFamily="'Inter', sans-serif">
                  {formatDate(job.posted_date)}
                </Text>
              </HStack>
            </WrapItem>
          )}
        </Wrap>

        {/* Description */}
        <Text
          fontSize="paragraph-sm"
          color="text.sub"
          noOfLines={2}
          fontFamily="'Inter', sans-serif"
        >
          {job.description}
        </Text>

        {/* Skills */}
        {job.required_skills && job.required_skills.length > 0 && (
          <Wrap spacing={2}>
            {job.required_skills.slice(0, 5).map((skill, index) => (
              <WrapItem key={index}>
                <Badge
                  colorScheme="purple"
                  fontSize="subheading-xs"
                  px={2}
                  py={1}
                  borderRadius="full"
                >
                  {skill.name || skill}
                </Badge>
              </WrapItem>
            ))}
            {job.required_skills.length > 5 && (
              <WrapItem>
                <Badge
                  fontSize="subheading-xs"
                  variant="subtle"
                  px={2}
                  py={1}
                  borderRadius="full"
                >
                  +{job.required_skills.length - 5} more
                </Badge>
              </WrapItem>
            )}
          </Wrap>
        )}

        {/* Applications Count (HR only) */}
        {isHR && job.applications_count !== undefined && (
          <HStack
            p={2}
            bg="rgba(125, 82, 244, 0.05)"
            borderRadius="8px"
            justify="center"
          >
            <Text
              fontSize="paragraph-xs"
              color="primary.base"
              fontWeight={500}
              fontFamily="'Inter', sans-serif"
            >
              {job.applications_count} application
              {job.applications_count !== 1 ? "s" : ""}
            </Text>
          </HStack>
        )}

        {/* Actions */}
        <HStack spacing={2}>
          <Button
            size="sm"
            h={9}
            flex={1}
            variant="outline"
            leftIcon={<Icon as={FiEye} boxSize={3.5} />}
            onClick={handleViewDetails}
            borderRadius="10px"
            fontSize="label-xs"
            fontFamily="'Inter', sans-serif"
            borderColor="rgba(229, 231, 235, 0.8)"
            _hover={{
              bg: "rgba(125, 82, 244, 0.05)",
              borderColor: "primary.base",
            }}
          >
            View Details
          </Button>
          {onApply && (
            <Button
              size="sm"
              h={9}
              flex={1}
              bgGradient="linear(135deg, primary.base, feature.base)"
              color="white"
              leftIcon={<Icon as={FiSend} boxSize={3.5} />}
              onClick={() => onApply(job)}
              borderRadius="10px"
              fontSize="label-xs"
              fontFamily="'Inter', sans-serif"
              _hover={{
                transform: "translateY(-1px)",
                shadow: "0 6px 16px -4px rgba(125, 82, 244, 0.4)",
              }}
            >
              Apply Now
            </Button>
          )}
        </HStack>
      </VStack>
    </Box>
  );
};

export default JobCard;
