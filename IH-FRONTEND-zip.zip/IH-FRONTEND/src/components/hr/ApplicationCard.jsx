import {
  Box,
  VStack,
  HStack,
  Text,
  Badge,
  Button,
  Avatar,
  Select,
  useToast,
  Icon,
  Progress,
  Flex,
} from "@chakra-ui/react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FiDownload, FiEye, FiCalendar, FiAward } from "react-icons/fi";
import { formatDate, getStatusLabel } from "../../utils/helpers";
import { STATUS_COLORS, APPLICATION_STATUS } from "../../utils/constants";
import { applicationAPI } from "../../api/application";

const ApplicationCard = ({ application, onUpdate }) => {
  const toast = useToast();
  const navigate = useNavigate();
  const [downloading, setDownloading] = useState(false);
  const [updating, setUpdating] = useState(false);

  const handleStatusChange = async (newStatus) => {
    setUpdating(true);
    try {
      await applicationAPI.updateStatus(application.id, { status: newStatus });
      toast({
        title: "Status updated",
        status: "success",
        duration: 2000,
      });
      if (onUpdate) onUpdate();
    } catch (error) {
      toast({
        title: "Update failed",
        description: error.response?.data?.detail || "Failed to update status",
        status: "error",
        duration: 3000,
      });
    } finally {
      setUpdating(false);
    }
  };

  const handleViewResume = async () => {
    if (!application.resume_id) {
      toast({
        title: "No resume",
        description: "This application has no resume attached",
        status: "warning",
        duration: 2000,
      });
      return;
    }

    setDownloading(true);
    try {
      const token = localStorage.getItem("access_token");
      const baseURL = import.meta.env.VITE_API_URL || "http://localhost:8000";
      const downloadUrl = `${baseURL}/api/resumes/${application.resume_id}/download`;

      const response = await fetch(downloadUrl, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok)
        throw new Error(`Download failed: ${response.statusText}`);

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `resume_${application.id}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Resume downloaded",
        status: "success",
        duration: 2000,
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: error.message || "Failed to download resume",
        status: "error",
        duration: 3000,
      });
    } finally {
      setDownloading(false);
    }
  };

  const handleViewDetails = () => {
    navigate(`/hr/applications/${application.id}`);
  };

  const getATSScoreColor = (score) => {
    if (score >= 80) return "green";
    if (score >= 60) return "yellow";
    return "red";
  };

  return (
    <Box
      bg="rgba(255, 255, 255, 0.7)"
      backdropFilter="blur(20px)"
      p={5}
      borderRadius="14px"
      border="1px solid rgba(255, 255, 255, 0.8)"
      shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
      transition="all 0.3s"
      _hover={{
        transform: "translateY(-4px)",
        shadow: "0 8px 24px rgba(0, 0, 0, 0.08)",
      }}
    >
      <VStack align="stretch" spacing={4}>
        {/* Header */}
        <Flex justify="space-between" align="start">
          <HStack spacing={3}>
            <Avatar
              name={application.student_profile_id}
              size="sm"
              bg="linear-gradient(135deg, #7d52f4, #8B5CF6)"
              color="white"
              fontFamily="'Inter', sans-serif"
            />
            <VStack align="start" spacing={0}>
              <Text
                fontSize="label-sm"
                fontWeight={600}
                fontFamily="'Inter', sans-serif"
              >
                Candidate #{application.student_profile_id.slice(0, 8)}
              </Text>
              <HStack spacing={1.5} fontSize="paragraph-xs" color="text.sub">
                <Icon as={FiCalendar} boxSize={3} />
                <Text fontFamily="'Inter', sans-serif">
                  {formatDate(application.applied_date)}
                </Text>
              </HStack>
            </VStack>
          </HStack>
          <Badge
            colorScheme={STATUS_COLORS[application.status]}
            fontSize="subheading-xs"
            px={2}
            py={1}
            borderRadius="full"
          >
            {getStatusLabel(application.status)}
          </Badge>
        </Flex>

        {/* Scores */}
        {(application.ats_score || application.ranking_score) && (
          <VStack align="stretch" spacing={2}>
            {application.ats_score && (
              <Box>
                <Flex justify="space-between" align="center" mb={1}>
                  <HStack spacing={1.5}>
                    <Icon as={FiAward} boxSize={3.5} color="text.sub" />
                    <Text
                      fontSize="label-xs"
                      color="text.sub"
                      fontFamily="'Inter', sans-serif"
                    >
                      ATS Score
                    </Text>
                  </HStack>
                  <Badge
                    colorScheme={getATSScoreColor(application.ats_score)}
                    fontSize="label-xs"
                    px={2}
                    py={0.5}
                  >
                    {application.ats_score.toFixed(1)}%
                  </Badge>
                </Flex>
                <Progress
                  value={application.ats_score}
                  size="sm"
                  colorScheme={getATSScoreColor(application.ats_score)}
                  borderRadius="full"
                />
              </Box>
            )}

            {application.ranking_score && (
              <Flex justify="space-between" align="center">
                <Text
                  fontSize="label-xs"
                  color="text.sub"
                  fontFamily="'Inter', sans-serif"
                >
                  Ranking Score
                </Text>
                <Text
                  fontSize="label-sm"
                  fontWeight={600}
                  fontFamily="'Inter', sans-serif"
                >
                  {application.ranking_score.toFixed(1)}
                </Text>
              </Flex>
            )}
          </VStack>
        )}

        {/* Notes */}
        {application.hr_notes && (
          <Box
            p={3}
            bg="rgba(248, 249, 250, 0.6)"
            borderRadius="10px"
            border="1px solid rgba(229, 231, 235, 0.5)"
          >
            <Text
              fontSize="label-xs"
              fontWeight={600}
              mb={1}
              fontFamily="'Inter', sans-serif"
            >
              Notes
            </Text>
            <Text
              fontSize="paragraph-sm"
              color="text.sub"
              fontFamily="'Inter', sans-serif"
            >
              {application.hr_notes}
            </Text>
          </Box>
        )}

        {/* Status Update */}
        <VStack align="stretch" spacing={2}>
          <Text
            fontSize="label-xs"
            fontWeight={500}
            fontFamily="'Inter', sans-serif"
          >
            Update Status
          </Text>
          <Select
            size="sm"
            value={application.status}
            onChange={(e) => handleStatusChange(e.target.value)}
            isDisabled={updating}
            h={9}
            bg="rgba(255, 255, 255, 0.6)"
            borderRadius="10px"
            fontSize="paragraph-sm"
            fontFamily="'Inter', sans-serif"
            borderColor="rgba(229, 231, 235, 0.8)"
            _hover={{ borderColor: "primary.lighter" }}
            _focus={{
              borderColor: "primary.base",
              boxShadow: "0 0 0 3px rgba(125, 82, 244, 0.08)",
            }}
          >
            {Object.values(APPLICATION_STATUS).map((status) => (
              <option key={status} value={status}>
                {getStatusLabel(status)}
              </option>
            ))}
          </Select>
        </VStack>

        {/* Actions */}
        <HStack spacing={2}>
          <Button
            size="sm"
            h={9}
            flex={1}
            variant="outline"
            leftIcon={<Icon as={FiDownload} boxSize={3.5} />}
            onClick={handleViewResume}
            isLoading={downloading}
            isDisabled={!application.resume_id}
            borderRadius="10px"
            fontSize="label-xs"
            fontFamily="'Inter', sans-serif"
            borderColor="rgba(229, 231, 235, 0.8)"
            _hover={{
              bg: "rgba(125, 82, 244, 0.05)",
              borderColor: "primary.base",
            }}
          >
            Resume
          </Button>
          <Button
            size="sm"
            h={9}
            flex={1}
            bgGradient="linear(135deg, primary.base, feature.base)"
            color="white"
            leftIcon={<Icon as={FiEye} boxSize={3.5} />}
            onClick={handleViewDetails}
            borderRadius="10px"
            fontSize="label-xs"
            fontFamily="'Inter', sans-serif"
            _hover={{
              transform: "translateY(-1px)",
              shadow: "0 6px 16px -4px rgba(125, 82, 244, 0.4)",
            }}
          >
            Details
          </Button>
        </HStack>
      </VStack>
    </Box>
  );
};

export default ApplicationCard;
