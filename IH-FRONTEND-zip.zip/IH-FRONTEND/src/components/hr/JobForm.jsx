import {
  VStack,
  FormControl,
  FormLabel,
  Input,
  Textarea,
  Button,
  SimpleGrid,
  useToast,
  Select,
  HStack,
  Box,
  Checkbox,
  Icon,
  Text,
  Badge,
  IconButton,
} from "@chakra-ui/react";
import { useState } from "react";
import { FiPlus, FiX } from "react-icons/fi";
import { jobAPI } from "../../api/job";

const JobForm = ({ onSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    department: "",
    location: "",
    employment_type: "full-time",
    experience_level: "mid",
    salary_min: "",
    salary_max: "",
    description: "",
    requirements: [],
    responsibilities: [],
    preferred_qualifications: [],
    benefits: [],
    required_skills: [],
    publish_immediately: false,
  });
  const [reqInput, setReqInput] = useState("");
  const [respInput, setRespInput] = useState("");
  const [skillInput, setSkillInput] = useState("");
  const [benefitInput, setBenefitInput] = useState("");

  const toast = useToast();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddItem = (field, value, setter) => {
    if (value.trim()) {
      setFormData({
        ...formData,
        [field]: [...formData[field], value.trim()],
      });
      setter("");
    }
  };

  const handleAddSkill = () => {
    if (skillInput.trim()) {
      setFormData({
        ...formData,
        required_skills: [
          ...formData.required_skills,
          { name: skillInput.trim() },
        ],
      });
      setSkillInput("");
    }
  };

  const handleRemoveItem = (field, index) => {
    setFormData({
      ...formData,
      [field]: formData[field].filter((_, i) => i !== index),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const submitData = {
        ...formData,
        salary_min: formData.salary_min ? parseInt(formData.salary_min) : null,
        salary_max: formData.salary_max ? parseInt(formData.salary_max) : null,
      };

      const createdJob = await jobAPI.create(submitData);

      if (formData.publish_immediately) {
        await jobAPI.publish(createdJob.id);
      }

      toast({
        title: formData.publish_immediately
          ? "Job published successfully"
          : "Job created as draft",
        description: formData.publish_immediately
          ? "Job is now visible to candidates"
          : "Publish the job when ready",
        status: "success",
        duration: 3000,
      });
      if (onSuccess) onSuccess();
    } catch (error) {
      toast({
        title: "Failed to create job",
        description: error.response?.data?.detail || "Something went wrong",
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <VStack spacing={5} align="stretch">
        {/* Basic Info */}
        <Box>
          <Text
            fontSize="label-sm"
            fontWeight={600}
            mb={3}
            fontFamily="'Inter', sans-serif"
          >
            Basic Information
          </Text>
          <VStack spacing={3}>
            <FormControl isRequired>
              <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                Job Title
              </FormLabel>
              <Input
                name="title"
                value={formData.title}
                onChange={handleChange}
                placeholder="Senior Software Engineer"
                h={10}
                bg="rgba(255, 255, 255, 0.6)"
                borderRadius="10px"
                fontSize="paragraph-sm"
                fontFamily="'Inter', sans-serif"
              />
            </FormControl>

            <SimpleGrid columns={{ base: 1, md: 2 }} spacing={3} w="full">
              <FormControl>
                <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                  Department
                </FormLabel>
                <Input
                  name="department"
                  value={formData.department}
                  onChange={handleChange}
                  placeholder="Engineering"
                  h={10}
                  bg="rgba(255, 255, 255, 0.6)"
                  borderRadius="10px"
                  fontSize="paragraph-sm"
                  fontFamily="'Inter', sans-serif"
                />
              </FormControl>

              <FormControl isRequired>
                <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                  Location
                </FormLabel>
                <Input
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  placeholder="San Francisco, CA"
                  h={10}
                  bg="rgba(255, 255, 255, 0.6)"
                  borderRadius="10px"
                  fontSize="paragraph-sm"
                  fontFamily="'Inter', sans-serif"
                />
              </FormControl>
            </SimpleGrid>

            <SimpleGrid columns={{ base: 1, md: 2 }} spacing={3} w="full">
              <FormControl isRequired>
                <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                  Employment Type
                </FormLabel>
                <Select
                  name="employment_type"
                  value={formData.employment_type}
                  onChange={handleChange}
                  h={10}
                  bg="rgba(255, 255, 255, 0.6)"
                  borderRadius="10px"
                  fontSize="paragraph-sm"
                  fontFamily="'Inter', sans-serif"
                >
                  <option value="full-time">Full Time</option>
                  <option value="part-time">Part Time</option>
                  <option value="contract">Contract</option>
                  <option value="internship">Internship</option>
                </Select>
              </FormControl>

              <FormControl isRequired>
                <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                  Experience Level
                </FormLabel>
                <Select
                  name="experience_level"
                  value={formData.experience_level}
                  onChange={handleChange}
                  h={10}
                  bg="rgba(255, 255, 255, 0.6)"
                  borderRadius="10px"
                  fontSize="paragraph-sm"
                  fontFamily="'Inter', sans-serif"
                >
                  <option value="entry">Entry Level</option>
                  <option value="mid">Mid Level</option>
                  <option value="senior">Senior</option>
                  <option value="executive">Executive</option>
                </Select>
              </FormControl>
            </SimpleGrid>

            <SimpleGrid columns={{ base: 1, md: 2 }} spacing={3} w="full">
              <FormControl>
                <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                  Minimum Salary
                </FormLabel>
                <Input
                  name="salary_min"
                  type="number"
                  value={formData.salary_min}
                  onChange={handleChange}
                  placeholder="80000"
                  h={10}
                  bg="rgba(255, 255, 255, 0.6)"
                  borderRadius="10px"
                  fontSize="paragraph-sm"
                  fontFamily="'Inter', sans-serif"
                />
              </FormControl>

              <FormControl>
                <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                  Maximum Salary
                </FormLabel>
                <Input
                  name="salary_max"
                  type="number"
                  value={formData.salary_max}
                  onChange={handleChange}
                  placeholder="120000"
                  h={10}
                  bg="rgba(255, 255, 255, 0.6)"
                  borderRadius="10px"
                  fontSize="paragraph-sm"
                  fontFamily="'Inter', sans-serif"
                />
              </FormControl>
            </SimpleGrid>
          </VStack>
        </Box>

        {/* Description */}
        <Box>
          <FormControl isRequired>
            <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
              Job Description
            </FormLabel>
            <Textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={5}
              placeholder="Describe the job role..."
              bg="rgba(255, 255, 255, 0.6)"
              borderRadius="10px"
              fontSize="paragraph-sm"
              fontFamily="'Inter', sans-serif"
            />
          </FormControl>
        </Box>

        {/* Requirements */}
        <Box>
          <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
            Requirements
          </FormLabel>
          <HStack spacing={2}>
            <Input
              value={reqInput}
              onChange={(e) => setReqInput(e.target.value)}
              placeholder="Add requirement"
              onKeyPress={(e) =>
                e.key === "Enter" &&
                (e.preventDefault(),
                handleAddItem("requirements", reqInput, setReqInput))
              }
              h={9}
              bg="rgba(255, 255, 255, 0.6)"
              borderRadius="10px"
              fontSize="paragraph-sm"
              fontFamily="'Inter', sans-serif"
            />
            <Button
              onClick={() =>
                handleAddItem("requirements", reqInput, setReqInput)
              }
              type="button"
              size="sm"
              h={9}
              px={4}
              leftIcon={<Icon as={FiPlus} boxSize={3.5} />}
              borderRadius="10px"
              fontSize="label-xs"
              fontFamily="'Inter', sans-serif"
            >
              Add
            </Button>
          </HStack>
          {formData.requirements.length > 0 && (
            <VStack align="stretch" spacing={2} mt={2}>
              {formData.requirements.map((req, index) => (
                <HStack
                  key={index}
                  p={2.5}
                  bg="rgba(248, 249, 250, 0.8)"
                  borderRadius="8px"
                  justify="space-between"
                >
                  <Text
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                    flex={1}
                  >
                    {req}
                  </Text>
                  <IconButton
                    size="xs"
                    icon={<Icon as={FiX} boxSize={3} />}
                    onClick={() => handleRemoveItem("requirements", index)}
                    variant="ghost"
                    colorScheme="red"
                    borderRadius="6px"
                  />
                </HStack>
              ))}
            </VStack>
          )}
        </Box>

        {/* Responsibilities */}
        <Box>
          <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
            Responsibilities
          </FormLabel>
          <HStack spacing={2}>
            <Input
              value={respInput}
              onChange={(e) => setRespInput(e.target.value)}
              placeholder="Add responsibility"
              onKeyPress={(e) =>
                e.key === "Enter" &&
                (e.preventDefault(),
                handleAddItem("responsibilities", respInput, setRespInput))
              }
              h={9}
              bg="rgba(255, 255, 255, 0.6)"
              borderRadius="10px"
              fontSize="paragraph-sm"
              fontFamily="'Inter', sans-serif"
            />
            <Button
              onClick={() =>
                handleAddItem("responsibilities", respInput, setRespInput)
              }
              type="button"
              size="sm"
              h={9}
              px={4}
              leftIcon={<Icon as={FiPlus} boxSize={3.5} />}
              borderRadius="10px"
              fontSize="label-xs"
              fontFamily="'Inter', sans-serif"
            >
              Add
            </Button>
          </HStack>
          {formData.responsibilities.length > 0 && (
            <VStack align="stretch" spacing={2} mt={2}>
              {formData.responsibilities.map((resp, index) => (
                <HStack
                  key={index}
                  p={2.5}
                  bg="rgba(248, 249, 250, 0.8)"
                  borderRadius="8px"
                  justify="space-between"
                >
                  <Text
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                    flex={1}
                  >
                    {resp}
                  </Text>
                  <IconButton
                    size="xs"
                    icon={<Icon as={FiX} boxSize={3} />}
                    onClick={() => handleRemoveItem("responsibilities", index)}
                    variant="ghost"
                    colorScheme="red"
                    borderRadius="6px"
                  />
                </HStack>
              ))}
            </VStack>
          )}
        </Box>

        {/* Skills */}
        <Box>
          <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
            Required Skills
          </FormLabel>
          <HStack spacing={2}>
            <Input
              value={skillInput}
              onChange={(e) => setSkillInput(e.target.value)}
              placeholder="Add skill"
              onKeyPress={(e) =>
                e.key === "Enter" && (e.preventDefault(), handleAddSkill())
              }
              h={9}
              bg="rgba(255, 255, 255, 0.6)"
              borderRadius="10px"
              fontSize="paragraph-sm"
              fontFamily="'Inter', sans-serif"
            />
            <Button
              onClick={handleAddSkill}
              type="button"
              size="sm"
              h={9}
              px={4}
              leftIcon={<Icon as={FiPlus} boxSize={3.5} />}
              borderRadius="10px"
              fontSize="label-xs"
              fontFamily="'Inter', sans-serif"
            >
              Add
            </Button>
          </HStack>
          {formData.required_skills.length > 0 && (
            <HStack mt={2} flexWrap="wrap" spacing={2}>
              {formData.required_skills.map((skill, index) => (
                <Badge
                  key={index}
                  px={3}
                  py={1.5}
                  bg="rgba(125, 82, 244, 0.1)"
                  color="primary.base"
                  borderRadius="full"
                  fontSize="label-xs"
                  display="flex"
                  alignItems="center"
                  gap={2}
                >
                  {skill.name}
                  <Icon
                    as={FiX}
                    boxSize={3}
                    cursor="pointer"
                    onClick={() => handleRemoveItem("required_skills", index)}
                    _hover={{ color: "error.base" }}
                  />
                </Badge>
              ))}
            </HStack>
          )}
        </Box>

        {/* Benefits */}
        <Box>
          <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
            Benefits
          </FormLabel>
          <HStack spacing={2}>
            <Input
              value={benefitInput}
              onChange={(e) => setBenefitInput(e.target.value)}
              placeholder="Add benefit"
              onKeyPress={(e) =>
                e.key === "Enter" &&
                (e.preventDefault(),
                handleAddItem("benefits", benefitInput, setBenefitInput))
              }
              h={9}
              bg="rgba(255, 255, 255, 0.6)"
              borderRadius="10px"
              fontSize="paragraph-sm"
              fontFamily="'Inter', sans-serif"
            />
            <Button
              onClick={() =>
                handleAddItem("benefits", benefitInput, setBenefitInput)
              }
              type="button"
              size="sm"
              h={9}
              px={4}
              leftIcon={<Icon as={FiPlus} boxSize={3.5} />}
              borderRadius="10px"
              fontSize="label-xs"
              fontFamily="'Inter', sans-serif"
            >
              Add
            </Button>
          </HStack>
          {formData.benefits.length > 0 && (
            <VStack align="stretch" spacing={2} mt={2}>
              {formData.benefits.map((benefit, index) => (
                <HStack
                  key={index}
                  p={2.5}
                  bg="rgba(248, 249, 250, 0.8)"
                  borderRadius="8px"
                  justify="space-between"
                >
                  <Text
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                    flex={1}
                  >
                    {benefit}
                  </Text>
                  <IconButton
                    size="xs"
                    icon={<Icon as={FiX} boxSize={3} />}
                    onClick={() => handleRemoveItem("benefits", index)}
                    variant="ghost"
                    colorScheme="red"
                    borderRadius="6px"
                  />
                </HStack>
              ))}
            </VStack>
          )}
        </Box>

        {/* Publish Option */}
        <Box
          p={3}
          bg="rgba(125, 82, 244, 0.05)"
          borderRadius="10px"
          border="1px solid rgba(125, 82, 244, 0.2)"
        >
          <Checkbox
            isChecked={formData.publish_immediately}
            onChange={(e) =>
              setFormData({
                ...formData,
                publish_immediately: e.target.checked,
              })
            }
            colorScheme="purple"
            fontSize="paragraph-sm"
            fontFamily="'Inter', sans-serif"
          >
            Publish job immediately (make visible to candidates)
          </Checkbox>
        </Box>

        {/* Submit */}
        <Button
          type="submit"
          size="md"
          // h={11}
          bgGradient="linear(135deg, primary.base, feature.base)"
          color="white"
          borderRadius="10px"
          isLoading={loading}
          loadingText={
            formData.publish_immediately ? "Publishing..." : "Creating..."
          }
          fontSize="label-sm"
          fontFamily="'Inter', sans-serif"
          _hover={{
            transform: "translateY(-2px)",
            shadow: "0 8px 20px -6px rgba(125, 82, 244, 0.4)",
          }}
        >
          {formData.publish_immediately
            ? "Create & Publish Job"
            : "Create Job as Draft"}
        </Button>
      </VStack>
    </form>
  );
};

export default JobForm;
