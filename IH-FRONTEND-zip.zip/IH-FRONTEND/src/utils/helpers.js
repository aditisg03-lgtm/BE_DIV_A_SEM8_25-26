import { format, formatDistance } from "date-fns";

export const formatDate = (date) => {
  if (!date) return "";
  return format(new Date(date), "MMM dd, yyyy");
};

export const formatDateTime = (date) => {
  if (!date) return "";
  return format(new Date(date), "MMM dd, yyyy HH:mm");
};

export const timeAgo = (date) => {
  if (!date) return "";
  return formatDistance(new Date(date), new Date(), { addSuffix: true });
};

export const getStatusLabel = (status) => {
  return status
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

export const formatSalary = (min, max) => {
  if (!min && !max) return "Not specified";
  if (!max) return `$${min.toLocaleString()}+`;
  if (!min) return `Up to $${max.toLocaleString()}`;
  return `$${min.toLocaleString()} - $${max.toLocaleString()}`;
};

export const truncateText = (text, maxLength = 100) => {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + "...";
};

export const getATSScoreColor = (score) => {
  if (score >= 80) return "green";
  if (score >= 60) return "yellow";
  if (score >= 40) return "orange";
  return "red";
};
