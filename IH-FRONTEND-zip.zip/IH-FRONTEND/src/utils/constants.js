export const USER_ROLES = {
  STUDENT: "student",
  HR: "hr",
};

export const APPLICATION_STATUS = {
  SUBMITTED: "submitted",
  UNDER_REVIEW: "under_review",
  SHORTLISTED: "shortlisted",
  INTERVIEW_SCHEDULED: "interview_scheduled",
  OFFER_EXTENDED: "offer_extended",
  REJECTED: "rejected",
  WITHDRAWN: "withdrawn",
};

export const JOB_STATUS = {
  DRAFT: "draft",
  ACTIVE: "active",
  CLOSED: "closed",
  ARCHIVED: "archived",
};

export const EMPLOYMENT_TYPE = {
  FULL_TIME: "full-time",
  PART_TIME: "part-time",
  CONTRACT: "contract",
  INTERNSHIP: "internship",
};

export const EXPERIENCE_LEVEL = {
  ENTRY: "entry",
  MID: "mid",
  SENIOR: "senior",
  EXECUTIVE: "executive",
};

export const SKILL_CATEGORIES = [
  "technical",
  "soft",
  "language",
  "tool",
  "framework",
];

export const STATUS_COLORS = {
  submitted: "blue",
  under_review: "yellow",
  shortlisted: "purple",
  interview_scheduled: "orange",
  offer_extended: "green",
  rejected: "red",
  withdrawn: "gray",
  draft: "gray",
  active: "green",
  closed: "red",
  archived: "gray",
};
