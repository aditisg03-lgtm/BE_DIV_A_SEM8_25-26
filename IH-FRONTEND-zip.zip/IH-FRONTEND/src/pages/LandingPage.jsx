import {
  Box,
  Button,
  Container,
  Heading,
  Text,
  VStack,
  HStack,
  SimpleGrid,
  Icon,
  Stack,
  Flex,
  Badge,
  Avatar,
  AvatarGroup,
  Circle,
  Wrap,
  useColorModeValue,
} from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import {
  RiSparklingFill,
  RiRocketLine,
  RiShieldCheckLine,
  RiLineChartLine,
  RiUserSmileLine,
  RiBriefcaseLine,
  RiFileTextLine,
  RiCheckboxCircleLine,
  RiStarFill,
  RiArrowRightLine,
  RiPlayCircleLine,
  RiLightbulbLine,
  // RiTargetLine,
  RiTeamLine,
} from "react-icons/ri";
import { useAuth } from "../context/AuthContext";
import { motion } from "framer-motion";
import { FaGripLinesVertical, FaLine } from "react-icons/fa";

const MotionBox = motion(Box);
const MotionFlex = motion(Flex);

// Feature Card Component
const FeatureCard = ({ icon, title, description, color = "primary.base" }) => {
  return (
    <MotionBox
      whileHover={{ y: -8, scale: 1.02 }}
      transition={{ duration: 0.3 }}
    >
      <Box
        bg="bg.white"
        p={8}
        borderRadius="2xl"
        border="1px"
        borderColor="stroke.soft"
        shadow="regular-xs"
        h="full"
        position="relative"
        overflow="hidden"
        _before={{
          content: '""',
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          h: "4px",
          bg: color,
          opacity: 0,
          transition: "all 0.3s",
        }}
        _hover={{
          shadow: "xl",
          borderColor: color,
          _before: {
            opacity: 1,
          },
        }}
      >
        <VStack align="start" spacing={4}>
          <Circle size={16} bg={`${color.split(".")[0]}.lighter`}>
            <Icon as={icon} boxSize={8} color={color} />
          </Circle>
          <VStack align="start" spacing={2}>
            <Heading fontSize="label-lg" fontWeight={600} color="text.strong">
              {title}
            </Heading>
            <Text fontSize="paragraph-sm" color="text.sub" lineHeight="tall">
              {description}
            </Text>
          </VStack>
        </VStack>
      </Box>
    </MotionBox>
  );
};

// Stat Card Component
const StatCard = ({ value, label, icon }) => {
  return (
    <MotionBox whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
      <VStack
        spacing={3}
        p={6}
        borderRadius="xl"
        bg="bg.white"
        border="1px"
        borderColor="stroke.soft"
        shadow="regular-xs"
      >
        <Icon as={icon} boxSize={8} color="primary.base" />
        <Text fontSize="title-h3" fontWeight={700} color="primary.base">
          {value}
        </Text>
        <Text fontSize="paragraph-sm" color="text.sub" textAlign="center">
          {label}
        </Text>
      </VStack>
    </MotionBox>
  );
};

// Testimonial Card Component
const TestimonialCard = ({ name, role, avatar, content, rating = 5 }) => {
  return (
    <Box
      bg="bg.white"
      p={6}
      borderRadius="xl"
      border="1px"
      borderColor="stroke.soft"
      shadow="regular-xs"
    >
      <VStack align="start" spacing={4}>
        <HStack spacing={1}>
          {[...Array(rating)].map((_, i) => (
            <Icon key={i} as={RiStarFill} color="warning.base" boxSize={4} />
          ))}
        </HStack>
        <Text fontSize="paragraph-sm" color="text.sub" lineHeight="tall">
          "{content}"
        </Text>
        <HStack spacing={3}>
          <Avatar size="md" src={avatar} name={name} />
          <VStack align="start" spacing={0}>
            <Text fontSize="label-sm" fontWeight={600} color="text.strong">
              {name}
            </Text>
            <Text fontSize="paragraph-xs" color="text.soft">
              {role}
            </Text>
          </VStack>
        </HStack>
      </VStack>
    </Box>
  );
};

const LandingPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleGetStarted = () => {
    if (user) {
      navigate(
        user.role === "student" ? "/student/dashboard" : "/hr/dashboard"
      );
    } else {
      navigate("/register");
    }
  };

  return (
    <Box bg="bg.weak">
      {/* Navigation */}
      <Box
        as="nav"
        bg="bg.white"
        shadow="regular-xs"
        position="sticky"
        top={0}
        zIndex={100}
        borderBottom="1px"
        borderColor="stroke.soft"
        backdropFilter="blur(10px)"
        backgroundColor="rgba(255, 255, 255, 0.95)"
      >
        <Container maxW="7xl">
          <Flex h={20} alignItems="center" justifyContent="space-between">
            <HStack spacing={3}>
              <Circle size={12} bg="primary.base">
                <Icon as={RiBriefcaseLine} boxSize={6} color="white" />
              </Circle>
              <VStack align="start" spacing={0}>
                <Heading fontSize="label-lg" color="text.strong">
                  IntelizenHire
                </Heading>
                <Text
                  fontSize="subheading-xs"
                  color="text.soft"
                  textTransform="uppercase"
                >
                  AI-Powered Hiring
                </Text>
              </VStack>
            </HStack>
            <HStack spacing={3}>
              {user ? (
                <Button
                  bg="primary.base"
                  color="white"
                  onClick={() =>
                    navigate(
                      user.role === "student"
                        ? "/student/dashboard"
                        : "/hr/dashboard"
                    )
                  }
                  borderRadius="10px"
                  _hover={{ bg: "primary.darker" }}
                >
                  Go to Dashboard
                </Button>
              ) : (
                <>
                  <Button
                    variant="ghost"
                    onClick={() => navigate("/login")}
                    color="text.sub"
                    display={{ base: "none", md: "flex" }}
                  >
                    Sign In
                  </Button>
                  <Button
                    bg="primary.base"
                    color="white"
                    onClick={() => navigate("/register")}
                    borderRadius="10px"
                    _hover={{ bg: "primary.darker" }}
                  >
                    Get Started
                  </Button>
                </>
              )}
            </HStack>
          </Flex>
        </Container>
      </Box>

      {/* Hero Section */}
      <Box
        position="relative"
        overflow="hidden"
        bgGradient="linear(135deg, primary.base 0%, feature.base 100%)"
        _before={{
          content: '""',
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundImage:
            "radial-gradient(circle at 20% 50%, rgba(255, 255, 255, 0.1) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(255, 255, 255, 0.1) 0%, transparent 50%)",
          zIndex: 0,
        }}
      >
        <Container maxW="7xl" position="relative" zIndex={1}>
          <Stack
            direction={{ base: "column", lg: "row" }}
            spacing={12}
            align="center"
            justify="space-between"
            py={{ base: 16, lg: 24 }}
          >
            {/* Left Content */}
            <VStack
              align={{ base: "center", lg: "start" }}
              spacing={8}
              flex={1}
              maxW={{ base: "full", lg: "600px" }}
            >
              <MotionBox
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <Badge
                  bg="whiteAlpha.200"
                  color="white"
                  px={4}
                  py={2}
                  borderRadius="full"
                  fontSize="label-sm"
                  backdropFilter="blur(10px)"
                  border="1px"
                  borderColor="whiteAlpha.300"
                >
                  <HStack spacing={2}>
                    <Icon as={RiSparklingFill} />
                    <Text>AI-Powered ATS Platform</Text>
                  </HStack>
                </Badge>
              </MotionBox>

              <MotionBox
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <Heading
                  fontSize={{ base: "title-h3", lg: "5xl" }}
                  fontWeight={700}
                  color="white"
                  lineHeight={1.2}
                  textAlign={{ base: "center", lg: "left" }}
                >
                  Transform Your Hiring Journey with{" "}
                  <Text
                    as="span"
                    bgGradient="linear(to-r, verified.lighter, success.lighter)"
                    bgClip="text"
                  >
                    Intelligent AI
                  </Text>
                </Heading>
              </MotionBox>

              <MotionBox
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <Text
                  fontSize="label-lg"
                  color="whiteAlpha.900"
                  lineHeight="tall"
                  textAlign={{ base: "center", lg: "left" }}
                >
                  Match perfect talent with dream opportunities using
                  cutting-edge AI. Streamline recruitment, optimize resumes, and
                  make data-driven decisions.
                </Text>
              </MotionBox>

              <MotionBox
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <HStack
                  spacing={4}
                  flexWrap="wrap"
                  justify={{ base: "center", lg: "flex-start" }}
                >
                  <Button
                    size="lg"
                    bg="white"
                    color="primary.base"
                    _hover={{
                      bg: "whiteAlpha.900",
                      transform: "translateY(-2px)",
                    }}
                    onClick={handleGetStarted}
                    leftIcon={<Icon as={RiRocketLine} />}
                    borderRadius="10px"
                    h={14}
                    px={8}
                    shadow="xl"
                  >
                    Get Started Free
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    borderColor="white"
                    color="white"
                    _hover={{ bg: "whiteAlpha.200" }}
                    leftIcon={<Icon as={RiPlayCircleLine} />}
                    borderRadius="10px"
                    h={14}
                    px={8}
                  >
                    Watch Demo
                  </Button>
                </HStack>
              </MotionBox>

              {/* Social Proof */}
              <MotionBox
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <HStack spacing={4} color="white">
                  <AvatarGroup size="md" max={4}>
                    <Avatar name="User 1" />
                    <Avatar name="User 2" />
                    <Avatar name="User 3" />
                    <Avatar name="User 4" />
                  </AvatarGroup>
                  <VStack align="start" spacing={0}>
                    <HStack spacing={1}>
                      {[...Array(5)].map((_, i) => (
                        <Icon
                          key={i}
                          as={RiStarFill}
                          color="warning.base"
                          boxSize={4}
                        />
                      ))}
                    </HStack>
                    <Text fontSize="paragraph-sm" opacity={0.9}>
                      Trusted by 10,000+ professionals
                    </Text>
                  </VStack>
                </HStack>
              </MotionBox>
            </VStack>

            {/* Right Content - Hero Card */}
            <MotionBox
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              flex={1}
              display={{ base: "none", lg: "block" }}
            >
              <Box
                bg="bg.white"
                p={8}
                borderRadius="3xl"
                shadow="2xl"
                border="1px"
                borderColor="stroke.soft"
                transform="rotate(2deg)"
                _hover={{ transform: "rotate(0deg)" }}
                transition="all 0.5s cubic-bezier(0.4, 0, 0.2, 1)"
              >
                <VStack align="stretch" spacing={4}>
                  {/* Score Card */}
                  <HStack
                    p={4}
                    bg="success.lighter"
                    borderRadius="xl"
                    border="1px"
                    borderColor="success.base"
                  >
                    <Circle size={12} bg="success.base">
                      <Icon
                        as={RiCheckboxCircleLine}
                        boxSize={6}
                        color="white"
                      />
                    </Circle>
                    <VStack align="start" spacing={0} flex={1}>
                      <Text fontSize="paragraph-xs" color="text.soft">
                        ATS Compatibility
                      </Text>
                      <Text
                        fontSize="label-lg"
                        fontWeight={700}
                        color="success.base"
                      >
                        95% Match
                      </Text>
                    </VStack>
                  </HStack>

                  {/* Feature List */}
                  <VStack align="stretch" spacing={3}>
                    <HStack spacing={3}>
                      <Circle size={8} bg="primary.alpha.10">
                        <Icon as={RiSparklingFill} color="primary.base" />
                      </Circle>
                      <Text fontSize="label-sm" fontWeight={500}>
                        AI Resume Analysis
                      </Text>
                    </HStack>
                    <HStack spacing={3}>
                      <Circle size={8} bg="feature.light">
                        <Icon as={FaLine} color="feature.base" />
                      </Circle>
                      <Text fontSize="label-sm" fontWeight={500}>
                        Smart Matching Algorithm
                      </Text>
                    </HStack>
                    <HStack spacing={3}>
                      <Circle size={8} bg="verified.lighter">
                        <Icon as={RiLineChartLine} color="verified.base" />
                      </Circle>
                      <Text fontSize="label-sm" fontWeight={500}>
                        Real-time Analytics
                      </Text>
                    </HStack>
                    <HStack spacing={3}>
                      <Circle size={8} bg="warning.lighter">
                        <Icon as={RiShieldCheckLine} color="warning.base" />
                      </Circle>
                      <Text fontSize="label-sm" fontWeight={500}>
                        100% Secure & Private
                      </Text>
                    </HStack>
                  </VStack>
                </VStack>
              </Box>
            </MotionBox>
          </Stack>
        </Container>
      </Box>

      {/* Stats Section */}
      <Box py={20}>
        <Container maxW="7xl">
          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={8}>
            <StatCard
              icon={RiLineChartLine}
              value="95%"
              label="ATS Compatibility Score"
            />
            <StatCard
              icon={RiRocketLine}
              value="10x"
              label="Faster Screening Process"
            />
            <StatCard
              icon={RiUserSmileLine}
              value="10K+"
              label="Happy Users Worldwide"
            />
          </SimpleGrid>
        </Container>
      </Box>

      {/* Features Section */}
      <Box py={20} bg="bg.white">
        <Container maxW="7xl">
          <VStack spacing={16}>
            {/* Section Header */}
            <VStack spacing={4} textAlign="center" maxW="3xl">
              <Badge
                bg="primary.alpha.10"
                color="primary.base"
                px={4}
                py={2}
                borderRadius="full"
                fontSize="label-sm"
              >
                Platform Features
              </Badge>
              <Heading fontSize="title-h3" fontWeight={700} color="text.strong">
                Everything You Need in One Platform
              </Heading>
              <Text fontSize="label-md" color="text.sub" lineHeight="tall">
                Powerful features designed for both job seekers and recruiters
                to streamline the entire hiring process from start to finish.
              </Text>
            </VStack>

            {/* Feature Cards Grid */}
            <SimpleGrid
              columns={{ base: 1, md: 2, lg: 3 }}
              spacing={8}
              w="full"
            >
              <FeatureCard
                icon={RiSparklingFill}
                title="AI Resume Analysis"
                description="Get instant AI-powered feedback on your resume. Optimize for ATS systems and stand out from thousands of applicants."
                color="primary.base"
              />
              <FeatureCard
                icon={FaLine}
                title="Smart Job Matching"
                description="Our intelligent algorithm matches candidates with perfect-fit opportunities based on skills, experience, and career goals."
                color="feature.base"
              />
              <FeatureCard
                icon={RiTeamLine}
                title="Candidate Management"
                description="Manage all applications in one dashboard. Track status, schedule interviews, and communicate seamlessly."
                color="verified.base"
              />
              <FeatureCard
                icon={RiLineChartLine}
                title="Advanced Analytics"
                description="Get deep insights into your hiring pipeline with comprehensive analytics and real-time performance metrics."
                color="success.base"
              />
              <FeatureCard
                icon={RiShieldCheckLine}
                title="Secure & Private"
                description="Enterprise-grade security protects your data. We comply with GDPR and all major privacy regulations."
                color="information.base"
              />
              <FeatureCard
                icon={RiRocketLine}
                title="Lightning Fast"
                description="Process applications 10x faster with automated screening, AI-powered ranking, and instant candidate evaluation."
                color="warning.base"
              />
            </SimpleGrid>
          </VStack>
        </Container>
      </Box>

      {/* For Students Section */}
      <Box py={20} bg="bg.weak">
        <Container maxW="7xl">
          <SimpleGrid
            columns={{ base: 1, lg: 2 }}
            spacing={16}
            alignItems="center"
          >
            <VStack align="start" spacing={8}>
              <Badge
                bg="information.light"
                color="information.dark"
                px={4}
                py={2}
                borderRadius="full"
                fontSize="label-sm"
              >
                For Job Seekers
              </Badge>
              <Heading fontSize="title-h3" fontWeight={700} color="text.strong">
                Land Your Dream Job Faster
              </Heading>
              <VStack align="start" spacing={5}>
                <HStack align="start" spacing={4}>
                  <Circle size={10} bg="success.lighter">
                    <Icon
                      as={RiCheckboxCircleLine}
                      color="success.base"
                      boxSize={5}
                    />
                  </Circle>
                  <VStack align="start" spacing={1}>
                    <Text
                      fontSize="label-md"
                      fontWeight={600}
                      color="text.strong"
                    >
                      Optimize Your Resume
                    </Text>
                    <Text fontSize="paragraph-sm" color="text.sub">
                      Get AI-powered insights to improve your resume and beat
                      ATS systems with 95% compatibility.
                    </Text>
                  </VStack>
                </HStack>
                <HStack align="start" spacing={4}>
                  <Circle size={10} bg="information.light">
                    <Icon as={FaLine} color="information.base" boxSize={5} />
                  </Circle>
                  <VStack align="start" spacing={1}>
                    <Text
                      fontSize="label-md"
                      fontWeight={600}
                      color="text.strong"
                    >
                      Smart Job Matching
                    </Text>
                    <Text fontSize="paragraph-sm" color="text.sub">
                      Receive personalized job recommendations that perfectly
                      match your skills and career goals.
                    </Text>
                  </VStack>
                </HStack>
                <HStack align="start" spacing={4}>
                  <Circle size={10} bg="feature.light">
                    <Icon
                      as={RiLineChartLine}
                      color="feature.base"
                      boxSize={5}
                    />
                  </Circle>
                  <VStack align="start" spacing={1}>
                    <Text
                      fontSize="label-md"
                      fontWeight={600}
                      color="text.strong"
                    >
                      Track Everything
                    </Text>
                    <Text fontSize="paragraph-sm" color="text.sub">
                      Monitor all your applications, interviews, and progress in
                      one centralized dashboard.
                    </Text>
                  </VStack>
                </HStack>
              </VStack>
              <Button
                size="lg"
                bg="primary.base"
                color="white"
                onClick={() => navigate("/register")}
                rightIcon={<Icon as={RiArrowRightLine} />}
                h={14}
                px={8}
                _hover={{ bg: "primary.darker", transform: "translateY(-2px)" }}
              >
                Start as Job Seeker
              </Button>
            </VStack>

            {/* Dashboard Preview */}
            <Box
              bg="bg.white"
              p={8}
              borderRadius="3xl"
              shadow="2xl"
              border="1px"
              borderColor="stroke.soft"
            >
              <VStack align="stretch" spacing={4}>
                <Box bg="information.light" p={5} borderRadius="xl">
                  <VStack align="start" spacing={2}>
                    <Text fontSize="paragraph-sm" color="text.soft">
                      Your ATS Score
                    </Text>
                    <Heading fontSize="title-h3" color="information.base">
                      92%
                    </Heading>
                    <Box w="full" h={2} bg="bg.soft" borderRadius="full">
                      <Box
                        w="92%"
                        h="full"
                        bg="information.base"
                        borderRadius="full"
                      />
                    </Box>
                  </VStack>
                </Box>
                <SimpleGrid columns={2} spacing={4}>
                  <Box bg="success.lighter" p={4} borderRadius="xl">
                    <VStack align="start" spacing={1}>
                      <Text fontSize="paragraph-xs" color="text.soft">
                        Applications
                      </Text>
                      <Text
                        fontSize="label-lg"
                        fontWeight={700}
                        color="success.base"
                      >
                        15 Active
                      </Text>
                    </VStack>
                  </Box>
                  <Box bg="warning.lighter" p={4} borderRadius="xl">
                    <VStack align="start" spacing={1}>
                      <Text fontSize="paragraph-xs" color="text.soft">
                        Interviews
                      </Text>
                      <Text
                        fontSize="label-lg"
                        fontWeight={700}
                        color="warning.base"
                      >
                        5 Pending
                      </Text>
                    </VStack>
                  </Box>
                </SimpleGrid>
                <Box bg="feature.light" p={4} borderRadius="xl">
                  <VStack align="start" spacing={1}>
                    <Text fontSize="paragraph-xs" color="text.soft">
                      Profile Strength
                    </Text>
                    <Text
                      fontSize="label-lg"
                      fontWeight={700}
                      color="feature.base"
                    >
                      Excellent
                    </Text>
                  </VStack>
                </Box>
              </VStack>
            </Box>
          </SimpleGrid>
        </Container>
      </Box>

      {/* For Recruiters Section */}
      <Box py={20} bg="bg.white">
        <Container maxW="7xl">
          <SimpleGrid
            columns={{ base: 1, lg: 2 }}
            spacing={16}
            alignItems="center"
          >
            {/* Dashboard Preview */}
            <Box
              bg="bg.weak"
              p={8}
              borderRadius="3xl"
              shadow="2xl"
              border="1px"
              borderColor="stroke.soft"
              order={{ base: 2, lg: 1 }}
            >
              <VStack align="stretch" spacing={4}>
                <Box bg="primary.alpha.10" p={5} borderRadius="xl">
                  <VStack align="start" spacing={2}>
                    <Text fontSize="paragraph-sm" color="text.soft">
                      Active Job Postings
                    </Text>
                    <Heading fontSize="title-h3" color="primary.base">
                      24 Positions
                    </Heading>
                  </VStack>
                </Box>
                <SimpleGrid columns={2} spacing={4}>
                  <Box bg="verified.lighter" p={4} borderRadius="xl">
                    <VStack align="start" spacing={1}>
                      <Text fontSize="paragraph-xs" color="text.soft">
                        Total Applicants
                      </Text>
                      <Text
                        fontSize="label-lg"
                        fontWeight={700}
                        color="verified.base"
                      >
                        342
                      </Text>
                    </VStack>
                  </Box>
                  <Box bg="success.lighter" p={4} borderRadius="xl">
                    <VStack align="start" spacing={1}>
                      <Text fontSize="paragraph-xs" color="text.soft">
                        Time Saved
                      </Text>
                      <Text
                        fontSize="label-lg"
                        fontWeight={700}
                        color="success.base"
                      >
                        85 hrs
                      </Text>
                    </VStack>
                  </Box>
                </SimpleGrid>
                <Box bg="feature.light" p={4} borderRadius="xl">
                  <VStack align="start" spacing={1}>
                    <Text fontSize="paragraph-xs" color="text.soft">
                      Shortlisted Candidates
                    </Text>
                    <Text
                      fontSize="label-lg"
                      fontWeight={700}
                      color="feature.base"
                    >
                      48 Top Matches
                    </Text>
                  </VStack>
                </Box>
              </VStack>
            </Box>

            <VStack align="start" spacing={8} order={{ base: 1, lg: 2 }}>
              <Badge
                bg="feature.light"
                color="feature.dark"
                px={4}
                py={2}
                borderRadius="full"
                fontSize="label-sm"
              >
                For Recruiters
              </Badge>
              <Heading fontSize="title-h3" fontWeight={700} color="text.strong">
                Hire Top Talent Efficiently
              </Heading>
              <VStack align="start" spacing={5}>
                <HStack align="start" spacing={4}>
                  <Circle size={10} bg="primary.alpha.10">
                    <Icon
                      as={RiSparklingFill}
                      color="primary.base"
                      boxSize={5}
                    />
                  </Circle>
                  <VStack align="start" spacing={1}>
                    <Text
                      fontSize="label-md"
                      fontWeight={600}
                      color="text.strong"
                    >
                      AI-Powered Screening
                    </Text>
                    <Text fontSize="paragraph-sm" color="text.sub">
                      Automatically rank and filter candidates based on job
                      requirements using advanced AI algorithms.
                    </Text>
                  </VStack>
                </HStack>
                <HStack align="start" spacing={4}>
                  <Circle size={10} bg="verified.lighter">
                    <Icon as={RiRocketLine} color="verified.base" boxSize={5} />
                  </Circle>
                  <VStack align="start" spacing={1}>
                    <Text
                      fontSize="label-md"
                      fontWeight={600}
                      color="text.strong"
                    >
                      Streamlined Workflow
                    </Text>
                    <Text fontSize="paragraph-sm" color="text.sub">
                      Manage the entire recruitment pipeline from job posting to
                      final hiring decision in one place.
                    </Text>
                  </VStack>
                </HStack>
                <HStack align="start" spacing={4}>
                  <Circle size={10} bg="success.lighter">
                    <Icon
                      as={RiLineChartLine}
                      color="success.base"
                      boxSize={5}
                    />
                  </Circle>
                  <VStack align="start" spacing={1}>
                    <Text
                      fontSize="label-md"
                      fontWeight={600}
                      color="text.strong"
                    >
                      Data-Driven Decisions
                    </Text>
                    <Text fontSize="paragraph-sm" color="text.sub">
                      Make informed hiring decisions with comprehensive
                      analytics and candidate insights.
                    </Text>
                  </VStack>
                </HStack>
              </VStack>
              <Button
                size="lg"
                bg="primary.base"
                color="white"
                onClick={() => navigate("/register")}
                rightIcon={<Icon as={RiArrowRightLine} />}
                h={14}
                px={8}
                _hover={{ bg: "primary.darker", transform: "translateY(-2px)" }}
              >
                Start as Recruiter
              </Button>
            </VStack>
          </SimpleGrid>
        </Container>
      </Box>

      {/* Testimonials Section */}
      <Box py={20} bg="bg.weak">
        <Container maxW="7xl">
          <VStack spacing={12}>
            <VStack spacing={4} textAlign="center">
              <Badge
                bg="success.lighter"
                color="success.base"
                px={4}
                py={2}
                borderRadius="full"
                fontSize="label-sm"
              >
                Testimonials
              </Badge>
              <Heading fontSize="title-h3" fontWeight={700} color="text.strong">
                Loved by Thousands
              </Heading>
              <Text fontSize="label-md" color="text.sub" maxW="2xl">
                See what our users have to say about their experience
              </Text>
            </VStack>

            <SimpleGrid columns={{ base: 1, md: 3 }} spacing={8} w="full">
              <TestimonialCard
                name="Sarah Johnson"
                role="Software Engineer"
                avatar="https://i.pravatar.cc/150?img=1"
                content="IntelizenHire helped me optimize my resume and I got 3 interview calls within a week! The AI analysis was spot-on."
              />
              <TestimonialCard
                name="Michael Chen"
                role="HR Manager at TechCorp"
                avatar="https://i.pravatar.cc/150?img=2"
                content="This platform cut our screening time by 80%. The AI matching is incredibly accurate and saves us countless hours."
              />
              <TestimonialCard
                name="Emily Rodriguez"
                role="Product Designer"
                avatar="https://i.pravatar.cc/150?img=3"
                content="The job matching feature is amazing! I found my dream job in just 2 weeks. Highly recommend to all job seekers."
              />
            </SimpleGrid>
          </VStack>
        </Container>
      </Box>

      {/* CTA Section */}
      <Box
        position="relative"
        overflow="hidden"
        bgGradient="linear(135deg, primary.base 0%, feature.base 100%)"
        py={20}
        _before={{
          content: '""',
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundImage:
            "radial-gradient(circle at 20% 50%, rgba(255, 255, 255, 0.1) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(255, 255, 255, 0.1) 0%, transparent 50%)",
          zIndex: 0,
        }}
      >
        <Container maxW="5xl" position="relative" zIndex={1}>
          <VStack spacing={10} textAlign="center" color="white">
            <VStack spacing={4}>
              <Heading fontSize="title-h3" fontWeight={700}>
                Ready to Transform Your Career?
              </Heading>
              <Text fontSize="label-lg" opacity={0.9} maxW="3xl">
                Join thousands of job seekers and recruiters who are already
                achieving their goals with IntelizenHire. Start your journey
                today.
              </Text>
            </VStack>
            <HStack spacing={4} flexWrap="wrap" justify="center">
              <Button
                size="lg"
                bg="white"
                color="primary.base"
                _hover={{ bg: "whiteAlpha.900", transform: "translateY(-2px)" }}
                onClick={handleGetStarted}
                rightIcon={<Icon as={RiArrowRightLine} />}
                h={14}
                px={8}
                shadow="xl"
              >
                Get Started Free
              </Button>
              <Button
                size="lg"
                variant="outline"
                borderColor="white"
                color="white"
                _hover={{ bg: "whiteAlpha.200" }}
                leftIcon={<Icon as={RiPlayCircleLine} />}
                h={14}
                px={8}
              >
                Schedule Demo
              </Button>
            </HStack>
            <Text fontSize="paragraph-sm" opacity={0.8}>
              No credit card required • Free forever plan • Cancel anytime
            </Text>
          </VStack>
        </Container>
      </Box>

      {/* Footer */}
      <Box bg="text.strong" color="white" py={16}>
        <Container maxW="7xl">
          <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={8} mb={12}>
            <VStack align="start" spacing={4}>
              <HStack spacing={3}>
                <Circle size={12} bg="primary.base">
                  <Icon as={RiBriefcaseLine} boxSize={6} />
                </Circle>
                <VStack align="start" spacing={0}>
                  <Heading fontSize="label-lg">IntelizenHire</Heading>
                  <Text
                    fontSize="subheading-xs"
                    color="text.disabled"
                    textTransform="uppercase"
                  >
                    AI-Powered Hiring
                  </Text>
                </VStack>
              </HStack>
              <Text
                fontSize="paragraph-sm"
                color="whiteAlpha.700"
                lineHeight="tall"
              >
                Revolutionizing recruitment with cutting-edge AI technology.
                Connect talent with opportunity.
              </Text>
            </VStack>

            <VStack align="start" spacing={3}>
              <Text fontWeight={600} fontSize="label-sm">
                Product
              </Text>
              <VStack align="start" spacing={2}>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Features
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Pricing
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  FAQ
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Integrations
                </Text>
              </VStack>
            </VStack>

            <VStack align="start" spacing={3}>
              <Text fontWeight={600} fontSize="label-sm">
                Company
              </Text>
              <VStack align="start" spacing={2}>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  About Us
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Careers
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Blog
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Contact
                </Text>
              </VStack>
            </VStack>

            <VStack align="start" spacing={3}>
              <Text fontWeight={600} fontSize="label-sm">
                Legal
              </Text>
              <VStack align="start" spacing={2}>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Privacy Policy
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Terms of Service
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Cookie Policy
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  GDPR
                </Text>
              </VStack>
            </VStack>
          </SimpleGrid>

          <Box pt={8} borderTop="1px" borderColor="whiteAlpha.200">
            <Flex
              direction={{ base: "column", md: "row" }}
              justify="space-between"
              align="center"
              gap={4}
            >
              <Text fontSize="paragraph-sm" color="whiteAlpha.700">
                © 2024 IntelizenHire. All rights reserved.
              </Text>
              <HStack spacing={4}>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  Twitter
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  LinkedIn
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  color="whiteAlpha.700"
                  cursor="pointer"
                  _hover={{ color: "white" }}
                >
                  GitHub
                </Text>
              </HStack>
            </Flex>
          </Box>
        </Container>
      </Box>
    </Box>
  );
};

export default LandingPage;
