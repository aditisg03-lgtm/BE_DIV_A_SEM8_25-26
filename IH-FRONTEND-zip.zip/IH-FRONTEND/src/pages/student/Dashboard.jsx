import {
  Box,
  SimpleGrid,
  Heading,
  VStack,
  Text,
  Icon,
  Progress,
  Button,
  HStack,
  Flex,
  Container,
  Badge,
} from "@chakra-ui/react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  RiFileTextLine,
  RiBriefcaseLine,
  RiLineChartLine,
  RiArrowRightLine,
  RiCheckboxCircleLine,
  // RiTrendingUpLine,
  RiArrowUpLine,
} from "react-icons/ri";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { analyticsAPI } from "../../api/analytics";
import { studentAPI } from "../../api/student";
import { LuFileChartColumnIncreasing } from "react-icons/lu";

const COLORS = {
  primary: "#7d52f4",
  success: "#10B981",
  warning: "#F59E0B",
  error: "#EF4444",
  purple: "#8B5CF6",
  blue: "#3B82F6",
  teal: "#14B8A6",
};

// Custom Tooltip
const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    return (
      <Box
        bg="rgba(255, 255, 255, 0.95)"
        backdropFilter="blur(20px)"
        p={3}
        borderRadius="10px"
        border="1px solid rgba(229, 231, 235, 0.8)"
        shadow="0 8px 24px rgba(0, 0, 0, 0.12)"
      >
        <Text
          fontSize="label-xs"
          fontWeight={600}
          mb={1}
          fontFamily="'Inter', sans-serif"
        >
          {payload[0].name}
        </Text>
        <HStack spacing={2}>
          <Box w={2} h={2} borderRadius="full" bg={payload[0].fill} />
          <Text fontSize="paragraph-xs" fontFamily="'Inter', sans-serif">
            {payload[0].value} applications
          </Text>
        </HStack>
      </Box>
    );
  }
  return null;
};

// Modern Stat Card
const ModernStatCard = ({
  title,
  value,
  icon,
  color = COLORS.primary,
  trend,
  trendValue,
}) => {
  return (
    <Box
      bg="rgba(255, 255, 255, 0.7)"
      backdropFilter="blur(20px)"
      p={5}
      mt={10}
      borderRadius="16px"
      border="1px solid rgba(255, 255, 255, 0.8)"
      shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
      position="relative"
      overflow="hidden"
      transition="all 0.3s"
      _hover={{
        transform: "translateY(-4px)",
        shadow: "0 8px 24px rgba(0, 0, 0, 0.08)",
      }}
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        right: 0,
        width: "100px",
        height: "100px",
        borderRadius: "full",
        bg: `${color}15`,
        filter: "blur(40px)",
        zIndex: 0,
      }}
    >
      <Flex
        justify="space-between"
        align="start"
        position="relative"
        zIndex={1}
      >
        <VStack align="start" spacing={2} flex={1}>
          <HStack spacing={2}>
            <Box
              w={10}
              h={10}
              borderRadius="12px"
              bg={`${color}15`}
              display="flex"
              alignItems="center"
              justifyContent="center"
            >
              <Icon as={icon} boxSize={5} color={color} />
            </Box>
            {trend && (
              <Badge
                colorScheme="green"
                borderRadius="full"
                px={2}
                py={1}
                fontSize="subheading-xs"
                display="flex"
                alignItems="center"
                gap={1}
              >
                <Icon as={RiArrowUpLine} boxSize={3} />
                {trendValue}
              </Badge>
            )}
          </HStack>
          <Text
            fontSize="label-xs"
            color="text.sub"
            fontFamily="'Inter', sans-serif"
          >
            {title}
          </Text>
          <Text
            fontSize="title-h4"
            fontWeight={600}
            color="text.strong"
            fontFamily="'Inter', sans-serif"
          >
            {value}
          </Text>
        </VStack>
      </Flex>
    </Box>
  );
};

// Quick Action Card
const QuickActionCard = ({ title, description, icon, onClick, gradient }) => {
  return (
    <Box
      bg="rgba(255, 255, 255, 0.7)"
      backdropFilter="blur(20px)"
      p={5}
      borderRadius="14px"
      border="1px solid rgba(255, 255, 255, 0.8)"
      shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
      cursor="pointer"
      onClick={onClick}
      transition="all 0.3s"
      _hover={{
        transform: "translateY(-4px)",
        shadow: "0 8px 24px rgba(0, 0, 0, 0.08)",
        borderColor: "rgba(125, 82, 244, 0.3)",
      }}
    >
      <HStack spacing={4} align="start">
        <Box
          w={12}
          h={12}
          borderRadius="12px"
          bgGradient={gradient}
          display="flex"
          alignItems="center"
          justifyContent="center"
          flexShrink={0}
        >
          <Icon as={icon} boxSize={6} color="white" />
        </Box>
        <VStack align="start" flex={1} spacing={1}>
          <Text
            fontSize="label-sm"
            fontWeight={600}
            fontFamily="'Inter', sans-serif"
          >
            {title}
          </Text>
          <Text
            fontSize="paragraph-xs"
            color="text.sub"
            fontFamily="'Inter', sans-serif"
          >
            {description}
          </Text>
        </VStack>
        <Icon as={RiArrowRightLine} color="text.soft" boxSize={5} />
      </HStack>
    </Box>
  );
};

const Dashboard = () => {
  const [loading, setLoading] = useState(true);
  const [hasProfile, setHasProfile] = useState(true);
  const [analytics, setAnalytics] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    checkProfileAndFetchAnalytics();
  }, []);

  const checkProfileAndFetchAnalytics = async () => {
    try {
      await studentAPI.getProfile();
      setHasProfile(true);
      await fetchAnalytics();
    } catch (error) {
      if (error.response?.status === 404) {
        setHasProfile(false);
      }
      setLoading(false);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const data = await analyticsAPI.getStudentOverview();
      setAnalytics(data);
    } catch (error) {
      console.error("Failed to fetch analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  const applicationStatusData = analytics?.application_status_breakdown
    ? Object.entries(analytics.application_status_breakdown).map(
        ([name, value]) => ({
          name:
            name.replace("_", " ").charAt(0).toUpperCase() +
            name.replace("_", " ").slice(1),
          value: value,
        })
      )
    : [];

  const getATSScoreMessage = (score) => {
    if (score < 60)
      return {
        emoji: "💡",
        text: "Consider improving your resume for better visibility",
        color: "warning.base",
      };
    if (score < 80)
      return {
        emoji: "📈",
        text: "Good progress! Keep optimizing for better results",
        color: "blue.600",
      };
    return {
      emoji: "🎉",
      text: "Excellent! Your resume is well-optimized for ATS",
      color: "success.base",
    };
  };

  const atsMessage = analytics?.average_ats_score
    ? getATSScoreMessage(analytics.average_ats_score)
    : null;

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)," +
            "radial-gradient(circle at 80% 20%, rgba(254, 242, 242, 0.2) 0%, transparent 25%)," +
            "radial-gradient(circle at 40% 70%, rgba(219, 234, 254, 0.25) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
        sx={{
          "@keyframes float": {
            "0%, 100%": { transform: "translate(0, 0) rotate(0deg)" },
            "33%": { transform: "translate(30px, -30px) rotate(120deg)" },
            "66%": { transform: "translate(-20px, 20px) rotate(240deg)" },
          },
        }}
      >
        <Container maxW="container.xl" position="relative" zIndex={1} py={8}>
          <VStack spacing={6} align="stretch">
            {/* Header */}
            <VStack align="start" spacing={1}>
              <Heading
                fontSize="title-h4"
                fontWeight={600}
                fontFamily="'Inter', sans-serif"
              >
                Dashboard Overview
              </Heading>
              <Text
                fontSize="paragraph-sm"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                Track your job search progress and performance
              </Text>
            </VStack>

            {/* Profile Alert */}
            {!hasProfile && (
              <Box
                bg="rgba(255, 255, 255, 0.7)"
                backdropFilter="blur(20px)"
                p={5}
                borderRadius="16px"
                border="1px solid rgba(59, 130, 246, 0.3)"
                shadow="0 4px 16px rgba(59, 130, 246, 0.1)"
              >
                <HStack spacing={3}>
                  <Icon
                    as={RiCheckboxCircleLine}
                    color="information.base"
                    boxSize={5}
                  />
                  <VStack align="start" spacing={1} flex={1}>
                    <Text
                      fontWeight={600}
                      fontSize="label-sm"
                      fontFamily="'Inter', sans-serif"
                    >
                      Welcome! Let's get you started
                    </Text>
                    <Text
                      fontSize="paragraph-sm"
                      color="text.sub"
                      fontFamily="'Inter', sans-serif"
                    >
                      Complete your profile to start applying to jobs and
                      tracking applications
                    </Text>
                  </VStack>
                  <Button
                    size="sm"
                    h={9}
                    colorScheme="blue"
                    borderRadius="10px"
                    onClick={() => navigate("/student/profile")}
                    fontFamily="'Inter', sans-serif"
                    fontSize="label-xs"
                  >
                    Complete Now
                  </Button>
                </HStack>
              </Box>
            )}

            {/* Stats Grid */}
            <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={4}>
              <ModernStatCard
                title="Total Applications"
                value={analytics?.total_applications || 0}
                icon={RiBriefcaseLine}
                color={COLORS.primary}
                trend="up"
                trendValue="+12%"
              />
              <ModernStatCard
                title="Average ATS Score"
                value={`${analytics?.average_ats_score?.toFixed(1) || 0}%`}
                icon={RiLineChartLine}
                color={COLORS.success}
              />
              <ModernStatCard
                title="Total Resumes"
                value={analytics?.total_resumes || 0}
                icon={RiFileTextLine}
                color={COLORS.purple}
              />
              <ModernStatCard
                title="Shortlisted"
                value={
                  analytics?.application_status_breakdown?.shortlisted || 0
                }
                icon={RiCheckboxCircleLine}
                color={COLORS.teal}
                trend="up"
                trendValue="+3"
              />
            </SimpleGrid>

            {/* Charts Row */}
            {hasProfile && (
              <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={5}>
                {/* ATS Score Progress */}
                {analytics?.average_ats_score && (
                  <Box
                    bg="rgba(255, 255, 255, 0.7)"
                    backdropFilter="blur(20px)"
                    p={6}
                    borderRadius="16px"
                    border="1px solid rgba(255, 255, 255, 0.8)"
                    shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                  >
                    <VStack align="stretch" spacing={4}>
                      <Flex justify="space-between" align="start">
                        <VStack align="start" spacing={0}>
                          <Text
                            fontSize="label-md"
                            fontWeight={600}
                            fontFamily="'Inter', sans-serif"
                          >
                            ATS Score Performance
                          </Text>
                          <Text
                            fontSize="paragraph-xs"
                            color="text.sub"
                            fontFamily="'Inter', sans-serif"
                          >
                            Your resume optimization level
                          </Text>
                        </VStack>
                        <VStack spacing={0} align="end">
                          <Text
                            fontSize="title-h4"
                            fontWeight={700}
                            color="primary.base"
                            fontFamily="'Inter', sans-serif"
                          >
                            {analytics.average_ats_score.toFixed(1)}%
                          </Text>
                          <Badge
                            colorScheme={
                              analytics.average_ats_score >= 80
                                ? "green"
                                : analytics.average_ats_score >= 60
                                ? "blue"
                                : "orange"
                            }
                            fontSize="subheading-xs"
                          >
                            {analytics.average_ats_score >= 80
                              ? "Excellent"
                              : analytics.average_ats_score >= 60
                              ? "Good"
                              : "Needs Work"}
                          </Badge>
                        </VStack>
                      </Flex>

                      <Box>
                        <Progress
                          value={analytics.average_ats_score}
                          h={3}
                          borderRadius="full"
                          bg="rgba(229, 231, 235, 0.3)"
                          sx={{
                            "& > div": {
                              bgGradient:
                                "linear(to-r, primary.base, feature.base)",
                            },
                          }}
                        />
                      </Box>

                      {atsMessage && (
                        <HStack
                          p={3}
                          bg="rgba(248, 249, 250, 0.6)"
                          borderRadius="10px"
                          spacing={2}
                        >
                          <Text
                            fontSize="paragraph-sm"
                            fontFamily="'Inter', sans-serif"
                          >
                            {atsMessage.emoji}
                          </Text>
                          <Text
                            fontSize="paragraph-sm"
                            color={atsMessage.color}
                            fontFamily="'Inter', sans-serif"
                          >
                            {atsMessage.text}
                          </Text>
                        </HStack>
                      )}
                    </VStack>
                  </Box>
                )}

                {/* Application Status Chart */}
                {applicationStatusData.length > 0 && (
                  <Box
                    bg="rgba(255, 255, 255, 0.7)"
                    backdropFilter="blur(20px)"
                    p={6}
                    borderRadius="16px"
                    border="1px solid rgba(255, 255, 255, 0.8)"
                    shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                  >
                    <VStack align="stretch" spacing={4}>
                      <VStack align="start" spacing={0}>
                        <Text
                          fontSize="label-md"
                          fontWeight={600}
                          fontFamily="'Inter', sans-serif"
                        >
                          Application Status
                        </Text>
                        <Text
                          fontSize="paragraph-xs"
                          color="text.sub"
                          fontFamily="'Inter', sans-serif"
                        >
                          Current status distribution
                        </Text>
                      </VStack>
                      <Flex h="200px" align="center" justify="center">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={applicationStatusData}
                              cx="50%"
                              cy="50%"
                              innerRadius={70}
                              outerRadius={80}
                              paddingAngle={3}
                              dataKey="value"
                            >
                              {applicationStatusData.map((entry, index) => {
                                const colors = [
                                  COLORS.primary,
                                  COLORS.success,
                                  COLORS.warning,
                                  COLORS.error,
                                  COLORS.teal,
                                ];
                                return (
                                  <Cell
                                    key={`cell-${index}`}
                                    fill={colors[index % colors.length]}
                                  />
                                );
                              })}
                            </Pie>
                            <Tooltip content={<CustomTooltip />} />
                          </PieChart>
                        </ResponsiveContainer>
                        <VStack position="absolute" spacing={0}>
                          <Text
                            fontSize="title-h5"
                            fontWeight={700}
                            fontFamily="'Inter', sans-serif"
                          >
                            {analytics?.total_applications || 0}
                          </Text>
                          <Text
                            fontSize="paragraph-xs"
                            color="text.sub"
                            fontFamily="'Inter', sans-serif"
                          >
                            Total
                          </Text>
                        </VStack>
                      </Flex>
                    </VStack>
                  </Box>
                )}
              </SimpleGrid>
            )}

            {/* Quick Actions */}
            <Box>
              <Text
                fontSize="label-md"
                fontWeight={600}
                mb={4}
                fontFamily="'Inter', sans-serif"
              >
                Quick Actions
              </Text>
              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                <QuickActionCard
                  title="Browse Jobs"
                  description="Discover new opportunities that match your profile"
                  icon={RiBriefcaseLine}
                  onClick={() => navigate("/student/jobs")}
                  gradient="linear(135deg, #7d52f4, #8B5CF6)"
                />
                <QuickActionCard
                  title="Upload Resume"
                  description="Add and analyze your resume with AI"
                  icon={RiFileTextLine}
                  onClick={() => navigate("/student/resumes")}
                  gradient="linear(135deg, #8B5CF6, #EC4899)"
                />
                <QuickActionCard
                  title="Analyze Job Match"
                  description="Find jobs that perfectly fit your skills"
                  icon={RiLineChartLine}
                  onClick={() => navigate("/student/job-comparison")}
                  gradient="linear(135deg, #10B981, #14B8A6)"
                />
                <QuickActionCard
                  title="View Activity"
                  description="Track your application progress and history"
                  icon={LuFileChartColumnIncreasing}
                  onClick={() => navigate("/student/activity-history")}
                  gradient="linear(135deg, #14B8A6, #3B82F6)"
                />
              </SimpleGrid>
            </Box>
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default Dashboard;
