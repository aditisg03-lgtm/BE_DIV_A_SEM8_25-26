import {
  Box,
  Heading,
  VStack,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  HStack,
  Icon,
  Text,
} from "@chakra-ui/react";
import {
  RiUserLine,
  RiGraduationCapLine,
  RiBriefcaseLine,
  RiCodeLine,
} from "react-icons/ri";
import Layout from "../../components/layout/Layout";
import ProfileForm from "../../components/student/ProfileForm";
import EducationForm from "../../components/student/EducationForm";
import ExperienceForm from "../../components/student/ExperienceForm";
import SkillForm from "../../components/student/SkillForm";

const TabButton = ({ icon, children }) => {
  return (
    <HStack spacing={2}>
      <Icon as={icon} boxSize={4} />
      <Text>{children}</Text>
    </HStack>
  );
};

const Profile = () => {
  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        <Heading size="lg" fontWeight={600}>
          My Profile
        </Heading>

        <Box
          bg="bg.white"
          borderRadius="2xl"
          shadow="regular-xs"
          border="1px"
          borderColor="stroke.soft"
        >
          <Tabs colorScheme="primary" variant="line">
            <TabList px={6} borderBottomWidth="1px" borderColor="stroke.soft">
              <Tab>
                <TabButton icon={RiUserLine}>Personal Info</TabButton>
              </Tab>
              <Tab>
                <TabButton icon={RiGraduationCapLine}>Education</TabButton>
              </Tab>
              <Tab>
                <TabButton icon={RiBriefcaseLine}>Experience</TabButton>
              </Tab>
              <Tab>
                <TabButton icon={RiCodeLine}>Skills</TabButton>
              </Tab>
            </TabList>

            <TabPanels>
              <TabPanel p={6}>
                <ProfileForm />
              </TabPanel>
              <TabPanel p={6}>
                <EducationForm />
              </TabPanel>
              <TabPanel p={6}>
                <ExperienceForm />
              </TabPanel>
              <TabPanel p={6}>
                <SkillForm />
              </TabPanel>
            </TabPanels>
          </Tabs>
        </Box>
      </VStack>
    </Layout>
  );
};

export default Profile;
