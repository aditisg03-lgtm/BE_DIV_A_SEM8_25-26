import {
  Box,
  Heading,
  VStack,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  Button,
  HStack,
  Text,
  Icon,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { RiBriefcaseLine } from "react-icons/ri";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { applicationAPI } from "../../api/application";
import { formatDate, getStatusLabel, timeAgo } from "../../utils/helpers";
import { STATUS_COLORS } from "../../utils/constants";

const MyApplications = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      const data = await applicationAPI.getAll();
      setApplications(data);
    } catch (error) {
      console.error("Failed to fetch applications:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        <HStack justify="space-between">
          <VStack align="start" spacing={1}>
            <Heading size="lg" fontWeight={600}>
              My Applications
            </Heading>
            <Text fontSize="paragraph-sm" color="text.sub">
              Track your job applications and their status
            </Text>
          </VStack>
          <Button
            bg="primary.base"
            color="white"
            onClick={() => navigate("/student/jobs")}
            leftIcon={<Icon as={RiBriefcaseLine} />}
          >
            Browse Jobs
          </Button>
        </HStack>

        {applications.length === 0 ? (
          <Box
            bg="bg.white"
            p={12}
            borderRadius="2xl"
            textAlign="center"
            border="1px"
            borderColor="stroke.soft"
          >
            <VStack spacing={4}>
              <Icon as={RiBriefcaseLine} boxSize={16} color="text.soft" />
              <Heading size="md" color="text.sub" fontWeight={600}>
                No applications yet
              </Heading>
              <Text color="text.sub">
                Start applying to jobs to see your applications here
              </Text>
              <Button
                bg="primary.base"
                color="white"
                size="lg"
                onClick={() => navigate("/student/jobs")}
              >
                Browse Jobs
              </Button>
            </VStack>
          </Box>
        ) : (
          <Box
            bg="bg.white"
            borderRadius="2xl"
            overflow="hidden"
            shadow="regular-xs"
            border="1px"
            borderColor="stroke.soft"
          >
            <Box overflowX="auto">
              <Table variant="simple">
                <Thead bg="bg.weak">
                  <Tr>
                    <Th fontSize="paragraph-sm">Job Title</Th>
                    <Th fontSize="paragraph-sm">Applied Date</Th>
                    <Th fontSize="paragraph-sm">Status</Th>
                    <Th fontSize="paragraph-sm">ATS Score</Th>
                    <Th fontSize="paragraph-sm">Last Update</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {applications.map((application) => (
                    <Tr key={application.id} _hover={{ bg: "bg.weak" }}>
                      <Td fontWeight={500}>{application.job_description_id}</Td>
                      <Td color="text.sub">
                        {formatDate(application.applied_date)}
                      </Td>
                      <Td>
                        <Badge
                          colorScheme={STATUS_COLORS[application.status]}
                          fontSize="label-xs"
                        >
                          {getStatusLabel(application.status)}
                        </Badge>
                      </Td>
                      <Td>
                        {application.ats_score ? (
                          <Badge
                            colorScheme={
                              application.ats_score >= 80
                                ? "green"
                                : application.ats_score >= 60
                                ? "yellow"
                                : "red"
                            }
                            fontSize="label-xs"
                          >
                            {application.ats_score.toFixed(1)}%
                          </Badge>
                        ) : (
                          <Text color="text.soft">-</Text>
                        )}
                      </Td>
                      <Td fontSize="paragraph-sm" color="text.sub">
                        {timeAgo(application.last_status_update)}
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Box>
          </Box>
        )}
      </VStack>
    </Layout>
  );
};

export default MyApplications;
