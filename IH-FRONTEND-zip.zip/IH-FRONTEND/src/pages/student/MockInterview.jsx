import {
  Box,
  Heading,
  VStack,
  HStack,
  Button,
  Text,
  useToast,
  Progress,
  Badge,
  Textarea,
  Divider,
  Alert,
  AlertIcon,
  AlertDescription,
  SimpleGrid,
  Icon,
  List,
  ListItem,
  ListIcon,
  Flex,
  CircularProgress,
  CircularProgressLabel,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  // RiCheckCircleLine,
  // RiAlertCircleLine,
  RiLineChartLine,
  RiArrowLeftLine,
  RiArrowRightLine,
  RiSendPlaneLine,
  RiLightbulbLine,
} from "react-icons/ri";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { studentEnhancementsAPI } from "../../api/studentEnhancements";
import { FaArrowCircleRight, FaCircle } from "react-icons/fa";

const MockInterview = () => {
  const { interviewId } = useParams();
  const navigate = useNavigate();
  const [interview, setInterview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [currentAnswer, setCurrentAnswer] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [evaluation, setEvaluation] = useState(null);
  const toast = useToast();

  useEffect(() => {
    if (interviewId) {
      fetchInterview();
    }
  }, [interviewId]);

  const fetchInterview = async () => {
    try {
      const data = await studentEnhancementsAPI.getInterview(interviewId);
      setInterview(data);

      if (data.answers && Object.keys(data.answers).length > 0) {
        setAnswers(data.answers);
      }

      if (data.status === "completed" && data.evaluation) {
        setEvaluation(data.evaluation);
      }
    } catch (error) {
      toast({
        title: "Failed to load interview",
        status: "error",
        duration: 3000,
      });
      navigate("/student/job-comparison");
    } finally {
      setLoading(false);
    }
  };

  const handleNext = () => {
    if (currentAnswer.trim()) {
      setAnswers({
        ...answers,
        [interview.questions[currentQuestion].id]: currentAnswer,
      });
      setCurrentAnswer("");

      if (currentQuestion < interview.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      }
    } else {
      toast({
        title: "Answer required",
        description: "Please provide an answer before proceeding",
        status: "warning",
        duration: 2000,
      });
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      const prevQuestionId = interview.questions[currentQuestion - 1].id;
      setCurrentAnswer(answers[prevQuestionId] || "");
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = async () => {
    const finalAnswers = {
      ...answers,
      [interview.questions[currentQuestion].id]: currentAnswer,
    };

    const unansweredCount = interview.questions.filter(
      (q) => !finalAnswers[q.id] || finalAnswers[q.id].trim() === ""
    ).length;

    if (unansweredCount > 0) {
      toast({
        title: "Incomplete interview",
        description: `You have ${unansweredCount} unanswered question(s)`,
        status: "warning",
        duration: 3000,
      });
      return;
    }

    setSubmitting(true);
    try {
      const result = await studentEnhancementsAPI.submitInterview(
        interviewId,
        finalAnswers
      );
      setEvaluation(result);
      toast({
        title: "Interview submitted successfully!",
        description: "Your responses have been evaluated",
        status: "success",
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: "Submission failed",
        description: error.response?.data?.detail || "Please try again",
        status: "error",
        duration: 3000,
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );
  if (!interview) return null;

  // Show evaluation results
  if (evaluation) {
    return (
      <Layout>
        <VStack spacing={6} align="stretch">
          <HStack>
            <Button
              variant="ghost"
              leftIcon={<Icon as={RiArrowLeftLine} />}
              onClick={() => navigate("/student/job-comparison")}
              color="text.sub"
            >
              Back
            </Button>
          </HStack>

          <Heading size="lg" fontWeight={600}>
            Mock Interview Results
          </Heading>

          {/* Overall Score */}
          <Box
            bg="bg.white"
            p={8}
            borderRadius="2xl"
            shadow="regular-xs"
            border="1px"
            borderColor="stroke.soft"
            textAlign="center"
          >
            <VStack spacing={4}>
              <CircularProgress
                value={evaluation.overall_score}
                size="200px"
                thickness="12px"
                color="primary.base"
              >
                <CircularProgressLabel>
                  <VStack spacing={0}>
                    <Text
                      fontSize="title-h3"
                      fontWeight={700}
                      color="primary.base"
                    >
                      {evaluation.overall_score}%
                    </Text>
                    <Text fontSize="paragraph-sm" color="text.soft">
                      Overall Score
                    </Text>
                  </VStack>
                </CircularProgressLabel>
              </CircularProgress>
              <Progress
                value={evaluation.overall_score}
                w="full"
                h={3}
                borderRadius="full"
                bg="bg.soft"
                sx={{ "& > div": { bg: "primary.base" } }}
              />
            </VStack>
          </Box>

          {/* Success Rate & Feedback */}
          <SimpleGrid columns={{ base: 1, md: 2 }} spacing={6}>
            <Box
              bg="success.lighter"
              p={6}
              borderRadius="xl"
              borderLeft="4px"
              borderColor="success.base"
            >
              <VStack align="start" spacing={3}>
                <HStack>
                  <Icon as={RiLineChartLine} color="success.base" boxSize={6} />
                  <Text fontWeight={600} fontSize="label-md">
                    Success Rate for This Job
                  </Text>
                </HStack>
                <Text fontSize="title-h3" fontWeight={700} color="success.base">
                  {evaluation.success_rate}%
                </Text>
                <Text fontSize="paragraph-sm" color="text.sub">
                  Based on your interview performance and profile
                </Text>
              </VStack>
            </Box>

            <Box
              bg="information.light"
              p={6}
              borderRadius="xl"
              borderLeft="4px"
              borderColor="information.base"
            >
              <VStack align="start" spacing={3}>
                <Text fontWeight={600} fontSize="label-md">
                  Overall Feedback
                </Text>
                <Text fontSize="paragraph-sm" color="text.sub">
                  {evaluation.feedback}
                </Text>
              </VStack>
            </Box>
          </SimpleGrid>

          {/* Strengths */}
          {evaluation.strengths?.length > 0 && (
            <Box
              bg="bg.white"
              p={6}
              borderRadius="xl"
              shadow="regular-xs"
              border="1px"
              borderColor="stroke.soft"
            >
              <Heading size="sm" mb={4} color="success.base" fontWeight={600}>
                ✓ Your Strengths
              </Heading>
              <List spacing={3}>
                {evaluation.strengths.map((strength, index) => (
                  <ListItem key={index}>
                    <HStack align="start">
                      <ListIcon as={FaCircle} color="success.base" mt={1} />
                      <Text fontSize="paragraph-sm">{strength}</Text>
                    </HStack>
                  </ListItem>
                ))}
              </List>
            </Box>
          )}

          {/* Areas for Improvement */}
          {evaluation.improvements?.length > 0 && (
            <Box
              bg="bg.white"
              p={6}
              borderRadius="xl"
              shadow="regular-xs"
              border="1px"
              borderColor="stroke.soft"
            >
              <Heading size="sm" mb={4} color="warning.base" fontWeight={600}>
                ⚠ Areas for Improvement
              </Heading>
              <List spacing={3}>
                {evaluation.improvements.map((improvement, index) => (
                  <ListItem key={index}>
                    <HStack align="start">
                      <ListIcon
                        as={FaArrowCircleRight}
                        color="warning.base"
                        mt={1}
                      />
                      <Text fontSize="paragraph-sm">{improvement}</Text>
                    </HStack>
                  </ListItem>
                ))}
              </List>
            </Box>
          )}

          {/* Tips */}
          {evaluation.tips_to_improve?.length > 0 && (
            <Box
              bg="information.light"
              p={6}
              borderRadius="xl"
              borderLeft="4px"
              borderColor="information.base"
            >
              <Heading size="sm" mb={4} fontWeight={600}>
                💡 Tips to Improve
              </Heading>
              <List spacing={3}>
                {evaluation.tips_to_improve.map((tip, index) => (
                  <ListItem key={index}>
                    <HStack align="start">
                      <Badge colorScheme="blue" mt={1} borderRadius="full">
                        {index + 1}
                      </Badge>
                      <Text fontSize="paragraph-sm">{tip}</Text>
                    </HStack>
                  </ListItem>
                ))}
              </List>
            </Box>
          )}

          {/* Actions */}
          <HStack justify="center" spacing={4}>
            <Button
              bg="primary.base"
              color="white"
              size="lg"
              onClick={() => navigate("/student/job-comparison")}
            >
              Analyze Another Job
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => navigate("/student/activity-history")}
              borderColor="stroke.soft"
            >
              View History
            </Button>
          </HStack>
        </VStack>
      </Layout>
    );
  }

  // Show interview questions
  const question = interview.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / interview.questions.length) * 100;

  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        <HStack justify="space-between">
          <Heading size="lg" fontWeight={600}>
            Mock Interview
          </Heading>
          <Badge
            bg="primary.alpha.10"
            color="primary.base"
            fontSize="label-sm"
            px={4}
            py={2}
            borderRadius="full"
          >
            Question {currentQuestion + 1} of {interview.questions.length}
          </Badge>
        </HStack>

        <Box>
          <Progress
            value={progress}
            h={2}
            borderRadius="full"
            bg="bg.soft"
            sx={{ "& > div": { bg: "primary.base" } }}
          />
          <Text fontSize="paragraph-xs" color="text.soft" mt={2}>
            {progress.toFixed(0)}% Complete
          </Text>
        </Box>

        <Alert
          status="info"
          borderRadius="xl"
          bg="information.light"
          border="1px"
          borderColor="information.base"
        >
          <AlertIcon color="information.base" />
          <AlertDescription fontSize="paragraph-sm" color="text.sub">
            Take your time to answer thoughtfully. Your responses will be
            evaluated by AI.
          </AlertDescription>
        </Alert>

        <Box
          bg="bg.white"
          p={8}
          borderRadius="2xl"
          shadow="regular-xs"
          border="1px"
          borderColor="stroke.soft"
        >
          <VStack spacing={6} align="stretch">
            <Badge
              alignSelf="flex-start"
              colorScheme="purple"
              px={3}
              py={1}
              borderRadius="full"
              fontSize="label-xs"
              textTransform="uppercase"
            >
              {question.type}
            </Badge>

            <Heading size="md" fontWeight={600} color="text.strong">
              {question.question}
            </Heading>

            {question.tips && (
              <Box
                bg="feature.light"
                p={4}
                borderRadius="lg"
                borderLeft="4px"
                borderColor="feature.base"
              >
                <HStack align="start" spacing={3}>
                  <Icon
                    as={RiLightbulbLine}
                    color="feature.base"
                    boxSize={5}
                    mt={0.5}
                  />
                  <VStack align="start" spacing={1}>
                    <Text
                      fontSize="label-sm"
                      fontWeight={600}
                      color="feature.dark"
                    >
                      Tip
                    </Text>
                    <Text fontSize="paragraph-sm" color="text.sub">
                      {question.tips}
                    </Text>
                  </VStack>
                </HStack>
              </Box>
            )}

            <Divider />

            <Textarea
              value={currentAnswer || answers[question.id] || ""}
              onChange={(e) => setCurrentAnswer(e.target.value)}
              placeholder="Type your answer here..."
              rows={12}
              fontSize="paragraph-sm"
              bg="bg.weak"
              borderColor="stroke.soft"
              _hover={{ borderColor: "primary.lighter" }}
              _focus={{
                borderColor: "primary.base",
                boxShadow: "button-primary-focus",
              }}
            />

            <Text fontSize="paragraph-xs" color="text.soft" textAlign="right">
              {(currentAnswer || answers[question.id] || "").length} characters
            </Text>
          </VStack>
        </Box>

        <HStack justify="space-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            isDisabled={currentQuestion === 0}
            leftIcon={<Icon as={RiArrowLeftLine} />}
            borderColor="stroke.soft"
            color="text.sub"
          >
            Previous
          </Button>

          {currentQuestion === interview.questions.length - 1 ? (
            <Button
              bg="success.base"
              color="white"
              size="lg"
              onClick={handleSubmit}
              isLoading={submitting}
              loadingText="Evaluating..."
              rightIcon={<Icon as={RiSendPlaneLine} />}
              _hover={{ bg: "success.dark" }}
            >
              Submit Interview
            </Button>
          ) : (
            <Button
              bg="primary.base"
              color="white"
              size="lg"
              onClick={handleNext}
              rightIcon={<Icon as={RiArrowRightLine} />}
              _hover={{ bg: "primary.darker" }}
            >
              Next Question
            </Button>
          )}
        </HStack>
      </VStack>
    </Layout>
  );
};

export default MockInterview;
