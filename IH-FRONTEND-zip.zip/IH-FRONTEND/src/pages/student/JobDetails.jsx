import {
  Box,
  Heading,
  VStack,
  HStack,
  Text,
  Button,
  Divider,
  SimpleGrid,
  Icon,
  useToast,
  Wrap,
  Tag,
  List,
  ListItem,
  ListIcon,
  Badge,
  Circle,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  RiMapPinLine,
  RiBriefcaseLine,
  RiMoneyDollarCircleLine,
  RiCalendarLine,
  RiCheckboxCircleLine,
  // RiTargetLine,
  RiBookmarkLine,
  RiBookmarkFill,
  RiArrowLeftLine,
  RiSendPlaneLine,
} from "react-icons/ri";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { jobAPI } from "../../api/job";
import { studentEnhancementsAPI } from "../../api/studentEnhancements";
import { formatDate, formatSalary, getStatusLabel } from "../../utils/helpers";
import { FaLine } from "react-icons/fa";

const JobDetails = () => {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isSaved, setIsSaved] = useState(false);
  const toast = useToast();

  useEffect(() => {
    fetchJobDetails();
    checkIfSaved();
  }, [jobId]);

  const fetchJobDetails = async () => {
    try {
      const data = await jobAPI.getById(jobId);
      setJob(data);
    } catch (error) {
      toast({
        title: "Failed to load job details",
        status: "error",
        duration: 3000,
      });
      navigate("/student/jobs");
    } finally {
      setLoading(false);
    }
  };

  const checkIfSaved = async () => {
    try {
      const savedJobs = await studentEnhancementsAPI.getSavedJobs();
      const saved = savedJobs.some((s) => s.job.id === jobId);
      setIsSaved(saved);
    } catch (error) {
      console.error("Failed to check saved status:", error);
    }
  };

  const handleSave = async () => {
    try {
      if (isSaved) {
        await studentEnhancementsAPI.unsaveJob(jobId);
        setIsSaved(false);
        toast({
          title: "Job removed from saved",
          status: "info",
          duration: 2000,
        });
      } else {
        await studentEnhancementsAPI.saveJob(jobId);
        setIsSaved(true);
        toast({
          title: "Job saved successfully",
          status: "success",
          duration: 2000,
        });
      }
    } catch (error) {
      toast({
        title: "Action failed",
        description: error.response?.data?.detail,
        status: "error",
        duration: 3000,
      });
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );
  if (!job) return null;

  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        {/* Back Button */}
        <HStack>
          <Button
            variant="ghost"
            leftIcon={<Icon as={RiArrowLeftLine} />}
            onClick={() => navigate("/student/jobs")}
            color="text.sub"
          >
            Back to Jobs
          </Button>
        </HStack>

        {/* Job Header */}
        <Box
          bg="bg.white"
          p={8}
          borderRadius="2xl"
          shadow="regular-xs"
          border="1px"
          borderColor="stroke.soft"
        >
          <VStack align="stretch" spacing={6}>
            <HStack justify="space-between" align="start">
              <VStack align="start" spacing={3} flex={1}>
                <Heading
                  fontSize="title-h3"
                  fontWeight={700}
                  color="text.strong"
                >
                  {job.title}
                </Heading>
                <Wrap spacing={4} fontSize="paragraph-sm" color="text.sub">
                  <HStack spacing={2}>
                    <Icon as={RiMapPinLine} boxSize={4} />
                    <Text>{job.location}</Text>
                  </HStack>
                  <HStack spacing={2}>
                    <Icon as={RiBriefcaseLine} boxSize={4} />
                    <Text>{getStatusLabel(job.employment_type)}</Text>
                  </HStack>
                  <HStack spacing={2}>
                    <Icon as={RiMoneyDollarCircleLine} boxSize={4} />
                    <Text>{formatSalary(job.salary_min, job.salary_max)}</Text>
                  </HStack>
                </Wrap>
              </VStack>

              <VStack spacing={2} display={{ base: "none", md: "flex" }}>
                <Button
                  bg="primary.base"
                  color="white"
                  size="lg"
                  onClick={() =>
                    navigate("/student/jobs", { state: { applyToJob: job } })
                  }
                  rightIcon={<Icon as={RiSendPlaneLine} />}
                  _hover={{ bg: "primary.darker" }}
                >
                  Apply Now
                </Button>
                <HStack spacing={2} w="full">
                  <Button
                    flex={1}
                    variant="outline"
                    leftIcon={
                      <Icon as={isSaved ? RiBookmarkFill : RiBookmarkLine} />
                    }
                    onClick={handleSave}
                    borderColor="stroke.soft"
                    color="text.sub"
                    size="sm"
                  >
                    {isSaved ? "Saved" : "Save"}
                  </Button>
                  <Button
                    flex={1}
                    variant="outline"
                    leftIcon={<Icon as={FaLine} />}
                    onClick={() =>
                      navigate("/student/job-comparison", {
                        state: { selectedJob: job },
                      })
                    }
                    borderColor="stroke.soft"
                    color="text.sub"
                    size="sm"
                  >
                    Analyze
                  </Button>
                </HStack>
              </VStack>
            </HStack>

            {/* Mobile Actions */}
            <VStack spacing={2} display={{ base: "flex", md: "none" }}>
              <Button
                bg="primary.base"
                color="white"
                w="full"
                onClick={() =>
                  navigate("/student/jobs", { state: { applyToJob: job } })
                }
                rightIcon={<Icon as={RiSendPlaneLine} />}
              >
                Apply Now
              </Button>
              <HStack spacing={2} w="full">
                <Button
                  flex={1}
                  variant="outline"
                  leftIcon={
                    <Icon as={isSaved ? RiBookmarkFill : RiBookmarkLine} />
                  }
                  onClick={handleSave}
                >
                  {isSaved ? "Saved" : "Save"}
                </Button>
                <Button
                  flex={1}
                  variant="outline"
                  leftIcon={<Icon as={FaLine} />}
                  onClick={() =>
                    navigate("/student/job-comparison", {
                      state: { selectedJob: job },
                    })
                  }
                >
                  Analyze
                </Button>
              </HStack>
            </VStack>
          </VStack>
        </Box>

        {/* Job Overview */}
        <Box
          bg="bg.white"
          p={6}
          borderRadius="2xl"
          shadow="regular-xs"
          border="1px"
          borderColor="stroke.soft"
        >
          <VStack align="stretch" spacing={4}>
            <Heading fontSize="label-lg" fontWeight={600}>
              Job Overview
            </Heading>
            <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
              <Box>
                <Text fontSize="paragraph-xs" color="text.soft" mb={1}>
                  Department
                </Text>
                <Text fontSize="label-sm" fontWeight={500} color="text.strong">
                  {job.department || "Not specified"}
                </Text>
              </Box>
              <Box>
                <Text fontSize="paragraph-xs" color="text.soft" mb={1}>
                  Experience Level
                </Text>
                <Text fontSize="label-sm" fontWeight={500} color="text.strong">
                  {getStatusLabel(job.experience_level)}
                </Text>
              </Box>
              <Box>
                <Text fontSize="paragraph-xs" color="text.soft" mb={1}>
                  Posted Date
                </Text>
                <HStack spacing={2}>
                  <Icon as={RiCalendarLine} color="text.soft" boxSize={4} />
                  <Text
                    fontSize="label-sm"
                    fontWeight={500}
                    color="text.strong"
                  >
                    {job.posted_date ? formatDate(job.posted_date) : "Recently"}
                  </Text>
                </HStack>
              </Box>
              <Box>
                <Text fontSize="paragraph-xs" color="text.soft" mb={1}>
                  Closing Date
                </Text>
                <HStack spacing={2}>
                  <Icon as={RiCalendarLine} color="text.soft" boxSize={4} />
                  <Text
                    fontSize="label-sm"
                    fontWeight={500}
                    color="text.strong"
                  >
                    {job.closing_date ? formatDate(job.closing_date) : "Open"}
                  </Text>
                </HStack>
              </Box>
            </SimpleGrid>
          </VStack>
        </Box>

        {/* Description */}
        <Box
          bg="bg.white"
          p={6}
          borderRadius="2xl"
          shadow="regular-xs"
          border="1px"
          borderColor="stroke.soft"
        >
          <VStack align="stretch" spacing={4}>
            <Heading fontSize="label-lg" fontWeight={600}>
              Job Description
            </Heading>
            <Text
              fontSize="paragraph-sm"
              color="text.sub"
              whiteSpace="pre-wrap"
              lineHeight="tall"
            >
              {job.description}
            </Text>
          </VStack>
        </Box>

        {/* Requirements */}
        {job.requirements && job.requirements.length > 0 && (
          <Box
            bg="bg.white"
            p={6}
            borderRadius="2xl"
            shadow="regular-xs"
            border="1px"
            borderColor="stroke.soft"
          >
            <VStack align="stretch" spacing={4}>
              <Heading fontSize="label-lg" fontWeight={600}>
                Requirements
              </Heading>
              <List spacing={3}>
                {job.requirements.map((req, index) => (
                  <ListItem key={index}>
                    <HStack align="start" spacing={3}>
                      <Circle size={6} bg="success.lighter">
                        <Icon
                          as={RiCheckboxCircleLine}
                          color="success.base"
                          boxSize={4}
                        />
                      </Circle>
                      <Text fontSize="paragraph-sm" color="text.sub" flex={1}>
                        {req}
                      </Text>
                    </HStack>
                  </ListItem>
                ))}
              </List>
            </VStack>
          </Box>
        )}

        {/* Responsibilities */}
        {job.responsibilities && job.responsibilities.length > 0 && (
          <Box
            bg="bg.white"
            p={6}
            borderRadius="2xl"
            shadow="regular-xs"
            border="1px"
            borderColor="stroke.soft"
          >
            <VStack align="stretch" spacing={4}>
              <Heading fontSize="label-lg" fontWeight={600}>
                Responsibilities
              </Heading>
              <List spacing={3}>
                {job.responsibilities.map((resp, index) => (
                  <ListItem key={index}>
                    <HStack align="start" spacing={3}>
                      <Circle size={6} bg="information.light">
                        <Icon
                          as={RiCheckboxCircleLine}
                          color="information.base"
                          boxSize={4}
                        />
                      </Circle>
                      <Text fontSize="paragraph-sm" color="text.sub" flex={1}>
                        {resp}
                      </Text>
                    </HStack>
                  </ListItem>
                ))}
              </List>
            </VStack>
          </Box>
        )}

        {/* Required Skills */}
        {job.required_skills && job.required_skills.length > 0 && (
          <Box
            bg="bg.white"
            p={6}
            borderRadius="2xl"
            shadow="regular-xs"
            border="1px"
            borderColor="stroke.soft"
          >
            <VStack align="stretch" spacing={4}>
              <Heading fontSize="label-lg" fontWeight={600}>
                Required Skills
              </Heading>
              <Wrap spacing={2}>
                {job.required_skills.map((skill, index) => (
                  <Tag
                    key={index}
                    size="lg"
                    borderRadius="full"
                    bg="feature.light"
                    color="feature.dark"
                    fontSize="label-sm"
                  >
                    {skill.name || skill}
                  </Tag>
                ))}
              </Wrap>
            </VStack>
          </Box>
        )}

        {/* Benefits */}
        {job.benefits && job.benefits.length > 0 && (
          <Box
            bg="bg.white"
            p={6}
            borderRadius="2xl"
            shadow="regular-xs"
            border="1px"
            borderColor="stroke.soft"
          >
            <VStack align="stretch" spacing={4}>
              <Heading fontSize="label-lg" fontWeight={600}>
                Benefits
              </Heading>
              <List spacing={3}>
                {job.benefits.map((benefit, index) => (
                  <ListItem key={index}>
                    <HStack align="start" spacing={3}>
                      <Circle size={6} bg="success.lighter">
                        <Icon
                          as={RiCheckboxCircleLine}
                          color="success.base"
                          boxSize={4}
                        />
                      </Circle>
                      <Text fontSize="paragraph-sm" color="text.sub" flex={1}>
                        {benefit}
                      </Text>
                    </HStack>
                  </ListItem>
                ))}
              </List>
            </VStack>
          </Box>
        )}

        {/* Apply Section */}
        <Box
          bgGradient="linear(135deg, primary.base 0%, feature.base 100%)"
          p={8}
          borderRadius="2xl"
          textAlign="center"
        >
          <VStack spacing={4} color="white">
            <Heading fontSize="title-h5" fontWeight={600}>
              Ready to apply?
            </Heading>
            <Text fontSize="label-md" opacity={0.9}>
              Join our team and take the next step in your career
            </Text>
            <HStack spacing={4} flexWrap="wrap" justify="center" pt={2}>
              <Button
                bg="white"
                color="primary.base"
                size="lg"
                onClick={() =>
                  navigate("/student/jobs", { state: { applyToJob: job } })
                }
                _hover={{ bg: "whiteAlpha.900", transform: "translateY(-2px)" }}
              >
                Apply for this Position
              </Button>
              <Button
                variant="outline"
                borderColor="white"
                color="white"
                size="lg"
                onClick={() =>
                  navigate("/student/job-comparison", {
                    state: { selectedJob: job },
                  })
                }
                _hover={{ bg: "whiteAlpha.200" }}
              >
                Check My Match Score
              </Button>
            </HStack>
          </VStack>
        </Box>
      </VStack>
    </Layout>
  );
};

export default JobDetails;
