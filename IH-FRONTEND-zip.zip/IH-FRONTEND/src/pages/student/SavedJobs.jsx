import {
  Box,
  Heading,
  VStack,
  SimpleGrid,
  Text,
  Button,
  HStack,
  useToast,
  Icon,
  Badge,
  Divider,
  IconButton,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import {
  RiArrowLeftLine,
  RiBookmarkLine,
  RiDeleteBinLine,
  RiMapPinLine,
  RiBriefcaseLine,
} from "react-icons/ri";
import { useNavigate } from "react-router-dom";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { studentEnhancementsAPI } from "../../api/studentEnhancements";
import { formatDate, formatSalary, getStatusLabel } from "../../utils/helpers";

const SavedJobCard = ({ savedJob, onRemove }) => {
  const navigate = useNavigate();
  const { job, saved_at } = savedJob;

  return (
    <Box
      bg="bg.white"
      p={6}
      borderRadius="xl"
      border="1px"
      borderColor="stroke.soft"
      shadow="regular-xs"
      transition="all 0.2s"
      _hover={{
        shadow: "md",
        transform: "translateY(-2px)",
        borderColor: "primary.lighter",
      }}
    >
      <VStack align="stretch" spacing={4}>
        <HStack justify="space-between" align="start">
          <VStack align="start" spacing={1} flex={1}>
            <Text fontSize="label-lg" fontWeight={600} color="text.strong">
              {job.title}
            </Text>
            <HStack spacing={2} fontSize="paragraph-sm" color="text.sub">
              <Icon as={RiMapPinLine} boxSize={4} />
              <Text>{job.location}</Text>
              <Text>•</Text>
              <Text>{getStatusLabel(job.employment_type)}</Text>
            </HStack>
          </VStack>
          <IconButton
            icon={<Icon as={RiDeleteBinLine} />}
            variant="ghost"
            colorScheme="red"
            size="sm"
            onClick={() => onRemove(savedJob.saved_id)}
            aria-label="Remove"
          />
        </HStack>

        <Text fontSize="paragraph-sm" color="text.sub" noOfLines={3}>
          {job.description}
        </Text>

        <Divider />

        <HStack
          justify="space-between"
          fontSize="paragraph-sm"
          color="text.soft"
        >
          <HStack spacing={2}>
            <Icon as={RiBookmarkLine} />
            <Text>Saved {formatDate(saved_at)}</Text>
          </HStack>
          {job.salary_min && (
            <Text fontWeight={500} color="text.sub">
              {formatSalary(job.salary_min, job.salary_max)}
            </Text>
          )}
        </HStack>

        <HStack spacing={2}>
          <Button
            flex={1}
            bg="primary.base"
            color="white"
            size="sm"
            onClick={() => navigate(`/student/jobs/${job.id}`)}
            _hover={{ bg: "primary.darker" }}
          >
            View Details
          </Button>
          <Button
            flex={1}
            variant="outline"
            borderColor="stroke.soft"
            size="sm"
            onClick={() =>
              navigate("/student/job-comparison", {
                state: { selectedJob: job },
              })
            }
          >
            Analyze Match
          </Button>
        </HStack>
      </VStack>
    </Box>
  );
};

const SavedJobs = () => {
  const [savedJobs, setSavedJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    fetchSavedJobs();
  }, []);

  const fetchSavedJobs = async () => {
    try {
      const data = await studentEnhancementsAPI.getSavedJobs();
      setSavedJobs(data);
    } catch (error) {
      console.error("Failed to fetch saved jobs:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (savedId) => {
    try {
      const savedJob = savedJobs.find((s) => s.saved_id === savedId);
      await studentEnhancementsAPI.unsaveJob(savedJob.job.id);
      setSavedJobs(savedJobs.filter((s) => s.saved_id !== savedId));
      toast({
        title: "Job removed from saved",
        status: "success",
        duration: 2000,
      });
    } catch (error) {
      toast({
        title: "Failed to remove job",
        description: "Please try again",
        status: "error",
        duration: 3000,
      });
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        <HStack>
          <Button
            variant="ghost"
            leftIcon={<Icon as={RiArrowLeftLine} />}
            onClick={() => navigate("/student/jobs")}
            color="text.sub"
          >
            Back to Jobs
          </Button>
        </HStack>

        <HStack justify="space-between">
          <VStack align="start" spacing={1}>
            <Heading size="lg" fontWeight={600}>
              Saved Jobs
            </Heading>
            <Text fontSize="paragraph-sm" color="text.sub">
              {savedJobs.length} {savedJobs.length === 1 ? "job" : "jobs"} saved
              for later
            </Text>
          </VStack>
          <Badge
            bg="primary.alpha.10"
            color="primary.base"
            px={3}
            py={1}
            borderRadius="full"
            fontSize="label-sm"
          >
            {savedJobs.length} Saved
          </Badge>
        </HStack>

        {savedJobs.length === 0 ? (
          <Box
            bg="bg.white"
            p={12}
            borderRadius="2xl"
            textAlign="center"
            border="1px"
            borderColor="stroke.soft"
          >
            <VStack spacing={4}>
              <Icon as={RiBookmarkLine} boxSize={16} color="text.soft" />
              <Heading size="md" color="text.sub" fontWeight={600}>
                No saved jobs yet
              </Heading>
              <Text color="text.sub" maxW="md">
                Start saving jobs to keep track of opportunities you're
                interested in
              </Text>
              <Button
                bg="primary.base"
                color="white"
                size="lg"
                onClick={() => navigate("/student/jobs")}
                leftIcon={<Icon as={RiBriefcaseLine} />}
              >
                Browse Jobs
              </Button>
            </VStack>
          </Box>
        ) : (
          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
            {savedJobs.map((savedJob) => (
              <SavedJobCard
                key={savedJob.saved_id}
                savedJob={savedJob}
                onRemove={handleRemove}
              />
            ))}
          </SimpleGrid>
        )}
      </VStack>
    </Layout>
  );
};

export default SavedJobs;
