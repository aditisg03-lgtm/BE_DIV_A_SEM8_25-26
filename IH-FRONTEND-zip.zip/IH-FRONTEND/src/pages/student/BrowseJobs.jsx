import {
  Box,
  Heading,
  VStack,
  SimpleGrid,
  Input,
  InputGroup,
  InputLeftElement,
  Icon,
  useToast,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Button,
  Select,
  useDisclosure,
  Alert,
  AlertIcon,
  AlertDescription,
  Text,
  HStack,
  Badge,
  IconButton,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Divider,
  Wrap,
  Tag,
  Circle,
  Flex,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import {
  RiSearchLine,
  RiBookmarkLine,
  RiBookmarkFill,
  RiEyeOffLine,
  // RiMoreVertical2Line,
  // RiTargetLine,
  RiExternalLinkLine,
  RiSendPlaneLine,
  RiMapPinLine,
  RiBriefcaseLine,
  RiMoneyDollarCircleLine,
  RiCalendarLine,
  RiFilterLine,
} from "react-icons/ri";
import { useNavigate } from "react-router-dom";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { jobAPI } from "../../api/job";
import { applicationAPI } from "../../api/application";
import { resumeAPI } from "../../api/resume";
import { studentAPI } from "../../api/student";
import { studentEnhancementsAPI } from "../../api/studentEnhancements";
import { formatDate, formatSalary, getStatusLabel } from "../../utils/helpers";
import { FaLine } from "react-icons/fa";

const JobCard = ({ job, onApply, onSave, onHide, onAnalyze, isSaved }) => {
  const navigate = useNavigate();

  return (
    <Box
      bg="bg.white"
      p={6}
      borderRadius="2xl"
      shadow="regular-xs"
      border="1px"
      borderColor="stroke.soft"
      transition="all 0.2s"
      _hover={{
        shadow: "md",
        transform: "translateY(-2px)",
        borderColor: "primary.lighter",
      }}
    >
      <VStack align="stretch" spacing={4}>
        {/* Header */}
        <HStack justify="space-between" align="start">
          <VStack align="start" spacing={2} flex={1}>
            <Heading
              fontSize="label-lg"
              fontWeight={600}
              color="text.strong"
              noOfLines={2}
            >
              {job.title}
            </Heading>
            <Wrap spacing={3} fontSize="paragraph-sm" color="text.sub">
              <HStack spacing={1}>
                <Icon as={RiMapPinLine} boxSize={4} />
                <Text>{job.location}</Text>
              </HStack>
              <HStack spacing={1}>
                <Icon as={RiBriefcaseLine} boxSize={4} />
                <Text>{getStatusLabel(job.employment_type)}</Text>
              </HStack>
            </Wrap>
          </VStack>

          <Menu>
            <MenuButton
              as={IconButton}
              icon={<Icon as={FaLine} />}
              variant="ghost"
              size="sm"
              color="text.sub"
              _hover={{ bg: "bg.weak" }}
            />
            <MenuList
              borderRadius="xl"
              shadow="md"
              border="1px"
              borderColor="stroke.soft"
            >
              <MenuItem
                icon={<Icon as={FaLine} />}
                onClick={() => onAnalyze?.(job)}
                fontSize="label-sm"
                borderRadius="md"
              >
                Analyze Match
              </MenuItem>
              <MenuItem
                icon={<Icon as={isSaved ? RiBookmarkFill : RiBookmarkLine} />}
                onClick={() => onSave?.(job.id)}
                fontSize="label-sm"
                borderRadius="md"
              >
                {isSaved ? "Unsave Job" : "Save Job"}
              </MenuItem>
              <MenuItem
                icon={<Icon as={RiEyeOffLine} />}
                onClick={() => onHide?.(job.id)}
                fontSize="label-sm"
                color="error.base"
                borderRadius="md"
              >
                Hide Job
              </MenuItem>
            </MenuList>
          </Menu>
        </HStack>

        {/* Description */}
        <Text
          fontSize="paragraph-sm"
          color="text.sub"
          noOfLines={3}
          lineHeight="tall"
        >
          {job.description}
        </Text>

        {/* Skills */}
        {job.required_skills && job.required_skills.length > 0 && (
          <Wrap spacing={2}>
            {job.required_skills.slice(0, 5).map((skill, index) => (
              <Tag
                key={index}
                size="sm"
                borderRadius="full"
                bg="feature.light"
                color="feature.dark"
                fontSize="label-xs"
              >
                {skill.name || skill}
              </Tag>
            ))}
            {job.required_skills.length > 5 && (
              <Tag
                size="sm"
                borderRadius="full"
                bg="bg.weak"
                color="text.soft"
                fontSize="label-xs"
              >
                +{job.required_skills.length - 5} more
              </Tag>
            )}
          </Wrap>
        )}

        <Divider />

        {/* Footer */}
        <HStack justify="space-between" fontSize="paragraph-sm">
          <HStack spacing={2} color="text.sub">
            <Icon as={RiMoneyDollarCircleLine} boxSize={4} />
            <Text fontWeight={500}>
              {formatSalary(job.salary_min, job.salary_max)}
            </Text>
          </HStack>
          {job.posted_date && (
            <HStack spacing={2} color="text.soft" fontSize="paragraph-xs">
              <Icon as={RiCalendarLine} boxSize={4} />
              <Text>{formatDate(job.posted_date)}</Text>
            </HStack>
          )}
        </HStack>

        {/* Actions */}
        <HStack spacing={2}>
          <Button
            flex={1}
            variant="outline"
            size="sm"
            onClick={() => navigate(`/student/jobs/${job.id}`)}
            leftIcon={<Icon as={RiExternalLinkLine} />}
            borderColor="stroke.soft"
            color="text.sub"
            _hover={{
              borderColor: "primary.base",
              color: "primary.base",
              bg: "primary.alpha.10",
            }}
          >
            View Details
          </Button>
          <Button
            flex={1}
            bg="primary.base"
            color="white"
            size="sm"
            onClick={() => onApply?.(job)}
            leftIcon={<Icon as={RiSendPlaneLine} />}
            _hover={{ bg: "primary.darker" }}
          >
            Apply Now
          </Button>
        </HStack>
      </VStack>
    </Box>
  );
};

const BrowseJobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedJob, setSelectedJob] = useState(null);
  const [resumes, setResumes] = useState([]);
  const [selectedResume, setSelectedResume] = useState("");
  const [applying, setApplying] = useState(false);
  const [hasProfile, setHasProfile] = useState(true);
  const [savedJobs, setSavedJobs] = useState([]);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    checkProfileAndFetchData();
  }, []);

  const checkProfileAndFetchData = async () => {
    try {
      await studentAPI.getProfile();
      setHasProfile(true);
      await fetchJobs();
      await fetchResumes();
      await fetchSavedJobs();
    } catch (error) {
      if (error.response?.status === 404) {
        setHasProfile(false);
      }
      setLoading(false);
    }
  };

  const fetchJobs = async () => {
    try {
      const data = await jobAPI.getAll({ status_filter: "active" });
      setJobs(data);
    } catch (error) {
      console.error("Failed to fetch jobs:", error);
      toast({
        title: "Failed to load jobs",
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchResumes = async () => {
    try {
      const data = await resumeAPI.getAll();
      setResumes(data);
      if (data.length > 0) {
        setSelectedResume(data[0].id);
      }
    } catch (error) {
      console.error("Failed to fetch resumes:", error);
    }
  };

  const fetchSavedJobs = async () => {
    try {
      const data = await studentEnhancementsAPI.getSavedJobs();
      setSavedJobs(data.map((s) => s.job.id));
    } catch (error) {
      console.error("Failed to fetch saved jobs:", error);
    }
  };

  const handleApply = (job) => {
    if (!hasProfile) {
      toast({
        title: "Profile Required",
        description: "Please complete your profile first",
        status: "warning",
        duration: 3000,
      });
      navigate("/student/profile");
      return;
    }

    if (resumes.length === 0) {
      toast({
        title: "Resume Required",
        description: "Please upload a resume first",
        status: "warning",
        duration: 3000,
      });
      navigate("/student/resumes");
      return;
    }

    setSelectedJob(job);
    onOpen();
  };

  const handleSubmitApplication = async () => {
    if (!selectedResume) {
      toast({
        title: "No resume selected",
        description: "Please select a resume to apply",
        status: "warning",
        duration: 3000,
      });
      return;
    }

    setApplying(true);
    try {
      await applicationAPI.apply({
        job_description_id: selectedJob.id,
        resume_id: selectedResume,
      });
      toast({
        title: "Application submitted successfully",
        status: "success",
        duration: 3000,
      });
      onClose();
    } catch (error) {
      toast({
        title: "Application failed",
        description:
          error.response?.data?.detail || "Failed to submit application",
        status: "error",
        duration: 3000,
      });
    } finally {
      setApplying(false);
    }
  };

  const handleSaveJob = async (jobId) => {
    try {
      if (savedJobs.includes(jobId)) {
        await studentEnhancementsAPI.unsaveJob(jobId);
        setSavedJobs(savedJobs.filter((id) => id !== jobId));
        toast({
          title: "Job removed from saved",
          status: "info",
          duration: 2000,
        });
      } else {
        await studentEnhancementsAPI.saveJob(jobId);
        setSavedJobs([...savedJobs, jobId]);
        toast({
          title: "Job saved successfully",
          status: "success",
          duration: 2000,
        });
      }
    } catch (error) {
      toast({
        title: "Action failed",
        description: error.response?.data?.detail,
        status: "error",
        duration: 3000,
      });
    }
  };

  const handleHideJob = async (jobId) => {
    try {
      await studentEnhancementsAPI.hideJob(jobId);
      setJobs(jobs.filter((j) => j.id !== jobId));
      toast({
        title: "Job hidden successfully",
        description: "This job will no longer appear in your feed",
        status: "success",
        duration: 2000,
      });
    } catch (error) {
      toast({
        title: "Failed to hide job",
        description: error.response?.data?.detail,
        status: "error",
        duration: 3000,
      });
    }
  };

  const handleAnalyzeJob = (job) => {
    navigate("/student/job-comparison", { state: { selectedJob: job } });
  };

  const filteredJobs = jobs.filter(
    (job) =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        {/* Header */}
        <HStack justify="space-between" flexWrap="wrap" gap={4}>
          <VStack align="start" spacing={1}>
            <Heading fontSize="title-h4" fontWeight={700} color="text.strong">
              Discover Opportunities
            </Heading>
            <Text fontSize="paragraph-sm" color="text.sub">
              Find your perfect job match
            </Text>
          </VStack>
          <Button
            bg="feature.base"
            color="white"
            onClick={() => navigate("/student/jobs/saved")}
            leftIcon={<Icon as={RiBookmarkLine} />}
            _hover={{ bg: "feature.dark" }}
          >
            Saved Jobs ({savedJobs.length})
          </Button>
        </HStack>

        {/* Profile Alert */}
        {!hasProfile && (
          <Alert
            status="warning"
            borderRadius="xl"
            bg="warning.lighter"
            border="1px"
            borderColor="warning.base"
          >
            <AlertIcon color="warning.base" />
            <VStack align="start" spacing={0} flex={1}>
              <Text fontWeight={600} color="warning.dark">
                Complete your profile to start applying
              </Text>
              <AlertDescription color="text.sub">
                <Button
                  size="sm"
                  variant="link"
                  colorScheme="orange"
                  onClick={() => navigate("/student/profile")}
                >
                  Go to Profile
                </Button>
              </AlertDescription>
            </VStack>
          </Alert>
        )}

        {/* Search and Filters */}
        <Box
          bg="bg.white"
          p={6}
          borderRadius="2xl"
          shadow="regular-xs"
          border="1px"
          borderColor="stroke.soft"
        >
          <HStack spacing={3} flexWrap="wrap">
            <InputGroup flex={1} minW="250px">
              <InputLeftElement h={12}>
                <Icon as={RiSearchLine} color="text.soft" boxSize={5} />
              </InputLeftElement>
              <Input
                placeholder="Search jobs by title, description, or location..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                bg="bg.weak"
                borderColor="stroke.soft"
                h={12}
                fontSize="paragraph-sm"
                _hover={{ borderColor: "primary.lighter" }}
                _focus={{
                  borderColor: "primary.base",
                  boxShadow: "button-primary-focus",
                }}
              />
            </InputGroup>
            <Button
              leftIcon={<Icon as={RiFilterLine} />}
              variant="outline"
              borderColor="stroke.soft"
              h={12}
              display={{ base: "none", md: "flex" }}
            >
              Filters
            </Button>
          </HStack>
        </Box>

        {/* Results Count */}
        {filteredJobs.length > 0 && (
          <HStack justify="space-between" px={2}>
            <Text fontSize="paragraph-sm" color="text.sub">
              Showing{" "}
              <Text as="span" fontWeight={600} color="text.strong">
                {filteredJobs.length}
              </Text>{" "}
              job{filteredJobs.length !== 1 ? "s" : ""}
            </Text>
            <HStack spacing={2} display={{ base: "none", md: "flex" }}>
              <Text fontSize="paragraph-xs" color="text.soft">
                Sort by:
              </Text>
              <Select
                size="sm"
                w="150px"
                borderColor="stroke.soft"
                fontSize="paragraph-sm"
              >
                <option>Most Recent</option>
                <option>Best Match</option>
                <option>Salary: High to Low</option>
              </Select>
            </HStack>
          </HStack>
        )}

        {/* Jobs Grid */}
        {filteredJobs.length === 0 ? (
          <Box
            bg="bg.white"
            p={12}
            borderRadius="2xl"
            textAlign="center"
            border="1px"
            borderColor="stroke.soft"
          >
            <Circle size={20} bg="primary.alpha.10" mx="auto" mb={4}>
              <Icon as={RiBriefcaseLine} boxSize={10} color="primary.base" />
            </Circle>
            <Heading
              fontSize="label-lg"
              fontWeight={600}
              mb={2}
              color="text.strong"
            >
              No jobs found
            </Heading>
            <Text fontSize="paragraph-sm" color="text.sub" mb={4}>
              Try adjusting your search criteria or filters
            </Text>
            {searchTerm && (
              <Button
                variant="outline"
                borderColor="stroke.soft"
                onClick={() => setSearchTerm("")}
              >
                Clear Search
              </Button>
            )}
          </Box>
        ) : (
          <SimpleGrid columns={{ base: 1, lg: 2, xl: 3 }} spacing={6}>
            {filteredJobs.map((job) => (
              <JobCard
                key={job.id}
                job={job}
                onApply={handleApply}
                onSave={handleSaveJob}
                onHide={handleHideJob}
                onAnalyze={handleAnalyzeJob}
                isSaved={savedJobs.includes(job.id)}
              />
            ))}
          </SimpleGrid>
        )}
      </VStack>

      {/* Apply Modal */}
      <Modal isOpen={isOpen} onClose={onClose} isCentered>
        <ModalOverlay bg="blackAlpha.600" backdropFilter="blur(10px)" />
        <ModalContent borderRadius="2xl">
          <ModalHeader borderBottomWidth={1} borderColor="stroke.soft">
            <VStack align="start" spacing={1}>
              <Text fontSize="label-lg" fontWeight={600}>
                Apply to {selectedJob?.title}
              </Text>
              <Text fontSize="paragraph-sm" color="text.sub" fontWeight={400}>
                Select your resume to submit
              </Text>
            </VStack>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6} pt={6}>
            <VStack spacing={4}>
              {resumes.length === 0 ? (
                <Box textAlign="center" py={4}>
                  <Circle size={16} bg="warning.lighter" mx="auto" mb={4}>
                    <Icon
                      as={RiBriefcaseLine}
                      boxSize={8}
                      color="warning.base"
                    />
                  </Circle>
                  <Text
                    fontSize="label-md"
                    fontWeight={600}
                    mb={2}
                    color="text.strong"
                  >
                    No resumes uploaded
                  </Text>
                  <Text fontSize="paragraph-sm" color="text.sub" mb={4}>
                    Upload a resume to start applying
                  </Text>
                  <Button
                    bg="primary.base"
                    color="white"
                    onClick={() => navigate("/student/resumes")}
                    _hover={{ bg: "primary.darker" }}
                  >
                    Upload Resume
                  </Button>
                </Box>
              ) : (
                <>
                  <Select
                    value={selectedResume}
                    onChange={(e) => setSelectedResume(e.target.value)}
                    size="lg"
                    bg="bg.weak"
                    borderColor="stroke.soft"
                    _hover={{ borderColor: "primary.lighter" }}
                  >
                    {resumes.map((resume) => (
                      <option key={resume.id} value={resume.id}>
                        {resume.file_name} (ATS:{" "}
                        {resume.ats_score?.toFixed(1) || "N/A"}%)
                      </option>
                    ))}
                  </Select>
                  <Button
                    bg="primary.base"
                    color="white"
                    w="full"
                    size="lg"
                    onClick={handleSubmitApplication}
                    isLoading={applying}
                    loadingText="Submitting..."
                    rightIcon={<Icon as={RiSendPlaneLine} />}
                    _hover={{ bg: "primary.darker" }}
                  >
                    Submit Application
                  </Button>
                </>
              )}
            </VStack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </Layout>
  );
};

export default BrowseJobs;
