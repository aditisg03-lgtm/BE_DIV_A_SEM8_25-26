import {
  Box,
  Heading,
  VStack,
  SimpleGrid,
  Text,
  Button,
  HStack,
  Badge,
  Icon,
  useToast,
  Progress,
  Divider,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Wrap,
  Tag,
  Circle,
  Flex,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import {
  RiFileTextLine,
  RiDeleteBinLine,
  // RiRefreshCwLine,
  RiEyeLine,
  RiDownloadLine,
  RiSparklingFill,
  RiCheckboxCircleLine,
  RiAlertLine,
  RiLightbulbLine,
} from "react-icons/ri";
import { useNavigate } from "react-router-dom";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import ResumeUpload from "../../components/student/ResumeUpload";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { resumeAPI } from "../../api/resume";
import { studentAPI } from "../../api/student";
import { formatDate, getATSScoreColor } from "../../utils/helpers";
import { studentEnhancementsAPI } from "../../api/studentEnhancements";
import { BiRefresh } from "react-icons/bi";

const AnalysisDetailsModal = ({ isOpen, onClose, analysis }) => {
  if (!analysis) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="4xl" scrollBehavior="inside">
      <ModalOverlay bg="blackAlpha.600" backdropFilter="blur(10px)" />
      <ModalContent borderRadius="2xl" maxH="90vh">
        <ModalHeader borderBottomWidth={1} borderColor="stroke.soft">
          <HStack spacing={3}>
            <Circle size={12} bg="information.light">
              <Icon as={RiFileTextLine} boxSize={6} color="information.base" />
            </Circle>
            <VStack align="start" spacing={0}>
              <Heading fontSize="label-lg" fontWeight={600}>
                Resume Analysis Details
              </Heading>
              <Text fontSize="paragraph-sm" color="text.sub" fontWeight={400}>
                AI-powered insights and recommendations
              </Text>
            </VStack>
          </HStack>
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <VStack spacing={6} align="stretch">
            {/* Score Cards */}
            <SimpleGrid columns={{ base: 1, md: 3 }} spacing={4}>
              <Box
                p={5}
                bg="information.light"
                borderRadius="xl"
                border="1px"
                borderColor="information.base"
              >
                <VStack spacing={3} align="stretch">
                  <Text fontSize="paragraph-sm" color="text.sub">
                    ATS Score
                  </Text>
                  <Progress
                    value={analysis.ats_score}
                    h={2}
                    borderRadius="full"
                    bg="bg.soft"
                    sx={{
                      "& > div": {
                        bg: "information.base",
                      },
                    }}
                  />
                  <Text
                    fontSize="title-h4"
                    fontWeight={700}
                    color="information.base"
                  >
                    {analysis.ats_score?.toFixed(1)}%
                  </Text>
                </VStack>
              </Box>

              <Box
                p={5}
                bg="feature.light"
                borderRadius="xl"
                border="1px"
                borderColor="feature.base"
              >
                <VStack spacing={3} align="stretch">
                  <Text fontSize="paragraph-sm" color="text.sub">
                    Keyword Match
                  </Text>
                  <Progress
                    value={analysis.keyword_match_percentage || 0}
                    h={2}
                    borderRadius="full"
                    bg="bg.soft"
                    sx={{
                      "& > div": {
                        bg: "feature.base",
                      },
                    }}
                  />
                  <Text
                    fontSize="title-h4"
                    fontWeight={700}
                    color="feature.base"
                  >
                    {analysis.keyword_match_percentage?.toFixed(1) || 0}%
                  </Text>
                </VStack>
              </Box>

              <Box
                p={5}
                bg="success.lighter"
                borderRadius="xl"
                border="1px"
                borderColor="success.base"
              >
                <VStack spacing={3} align="stretch">
                  <Text fontSize="paragraph-sm" color="text.sub">
                    Skills Match
                  </Text>
                  <Progress
                    value={analysis.skills_match?.match_percentage || 0}
                    h={2}
                    borderRadius="full"
                    bg="bg.soft"
                    sx={{
                      "& > div": {
                        bg: "success.base",
                      },
                    }}
                  />
                  <Text
                    fontSize="title-h4"
                    fontWeight={700}
                    color="success.base"
                  >
                    {analysis.skills_match?.match_percentage?.toFixed(1) || 0}%
                  </Text>
                </VStack>
              </Box>
            </SimpleGrid>

            <Divider />

            {/* Tabs */}
            <Tabs colorScheme="primary">
              <TabList borderColor="stroke.soft">
                <Tab>Overview</Tab>
                <Tab>Strengths</Tab>
                <Tab>Improvements</Tab>
                <Tab>Skills</Tab>
              </TabList>

              <TabPanels>
                <TabPanel px={0}>
                  <VStack align="stretch" spacing={4}>
                    <Box>
                      <Text fontSize="label-md" fontWeight={600} mb={2}>
                        Overall Feedback
                      </Text>
                      <Text
                        fontSize="paragraph-sm"
                        color="text.sub"
                        lineHeight="tall"
                      >
                        {analysis.overall_feedback}
                      </Text>
                    </Box>

                    {analysis.education_match && (
                      <Box
                        p={4}
                        bg="bg.weak"
                        borderRadius="xl"
                        border="1px"
                        borderColor="stroke.soft"
                      >
                        <Text fontSize="label-sm" fontWeight={600} mb={2}>
                          Education
                        </Text>
                        <HStack spacing={4} flexWrap="wrap" mb={2}>
                          <Badge
                            bg={`${getATSScoreColor(
                              analysis.education_match.score
                            )}.lighter`}
                            color={`${getATSScoreColor(
                              analysis.education_match.score
                            )}.base`}
                            fontSize="label-xs"
                            px={3}
                            py={1}
                            borderRadius="md"
                          >
                            Score: {analysis.education_match.score}%
                          </Badge>
                          <Text fontSize="paragraph-sm" color="text.sub">
                            <strong>Degree:</strong>{" "}
                            {analysis.education_match.degree || "Not specified"}
                          </Text>
                          <Text fontSize="paragraph-sm" color="text.sub">
                            <strong>Field:</strong>{" "}
                            {analysis.education_match.field || "Not specified"}
                          </Text>
                        </HStack>
                        {analysis.education_match.feedback && (
                          <Text fontSize="paragraph-sm" color="text.sub">
                            {analysis.education_match.feedback}
                          </Text>
                        )}
                      </Box>
                    )}

                    {analysis.experience_match && (
                      <Box
                        p={4}
                        bg="bg.weak"
                        borderRadius="xl"
                        border="1px"
                        borderColor="stroke.soft"
                      >
                        <Text fontSize="label-sm" fontWeight={600} mb={2}>
                          Experience
                        </Text>
                        <HStack spacing={4} mb={2}>
                          <Badge
                            bg={`${getATSScoreColor(
                              analysis.experience_match.score
                            )}.lighter`}
                            color={`${getATSScoreColor(
                              analysis.experience_match.score
                            )}.base`}
                            fontSize="label-xs"
                            px={3}
                            py={1}
                            borderRadius="md"
                          >
                            Score: {analysis.experience_match.score}%
                          </Badge>
                          {analysis.experience_match.years_of_experience && (
                            <Text fontSize="paragraph-sm" color="text.sub">
                              <strong>Years:</strong>{" "}
                              {analysis.experience_match.years_of_experience}
                            </Text>
                          )}
                        </HStack>
                        {analysis.experience_match.feedback && (
                          <Text fontSize="paragraph-sm" color="text.sub">
                            {analysis.experience_match.feedback}
                          </Text>
                        )}
                      </Box>
                    )}
                  </VStack>
                </TabPanel>

                <TabPanel px={0}>
                  <VStack align="stretch" spacing={3}>
                    <HStack spacing={2} mb={2}>
                      <Circle size={8} bg="success.lighter">
                        <Icon
                          as={RiCheckboxCircleLine}
                          color="success.base"
                          boxSize={4}
                        />
                      </Circle>
                      <Text
                        fontSize="label-md"
                        fontWeight={600}
                        color="success.base"
                      >
                        Key Strengths
                      </Text>
                    </HStack>
                    {analysis.strengths && analysis.strengths.length > 0 ? (
                      analysis.strengths.map((strength, index) => (
                        <Box
                          key={index}
                          p={4}
                          bg="success.lighter"
                          borderRadius="xl"
                          borderLeft="4px"
                          borderColor="success.base"
                        >
                          <Text fontSize="paragraph-sm" color="text.sub">
                            • {strength}
                          </Text>
                        </Box>
                      ))
                    ) : (
                      <Text fontSize="paragraph-sm" color="text.soft">
                        No strengths data available
                      </Text>
                    )}
                  </VStack>
                </TabPanel>

                <TabPanel px={0}>
                  <VStack align="stretch" spacing={4}>
                    <Box>
                      <HStack spacing={2} mb={3}>
                        <Circle size={8} bg="warning.lighter">
                          <Icon
                            as={RiAlertLine}
                            color="warning.base"
                            boxSize={4}
                          />
                        </Circle>
                        <Text
                          fontSize="label-md"
                          fontWeight={600}
                          color="warning.base"
                        >
                          Areas for Improvement
                        </Text>
                      </HStack>
                      {analysis.weaknesses && analysis.weaknesses.length > 0 ? (
                        <VStack align="stretch" spacing={2}>
                          {analysis.weaknesses.map((weakness, index) => (
                            <Box
                              key={index}
                              p={4}
                              bg="warning.lighter"
                              borderRadius="xl"
                              borderLeft="4px"
                              borderColor="warning.base"
                            >
                              <Text fontSize="paragraph-sm" color="text.sub">
                                • {weakness}
                              </Text>
                            </Box>
                          ))}
                        </VStack>
                      ) : (
                        <Text fontSize="paragraph-sm" color="text.soft">
                          No weaknesses identified
                        </Text>
                      )}
                    </Box>

                    <Divider />

                    <Box>
                      <HStack spacing={2} mb={3}>
                        <Circle size={8} bg="information.light">
                          <Icon
                            as={RiLightbulbLine}
                            color="information.base"
                            boxSize={4}
                          />
                        </Circle>
                        <Text
                          fontSize="label-md"
                          fontWeight={600}
                          color="information.base"
                        >
                          Improvement Suggestions
                        </Text>
                      </HStack>
                      {analysis.improvement_suggestions &&
                      analysis.improvement_suggestions.length > 0 ? (
                        <VStack align="stretch" spacing={2}>
                          {analysis.improvement_suggestions.map(
                            (suggestion, index) => (
                              <Box
                                key={index}
                                p={4}
                                bg="information.light"
                                borderRadius="xl"
                                borderLeft="4px"
                                borderColor="information.base"
                              >
                                <Text fontSize="paragraph-sm" color="text.sub">
                                  {index + 1}. {suggestion}
                                </Text>
                              </Box>
                            )
                          )}
                        </VStack>
                      ) : (
                        <Text fontSize="paragraph-sm" color="text.soft">
                          No suggestions available
                        </Text>
                      )}
                    </Box>
                  </VStack>
                </TabPanel>

                <TabPanel px={0}>
                  <VStack align="stretch" spacing={4}>
                    {analysis.skills_match && (
                      <>
                        {analysis.skills_match.matched_skills?.length > 0 && (
                          <Box>
                            <Text
                              fontSize="label-sm"
                              fontWeight={600}
                              color="success.base"
                              mb={2}
                            >
                              ✓ Matched Skills
                            </Text>
                            <Wrap spacing={2}>
                              {analysis.skills_match.matched_skills.map(
                                (skill, index) => (
                                  <Tag
                                    key={index}
                                    size="md"
                                    colorScheme="green"
                                    borderRadius="full"
                                  >
                                    {skill}
                                  </Tag>
                                )
                              )}
                            </Wrap>
                          </Box>
                        )}
                        {analysis.skills_match.missing_skills?.length > 0 && (
                          <Box>
                            <Text
                              fontSize="label-sm"
                              fontWeight={600}
                              color="error.base"
                              mb={2}
                            >
                              ✗ Missing Skills
                            </Text>
                            <Wrap spacing={2}>
                              {analysis.skills_match.missing_skills.map(
                                (skill, index) => (
                                  <Tag
                                    key={index}
                                    size="md"
                                    colorScheme="red"
                                    borderRadius="full"
                                  >
                                    {skill}
                                  </Tag>
                                )
                              )}
                            </Wrap>
                          </Box>
                        )}
                      </>
                    )}
                  </VStack>
                </TabPanel>
              </TabPanels>
            </Tabs>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

const ResumeCard = ({
  resume,
  onDelete,
  onAnalyze,
  analyzing,
  onViewAnalysis,
  onImprove,
  improving,
}) => {
  const [showConfirm, setShowConfirm] = useState(false);
  const [improvedResume, setImprovedResume] = useState(null);
  const [downloading, setDownloading] = useState(false);
  const toast = useToast();

  useEffect(() => {
    checkImprovedVersion();
  }, [resume.id]);

  const checkImprovedVersion = async () => {
    try {
      const improved = await studentEnhancementsAPI.getImprovedResume(
        resume.id
      );
      setImprovedResume(improved);
    } catch (error) {
      setImprovedResume(null);
    }
  };

  const handleDownloadImproved = async () => {
    setDownloading(true);
    try {
      const blob = await studentEnhancementsAPI.downloadImprovedResume(
        improvedResume.id
      );

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = improvedResume.file_name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Downloaded Successfully",
        description: improvedResume.file_name,
        status: "success",
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Please try again",
        status: "error",
        duration: 3000,
      });
    } finally {
      setDownloading(false);
    }
  };

  return (
    <>
      <Box
        bg="bg.white"
        p={6}
        borderRadius="2xl"
        shadow="regular-xs"
        border="1px"
        borderColor="stroke.soft"
        transition="all 0.2s"
        _hover={{ shadow: "md", transform: "translateY(-2px)" }}
      >
        <VStack align="stretch" spacing={4}>
          <HStack justify="space-between">
            <HStack spacing={3}>
              <Circle size={12} bg="primary.alpha.10">
                <Icon as={RiFileTextLine} boxSize={6} color="primary.base" />
              </Circle>
              <VStack align="start" spacing={0}>
                <Text
                  fontSize="label-md"
                  fontWeight={600}
                  noOfLines={1}
                  color="text.strong"
                >
                  {resume.file_name}
                </Text>
                <Text fontSize="paragraph-xs" color="text.soft">
                  {(resume.file_size / 1024).toFixed(2)} KB
                </Text>
              </VStack>
            </HStack>
            {resume.ats_score && (
              <Badge
                bg={`${getATSScoreColor(resume.ats_score)}.lighter`}
                color={`${getATSScoreColor(resume.ats_score)}.base`}
                fontSize="label-sm"
                px={3}
                py={2}
                borderRadius="full"
                fontWeight={600}
              >
                {resume.ats_score.toFixed(1)}%
              </Badge>
            )}
          </HStack>

          {resume.ats_score && (
            <Box>
              <HStack justify="space-between" mb={2}>
                <Text fontSize="paragraph-sm" color="text.sub">
                  ATS Score
                </Text>
                <Text
                  fontSize="paragraph-sm"
                  fontWeight={600}
                  color={`${getATSScoreColor(resume.ats_score)}.base`}
                >
                  {resume.ats_score.toFixed(1)}%
                </Text>
              </HStack>
              <Progress
                value={resume.ats_score}
                h={2}
                borderRadius="full"
                bg="bg.soft"
                sx={{
                  "& > div": {
                    bg: `${getATSScoreColor(resume.ats_score)}.base`,
                  },
                }}
              />
            </Box>
          )}

          {improvedResume && (
            <Box
              bg="success.lighter"
              p={4}
              borderRadius="xl"
              border="1px"
              borderColor="success.base"
            >
              <VStack align="stretch" spacing={3}>
                <HStack justify="space-between">
                  <VStack align="start" spacing={1}>
                    <HStack spacing={2}>
                      <Icon
                        as={RiSparklingFill}
                        color="success.base"
                        boxSize={4}
                      />
                      <Text
                        fontSize="label-sm"
                        fontWeight={600}
                        color="success.base"
                      >
                        AI-Improved Version Ready
                      </Text>
                    </HStack>
                    <Text fontSize="paragraph-xs" color="text.sub">
                      Score: {improvedResume.ats_score_before?.toFixed(1)}% →{" "}
                      <Text
                        as="span"
                        fontWeight={700}
                        fontSize="paragraph-sm"
                        color="success.base"
                      >
                        {improvedResume.ats_score_after?.toFixed(1)}%
                      </Text>
                    </Text>
                  </VStack>
                </HStack>

                <Button
                  size="sm"
                  bg="success.base"
                  color="white"
                  leftIcon={<Icon as={RiDownloadLine} />}
                  onClick={handleDownloadImproved}
                  isLoading={downloading}
                  loadingText="Downloading..."
                  _hover={{ bg: "success.dark" }}
                >
                  Download Improved PDF
                </Button>

                {improvedResume.improvement_notes?.improvements_made && (
                  <Box>
                    <Text
                      fontSize="paragraph-xs"
                      fontWeight={600}
                      color="success.base"
                      mb={1}
                    >
                      Key Improvements:
                    </Text>
                    <VStack
                      align="start"
                      spacing={1}
                      maxH="100px"
                      overflowY="auto"
                    >
                      {improvedResume.improvement_notes.improvements_made
                        .slice(0, 3)
                        .map((improvement, idx) => (
                          <Text
                            key={idx}
                            fontSize="paragraph-xs"
                            color="text.sub"
                          >
                            •{" "}
                            {improvement.length > 80
                              ? improvement.substring(0, 80) + "..."
                              : improvement}
                          </Text>
                        ))}
                    </VStack>
                  </Box>
                )}
              </VStack>
            </Box>
          )}

          <Divider />

          <HStack justify="space-between">
            <Text fontSize="paragraph-xs" color="text.soft">
              Uploaded {formatDate(resume.upload_date)}
            </Text>
          </HStack>

          <VStack spacing={2}>
            <HStack spacing={2} w="100%">
              <Button
                size="sm"
                flex={1}
                leftIcon={<Icon as={BiRefresh} />}
                onClick={() => onAnalyze(resume.id)}
                isLoading={analyzing === resume.id}
                loadingText="Analyzing..."
                variant="outline"
                borderColor="stroke.soft"
                color="text.sub"
              >
                Re-analyze
              </Button>
              {resume.ats_score && (
                <Button
                  size="sm"
                  flex={1}
                  leftIcon={<Icon as={RiEyeLine} />}
                  onClick={() => onViewAnalysis(resume.id)}
                  bg="primary.base"
                  color="white"
                  _hover={{ bg: "primary.darker" }}
                >
                  Details
                </Button>
              )}
            </HStack>

            {!improvedResume && (
              <Button
                size="sm"
                w="100%"
                leftIcon={<Icon as={RiSparklingFill} />}
                onClick={() => onImprove(resume.id)}
                isLoading={improving === resume.id}
                loadingText="AI is improving..."
                bg="feature.base"
                color="white"
                _hover={{ bg: "feature.dark" }}
              >
                ✨ AI Improve Resume
              </Button>
            )}

            <Button
              size="sm"
              w="100%"
              variant="ghost"
              colorScheme="red"
              leftIcon={<Icon as={RiDeleteBinLine} />}
              onClick={() => setShowConfirm(true)}
            >
              Delete
            </Button>
          </VStack>
        </VStack>
      </Box>

      <ConfirmDialog
        isOpen={showConfirm}
        onClose={() => setShowConfirm(false)}
        onConfirm={() => {
          onDelete(resume.id);
          setShowConfirm(false);
        }}
        title="Delete Resume"
        message="Are you sure you want to delete this resume? This action cannot be undone."
      />
    </>
  );
};

const MyResumes = () => {
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hasProfile, setHasProfile] = useState(true);
  const [analyzing, setAnalyzing] = useState(null);
  const [selectedAnalysis, setSelectedAnalysis] = useState(null);
  const [analysisModalOpen, setAnalysisModalOpen] = useState(false);
  const [improving, setImproving] = useState(null);
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    checkProfileAndFetchResumes();
  }, []);

  const checkProfileAndFetchResumes = async () => {
    try {
      await studentAPI.getProfile();
      setHasProfile(true);
      await fetchResumes();
    } catch (error) {
      if (error.response?.status === 404) {
        setHasProfile(false);
      }
      setLoading(false);
    }
  };

  const fetchResumes = async () => {
    try {
      const data = await resumeAPI.getAll();
      setResumes(data);
    } catch (error) {
      console.error("Failed to fetch resumes:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleImprove = async (id) => {
    setImproving(id);
    try {
      const result = await studentEnhancementsAPI.improveResume(id);

      toast({
        title: "Resume Improved! 🎉",
        description: `ATS Score: ${result.ats_score_before?.toFixed(
          1
        )}% → ${result.ats_score_after?.toFixed(1)}%`,
        status: "success",
        duration: 5000,
        isClosable: true,
      });

      try {
        const blob = await studentEnhancementsAPI.downloadImprovedResume(
          result.improved_resume_id
        );

        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = result.file_name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);

        toast({
          title: "PDF Downloaded!",
          description: `Check your downloads folder for ${result.file_name}`,
          status: "info",
          duration: 4000,
        });
      } catch (downloadError) {
        toast({
          title: "Download Available",
          description: "Click the download button to get your PDF",
          status: "info",
          duration: 4000,
        });
      }

      fetchResumes();
    } catch (error) {
      toast({
        title: "Improvement Failed",
        description: error.response?.data?.detail || "Failed to improve resume",
        status: "error",
        duration: 5000,
      });
    } finally {
      setImproving(null);
    }
  };

  const handleUploadSuccess = () => {
    fetchResumes();
  };

  const handleDelete = async (id) => {
    try {
      await resumeAPI.delete(id);
      toast({
        title: "Resume deleted",
        status: "success",
        duration: 2000,
      });
      fetchResumes();
    } catch (error) {
      toast({
        title: "Delete failed",
        description: error.response?.data?.detail || "Failed to delete resume",
        status: "error",
        duration: 3000,
      });
    }
  };

  const handleAnalyze = async (id) => {
    setAnalyzing(id);
    try {
      const analysis = await resumeAPI.analyze(id);
      toast({
        title: "Analysis complete",
        description: `ATS Score: ${analysis.ats_score?.toFixed(1)}%`,
        status: "success",
        duration: 3000,
      });
      fetchResumes();

      setSelectedAnalysis(analysis);
      setAnalysisModalOpen(true);
    } catch (error) {
      toast({
        title: "Analysis failed",
        description: error.response?.data?.detail || "Failed to analyze resume",
        status: "error",
        duration: 3000,
      });
    } finally {
      setAnalyzing(null);
    }
  };

  const handleViewAnalysis = async (id) => {
    try {
      const analyses = await resumeAPI.getAnalyses(id);
      if (analyses && analyses.length > 0) {
        setSelectedAnalysis(analyses[0]);
        setAnalysisModalOpen(true);
      } else {
        toast({
          title: "No analysis found",
          description: "Please analyze this resume first",
          status: "info",
          duration: 3000,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load analysis",
        status: "error",
        duration: 3000,
      });
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        <VStack align="start" spacing={2}>
          <Heading fontSize="title-h4" fontWeight={700} color="text.strong">
            My Resumes
          </Heading>
          <Text fontSize="paragraph-sm" color="text.sub">
            Upload and manage your resumes with AI-powered analysis
          </Text>
        </VStack>

        {!hasProfile ? (
          <Alert
            status="warning"
            variant="subtle"
            flexDirection="column"
            alignItems="center"
            justifyContent="center"
            textAlign="center"
            minH="300px"
            borderRadius="2xl"
            bg="warning.lighter"
            border="1px"
            borderColor="warning.base"
          >
            <Circle size={16} bg="warning.light" mb={4}>
              <AlertIcon boxSize={8} color="warning.base" mr={0} />
            </Circle>
            <AlertTitle fontSize="label-lg" fontWeight={600} mb={2}>
              Profile Required
            </AlertTitle>
            <AlertDescription maxWidth="sm" mb={4} color="text.sub">
              You need to complete your student profile before you can upload
              resumes.
            </AlertDescription>
            <Button
              bg="primary.base"
              color="white"
              onClick={() => navigate("/student/profile")}
              _hover={{ bg: "primary.darker" }}
            >
              Complete Profile
            </Button>
          </Alert>
        ) : (
          <>
            <ResumeUpload onUploadSuccess={handleUploadSuccess} />

            {resumes.length === 0 ? (
              <Box
                bg="bg.white"
                p={12}
                borderRadius="2xl"
                textAlign="center"
                border="1px"
                borderColor="stroke.soft"
              >
                <Circle size={20} bg="primary.alpha.10" mx="auto" mb={4}>
                  <Icon as={RiFileTextLine} boxSize={10} color="primary.base" />
                </Circle>
                <Heading
                  fontSize="label-lg"
                  fontWeight={600}
                  mb={2}
                  color="text.strong"
                >
                  No resumes uploaded yet
                </Heading>
                <Text fontSize="paragraph-sm" color="text.sub">
                  Upload your first resume above to get started with AI analysis
                </Text>
              </Box>
            ) : (
              <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
                {resumes.map((resume) => (
                  <ResumeCard
                    key={resume.id}
                    resume={resume}
                    onDelete={handleDelete}
                    onAnalyze={handleAnalyze}
                    onViewAnalysis={handleViewAnalysis}
                    onImprove={handleImprove}
                    analyzing={analyzing}
                    improving={improving}
                  />
                ))}
              </SimpleGrid>
            )}
          </>
        )}
      </VStack>

      <AnalysisDetailsModal
        isOpen={analysisModalOpen}
        onClose={() => setAnalysisModalOpen(false)}
        analysis={selectedAnalysis}
      />
    </Layout>
  );
};

export default MyResumes;
