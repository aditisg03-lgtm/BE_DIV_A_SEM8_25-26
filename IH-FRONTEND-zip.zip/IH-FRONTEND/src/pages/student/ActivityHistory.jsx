import {
  Box,
  Heading,
  VStack,
  HStack,
  Text,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  SimpleGrid,
  Icon,
  Button,
  Flex,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  RiFileTextLine,
  RiBriefcaseLine,
  // RiTargetLine,
  RiVideoLine,
  RiLineChartLine,
} from "react-icons/ri";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { studentEnhancementsAPI } from "../../api/studentEnhancements";
import { formatDate, getStatusLabel } from "../../utils/helpers";
import { STATUS_COLORS } from "../../utils/constants";
import { FaLine } from "react-icons/fa";

const StatCard = ({ icon, label, value, color = "primary.base" }) => {
  return (
    <Box
      bg="bg.white"
      p={5}
      borderRadius="xl"
      border="1px"
      borderColor="stroke.soft"
      transition="all 0.2s"
      _hover={{ shadow: "md", transform: "translateY(-2px)" }}
    >
      <HStack spacing={4}>
        <Flex
          boxSize={12}
          align="center"
          justify="center"
          borderRadius="xl"
          bg={`${color.split(".")[0]}.lighter`}
        >
          <Icon as={icon} boxSize={6} color={color} />
        </Flex>
        <VStack align="start" spacing={0}>
          <Text fontSize="title-h4" fontWeight={600} color="text.strong">
            {value}
          </Text>
          <Text fontSize="paragraph-sm" color="text.sub">
            {label}
          </Text>
        </VStack>
      </HStack>
    </Box>
  );
};

const ActivityHistory = () => {
  const [history, setHistory] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const data = await studentEnhancementsAPI.getHistory();
      setHistory(data);
    } catch (error) {
      console.error("Failed to fetch history:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );
  if (!history) return null;

  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        <VStack align="start" spacing={2}>
          <Heading size="lg" fontWeight={600}>
            Activity History & Analytics
          </Heading>
          <Text fontSize="paragraph-sm" color="text.sub">
            Track your progress and view detailed insights
          </Text>
        </VStack>

        {/* Statistics */}
        <SimpleGrid columns={{ base: 2, md: 4 }} spacing={4}>
          <StatCard
            icon={RiFileTextLine}
            label="Total Resumes"
            value={history.statistics.total_resumes}
            color="feature.base"
          />
          <StatCard
            icon={RiBriefcaseLine}
            label="Applications"
            value={history.statistics.total_applications}
            color="success.base"
          />
          <StatCard
            icon={FaLine}
            label="Job Comparisons"
            value={history.statistics.total_comparisons}
            color="information.base"
          />
          <StatCard
            icon={RiLineChartLine}
            label="Avg ATS Score"
            value={`${history.statistics.average_ats_score?.toFixed(1)}%`}
            color="verified.base"
          />
        </SimpleGrid>

        {/* Activity Tabs */}
        <Box
          bg="bg.white"
          borderRadius="2xl"
          shadow="regular-xs"
          border="1px"
          borderColor="stroke.soft"
        >
          <Tabs colorScheme="primary">
            <TabList px={6} borderBottomWidth="1px" borderColor="stroke.soft">
              <Tab>
                <HStack spacing={2}>
                  <Icon as={RiFileTextLine} />
                  <Text>Resumes ({history.resume_history?.length || 0})</Text>
                </HStack>
              </Tab>
              <Tab>
                <HStack spacing={2}>
                  <Icon as={RiBriefcaseLine} />
                  <Text>
                    Applications ({history.application_history?.length || 0})
                  </Text>
                </HStack>
              </Tab>
              <Tab>
                <HStack spacing={2}>
                  <Icon as={FaLine} />
                  <Text>
                    Comparisons ({history.comparison_history?.length || 0})
                  </Text>
                </HStack>
              </Tab>
              <Tab>
                <HStack spacing={2}>
                  <Icon as={RiVideoLine} />
                  <Text>
                    Interviews ({history.interview_history?.length || 0})
                  </Text>
                </HStack>
              </Tab>
            </TabList>

            <TabPanels>
              {/* Resumes */}
              <TabPanel p={0}>
                <Box overflowX="auto">
                  <Table variant="simple">
                    <Thead bg="bg.weak">
                      <Tr>
                        <Th fontSize="paragraph-sm">File Name</Th>
                        <Th fontSize="paragraph-sm">Upload Date</Th>
                        <Th fontSize="paragraph-sm">ATS Score</Th>
                        <Th fontSize="paragraph-sm">Analyses</Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                      {history.resume_history?.map((resume) => (
                        <Tr key={resume.resume_id} _hover={{ bg: "bg.weak" }}>
                          <Td fontWeight={500}>{resume.file_name}</Td>
                          <Td color="text.sub">
                            {formatDate(resume.upload_date)}
                          </Td>
                          <Td>
                            {resume.ats_score ? (
                              <Badge colorScheme="purple" fontSize="label-xs">
                                {resume.ats_score.toFixed(1)}%
                              </Badge>
                            ) : (
                              <Text color="text.soft">-</Text>
                            )}
                          </Td>
                          <Td color="text.sub">
                            {resume.analyses_count} times
                          </Td>
                        </Tr>
                      ))}
                    </Tbody>
                  </Table>
                </Box>
              </TabPanel>

              {/* Applications */}
              <TabPanel p={0}>
                <Box overflowX="auto">
                  <Table variant="simple">
                    <Thead bg="bg.weak">
                      <Tr>
                        <Th fontSize="paragraph-sm">Position</Th>
                        <Th fontSize="paragraph-sm">Company</Th>
                        <Th fontSize="paragraph-sm">Applied</Th>
                        <Th fontSize="paragraph-sm">Status</Th>
                        <Th fontSize="paragraph-sm">ATS Score</Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                      {history.application_history?.map((app) => (
                        <Tr key={app.application_id} _hover={{ bg: "bg.weak" }}>
                          <Td fontWeight={500}>{app.job_title}</Td>
                          <Td color="text.sub">{app.company}</Td>
                          <Td color="text.sub">
                            {formatDate(app.applied_date)}
                          </Td>
                          <Td>
                            <Badge
                              colorScheme={STATUS_COLORS[app.status]}
                              fontSize="label-xs"
                            >
                              {getStatusLabel(app.status)}
                            </Badge>
                          </Td>
                          <Td>
                            {app.ats_score ? (
                              <Badge colorScheme="purple" fontSize="label-xs">
                                {app.ats_score.toFixed(1)}%
                              </Badge>
                            ) : (
                              <Text color="text.soft">-</Text>
                            )}
                          </Td>
                        </Tr>
                      ))}
                    </Tbody>
                  </Table>
                </Box>
              </TabPanel>

              {/* Comparisons */}
              <TabPanel p={0}>
                <Box overflowX="auto">
                  <Table variant="simple">
                    <Thead bg="bg.weak">
                      <Tr>
                        <Th fontSize="paragraph-sm">Job Title</Th>
                        <Th fontSize="paragraph-sm">Date</Th>
                        <Th fontSize="paragraph-sm">Match Score</Th>
                        <Th fontSize="paragraph-sm">Success Level</Th>
                        <Th fontSize="paragraph-sm">Action</Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                      {history.comparison_history?.map((comp) => (
                        <Tr key={comp.comparison_id} _hover={{ bg: "bg.weak" }}>
                          <Td fontWeight={500}>{comp.job_title}</Td>
                          <Td color="text.sub">
                            {formatDate(comp.created_at)}
                          </Td>
                          <Td>
                            <Badge colorScheme="blue" fontSize="label-xs">
                              {comp.success_probability?.toFixed(1)}%
                            </Badge>
                          </Td>
                          <Td>
                            <Badge
                              colorScheme={
                                comp.success_level === "EXCELLENT"
                                  ? "green"
                                  : comp.success_level === "GOOD"
                                  ? "blue"
                                  : "yellow"
                              }
                              fontSize="label-xs"
                            >
                              {comp.success_level}
                            </Badge>
                          </Td>
                          <Td>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() =>
                                navigate("/student/job-comparison")
                              }
                            >
                              View
                            </Button>
                          </Td>
                        </Tr>
                      ))}
                    </Tbody>
                  </Table>
                </Box>
              </TabPanel>

              {/* Interviews */}
              <TabPanel p={0}>
                <Box overflowX="auto">
                  <Table variant="simple">
                    <Thead bg="bg.weak">
                      <Tr>
                        <Th fontSize="paragraph-sm">Date</Th>
                        <Th fontSize="paragraph-sm">Status</Th>
                        <Th fontSize="paragraph-sm">Score</Th>
                        <Th fontSize="paragraph-sm">Completed</Th>
                        <Th fontSize="paragraph-sm">Action</Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                      {history.interview_history?.map((interview) => (
                        <Tr
                          key={interview.interview_id}
                          _hover={{ bg: "bg.weak" }}
                        >
                          <Td color="text.sub">
                            {formatDate(interview.created_at)}
                          </Td>
                          <Td>
                            <Badge
                              colorScheme={
                                interview.status === "completed"
                                  ? "green"
                                  : interview.status === "in_progress"
                                  ? "blue"
                                  : "gray"
                              }
                              fontSize="label-xs"
                            >
                              {interview.status.toUpperCase()}
                            </Badge>
                          </Td>
                          <Td>
                            {interview.overall_score ? (
                              <Badge colorScheme="purple" fontSize="label-xs">
                                {interview.overall_score.toFixed(1)}%
                              </Badge>
                            ) : (
                              <Text color="text.soft">-</Text>
                            )}
                          </Td>
                          <Td color="text.sub">
                            {interview.completed_at
                              ? formatDate(interview.completed_at)
                              : "N/A"}
                          </Td>
                          <Td>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() =>
                                navigate(
                                  `/student/mock-interview/${interview.interview_id}`
                                )
                              }
                            >
                              {interview.status === "completed"
                                ? "View Results"
                                : "Continue"}
                            </Button>
                          </Td>
                        </Tr>
                      ))}
                    </Tbody>
                  </Table>
                </Box>
              </TabPanel>
            </TabPanels>
          </Tabs>
        </Box>

        {/* Status Breakdown */}
        {history.statistics.applications_by_status &&
          Object.keys(history.statistics.applications_by_status).length > 0 && (
            <Box
              bg="bg.white"
              p={6}
              borderRadius="2xl"
              shadow="regular-xs"
              border="1px"
              borderColor="stroke.soft"
            >
              <Heading size="md" mb={4} fontWeight={600}>
                Application Status Breakdown
              </Heading>
              <SimpleGrid columns={{ base: 2, md: 4 }} spacing={4}>
                {Object.entries(history.statistics.applications_by_status).map(
                  ([status, count]) => (
                    <Box key={status} p={4} borderRadius="lg" bg="bg.weak">
                      <Text
                        fontSize="title-h4"
                        fontWeight={600}
                        color="primary.base"
                      >
                        {count}
                      </Text>
                      <Text
                        fontSize="paragraph-sm"
                        color="text.sub"
                        textTransform="capitalize"
                      >
                        {getStatusLabel(status)}
                      </Text>
                    </Box>
                  )
                )}
              </SimpleGrid>
            </Box>
          )}
      </VStack>
    </Layout>
  );
};

export default ActivityHistory;
