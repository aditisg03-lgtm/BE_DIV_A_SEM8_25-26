import {
  Box,
  Heading,
  VStack,
  HStack,
  Button,
  Select,
  FormControl,
  FormLabel,
  Text,
  useToast,
  SimpleGrid,
  Badge,
  Icon,
  Alert,
  AlertIcon,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Wrap,
  Tag,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  ModalFooter,
  useDisclosure,
  Textarea,
  Input,
  Container,
  Flex,
  Progress,
  Grid,
  GridItem,
  Divider,
  Center,
  Circle,
  CircularProgress,
  CircularProgressLabel,
  Tooltip,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
  List,
  ListItem,
  Link,
  Image,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import {
  RiCloseLine,
  RiAlertLine,
  RiLineChartLine,
  RiBookOpenLine,
  RiVideoLine,
  RiBriefcaseLine,
  RiAwardLine,
  RiTimeLine,
  RiBarChartLine,
  RiExternalLinkLine,
  RiSparklingLine,
  RiFileTextLine,
  RiCheckLine,
  RiArrowRightLine,
  RiLightbulbLine,
  RiErrorWarningLine,
} from "react-icons/ri";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { resumeAPI } from "../../api/resume";
import { jobAPI } from "../../api/job";
import { studentEnhancementsAPI } from "../../api/studentEnhancements";

// Compact Success Gauge Component
const CompactSuccessGauge = ({ probability = 0, level = "UNKNOWN" }) => {
  const getColor = () => {
    if (probability >= 85) return "success";
    if (probability >= 70) return "blue";
    if (probability >= 55) return "orange";
    return "red";
  };

  const getEmoji = () => {
    if (probability >= 85) return "🎉";
    if (probability >= 70) return "👍";
    if (probability >= 55) return "🤔";
    return "😟";
  };

  return (
    <VStack spacing={3} align="center">
      <Box position="relative">
        <Circle
          size="120px"
          bgGradient={`linear(135deg, ${getColor()}.300, ${getColor()}.500)`}
          position="relative"
          shadow="0 8px 32px -8px rgba(125, 82, 244, 0.4)"
        >
          <VStack spacing={0}>
            <Text
              fontSize="title-h4"
              fontWeight={700}
              color="white"
              fontFamily="'Inter', sans-serif"
            >
              {probability.toFixed(0)}%
            </Text>
            <Text
              fontSize="paragraph-xs"
              color="white"
              opacity={0.9}
              fontFamily="'Inter', sans-serif"
            >
              Match
            </Text>
          </VStack>
        </Circle>
        <Box position="absolute" top="-10px" right="-10px" fontSize="2xl">
          {getEmoji()}
        </Box>
      </Box>
      <Badge
        colorScheme={getColor()}
        fontSize="label-xs"
        px={3}
        py={1}
        borderRadius="full"
      >
        {level} FIT
      </Badge>
    </VStack>
  );
};

// Selection Card Component
const SelectionCard = ({
  type,
  title,
  subtitle,
  value,
  options,
  onChange,
  icon,
  color,
}) => {
  return (
    <Box
      bg="rgba(255, 255, 255, 0.7)"
      backdropFilter="blur(20px)"
      p={5}
      borderRadius="16px"
      border="2px solid"
      borderColor={value ? `${color}.200` : "rgba(229, 231, 235, 0.5)"}
      shadow={
        value
          ? "0 8px 24px rgba(125, 82, 244, 0.1)"
          : "0 4px 16px rgba(0, 0, 0, 0.02)"
      }
      transition="all 0.3s"
      _hover={{
        transform: "translateY(-2px)",
        shadow: "0 8px 24px rgba(125, 82, 244, 0.12)",
      }}
    >
      <VStack align="stretch" spacing={4}>
        <HStack spacing={3}>
          <Box
            w={10}
            h={10}
            borderRadius="10px"
            bgGradient={`linear(135deg, ${color}.300, ${color}.400)`}
            display="flex"
            alignItems="center"
            justifyContent="center"
          >
            <Icon as={icon} color="white" boxSize={5} />
          </Box>
          <VStack align="start" spacing={0} flex={1}>
            <Text
              fontSize="label-sm"
              fontWeight={600}
              fontFamily="'Inter', sans-serif"
            >
              {title}
            </Text>
            <Text
              fontSize="paragraph-xs"
              color="text.sub"
              fontFamily="'Inter', sans-serif"
            >
              {subtitle}
            </Text>
          </VStack>
        </HStack>

        <Select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={`Choose ${type}`}
          size="sm"
          h={10}
          bg="rgba(255, 255, 255, 0.6)"
          borderRadius="10px"
          fontSize="paragraph-sm"
          fontFamily="'Inter', sans-serif"
          borderColor="rgba(229, 231, 235, 0.8)"
          _hover={{ borderColor: `${color}.300` }}
          _focus={{
            borderColor: `${color}.400`,
            boxShadow: `0 0 0 3px rgba(125, 82, 244, 0.08)`,
          }}
        >
          {options.map((option) => (
            <option key={option.id} value={option.id}>
              {option.label}
            </option>
          ))}
        </Select>

        {value && options.find((o) => o.id === value)?.meta && (
          <HStack spacing={2} flexWrap="wrap">
            {Object.entries(options.find((o) => o.id === value).meta).map(
              ([key, val]) => (
                <Badge
                  key={key}
                  fontSize="subheading-xs"
                  variant="subtle"
                  colorScheme={color}
                >
                  {key}: {val}
                </Badge>
              )
            )}
          </HStack>
        )}
      </VStack>
    </Box>
  );
};

// RESTORED: Courses Modal with ALL Content
const CoursesModal = ({ isOpen, onClose, courses, loading }) => {
  if (!courses && !loading) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="6xl" scrollBehavior="inside">
      <ModalOverlay bg="blackAlpha.600" backdropFilter="blur(10px)" />
      <ModalContent
        bg="rgba(255, 255, 255, 0.95)"
        backdropFilter="blur(20px)"
        borderRadius="20px"
        border="1px solid rgba(255, 255, 255, 0.8)"
        maxH="90vh"
      >
        <ModalHeader borderBottom="1px solid rgba(229, 231, 235, 0.5)" pb={4}>
          <HStack spacing={3}>
            <Circle size={12} bg="rgba(139, 92, 246, 0.1)">
              <Icon as={RiBookOpenLine} boxSize={6} color="purple.500" />
            </Circle>
            <VStack align="start" spacing={0}>
              <Heading
                fontSize="label-md"
                fontWeight={600}
                fontFamily="'Inter', sans-serif"
              >
                📚 Recommended Courses
              </Heading>
              <Text
                fontSize="paragraph-xs"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                AI-curated learning paths to bridge your skill gaps
              </Text>
            </VStack>
          </HStack>
        </ModalHeader>
        <ModalCloseButton />

        <ModalBody py={6}>
          {loading ? (
            <VStack spacing={4} py={10}>
              <CircularProgress
                isIndeterminate
                color="purple.400"
                size="80px"
              />
              <Text
                color="text.sub"
                fontSize="paragraph-sm"
                fontFamily="'Inter', sans-serif"
              >
                AI is finding the best courses for you...
              </Text>
            </VStack>
          ) : (
            <VStack spacing={6} align="stretch">
              <Alert
                status="info"
                borderRadius="14px"
                bg="rgba(219, 234, 254, 0.5)"
                border="1px solid rgba(59, 130, 246, 0.3)"
              >
                <AlertIcon color="blue.500" />
                <VStack align="start" spacing={0}>
                  <Text
                    fontWeight={600}
                    color="blue.700"
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                  >
                    {courses?.courses?.length || 0} courses found
                  </Text>
                  <Text
                    fontSize="paragraph-xs"
                    color="text.sub"
                    fontFamily="'Inter', sans-serif"
                  >
                    Click any course to explore on the platform
                  </Text>
                </VStack>
              </Alert>

              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                {courses?.courses?.map((course, index) => (
                  <Box
                    key={index}
                    borderRadius="14px"
                    overflow="hidden"
                    border="1px solid rgba(229, 231, 235, 0.5)"
                    bg="rgba(255, 255, 255, 0.7)"
                    backdropFilter="blur(10px)"
                    transition="all 0.2s"
                    _hover={{
                      shadow: "0 8px 24px rgba(125, 82, 244, 0.15)",
                      transform: "translateY(-2px)",
                      borderColor: "rgba(139, 92, 246, 0.3)",
                    }}
                  >
                    <Box
                      bg="rgba(237, 233, 254, 0.3)"
                      p={4}
                      borderBottom="1px solid rgba(229, 231, 235, 0.3)"
                    >
                      <HStack justify="space-between" mb={3}>
                        <HStack spacing={3}>
                          <Image
                            src={
                              course.platform_logo ||
                              "https://via.placeholder.com/40"
                            }
                            alt={course.platform}
                            boxSize="40px"
                            borderRadius="md"
                            fallbackSrc="https://via.placeholder.com/40?text=📚"
                          />
                          <VStack align="start" spacing={0}>
                            <Text
                              fontSize="paragraph-xs"
                              color="text.sub"
                              fontWeight={500}
                              fontFamily="'Inter', sans-serif"
                            >
                              {course.platform}
                            </Text>
                            <Badge
                              bg="purple.400"
                              color="white"
                              fontSize="subheading-xs"
                              borderRadius="md"
                            >
                              {course.relevance_score}% Match
                            </Badge>
                          </VStack>
                        </HStack>
                      </HStack>

                      <Heading
                        fontSize="label-sm"
                        fontWeight={600}
                        noOfLines={2}
                        mb={2}
                        fontFamily="'Inter', sans-serif"
                      >
                        {course.name}
                      </Heading>

                      <HStack
                        spacing={4}
                        fontSize="paragraph-xs"
                        color="text.soft"
                      >
                        <HStack spacing={1}>
                          <Icon as={RiTimeLine} boxSize={3} />
                          <Text fontFamily="'Inter', sans-serif">
                            {course.estimated_duration || "Self-paced"}
                          </Text>
                        </HStack>
                        <HStack spacing={1}>
                          <Icon as={RiBarChartLine} boxSize={3} />
                          <Text fontFamily="'Inter', sans-serif">
                            {course.level || "All Levels"}
                          </Text>
                        </HStack>
                      </HStack>
                    </Box>

                    <Box p={4} bg="rgba(255, 255, 255, 0.9)">
                      <VStack align="stretch" spacing={3}>
                        <Box>
                          <Text
                            fontSize="subheading-2xs"
                            fontWeight={600}
                            color="text.soft"
                            mb={1}
                            textTransform="uppercase"
                            fontFamily="'Inter', sans-serif"
                          >
                            Addresses Skill Gap
                          </Text>
                          <Tag
                            colorScheme="orange"
                            size="sm"
                            borderRadius="md"
                            fontSize="subheading-xs"
                          >
                            {course.skill_gap}
                          </Tag>
                        </Box>

                        <Box>
                          <Text
                            fontSize="subheading-2xs"
                            fontWeight={600}
                            color="text.soft"
                            mb={1}
                            textTransform="uppercase"
                            fontFamily="'Inter', sans-serif"
                          >
                            Why This Course
                          </Text>
                          <Text
                            fontSize="paragraph-xs"
                            color="text.sub"
                            fontFamily="'Inter', sans-serif"
                          >
                            {course.reason}
                          </Text>
                        </Box>

                        <Link
                          href={course.url}
                          isExternal
                          _hover={{ textDecoration: "none" }}
                        >
                          <Button
                            colorScheme="purple"
                            size="sm"
                            h={9}
                            width="full"
                            rightIcon={
                              <Icon as={RiExternalLinkLine} boxSize={3.5} />
                            }
                            borderRadius="10px"
                            fontSize="label-xs"
                            fontFamily="'Inter', sans-serif"
                          >
                            View on {course.platform.split(" ")[0]}
                          </Button>
                        </Link>
                      </VStack>
                    </Box>
                  </Box>
                ))}
              </SimpleGrid>

              {(!courses?.courses || courses.courses.length === 0) &&
                !loading && (
                  <Alert
                    status="warning"
                    borderRadius="14px"
                    bg="rgba(254, 243, 199, 0.5)"
                    border="1px solid rgba(251, 191, 36, 0.3)"
                  >
                    <AlertIcon color="orange.500" />
                    <Text
                      color="orange.700"
                      fontSize="paragraph-sm"
                      fontFamily="'Inter', sans-serif"
                    >
                      No courses found. Try analyzing again.
                    </Text>
                  </Alert>
                )}
            </VStack>
          )}
        </ModalBody>

        <ModalFooter borderTop="1px solid rgba(229, 231, 235, 0.5)">
          <Button
            onClick={onClose}
            variant="outline"
            borderRadius="10px"
            fontSize="label-xs"
            fontFamily="'Inter', sans-serif"
          >
            Close
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

// RESTORED: Custom Job Modal
const CustomJobModal = ({ isOpen, onClose, onSubmit, resumes }) => {
  const [formData, setFormData] = useState({
    resume_id: "",
    job_title: "",
    company_name: "",
    job_description: "",
    required_skills: "",
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    await onSubmit({
      ...formData,
      required_skills: formData.required_skills
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
    });
    setLoading(false);
    onClose();
    setFormData({
      resume_id: "",
      job_title: "",
      company_name: "",
      job_description: "",
      required_skills: "",
    });
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="xl">
      <ModalOverlay bg="blackAlpha.600" backdropFilter="blur(10px)" />
      <ModalContent
        bg="rgba(255, 255, 255, 0.95)"
        backdropFilter="blur(20px)"
        borderRadius="20px"
        border="1px solid rgba(255, 255, 255, 0.8)"
      >
        <ModalHeader
          borderBottom="1px solid rgba(229, 231, 235, 0.5)"
          fontSize="label-md"
          fontFamily="'Inter', sans-serif"
        >
          Compare with Custom Job Description
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6} pt={6}>
          <VStack spacing={4} align="stretch">
            <FormControl isRequired>
              <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                Select Resume
              </FormLabel>
              <Select
                value={formData.resume_id}
                onChange={(e) =>
                  setFormData({ ...formData, resume_id: e.target.value })
                }
                placeholder="Choose resume"
                h={10}
                bg="rgba(248, 249, 250, 0.8)"
                borderRadius="10px"
                fontSize="paragraph-sm"
                fontFamily="'Inter', sans-serif"
              >
                {resumes.map((resume) => (
                  <option key={resume.id} value={resume.id}>
                    {resume.label}
                  </option>
                ))}
              </Select>
            </FormControl>

            <FormControl isRequired>
              <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                Job Title
              </FormLabel>
              <Input
                value={formData.job_title}
                onChange={(e) =>
                  setFormData({ ...formData, job_title: e.target.value })
                }
                placeholder="e.g., Senior Software Engineer"
                h={10}
                bg="rgba(248, 249, 250, 0.8)"
                borderRadius="10px"
                fontSize="paragraph-sm"
                fontFamily="'Inter', sans-serif"
              />
            </FormControl>

            <FormControl>
              <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                Company Name
              </FormLabel>
              <Input
                value={formData.company_name}
                onChange={(e) =>
                  setFormData({ ...formData, company_name: e.target.value })
                }
                placeholder="Optional"
                h={10}
                bg="rgba(248, 249, 250, 0.8)"
                borderRadius="10px"
                fontSize="paragraph-sm"
                fontFamily="'Inter', sans-serif"
              />
            </FormControl>

            <FormControl isRequired>
              <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                Job Description
              </FormLabel>
              <Textarea
                value={formData.job_description}
                onChange={(e) =>
                  setFormData({ ...formData, job_description: e.target.value })
                }
                placeholder="Paste the full job description here..."
                rows={8}
                bg="rgba(248, 249, 250, 0.8)"
                borderRadius="10px"
                fontSize="paragraph-sm"
                fontFamily="'Inter', sans-serif"
              />
            </FormControl>

            <FormControl>
              <FormLabel fontSize="label-xs" fontFamily="'Inter', sans-serif">
                Required Skills (comma-separated)
              </FormLabel>
              <Input
                value={formData.required_skills}
                onChange={(e) =>
                  setFormData({ ...formData, required_skills: e.target.value })
                }
                placeholder="e.g., Python, React, AWS, Docker"
                h={10}
                bg="rgba(248, 249, 250, 0.8)"
                borderRadius="10px"
                fontSize="paragraph-sm"
                fontFamily="'Inter', sans-serif"
              />
            </FormControl>

            <Button
              bgGradient="linear(135deg, purple.300, purple.400)"
              color="white"
              h={10}
              onClick={handleSubmit}
              isLoading={loading}
              isDisabled={
                !formData.resume_id ||
                !formData.job_title ||
                !formData.job_description
              }
              borderRadius="10px"
              fontSize="label-sm"
              fontFamily="'Inter', sans-serif"
              _hover={{ bgGradient: "linear(135deg, purple.400, purple.500)" }}
            >
              Analyze Match
            </Button>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

// RESTORED: Complete Results Modal with ALL Details
const ResultsModal = ({
  isOpen,
  onClose,
  result,
  onGetCourses,
  onMockInterview,
  onApply,
  loadingCourses,
  loadingInterview,
}) => {
  if (!result) return null;

  const analysis = result.analysis || {};
  const scores = result.scores || {};
  const nextSteps = result.next_steps || {};

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="6xl" scrollBehavior="inside">
      <ModalOverlay bg="blackAlpha.600" backdropFilter="blur(10px)" />
      <ModalContent
        bg="rgba(255, 255, 255, 0.95)"
        backdropFilter="blur(20px)"
        borderRadius="20px"
        border="1px solid rgba(255, 255, 255, 0.8)"
        shadow="0 24px 48px rgba(0, 0, 0, 0.12)"
      >
        <ModalHeader borderBottom="1px solid rgba(229, 231, 235, 0.5)" pb={4}>
          <HStack spacing={3}>
            <Text
              fontSize="label-md"
              fontWeight={600}
              fontFamily="'Inter', sans-serif"
            >
              {result.job_title}
            </Text>
            <Badge colorScheme="purple" fontSize="subheading-xs">
              AI Analysis
            </Badge>
          </HStack>
        </ModalHeader>
        <ModalCloseButton />

        <ModalBody py={5}>
          <VStack spacing={5} align="stretch">
            {/* Success Gauge */}
            <Box
              bgGradient="linear(135deg, rgba(237, 233, 254, 0.3), rgba(219, 234, 254, 0.3))"
              p={6}
              borderRadius="16px"
              textAlign="center"
            >
              <CompactSuccessGauge
                probability={result.success_probability}
                level={result.success_level}
              />
            </Box>

            {/* Score Breakdown - Smaller Circles */}
            <Box
              bg="rgba(248, 249, 250, 0.6)"
              p={4}
              borderRadius="14px"
              border="1px solid rgba(229, 231, 235, 0.3)"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={3}
                fontFamily="'Inter', sans-serif"
              >
                📊 Detailed Score Breakdown
              </Text>
              <HStack spacing={6} justify="space-around">
                {[
                  { label: "ATS", value: scores.ats_score, color: "purple" },
                  {
                    label: "Keywords",
                    value: scores.keyword_match,
                    color: "blue",
                  },
                  {
                    label: "Skills",
                    value: scores.skills_match,
                    color: "green",
                  },
                  {
                    label: "Experience",
                    value: scores.experience_match,
                    color: "orange",
                  },
                  {
                    label: "Education",
                    value: scores.education_match,
                    color: "teal",
                  },
                ].map((item) => (
                  <VStack key={item.label} spacing={2}>
                    <CircularProgress
                      value={item.value || 0}
                      color={`${item.color}.400`}
                      trackColor="gray.100"
                      size="60px"
                      thickness="6px"
                    >
                      <CircularProgressLabel
                        fontSize="label-xs"
                        fontWeight={600}
                        fontFamily="'Inter', sans-serif"
                      >
                        {item.value || 0}%
                      </CircularProgressLabel>
                    </CircularProgress>
                    <Text
                      fontSize="subheading-2xs"
                      color="text.sub"
                      fontFamily="'Inter', sans-serif"
                    >
                      {item.label}
                    </Text>
                  </VStack>
                ))}
              </HStack>
            </Box>

            <Divider borderColor="rgba(229, 231, 235, 0.5)" />

            {/* RESTORED: Full Accordion with ALL Details */}
            <Accordion allowMultiple defaultIndex={[0, 1]}>
              {/* Strengths */}
              {analysis.strengths && analysis.strengths.length > 0 && (
                <AccordionItem border="none" mb={2}>
                  <AccordionButton
                    bg="rgba(236, 253, 245, 0.5)"
                    borderRadius="12px"
                    _hover={{ bg: "rgba(236, 253, 245, 0.7)" }}
                    p={4}
                  >
                    <HStack flex="1" textAlign="left" spacing={3}>
                      <Circle size={10} bg="rgba(16, 185, 129, 0.2)">
                        <Icon as={RiAwardLine} color="green.500" boxSize={5} />
                      </Circle>
                      <Heading
                        fontSize="label-sm"
                        fontWeight={600}
                        fontFamily="'Inter', sans-serif"
                      >
                        Your Strengths ({analysis.strengths.length})
                      </Heading>
                    </HStack>
                    <AccordionIcon />
                  </AccordionButton>
                  <AccordionPanel pb={4} pt={4}>
                    <List spacing={3}>
                      {analysis.strengths.map((strength, index) => (
                        <ListItem key={index}>
                          <HStack align="start" spacing={3}>
                            <Circle size={6} bg="rgba(16, 185, 129, 0.15)">
                              <Icon
                                as={RiCheckLine}
                                color="green.500"
                                boxSize={4}
                              />
                            </Circle>
                            <Text
                              fontSize="paragraph-sm"
                              color="text.sub"
                              flex={1}
                              fontFamily="'Inter', sans-serif"
                            >
                              {strength}
                            </Text>
                          </HStack>
                        </ListItem>
                      ))}
                    </List>
                  </AccordionPanel>
                </AccordionItem>
              )}

              {/* Skill Gaps */}
              {nextSteps.critical_gaps &&
                nextSteps.critical_gaps.length > 0 && (
                  <AccordionItem border="none" mb={2}>
                    <AccordionButton
                      bg="rgba(254, 243, 199, 0.5)"
                      borderRadius="12px"
                      _hover={{ bg: "rgba(254, 243, 199, 0.7)" }}
                      p={4}
                    >
                      <HStack flex="1" textAlign="left" spacing={3}>
                        <Circle size={10} bg="rgba(251, 191, 36, 0.2)">
                          <Icon
                            as={RiAlertLine}
                            color="orange.500"
                            boxSize={5}
                          />
                        </Circle>
                        <Heading
                          fontSize="label-sm"
                          fontWeight={600}
                          fontFamily="'Inter', sans-serif"
                        >
                          Skill Gaps ({nextSteps.critical_gaps.length})
                        </Heading>
                      </HStack>
                      <AccordionIcon />
                    </AccordionButton>
                    <AccordionPanel pb={4} pt={4}>
                      <Wrap spacing={2}>
                        {nextSteps.critical_gaps.map((gap, index) => (
                          <Tag
                            key={index}
                            size="md"
                            colorScheme="orange"
                            borderRadius="full"
                            fontSize="paragraph-xs"
                          >
                            {gap}
                          </Tag>
                        ))}
                      </Wrap>
                    </AccordionPanel>
                  </AccordionItem>
                )}

              {/* Weaknesses */}
              {analysis.weaknesses && analysis.weaknesses.length > 0 && (
                <AccordionItem border="none" mb={2}>
                  <AccordionButton
                    bg="rgba(254, 226, 226, 0.5)"
                    borderRadius="12px"
                    _hover={{ bg: "rgba(254, 226, 226, 0.7)" }}
                    p={4}
                  >
                    <HStack flex="1" textAlign="left" spacing={3}>
                      <Circle size={10} bg="rgba(239, 68, 68, 0.2)">
                        <Icon
                          as={RiErrorWarningLine}
                          color="red.500"
                          boxSize={5}
                        />
                      </Circle>
                      <Heading
                        fontSize="label-sm"
                        fontWeight={600}
                        fontFamily="'Inter', sans-serif"
                      >
                        Areas for Improvement ({analysis.weaknesses.length})
                      </Heading>
                    </HStack>
                    <AccordionIcon />
                  </AccordionButton>
                  <AccordionPanel pb={4} pt={4}>
                    <List spacing={3}>
                      {analysis.weaknesses.map((weakness, index) => (
                        <ListItem key={index}>
                          <HStack align="start" spacing={3}>
                            <Circle size={6} bg="rgba(239, 68, 68, 0.15)">
                              <Icon
                                as={RiCloseLine}
                                color="red.500"
                                boxSize={4}
                              />
                            </Circle>
                            <Text
                              fontSize="paragraph-sm"
                              color="text.sub"
                              flex={1}
                              fontFamily="'Inter', sans-serif"
                            >
                              {weakness}
                            </Text>
                          </HStack>
                        </ListItem>
                      ))}
                    </List>
                  </AccordionPanel>
                </AccordionItem>
              )}

              {/* AI Recommendations */}
              {nextSteps.recommended_actions &&
                nextSteps.recommended_actions.length > 0 && (
                  <AccordionItem border="none" mb={2}>
                    <AccordionButton
                      bg="rgba(219, 234, 254, 0.5)"
                      borderRadius="12px"
                      _hover={{ bg: "rgba(219, 234, 254, 0.7)" }}
                      p={4}
                    >
                      <HStack flex="1" textAlign="left" spacing={3}>
                        <Circle size={10} bg="rgba(59, 130, 246, 0.2)">
                          <Icon
                            as={RiLineChartLine}
                            color="blue.500"
                            boxSize={5}
                          />
                        </Circle>
                        <Heading
                          fontSize="label-sm"
                          fontWeight={600}
                          fontFamily="'Inter', sans-serif"
                        >
                          AI Recommendations (
                          {nextSteps.recommended_actions.length})
                        </Heading>
                      </HStack>
                      <AccordionIcon />
                    </AccordionButton>
                    <AccordionPanel pb={4} pt={4}>
                      <List spacing={3}>
                        {nextSteps.recommended_actions.map((action, index) => (
                          <ListItem key={index}>
                            <HStack align="start" spacing={3}>
                              <Badge
                                bg="blue.400"
                                color="white"
                                borderRadius="full"
                                px={2}
                                minW={6}
                                h={6}
                                display="flex"
                                alignItems="center"
                                justifyContent="center"
                                fontSize="subheading-xs"
                              >
                                {index + 1}
                              </Badge>
                              <Text
                                fontSize="paragraph-sm"
                                color="text.sub"
                                flex={1}
                                fontFamily="'Inter', sans-serif"
                              >
                                {action}
                              </Text>
                            </HStack>
                          </ListItem>
                        ))}
                      </List>
                    </AccordionPanel>
                  </AccordionItem>
                )}

              {/* Overall Assessment */}
              {analysis.overall_feedback && (
                <AccordionItem border="none">
                  <AccordionButton
                    bg="rgba(237, 233, 254, 0.5)"
                    borderRadius="12px"
                    _hover={{ bg: "rgba(237, 233, 254, 0.7)" }}
                    p={4}
                  >
                    <HStack flex="1" textAlign="left" spacing={3}>
                      <Circle size={10} bg="rgba(125, 82, 244, 0.2)">
                        <Icon
                          as={RiBriefcaseLine}
                          color="purple.500"
                          boxSize={5}
                        />
                      </Circle>
                      <Heading
                        fontSize="label-sm"
                        fontWeight={600}
                        fontFamily="'Inter', sans-serif"
                      >
                        Overall AI Assessment
                      </Heading>
                    </HStack>
                    <AccordionIcon />
                  </AccordionButton>
                  <AccordionPanel pb={4} pt={4}>
                    <Text
                      fontSize="paragraph-sm"
                      color="text.sub"
                      lineHeight="tall"
                      fontFamily="'Inter', sans-serif"
                    >
                      {analysis.overall_feedback}
                    </Text>
                  </AccordionPanel>
                </AccordionItem>
              )}
            </Accordion>

            {/* Recommendation Badge */}
            {analysis.recommendation && (
              <Box
                p={4}
                bg={
                  analysis.recommendation === "HIGHLY RECOMMENDED"
                    ? "rgba(236, 253, 245, 0.5)"
                    : analysis.recommendation === "RECOMMENDED"
                    ? "rgba(219, 234, 254, 0.5)"
                    : analysis.recommendation === "CONSIDER"
                    ? "rgba(254, 243, 199, 0.5)"
                    : "rgba(254, 226, 226, 0.5)"
                }
                borderRadius="14px"
                border="1px solid"
                borderColor={
                  analysis.recommendation === "HIGHLY RECOMMENDED"
                    ? "rgba(16, 185, 129, 0.3)"
                    : analysis.recommendation === "RECOMMENDED"
                    ? "rgba(59, 130, 246, 0.3)"
                    : analysis.recommendation === "CONSIDER"
                    ? "rgba(251, 191, 36, 0.3)"
                    : "rgba(239, 68, 68, 0.3)"
                }
                textAlign="center"
              >
                <HStack justify="center" spacing={2}>
                  <Icon
                    as={
                      analysis.recommendation === "HIGHLY RECOMMENDED"
                        ? RiCheckLine
                        : analysis.recommendation === "RECOMMENDED"
                        ? RiLineChartLine
                        : analysis.recommendation === "CONSIDER"
                        ? RiLightbulbLine
                        : RiAlertLine
                    }
                    boxSize={5}
                    color={
                      analysis.recommendation === "HIGHLY RECOMMENDED"
                        ? "green.500"
                        : analysis.recommendation === "RECOMMENDED"
                        ? "blue.500"
                        : analysis.recommendation === "CONSIDER"
                        ? "orange.500"
                        : "red.500"
                    }
                  />
                  <Text
                    fontSize="label-sm"
                    fontWeight={600}
                    fontFamily="'Inter', sans-serif"
                  >
                    AI Recommendation: {analysis.recommendation}
                  </Text>
                </HStack>

                {nextSteps?.should_apply === false && (
                  <Text
                    fontSize="paragraph-xs"
                    color="text.sub"
                    mt={2}
                    fontFamily="'Inter', sans-serif"
                  >
                    💡 We recommend improving your skills first, but the choice
                    is yours!
                  </Text>
                )}
              </Box>
            )}
          </VStack>
        </ModalBody>

        <ModalFooter borderTop="1px solid rgba(229, 231, 235, 0.5)" pt={4}>
          <HStack spacing={2} w="full" justify="space-between">
            <Button
              size="sm"
              h={9}
              variant="ghost"
              onClick={onClose}
              fontSize="label-xs"
              fontFamily="'Inter', sans-serif"
            >
              Close
            </Button>
            <HStack spacing={2}>
              <Button
                size="sm"
                h={9}
                leftIcon={<Icon as={RiBookOpenLine} boxSize={3.5} />}
                colorScheme="purple"
                onClick={onGetCourses}
                isLoading={loadingCourses}
                borderRadius="10px"
                fontSize="label-xs"
                fontFamily="'Inter', sans-serif"
              >
                Get Courses
              </Button>
              <Button
                size="sm"
                h={9}
                leftIcon={<Icon as={RiVideoLine} boxSize={3.5} />}
                colorScheme="blue"
                onClick={onMockInterview}
                isLoading={loadingInterview}
                borderRadius="10px"
                fontSize="label-xs"
                fontFamily="'Inter', sans-serif"
              >
                Mock Interview
              </Button>

              {/* Always Enabled Apply Button */}
              <Tooltip
                label={
                  result.success_probability < 50
                    ? "Your match score is low, but you can still apply!"
                    : "Good match! Ready to apply"
                }
                fontSize="xs"
                bg="gray.700"
                color="white"
                borderRadius="md"
              >
                <Button
                  size="sm"
                  h={9}
                  leftIcon={<Icon as={RiBriefcaseLine} boxSize={3.5} />}
                  bgGradient={
                    result.success_probability >= 70
                      ? "linear(135deg, green.300, teal.400)"
                      : result.success_probability >= 50
                      ? "linear(135deg, blue.300, blue.400)"
                      : "linear(135deg, orange.300, orange.400)"
                  }
                  color="white"
                  onClick={onApply}
                  borderRadius="10px"
                  fontSize="label-xs"
                  fontFamily="'Inter', sans-serif"
                  _hover={{
                    transform: "translateY(-1px)",
                    shadow: "0 6px 16px -4px rgba(125, 82, 244, 0.4)",
                  }}
                >
                  {result.success_probability >= 70
                    ? "Apply Now"
                    : result.success_probability >= 50
                    ? "Apply Anyway"
                    : "Take a Shot"}
                </Button>
              </Tooltip>
            </HStack>
          </HStack>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

// Main Component (rest remains same with restored functionality)
const JobComparison = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [resumes, setResumes] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [selectedResume, setSelectedResume] = useState("");
  const [selectedJob, setSelectedJob] = useState("");
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [comparisonId, setComparisonId] = useState(null);
  const [loadingCourses, setLoadingCourses] = useState(false);
  const [loadingInterview, setLoadingInterview] = useState(false);
  const [courses, setCourses] = useState(null);

  const {
    isOpen: isResultsOpen,
    onOpen: onResultsOpen,
    onClose: onResultsClose,
  } = useDisclosure();
  const {
    isOpen: isCustomJobOpen,
    onOpen: onCustomJobOpen,
    onClose: onCustomJobClose,
  } = useDisclosure();
  const {
    isOpen: isCoursesOpen,
    onOpen: onCoursesOpen,
    onClose: onCoursesClose,
  } = useDisclosure();
  const toast = useToast();

  useEffect(() => {
    fetchData();
    if (location.state?.selectedJob) {
      setSelectedJob(location.state.selectedJob.id);
    }
  }, []);

  const fetchData = async () => {
    try {
      const [resumesData, jobsData] = await Promise.all([
        resumeAPI.getAll(),
        jobAPI.getAll({ status_filter: "active" }),
      ]);

      const resumeOptions = resumesData.map((r) => ({
        id: r.id,
        label: r.file_name,
        meta: { ATS: `${r.ats_score?.toFixed(0) || "N/A"}%` },
      }));

      const jobOptions = jobsData.map((j) => ({
        id: j.id,
        label: `${j.title} - ${j.location}`,
        meta: { Type: j.employment_type },
      }));

      setResumes(resumeOptions);
      setJobs(jobOptions);

      if (resumeOptions.length > 0) setSelectedResume(resumeOptions[0].id);
      if (jobOptions.length > 0 && !selectedJob)
        setSelectedJob(jobOptions[0].id);
    } catch (error) {
      console.error("Failed to fetch data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCompare = async () => {
    if (!selectedResume || !selectedJob) {
      toast({
        title: "Selection Required",
        description: "Please select both a resume and a job",
        status: "warning",
        duration: 3000,
      });
      return;
    }

    setAnalyzing(true);
    try {
      const comparison = await resumeAPI.compareWithJob(
        selectedResume,
        selectedJob
      );
      setResult(comparison);
      setComparisonId(comparison.comparison_id);
      onResultsOpen();

      toast({
        title: "Analysis Complete",
        description: `Match Score: ${comparison.success_probability.toFixed(
          1
        )}%`,
        status: "success",
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: error.response?.data?.detail || "Failed to compare",
        status: "error",
        duration: 5000,
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCustomJobCompare = async (customJobData) => {
    setAnalyzing(true);
    try {
      const comparison = await studentEnhancementsAPI.compareCustomJob(
        customJobData
      );
      setResult(comparison);
      setComparisonId(comparison.comparison_id);
      onResultsOpen();

      toast({
        title: "Analysis Complete",
        description: `Match Score: ${comparison.success_probability.toFixed(
          1
        )}%`,
        status: "success",
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: error.response?.data?.detail || "Failed to analyze",
        status: "error",
        duration: 5000,
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const handleGetCourses = async () => {
    if (!comparisonId) return;

    setLoadingCourses(true);
    onCoursesOpen();

    try {
      const coursesData = await studentEnhancementsAPI.suggestCourses(
        comparisonId
      );
      setCourses(coursesData);

      toast({
        title: "Courses Generated",
        description: `Found ${
          coursesData.courses?.length || 0
        } relevant courses`,
        status: "success",
        duration: 3000,
      });
    } catch (error) {
      onCoursesClose();
      toast({
        title: "Error",
        description: error.response?.data?.detail || "Failed to get courses",
        status: "error",
        duration: 5000,
      });
    } finally {
      setLoadingCourses(false);
    }
  };

  const handleStartMockInterview = async () => {
    if (!comparisonId) return;

    setLoadingInterview(true);
    try {
      const interview = await studentEnhancementsAPI.generateInterview(
        comparisonId
      );

      toast({
        title: "Mock Interview Ready",
        description: "Redirecting to interview...",
        status: "success",
        duration: 2000,
      });

      setTimeout(() => {
        navigate(`/student/mock-interview/${interview.interview_id}`);
      }, 1000);
    } catch (error) {
      toast({
        title: "Error",
        description:
          error.response?.data?.detail || "Failed to generate interview",
        status: "error",
        duration: 5000,
      });
      setLoadingInterview(false);
    }
  };

  const handleApply = () => {
    if (result?.job_id) {
      navigate(`/student/jobs/${result.job_id}`);
      onResultsClose();
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.xl" position="relative" zIndex={1} py={8}>
          <VStack spacing={6} align="stretch">
            {/* Header */}
            <VStack align="start" spacing={1}>
              <HStack spacing={3}>
                <Box
                  w={10}
                  h={10}
                  borderRadius="10px"
                  bgGradient="linear(135deg, purple.300, purple.400)"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                >
                  <Icon as={RiLineChartLine} color="white" boxSize={5} />
                </Box>
                <VStack align="start" spacing={0}>
                  <Heading
                    fontSize="title-h5"
                    fontWeight={600}
                    fontFamily="'Inter', sans-serif"
                  >
                    Smart Job Match Analyzer
                  </Heading>
                  <Text
                    fontSize="paragraph-sm"
                    color="text.sub"
                    fontFamily="'Inter', sans-serif"
                  >
                    AI-powered resume to job comparison
                  </Text>
                </VStack>
              </HStack>
            </VStack>

            {/* Main Selection Area */}
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(20px)"
              p={6}
              borderRadius="20px"
              border="1px solid rgba(255, 255, 255, 0.8)"
              shadow="0 8px 32px rgba(0, 0, 0, 0.04)"
            >
              <Tabs colorScheme="purple" variant="soft-rounded">
                <TabList gap={2} mb={5}>
                  <Tab
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _selected={{ bg: "purple.300", color: "white" }}
                  >
                    <HStack spacing={2}>
                      <Icon as={RiBriefcaseLine} boxSize={3.5} />
                      <Text>Posted Jobs</Text>
                    </HStack>
                  </Tab>
                  <Tab
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _selected={{ bg: "purple.300", color: "white" }}
                  >
                    <HStack spacing={2}>
                      <Icon as={RiSparklingLine} boxSize={3.5} />
                      <Text>Custom Job</Text>
                    </HStack>
                  </Tab>
                </TabList>

                <TabPanels>
                  <TabPanel px={0}>
                    <VStack spacing={5}>
                      <SimpleGrid
                        columns={{ base: 1, md: 2 }}
                        spacing={4}
                        w="full"
                      >
                        <SelectionCard
                          type="resume"
                          title="Select Resume"
                          subtitle="Choose your optimized resume"
                          value={selectedResume}
                          options={resumes}
                          onChange={setSelectedResume}
                          icon={RiFileTextLine}
                          color="purple"
                        />

                        <SelectionCard
                          type="job"
                          title="Select Job"
                          subtitle="Pick a target position"
                          value={selectedJob}
                          options={jobs}
                          onChange={setSelectedJob}
                          icon={RiBriefcaseLine}
                          color="blue"
                        />
                      </SimpleGrid>

                      <Box
                        p={4}
                        bg="rgba(237, 233, 254, 0.3)"
                        borderRadius="14px"
                        border="1px dashed rgba(125, 82, 244, 0.3)"
                        w="full"
                      >
                        <VStack spacing={3}>
                          <Text
                            fontSize="paragraph-sm"
                            color="text.sub"
                            textAlign="center"
                            fontFamily="'Inter', sans-serif"
                          >
                            Ready to discover your match?
                          </Text>
                          <Button
                            size="md"
                            // h={11}
                            px={8}
                            bgGradient="linear(135deg, purple.300, purple.400)"
                            color="white"
                            borderRadius="10px"
                            onClick={handleCompare}
                            isLoading={analyzing}
                            loadingText="AI Analyzing..."
                            isDisabled={!selectedResume || !selectedJob}
                            rightIcon={
                              <Icon as={RiArrowRightLine} boxSize={4} />
                            }
                            _hover={{
                              transform: "translateY(-2px)",
                              shadow: "0 8px 20px -6px rgba(125, 82, 244, 0.4)",
                              bgGradient:
                                "linear(135deg, purple.400, purple.500)",
                            }}
                            fontSize="label-sm"
                            fontFamily="'Inter', sans-serif"
                          >
                            Analyze Match
                          </Button>
                        </VStack>
                      </Box>
                    </VStack>
                  </TabPanel>

                  <TabPanel px={0}>
                    <VStack spacing={4}>
                      <Box
                        p={8}
                        bg="rgba(237, 233, 254, 0.3)"
                        borderRadius="16px"
                        border="1px dashed rgba(139, 92, 246, 0.3)"
                        textAlign="center"
                      >
                        <Icon
                          as={RiSparklingLine}
                          boxSize={12}
                          color="purple.400"
                          mb={3}
                        />
                        <Text
                          fontSize="label-sm"
                          fontWeight={600}
                          mb={2}
                          fontFamily="'Inter', sans-serif"
                        >
                          Have a specific job in mind?
                        </Text>
                        <Text
                          fontSize="paragraph-sm"
                          color="text.sub"
                          mb={4}
                          fontFamily="'Inter', sans-serif"
                        >
                          Paste any job description from LinkedIn, Indeed, or
                          other platforms
                        </Text>
                        <Button
                          size="sm"
                          h={10}
                          bgGradient="linear(135deg, purple.300, purple.400)"
                          color="white"
                          borderRadius="10px"
                          onClick={onCustomJobOpen}
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                          _hover={{
                            bgGradient:
                              "linear(135deg, purple.400, purple.500)",
                          }}
                        >
                          Compare with Custom JD
                        </Button>
                      </Box>
                    </VStack>
                  </TabPanel>
                </TabPanels>
              </Tabs>
            </Box>
          </VStack>
        </Container>
      </Box>

      {/* All Modals */}
      <ResultsModal
        isOpen={isResultsOpen}
        onClose={onResultsClose}
        result={result}
        onGetCourses={handleGetCourses}
        onMockInterview={handleStartMockInterview}
        onApply={handleApply}
        loadingCourses={loadingCourses}
        loadingInterview={loadingInterview}
      />

      <CoursesModal
        isOpen={isCoursesOpen}
        onClose={onCoursesClose}
        courses={courses}
        loading={loadingCourses}
      />

      <CustomJobModal
        isOpen={isCustomJobOpen}
        onClose={onCustomJobClose}
        onSubmit={handleCustomJobCompare}
        resumes={resumes}
      />
    </Layout>
  );
};

export default JobComparison;
