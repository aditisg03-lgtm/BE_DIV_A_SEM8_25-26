import {
  Box,
  Heading,
  VStack,
  SimpleGrid,
  Text,
  Progress,
  Icon,
  Circle,
  HStack,
  List,
  ListItem,
  ListIcon,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import {
  RiLineChartLine,
  RiFileTextLine,
  RiBriefcaseLine,
  RiCheckboxCircleLine,
  RiLightbulbLine,
} from "react-icons/ri";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { analyticsAPI } from "../../api/analytics";
import { getATSScoreColor, getStatusLabel } from "../../utils/helpers";

const Analytics = () => {
  const [loading, setLoading] = useState(true);
  const [analytics, setAnalytics] = useState(null);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const data = await analyticsAPI.getStudentOverview();
      setAnalytics(data);
    } catch (error) {
      console.error("Failed to fetch analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  const atsScoreColor = getATSScoreColor(analytics?.average_ats_score || 0);

  return (
    <Layout>
      <VStack spacing={6} align="stretch">
        <VStack align="start" spacing={2}>
          <Heading fontSize="title-h4" fontWeight={700} color="text.strong">
            Analytics
          </Heading>
          <Text fontSize="paragraph-sm" color="text.sub">
            Track your performance and get insights
          </Text>
        </VStack>

        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={6}>
          {/* ATS Score Overview */}
          <Box
            bg="bg.white"
            p={8}
            borderRadius="2xl"
            shadow="regular-xs"
            border="1px"
            borderColor="stroke.soft"
          >
            <VStack align="stretch" spacing={6}>
              <HStack spacing={3}>
                <Circle size={12} bg={`${atsScoreColor}.lighter`}>
                  <Icon
                    as={RiLineChartLine}
                    boxSize={6}
                    color={`${atsScoreColor}.base`}
                  />
                </Circle>
                <VStack align="start" spacing={0}>
                  <Heading fontSize="label-lg" fontWeight={600}>
                    ATS Score Overview
                  </Heading>
                  <Text fontSize="paragraph-xs" color="text.soft">
                    Your resume optimization level
                  </Text>
                </VStack>
              </HStack>

              <Box>
                <Text
                  fontSize="title-h3"
                  fontWeight={700}
                  color={`${atsScoreColor}.base`}
                >
                  {analytics?.average_ats_score?.toFixed(1) || 0}%
                </Text>
                <Text fontSize="paragraph-sm" color="text.sub">
                  Average ATS Score
                </Text>
              </Box>

              <Progress
                value={analytics?.average_ats_score || 0}
                h={3}
                borderRadius="full"
                bg="bg.soft"
                sx={{
                  "& > div": {
                    bg: `${atsScoreColor}.base`,
                  },
                }}
              />

              <Box
                p={4}
                bg={`${atsScoreColor}.lighter`}
                borderRadius="xl"
                border="1px"
                borderColor={`${atsScoreColor}.base`}
              >
                <Text fontSize="paragraph-sm" color="text.sub">
                  {analytics?.average_ats_score < 60 &&
                    "⚠️ Your resume needs improvement. Consider optimizing keywords and format."}
                  {analytics?.average_ats_score >= 60 &&
                    analytics?.average_ats_score < 80 &&
                    "✓ Good score! Keep refining your resume for better results."}
                  {analytics?.average_ats_score >= 80 &&
                    "🎉 Excellent! Your resume is highly optimized for ATS systems."}
                </Text>
              </Box>
            </VStack>
          </Box>

          {/* Application Statistics */}
          <Box
            bg="bg.white"
            p={8}
            borderRadius="2xl"
            shadow="regular-xs"
            border="1px"
            borderColor="stroke.soft"
          >
            <VStack align="stretch" spacing={6}>
              <HStack spacing={3}>
                <Circle size={12} bg="information.light">
                  <Icon
                    as={RiBriefcaseLine}
                    boxSize={6}
                    color="information.base"
                  />
                </Circle>
                <VStack align="start" spacing={0}>
                  <Heading fontSize="label-lg" fontWeight={600}>
                    Application Statistics
                  </Heading>
                  <Text fontSize="paragraph-xs" color="text.soft">
                    Your activity summary
                  </Text>
                </VStack>
              </HStack>

              <SimpleGrid columns={2} spacing={4}>
                <Box
                  p={4}
                  bg="primary.alpha.10"
                  borderRadius="xl"
                  border="1px"
                  borderColor="primary.base"
                >
                  <Text
                    fontSize="title-h4"
                    fontWeight={700}
                    color="primary.base"
                  >
                    {analytics?.total_applications || 0}
                  </Text>
                  <Text fontSize="paragraph-sm" color="text.sub">
                    Total Applications
                  </Text>
                </Box>
                <Box
                  p={4}
                  bg="feature.light"
                  borderRadius="xl"
                  border="1px"
                  borderColor="feature.base"
                >
                  <Text
                    fontSize="title-h4"
                    fontWeight={700}
                    color="feature.base"
                  >
                    {analytics?.total_resumes || 0}
                  </Text>
                  <Text fontSize="paragraph-sm" color="text.sub">
                    Total Resumes
                  </Text>
                </Box>
              </SimpleGrid>
            </VStack>
          </Box>
        </SimpleGrid>

        {/* Application Status Breakdown */}
        {analytics?.application_status_breakdown &&
          Object.keys(analytics.application_status_breakdown).length > 0 && (
            <Box
              bg="bg.white"
              p={6}
              borderRadius="2xl"
              shadow="regular-xs"
              border="1px"
              borderColor="stroke.soft"
            >
              <VStack align="stretch" spacing={4}>
                <Heading fontSize="label-lg" fontWeight={600}>
                  Application Status Breakdown
                </Heading>
                <SimpleGrid columns={{ base: 2, md: 3, lg: 4 }} spacing={4}>
                  {Object.entries(analytics.application_status_breakdown).map(
                    ([status, count]) => (
                      <Box
                        key={status}
                        p={4}
                        borderRadius="xl"
                        bg="bg.weak"
                        border="1px"
                        borderColor="stroke.soft"
                      >
                        <Text
                          fontSize="title-h4"
                          fontWeight={700}
                          color="primary.base"
                        >
                          {count}
                        </Text>
                        <Text
                          fontSize="paragraph-sm"
                          color="text.sub"
                          textTransform="capitalize"
                        >
                          {getStatusLabel(status)}
                        </Text>
                      </Box>
                    )
                  )}
                </SimpleGrid>
              </VStack>
            </Box>
          )}

        {/* Tips and Recommendations */}
        <Box
          bg="bg.white"
          p={6}
          borderRadius="2xl"
          shadow="regular-xs"
          border="1px"
          borderColor="stroke.soft"
        >
          <VStack align="stretch" spacing={4}>
            <HStack spacing={3}>
              <Circle size={12} bg="success.lighter">
                <Icon as={RiLightbulbLine} boxSize={6} color="success.base" />
              </Circle>
              <VStack align="start" spacing={0}>
                <Heading fontSize="label-lg" fontWeight={600}>
                  Tips to Improve
                </Heading>
                <Text fontSize="paragraph-xs" color="text.soft">
                  Best practices for success
                </Text>
              </VStack>
            </HStack>

            <List spacing={3}>
              {[
                "Keep your resume updated with latest skills and experience",
                "Use action verbs and quantify achievements",
                "Tailor your resume for each job application",
                "Include relevant keywords from job descriptions",
                "Maintain a clean, ATS-friendly format",
              ].map((tip, index) => (
                <ListItem key={index}>
                  <HStack align="start" spacing={3}>
                    <Circle size={6} bg="success.lighter">
                      <ListIcon
                        as={RiCheckboxCircleLine}
                        color="success.base"
                        boxSize={4}
                        m={0}
                      />
                    </Circle>
                    <Text fontSize="paragraph-sm" color="text.sub" flex={1}>
                      {tip}
                    </Text>
                  </HStack>
                </ListItem>
              ))}
            </List>
          </VStack>
        </Box>
      </VStack>
    </Layout>
  );
};

export default Analytics;
