import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Heading,
  Text,
  Link,
  useToast,
  Container,
  RadioGroup,
  Radio,
  HStack,
  Icon,
  Flex,
  InputGroup,
  InputRightElement,
  IconButton,
  SimpleGrid,
} from "@chakra-ui/react";
import { useState } from "react";
import { useNavigate, Link as RouterLink } from "react-router-dom";
import {
  RiMailLine,
  RiLockPasswordLine,
  RiUserLine,
  RiBriefcaseLine,
  RiEyeLine,
  RiEyeOffLine,
  RiArrowRightLine,
  RiGoogleFill,
  RiGithubFill,
  RiLinkedinBoxFill,
} from "react-icons/ri";
import { useAuth } from "../../context/AuthContext";

const Register = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("student");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      toast({
        title: "Passwords do not match",
        status: "error",
        duration: 3000,
      });
      return;
    }

    if (password.length < 6) {
      toast({
        title: "Password too short",
        description: "Password must be at least 6 characters",
        status: "error",
        duration: 3000,
      });
      return;
    }

    setLoading(true);
    try {
      await register({ email, password, role });
      toast({
        title: "Registration successful",
        description: "Please login to continue",
        status: "success",
        duration: 3000,
      });
      navigate("/login");
    } catch (error) {
      toast({
        title: "Registration failed",
        description: error.response?.data?.detail || "Something went wrong",
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSSOLogin = (provider) => {
    toast({
      title: `${provider} registration`,
      description: "SSO integration coming soon",
      status: "info",
      duration: 2000,
    });
  };

  return (
    <Box
      minH="100vh"
      position="relative"
      overflow="hidden"
      bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
      display="flex"
      alignItems="center"
      _before={{
        content: '""',
        position: "absolute",
        top: "-50%",
        left: "-50%",
        width: "200%",
        height: "200%",
        background:
          "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.4) 0%, transparent 25%)," +
          "radial-gradient(circle at 80% 20%, rgba(254, 242, 242, 0.3) 0%, transparent 25%)," +
          "radial-gradient(circle at 40% 70%, rgba(219, 234, 254, 0.35) 0%, transparent 25%)," +
          "radial-gradient(circle at 90% 80%, rgba(253, 230, 255, 0.3) 0%, transparent 25%)," +
          "radial-gradient(circle at 10% 90%, rgba(236, 252, 246, 0.3) 0%, transparent 25%)",
        animation: "float 20s ease-in-out infinite",
        zIndex: 0,
      }}
      _after={{
        content: '""',
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%239C92AC' fill-opacity='0.02'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        opacity: 0.4,
        zIndex: 0,
      }}
      sx={{
        "@keyframes float": {
          "0%, 100%": { transform: "translate(0, 0) rotate(0deg)" },
          "33%": { transform: "translate(30px, -30px) rotate(120deg)" },
          "66%": { transform: "translate(-20px, 20px) rotate(240deg)" },
        },
      }}
    >
      <Container maxW="400px" position="relative" zIndex={1} py={8}>
        {/* Minimalist Logo */}
        <Flex justify="center" mb={6}>
          <VStack spacing={1.5}>
            <Box
              w={10}
              h={10}
              borderRadius="14px"
              bgGradient="linear(135deg, primary.base, feature.base)"
              display="flex"
              alignItems="center"
              justifyContent="center"
              shadow="0 6px 24px -6px rgba(125, 82, 244, 0.3)"
              position="relative"
              _before={{
                content: '""',
                position: "absolute",
                inset: 0,
                borderRadius: "14px",
                padding: "1.5px",
                background:
                  "linear-gradient(135deg, rgba(255,255,255,0.8), rgba(255,255,255,0.2))",
                WebkitMask:
                  "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
                WebkitMaskComposite: "xor",
                maskComposite: "exclude",
              }}
            >
              <Text fontSize="md" fontWeight={700} color="white">
                IH
              </Text>
            </Box>
            <Text
              fontSize="label-sm"
              fontWeight={600}
              color="text.strong"
              letterSpacing="tight"
              fontFamily="'Inter', sans-serif"
            >
              IntelizenHire
            </Text>
          </VStack>
        </Flex>

        {/* Main Card with Glassmorphism */}
        <Box
          bg="rgba(255, 255, 255, 0.7)"
          backdropFilter="blur(20px)"
          borderRadius="20px"
          border="1px solid"
          borderColor="rgba(255, 255, 255, 0.8)"
          shadow="0 8px 32px rgba(0, 0, 0, 0.04)"
          p={7}
          position="relative"
          _before={{
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            borderRadius: "20px",
            padding: "1px",
            background:
              "linear-gradient(135deg, rgba(255,255,255,0.8), rgba(255,255,255,0.2))",
            WebkitMask:
              "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
            WebkitMaskComposite: "xor",
            maskComposite: "exclude",
            pointerEvents: "none",
          }}
        >
          <VStack spacing={5} align="stretch">
            {/* Minimal Header */}
            <VStack spacing={1.5} textAlign="center">
              <Heading
                fontSize="title-h5"
                fontWeight={600}
                color="text.strong"
                letterSpacing="-0.02em"
                fontFamily="'Inter', sans-serif"
              >
                Create your account
              </Heading>
              <Text
                fontSize="paragraph-xs"
                color="text.sub"
                fontWeight={400}
                fontFamily="'Inter', sans-serif"
              >
                Get started with IntelizenHire today
              </Text>
            </VStack>

            {/* SSO Buttons */}
            <VStack spacing={2.5}>
              <SimpleGrid columns={3} spacing={2.5} w="full">
                <Button
                  variant="outline"
                  size="sm"
                  h={9}
                  borderRadius="10px"
                  bg="rgba(255, 255, 255, 0.6)"
                  backdropFilter="blur(10px)"
                  border="1px solid"
                  borderColor="rgba(229, 231, 235, 0.8)"
                  _hover={{
                    bg: "rgba(255, 255, 255, 0.9)",
                    borderColor: "#4285F4",
                    transform: "translateY(-1px)",
                    shadow: "0 4px 12px -4px rgba(66, 133, 244, 0.3)",
                  }}
                  onClick={() => handleSSOLogin("Google")}
                  transition="all 0.2s"
                >
                  <Icon as={RiGoogleFill} boxSize={4} color="#4285F4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  h={9}
                  borderRadius="10px"
                  bg="rgba(255, 255, 255, 0.6)"
                  backdropFilter="blur(10px)"
                  border="1px solid"
                  borderColor="rgba(229, 231, 235, 0.8)"
                  _hover={{
                    bg: "rgba(255, 255, 255, 0.9)",
                    borderColor: "#0A66C2",
                    transform: "translateY(-1px)",
                    shadow: "0 4px 12px -4px rgba(10, 102, 194, 0.3)",
                  }}
                  onClick={() => handleSSOLogin("LinkedIn")}
                  transition="all 0.2s"
                >
                  <Icon as={RiLinkedinBoxFill} boxSize={4} color="#0A66C2" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  h={9}
                  borderRadius="10px"
                  bg="rgba(255, 255, 255, 0.6)"
                  backdropFilter="blur(10px)"
                  border="1px solid"
                  borderColor="rgba(229, 231, 235, 0.8)"
                  _hover={{
                    bg: "rgba(255, 255, 255, 0.9)",
                    borderColor: "#24292e",
                    transform: "translateY(-1px)",
                    shadow: "0 4px 12px -4px rgba(36, 41, 46, 0.3)",
                  }}
                  onClick={() => handleSSOLogin("GitHub")}
                  transition="all 0.2s"
                >
                  <Icon as={RiGithubFill} boxSize={4} color="#24292e" />
                </Button>
              </SimpleGrid>

              {/* Divider */}
              <Flex align="center" gap={3} w="full">
                <Box flex={1} h="1px" bg="stroke.soft" />
                <Text
                  fontSize="subheading-xs"
                  color="text.soft"
                  fontWeight={500}
                  textTransform="uppercase"
                  letterSpacing="wide"
                  fontFamily="'Inter', sans-serif"
                >
                  or
                </Text>
                <Box flex={1} h="1px" bg="stroke.soft" />
              </Flex>
            </VStack>

            {/* Form */}
            <form onSubmit={handleSubmit}>
              <VStack spacing={3.5}>
                {/* Email Field */}
                <FormControl isRequired>
                  <FormLabel
                    fontSize="label-xs"
                    color="text.sub"
                    fontWeight={500}
                    mb={1.5}
                    fontFamily="'Inter', sans-serif"
                  >
                    Email
                  </FormLabel>
                  <InputGroup size="md">
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      h={10}
                      fontSize="paragraph-sm"
                      bg="rgba(255, 255, 255, 0.6)"
                      backdropFilter="blur(10px)"
                      border="1px solid"
                      borderColor="rgba(229, 231, 235, 0.8)"
                      borderRadius="10px"
                      _hover={{
                        borderColor: "primary.lighter",
                        bg: "rgba(255, 255, 255, 0.8)",
                      }}
                      _focus={{
                        borderColor: "primary.base",
                        boxShadow: "0 0 0 3px rgba(125, 82, 244, 0.08)",
                        bg: "rgba(255, 255, 255, 0.9)",
                      }}
                      _placeholder={{
                        color: "text.disabled",
                        fontSize: "paragraph-sm",
                      }}
                      pl={9}
                      transition="all 0.2s"
                      fontFamily="'Inter', sans-serif"
                    />
                    <Box
                      position="absolute"
                      left={3}
                      top="50%"
                      transform="translateY(-50%)"
                      zIndex={2}
                      pointerEvents="none"
                    >
                      <Icon as={RiMailLine} color="text.soft" boxSize={4} />
                    </Box>
                  </InputGroup>
                </FormControl>

                {/* Password Field */}
                <FormControl isRequired>
                  <FormLabel
                    fontSize="label-xs"
                    color="text.sub"
                    fontWeight={500}
                    mb={1.5}
                    fontFamily="'Inter', sans-serif"
                  >
                    Password
                  </FormLabel>
                  <InputGroup size="md">
                    <Input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Min. 6 characters"
                      h={10}
                      fontSize="paragraph-sm"
                      bg="rgba(255, 255, 255, 0.6)"
                      backdropFilter="blur(10px)"
                      border="1px solid"
                      borderColor="rgba(229, 231, 235, 0.8)"
                      borderRadius="10px"
                      _hover={{
                        borderColor: "primary.lighter",
                        bg: "rgba(255, 255, 255, 0.8)",
                      }}
                      _focus={{
                        borderColor: "primary.base",
                        boxShadow: "0 0 0 3px rgba(125, 82, 244, 0.08)",
                        bg: "rgba(255, 255, 255, 0.9)",
                      }}
                      _placeholder={{
                        color: "text.disabled",
                        fontSize: "paragraph-sm",
                      }}
                      pl={9}
                      pr={10}
                      transition="all 0.2s"
                      fontFamily="'Inter', sans-serif"
                    />
                    <Box
                      position="absolute"
                      left={3}
                      top="50%"
                      transform="translateY(-50%)"
                      zIndex={2}
                      pointerEvents="none"
                    >
                      <Icon
                        as={RiLockPasswordLine}
                        color="text.soft"
                        boxSize={4}
                      />
                    </Box>
                    <InputRightElement h="full">
                      <IconButton
                        variant="ghost"
                        size="xs"
                        icon={
                          <Icon
                            as={showPassword ? RiEyeOffLine : RiEyeLine}
                            boxSize={4}
                            color="text.soft"
                          />
                        }
                        onClick={() => setShowPassword(!showPassword)}
                        aria-label={
                          showPassword ? "Hide password" : "Show password"
                        }
                        _hover={{ bg: "transparent", color: "text.sub" }}
                        borderRadius="6px"
                      />
                    </InputRightElement>
                  </InputGroup>
                </FormControl>

                {/* Confirm Password Field */}
                <FormControl isRequired>
                  <FormLabel
                    fontSize="label-xs"
                    color="text.sub"
                    fontWeight={500}
                    mb={1.5}
                    fontFamily="'Inter', sans-serif"
                  >
                    Confirm Password
                  </FormLabel>
                  <InputGroup size="md">
                    <Input
                      type={showConfirmPassword ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Re-enter password"
                      h={10}
                      fontSize="paragraph-sm"
                      bg="rgba(255, 255, 255, 0.6)"
                      backdropFilter="blur(10px)"
                      border="1px solid"
                      borderColor="rgba(229, 231, 235, 0.8)"
                      borderRadius="10px"
                      _hover={{
                        borderColor: "primary.lighter",
                        bg: "rgba(255, 255, 255, 0.8)",
                      }}
                      _focus={{
                        borderColor: "primary.base",
                        boxShadow: "0 0 0 3px rgba(125, 82, 244, 0.08)",
                        bg: "rgba(255, 255, 255, 0.9)",
                      }}
                      _placeholder={{
                        color: "text.disabled",
                        fontSize: "paragraph-sm",
                      }}
                      pl={9}
                      pr={10}
                      transition="all 0.2s"
                      fontFamily="'Inter', sans-serif"
                    />
                    <Box
                      position="absolute"
                      left={3}
                      top="50%"
                      transform="translateY(-50%)"
                      zIndex={2}
                      pointerEvents="none"
                    >
                      <Icon
                        as={RiLockPasswordLine}
                        color="text.soft"
                        boxSize={4}
                      />
                    </Box>
                    <InputRightElement h="full">
                      <IconButton
                        variant="ghost"
                        size="xs"
                        icon={
                          <Icon
                            as={showConfirmPassword ? RiEyeOffLine : RiEyeLine}
                            boxSize={4}
                            color="text.soft"
                          />
                        }
                        onClick={() =>
                          setShowConfirmPassword(!showConfirmPassword)
                        }
                        aria-label={
                          showConfirmPassword
                            ? "Hide password"
                            : "Show password"
                        }
                        _hover={{ bg: "transparent", color: "text.sub" }}
                        borderRadius="6px"
                      />
                    </InputRightElement>
                  </InputGroup>
                </FormControl>

                {/* Role Selection */}
                <FormControl isRequired>
                  <FormLabel
                    fontSize="label-xs"
                    color="text.sub"
                    fontWeight={500}
                    mb={2}
                    fontFamily="'Inter', sans-serif"
                  >
                    I am a
                  </FormLabel>
                  <RadioGroup value={role} onChange={setRole}>
                    <VStack spacing={2} align="stretch">
                      <Box
                        p={3}
                        borderRadius="10px"
                        border="1.5px solid"
                        borderColor={
                          role === "student"
                            ? "primary.base"
                            : "rgba(229, 231, 235, 0.8)"
                        }
                        bg={
                          role === "student"
                            ? "rgba(125, 82, 244, 0.05)"
                            : "rgba(255, 255, 255, 0.6)"
                        }
                        backdropFilter="blur(10px)"
                        cursor="pointer"
                        transition="all 0.2s"
                        onClick={() => setRole("student")}
                        _hover={{
                          borderColor: "primary.lighter",
                          bg:
                            role === "student"
                              ? "rgba(125, 82, 244, 0.08)"
                              : "rgba(255, 255, 255, 0.8)",
                        }}
                      >
                        <Radio value="student" colorScheme="purple">
                          <HStack spacing={2.5}>
                            <Box
                              w={8}
                              h={8}
                              borderRadius="8px"
                              bg={
                                role === "student"
                                  ? "primary.base"
                                  : "rgba(248, 249, 250, 1)"
                              }
                              display="flex"
                              alignItems="center"
                              justifyContent="center"
                              transition="all 0.2s"
                            >
                              <Icon
                                as={RiUserLine}
                                boxSize={4}
                                color={
                                  role === "student" ? "white" : "text.soft"
                                }
                              />
                            </Box>
                            <VStack align="start" spacing={0}>
                              <Text
                                fontSize="label-xs"
                                fontWeight={600}
                                color="text.strong"
                                fontFamily="'Inter', sans-serif"
                              >
                                Student / Job Seeker
                              </Text>
                              <Text
                                fontSize="subheading-xs"
                                color="text.sub"
                                fontFamily="'Inter', sans-serif"
                              >
                                Find jobs and optimize resume
                              </Text>
                            </VStack>
                          </HStack>
                        </Radio>
                      </Box>

                      <Box
                        p={3}
                        borderRadius="10px"
                        border="1.5px solid"
                        borderColor={
                          role === "hr"
                            ? "primary.base"
                            : "rgba(229, 231, 235, 0.8)"
                        }
                        bg={
                          role === "hr"
                            ? "rgba(125, 82, 244, 0.05)"
                            : "rgba(255, 255, 255, 0.6)"
                        }
                        backdropFilter="blur(10px)"
                        cursor="pointer"
                        transition="all 0.2s"
                        onClick={() => setRole("hr")}
                        _hover={{
                          borderColor: "primary.lighter",
                          bg:
                            role === "hr"
                              ? "rgba(125, 82, 244, 0.08)"
                              : "rgba(255, 255, 255, 0.8)",
                        }}
                      >
                        <Radio value="hr" colorScheme="purple">
                          <HStack spacing={2.5}>
                            <Box
                              w={8}
                              h={8}
                              borderRadius="8px"
                              bg={
                                role === "hr"
                                  ? "primary.base"
                                  : "rgba(248, 249, 250, 1)"
                              }
                              display="flex"
                              alignItems="center"
                              justifyContent="center"
                              transition="all 0.2s"
                            >
                              <Icon
                                as={RiBriefcaseLine}
                                boxSize={4}
                                color={role === "hr" ? "white" : "text.soft"}
                              />
                            </Box>
                            <VStack align="start" spacing={0}>
                              <Text
                                fontSize="label-xs"
                                fontWeight={600}
                                color="text.strong"
                                fontFamily="'Inter', sans-serif"
                              >
                                HR / Recruiter
                              </Text>
                              <Text
                                fontSize="subheading-xs"
                                color="text.sub"
                                fontFamily="'Inter', sans-serif"
                              >
                                Post jobs and manage applications
                              </Text>
                            </VStack>
                          </HStack>
                        </Radio>
                      </Box>
                    </VStack>
                  </RadioGroup>
                </FormControl>

                {/* Submit Button */}
                <Button
                  type="submit"
                  size="md"
                  w="full"
                  h={10}
                  fontSize="label-sm"
                  fontWeight={500}
                  bgGradient="linear(135deg, primary.base, feature.base)"
                  color="white"
                  borderRadius="10px"
                  isLoading={loading}
                  loadingText="Creating account..."
                  rightIcon={<Icon as={RiArrowRightLine} boxSize={4} />}
                  _hover={{
                    transform: "translateY(-1px)",
                    shadow: "0 8px 20px -6px rgba(125, 82, 244, 0.4)",
                  }}
                  _active={{
                    transform: "translateY(0)",
                    shadow: "0 4px 12px -4px rgba(125, 82, 244, 0.3)",
                  }}
                  transition="all 0.2s cubic-bezier(0.4, 0, 0.2, 1)"
                  shadow="0 4px 14px -4px rgba(125, 82, 244, 0.3)"
                  fontFamily="'Inter', sans-serif"
                >
                  Create account
                </Button>
              </VStack>
            </form>

            {/* Sign In Link */}
            <Text
              textAlign="center"
              fontSize="paragraph-xs"
              color="text.sub"
              fontWeight={400}
              fontFamily="'Inter', sans-serif"
            >
              Already have an account?{" "}
              <Link
                as={RouterLink}
                to="/login"
                color="primary.base"
                fontWeight={500}
                _hover={{
                  color: "primary.darker",
                  textDecoration: "none",
                }}
                transition="color 0.2s"
              >
                Sign in
              </Link>
            </Text>
          </VStack>
        </Box>

        {/* Footer */}
        <Text
          textAlign="center"
          mt={5}
          fontSize="subheading-xs"
          color="text.soft"
          fontWeight={400}
          fontFamily="'Inter', sans-serif"
        >
          By signing up, you agree to our Terms & Privacy Policy
        </Text>
      </Container>
    </Box>
  );
};

export default Register;
