import {
  Box,
  Heading,
  VStack,
  useToast,
  Button,
  Container,
  Icon,
  HStack,
  Text,
} from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { FiPlus, FiAlertCircle } from "react-icons/fi";
import Layout from "../../components/layout/Layout";
import JobForm from "../../components/hr/JobForm";
import Loading from "../../components/common/Loading";
import api from "../../api/axios";

const CreateJob = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [hasProfile, setHasProfile] = useState(false);

  useEffect(() => {
    checkProfile();
  }, []);

  const checkProfile = async () => {
    try {
      await api.get("/api/hr/profile");
      setHasProfile(true);
    } catch (error) {
      if (error.response?.status === 404) {
        setHasProfile(false);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSuccess = () => {
    navigate("/hr/jobs");
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  if (!hasProfile) {
    return (
      <Layout>
        <Box
          minH="100vh"
          bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
          position="relative"
        >
          <Container maxW="container.md" py={16}>
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(20px)"
              p={10}
              borderRadius="20px"
              border="1px solid rgba(255, 255, 255, 0.8)"
              textAlign="center"
            >
              <Icon
                as={FiAlertCircle}
                boxSize={16}
                color="warning.base"
                mb={4}
              />
              <Heading
                size="md"
                mb={2}
                fontFamily="'Inter', sans-serif"
                fontWeight={600}
              >
                Profile Required
              </Heading>
              <Text
                fontSize="paragraph-sm"
                color="text.sub"
                mb={6}
                fontFamily="'Inter', sans-serif"
              >
                Complete your HR profile before creating job postings
              </Text>
              <Button
                size="sm"
                h={10}
                bgGradient="linear(135deg, primary.base, feature.base)"
                color="white"
                borderRadius="10px"
                onClick={() => navigate("/hr/profile")}
                fontFamily="'Inter', sans-serif"
                fontSize="label-sm"
              >
                Complete Profile
              </Button>
            </Box>
          </Container>
        </Box>
      </Layout>
    );
  }

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.lg" position="relative" zIndex={1} py={8}>
          <VStack spacing={6} align="stretch">
            {/* Header */}
            <HStack spacing={3}>
              <Box
                w={10}
                h={10}
                borderRadius="10px"
                bgGradient="linear(135deg, primary.base, feature.base)"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                <Icon as={FiPlus} color="white" boxSize={5} />
              </Box>
              <VStack align="start" spacing={0}>
                <Heading
                  fontSize="title-h5"
                  fontWeight={600}
                  fontFamily="'Inter', sans-serif"
                >
                  Create New Job
                </Heading>
                <Text
                  fontSize="paragraph-xs"
                  color="text.sub"
                  fontFamily="'Inter', sans-serif"
                >
                  Post a new position to attract candidates
                </Text>
              </VStack>
            </HStack>

            {/* Form */}
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(20px)"
              p={6}
              borderRadius="16px"
              border="1px solid rgba(255, 255, 255, 0.8)"
              shadow="0 8px 32px rgba(0, 0, 0, 0.04)"
            >
              <JobForm onSuccess={handleSuccess} />
            </Box>
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default CreateJob;
