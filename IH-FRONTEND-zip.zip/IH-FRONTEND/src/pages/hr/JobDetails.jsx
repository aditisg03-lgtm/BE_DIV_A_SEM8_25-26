import {
  Box,
  Heading,
  VStack,
  HStack,
  Text,
  Badge,
  Button,
  SimpleGrid,
  useToast,
  Icon,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Container,
  Flex,
  Wrap,
  WrapItem,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  FiEdit,
  FiTrash2,
  FiCheckCircle,
  FiXCircle,
  FiEye,
  FiMapPin,
  FiDollarSign,
  FiClock,
  FiBriefcase,
  FiAlertTriangle,
} from "react-icons/fi";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import EditJobForm from "../../components/hr/EditJobForm";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { jobAPI } from "../../api/job";
import { applicationAPI } from "../../api/application";
import { formatDate, formatSalary, getStatusLabel } from "../../utils/helpers";
import { STATUS_COLORS } from "../../utils/constants";

const JobDetails = () => {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const toast = useToast();

  useEffect(() => {
    fetchJobDetails();
    fetchApplications();
  }, [jobId]);

  const fetchJobDetails = async () => {
    try {
      const data = await jobAPI.getById(jobId);
      setJob(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load job details",
        status: "error",
        duration: 3000,
      });
      navigate("/hr/jobs");
    } finally {
      setLoading(false);
    }
  };

  const fetchApplications = async () => {
    try {
      const allApps = await applicationAPI.getAll();
      const jobApps = allApps.filter((app) => app.job_description_id === jobId);
      setApplications(jobApps);
    } catch (error) {
      console.error("Failed to fetch applications:", error);
    }
  };

  const handlePublish = async () => {
    try {
      await jobAPI.publish(jobId);
      toast({
        title: "Job published",
        status: "success",
        duration: 2000,
      });
      fetchJobDetails();
    } catch (error) {
      toast({
        title: "Publish failed",
        status: "error",
        duration: 2000,
      });
    }
  };

  const handleClose = async () => {
    try {
      await jobAPI.close(jobId);
      toast({
        title: "Job closed",
        status: "success",
        duration: 2000,
      });
      fetchJobDetails();
    } catch (error) {
      toast({
        title: "Close failed",
        status: "error",
        duration: 2000,
      });
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await jobAPI.delete(jobId);
      toast({
        title: "Job deleted",
        status: "success",
        duration: 2000,
      });
      navigate("/hr/jobs");
    } catch (error) {
      toast({
        title: "Delete failed",
        status: "error",
        duration: 2000,
      });
    } finally {
      setDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  const handleUpdateSuccess = () => {
    fetchJobDetails();
    toast({
      title: "Job updated successfully",
      status: "success",
      duration: 2000,
    });
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );
  if (!job) return null;

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.xl" position="relative" zIndex={1} py={8}>
          <VStack spacing={5} align="stretch">
            {/* Header */}
            <Flex justify="space-between" align="start">
              <VStack align="start" spacing={2}>
                <Heading
                  fontSize="title-h5"
                  fontWeight={600}
                  fontFamily="'Inter', sans-serif"
                >
                  {job.title}
                </Heading>
                <HStack spacing={3} flexWrap="wrap">
                  <Badge
                    colorScheme={STATUS_COLORS[job.status]}
                    fontSize="label-xs"
                    px={2}
                    py={1}
                  >
                    {getStatusLabel(job.status)}
                  </Badge>
                  <HStack fontSize="paragraph-sm" color="text.sub">
                    <Icon as={FiClock} boxSize={3.5} />
                    <Text fontFamily="'Inter', sans-serif">
                      {job.posted_date ? formatDate(job.posted_date) : "Draft"}
                    </Text>
                  </HStack>
                  <Badge colorScheme="purple" fontSize="label-xs" px={2} py={1}>
                    {applications.length} applications
                  </Badge>
                </HStack>
              </VStack>
              <HStack spacing={2}>
                {job.status === "draft" && (
                  <Button
                    size="sm"
                    h={9}
                    leftIcon={<Icon as={FiCheckCircle} boxSize={3.5} />}
                    colorScheme="green"
                    onClick={handlePublish}
                    borderRadius="10px"
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                  >
                    Publish
                  </Button>
                )}
                {job.status === "active" && (
                  <Button
                    size="sm"
                    h={9}
                    leftIcon={<Icon as={FiXCircle} boxSize={3.5} />}
                    colorScheme="orange"
                    onClick={handleClose}
                    borderRadius="10px"
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                  >
                    Close
                  </Button>
                )}
              </HStack>
            </Flex>

            {/* Tabs */}
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(20px)"
              borderRadius="16px"
              border="1px solid rgba(255, 255, 255, 0.8)"
              shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
              overflow="hidden"
            >
              <Tabs colorScheme="purple" variant="soft-rounded" p={4}>
                <TabList gap={2}>
                  <Tab
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _selected={{ bg: "primary.base", color: "white" }}
                  >
                    <HStack spacing={2}>
                      <Icon as={FiEye} boxSize={3.5} />
                      <Text>Details</Text>
                    </HStack>
                  </Tab>
                  <Tab
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _selected={{ bg: "primary.base", color: "white" }}
                  >
                    <HStack spacing={2}>
                      <Icon as={FiEdit} boxSize={3.5} />
                      <Text>Edit</Text>
                    </HStack>
                  </Tab>
                  <Tab
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _selected={{ bg: "red.500", color: "white" }}
                  >
                    <HStack spacing={2}>
                      <Icon as={FiTrash2} boxSize={3.5} />
                      <Text>Delete</Text>
                    </HStack>
                  </Tab>
                </TabList>

                <TabPanels>
                  {/* View Tab */}
                  <TabPanel px={0}>
                    <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={4}>
                      {/* Job Details */}
                      <Box
                        bg="rgba(255, 255, 255, 0.5)"
                        backdropFilter="blur(10px)"
                        p={5}
                        borderRadius="12px"
                        border="1px solid rgba(229, 231, 235, 0.8)"
                      >
                        <VStack align="stretch" spacing={4}>
                          <Text
                            fontSize="label-sm"
                            fontWeight={600}
                            fontFamily="'Inter', sans-serif"
                          >
                            Job Information
                          </Text>

                          <VStack align="stretch" spacing={3}>
                            <HStack>
                              <Icon
                                as={FiMapPin}
                                color="primary.base"
                                boxSize={4}
                              />
                              <VStack align="start" spacing={0} flex={1}>
                                <Text
                                  fontSize="subheading-xs"
                                  color="text.soft"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  Location
                                </Text>
                                <Text
                                  fontSize="paragraph-sm"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {job.location}
                                </Text>
                              </VStack>
                            </HStack>

                            <HStack>
                              <Icon
                                as={FiBriefcase}
                                color="primary.base"
                                boxSize={4}
                              />
                              <VStack align="start" spacing={0} flex={1}>
                                <Text
                                  fontSize="subheading-xs"
                                  color="text.soft"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  Employment Type
                                </Text>
                                <Text
                                  fontSize="paragraph-sm"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {getStatusLabel(job.employment_type)}
                                </Text>
                              </VStack>
                            </HStack>

                            <HStack>
                              <Icon
                                as={FiDollarSign}
                                color="primary.base"
                                boxSize={4}
                              />
                              <VStack align="start" spacing={0} flex={1}>
                                <Text
                                  fontSize="subheading-xs"
                                  color="text.soft"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  Salary Range
                                </Text>
                                <Text
                                  fontSize="paragraph-sm"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {formatSalary(job.salary_min, job.salary_max)}
                                </Text>
                              </VStack>
                            </HStack>

                            {job.department && (
                              <Box>
                                <Text
                                  fontSize="subheading-xs"
                                  color="text.soft"
                                  mb={1}
                                  fontFamily="'Inter', sans-serif"
                                >
                                  Department
                                </Text>
                                <Text
                                  fontSize="paragraph-sm"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {job.department}
                                </Text>
                              </Box>
                            )}

                            <Box>
                              <Text
                                fontSize="subheading-xs"
                                color="text.soft"
                                mb={1}
                                fontFamily="'Inter', sans-serif"
                              >
                                Experience Level
                              </Text>
                              <Text
                                fontSize="paragraph-sm"
                                fontFamily="'Inter', sans-serif"
                              >
                                {getStatusLabel(job.experience_level)}
                              </Text>
                            </Box>

                            <Box>
                              <Text
                                fontSize="subheading-xs"
                                color="text.soft"
                                mb={1}
                                fontFamily="'Inter', sans-serif"
                              >
                                Description
                              </Text>
                              <Text
                                fontSize="paragraph-sm"
                                fontFamily="'Inter', sans-serif"
                              >
                                {job.description}
                              </Text>
                            </Box>
                          </VStack>
                        </VStack>
                      </Box>

                      {/* Requirements & Skills */}
                      <Box
                        bg="rgba(255, 255, 255, 0.5)"
                        backdropFilter="blur(10px)"
                        p={5}
                        borderRadius="12px"
                        border="1px solid rgba(229, 231, 235, 0.8)"
                      >
                        <VStack align="stretch" spacing={4}>
                          <Text
                            fontSize="label-sm"
                            fontWeight={600}
                            fontFamily="'Inter', sans-serif"
                          >
                            Requirements & Skills
                          </Text>

                          {job.requirements && job.requirements.length > 0 && (
                            <Box>
                              <Text
                                fontSize="subheading-xs"
                                fontWeight={500}
                                mb={2}
                                fontFamily="'Inter', sans-serif"
                              >
                                Requirements
                              </Text>
                              <VStack align="stretch" spacing={1}>
                                {job.requirements.map((req, index) => (
                                  <Text
                                    key={index}
                                    fontSize="paragraph-sm"
                                    fontFamily="'Inter', sans-serif"
                                  >
                                    • {req}
                                  </Text>
                                ))}
                              </VStack>
                            </Box>
                          )}

                          {job.responsibilities &&
                            job.responsibilities.length > 0 && (
                              <Box>
                                <Text
                                  fontSize="subheading-xs"
                                  fontWeight={500}
                                  mb={2}
                                  fontFamily="'Inter', sans-serif"
                                >
                                  Responsibilities
                                </Text>
                                <VStack align="stretch" spacing={1}>
                                  {job.responsibilities.map((resp, index) => (
                                    <Text
                                      key={index}
                                      fontSize="paragraph-sm"
                                      fontFamily="'Inter', sans-serif"
                                    >
                                      • {resp}
                                    </Text>
                                  ))}
                                </VStack>
                              </Box>
                            )}

                          {job.required_skills &&
                            job.required_skills.length > 0 && (
                              <Box>
                                <Text
                                  fontSize="subheading-xs"
                                  fontWeight={500}
                                  mb={2}
                                  fontFamily="'Inter', sans-serif"
                                >
                                  Required Skills
                                </Text>
                                <Wrap>
                                  {job.required_skills.map((skill, index) => (
                                    <WrapItem key={index}>
                                      <Badge
                                        colorScheme="purple"
                                        fontSize="subheading-xs"
                                      >
                                        {skill.name || skill}
                                      </Badge>
                                    </WrapItem>
                                  ))}
                                </Wrap>
                              </Box>
                            )}

                          {job.benefits && job.benefits.length > 0 && (
                            <Box>
                              <Text
                                fontSize="subheading-xs"
                                fontWeight={500}
                                mb={2}
                                fontFamily="'Inter', sans-serif"
                              >
                                Benefits
                              </Text>
                              <VStack align="stretch" spacing={1}>
                                {job.benefits.map((benefit, index) => (
                                  <Text
                                    key={index}
                                    fontSize="paragraph-sm"
                                    fontFamily="'Inter', sans-serif"
                                  >
                                    • {benefit}
                                  </Text>
                                ))}
                              </VStack>
                            </Box>
                          )}
                        </VStack>
                      </Box>
                    </SimpleGrid>

                    {/* Applications */}
                    <Box mt={5}>
                      <Text
                        fontSize="label-sm"
                        fontWeight={600}
                        mb={3}
                        fontFamily="'Inter', sans-serif"
                      >
                        Applications ({applications.length})
                      </Text>

                      {applications.length === 0 ? (
                        <Box
                          bg="rgba(255, 255, 255, 0.5)"
                          backdropFilter="blur(10px)"
                          p={8}
                          borderRadius="12px"
                          textAlign="center"
                        >
                          <Text
                            fontSize="paragraph-sm"
                            color="text.sub"
                            fontFamily="'Inter', sans-serif"
                          >
                            No applications yet
                          </Text>
                        </Box>
                      ) : (
                        <SimpleGrid
                          columns={{ base: 1, md: 2, lg: 3 }}
                          spacing={3}
                        >
                          {applications.map((application) => (
                            <Box
                              key={application.id}
                              bg="rgba(255, 255, 255, 0.5)"
                              backdropFilter="blur(10px)"
                              p={4}
                              borderRadius="10px"
                              border="1px solid rgba(229, 231, 235, 0.8)"
                              transition="all 0.2s"
                              _hover={{
                                transform: "translateY(-2px)",
                                shadow: "md",
                                borderColor: "primary.base",
                              }}
                            >
                              <VStack align="stretch" spacing={2}>
                                <HStack justify="space-between">
                                  <Text
                                    fontSize="label-xs"
                                    fontWeight={600}
                                    fontFamily="'Inter', sans-serif"
                                  >
                                    Application #
                                    {application.id.substring(0, 8)}
                                  </Text>
                                  <Badge
                                    colorScheme={
                                      STATUS_COLORS[application.status]
                                    }
                                    fontSize="subheading-xs"
                                  >
                                    {getStatusLabel(application.status)}
                                  </Badge>
                                </HStack>
                                <Text
                                  fontSize="paragraph-xs"
                                  color="text.sub"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {formatDate(application.applied_date)}
                                </Text>
                                {application.ats_score && (
                                  <Badge
                                    alignSelf="start"
                                    fontSize="subheading-xs"
                                  >
                                    ATS: {application.ats_score.toFixed(1)}%
                                  </Badge>
                                )}
                              </VStack>
                            </Box>
                          ))}
                        </SimpleGrid>
                      )}
                    </Box>
                  </TabPanel>

                  {/* Edit Tab */}
                  <TabPanel px={0}>
                    <Box
                      bg="rgba(255, 255, 255, 0.5)"
                      backdropFilter="blur(10px)"
                      p={5}
                      borderRadius="12px"
                      border="1px solid rgba(229, 231, 235, 0.8)"
                    >
                      <EditJobForm
                        job={job}
                        onSuccess={handleUpdateSuccess}
                        onCancel={() => {}}
                      />
                    </Box>
                  </TabPanel>

                  {/* Delete Tab */}
                  <TabPanel px={0}>
                    <Box
                      bg="rgba(255, 255, 255, 0.5)"
                      backdropFilter="blur(10px)"
                      p={5}
                      borderRadius="12px"
                      border="1px solid rgba(229, 231, 235, 0.8)"
                    >
                      <VStack spacing={5} align="stretch">
                        <Box
                          bg="rgba(239, 68, 68, 0.1)"
                          p={5}
                          borderRadius="12px"
                          border="1px solid rgba(239, 68, 68, 0.3)"
                        >
                          <HStack spacing={3} mb={3}>
                            <Icon
                              as={FiAlertTriangle}
                              color="red.600"
                              boxSize={6}
                            />
                            <Text
                              fontSize="label-sm"
                              fontWeight={600}
                              color="red.600"
                              fontFamily="'Inter', sans-serif"
                            >
                              Danger Zone
                            </Text>
                          </HStack>
                          <Text
                            fontSize="paragraph-sm"
                            mb={3}
                            fontFamily="'Inter', sans-serif"
                          >
                            Deleting this job will permanently remove:
                          </Text>
                          <VStack align="start" spacing={1} mb={3}>
                            <Text
                              fontSize="paragraph-sm"
                              fontFamily="'Inter', sans-serif"
                            >
                              • The job posting
                            </Text>
                            <Text
                              fontSize="paragraph-sm"
                              fontFamily="'Inter', sans-serif"
                            >
                              • All {applications.length} applications
                            </Text>
                            <Text
                              fontSize="paragraph-sm"
                              fontFamily="'Inter', sans-serif"
                            >
                              • All associated data
                            </Text>
                          </VStack>
                          <Text
                            fontWeight={600}
                            color="red.600"
                            fontSize="paragraph-sm"
                            fontFamily="'Inter', sans-serif"
                          >
                            This action cannot be undone!
                          </Text>
                        </Box>

                        <Button
                          colorScheme="red"
                          size="md"
                          h={10}
                          leftIcon={<Icon as={FiTrash2} />}
                          onClick={() => setShowDeleteConfirm(true)}
                          borderRadius="10px"
                          fontSize="label-sm"
                          fontFamily="'Inter', sans-serif"
                        >
                          Delete This Job
                        </Button>
                      </VStack>
                    </Box>
                  </TabPanel>
                </TabPanels>
              </Tabs>
            </Box>
          </VStack>
        </Container>
      </Box>

      <ConfirmDialog
        isOpen={showDeleteConfirm}
        onClose={() => setShowDeleteConfirm(false)}
        onConfirm={handleDelete}
        title="Delete Job"
        message="Are you sure you want to delete this job? This will also delete all applications."
        isLoading={deleting}
      />
    </Layout>
  );
};

export default JobDetails;
