import {
  Box,
  Heading,
  VStack,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Badge,
  Button,
  Select,
  useToast,
  HStack,
  Text,
  Tabs,
  TabList,
  TabPanels,
  Tab,
  TabPanel,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
  SimpleGrid,
  Icon,
  Container,
  Flex,
  Stat,
  StatLabel,
  StatNumber,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FiUsers, FiFileText, FiEye } from "react-icons/fi";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { applicationAPI } from "../../api/application";
import { analyticsAPI } from "../../api/analytics";
import { hrResumeAPI } from "../../api/hrResume";
import { formatDate, getStatusLabel } from "../../utils/helpers";
import { STATUS_COLORS, APPLICATION_STATUS } from "../../utils/constants";
import { getATSScoreColor } from "../../utils/helpers";

const Applications = () => {
  const [studentApplications, setStudentApplications] = useState([]);
  const [bulkCandidates, setBulkCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    fetchApplicationsData();
  }, []);

  const fetchApplicationsData = async () => {
    try {
      const summary = await analyticsAPI.getApplicationsSummary();
      setStudentApplications(summary.student_applications);
      setBulkCandidates(summary.bulk_uploaded_candidates);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load applications",
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (applicationId, newStatus) => {
    try {
      await applicationAPI.updateStatus(applicationId, { status: newStatus });
      toast({
        title: "Status updated",
        status: "success",
        duration: 2000,
      });
      fetchApplicationsData();
    } catch (error) {
      toast({
        title: "Update failed",
        status: "error",
        duration: 3000,
      });
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.xl" position="relative" zIndex={1} py={8}>
          <VStack spacing={5} align="stretch">
            {/* Header */}
            <Heading
              fontSize="title-h5"
              fontWeight={600}
              fontFamily="'Inter', sans-serif"
            >
              Applications
            </Heading>

            {/* Tabs */}
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(20px)"
              borderRadius="16px"
              border="1px solid rgba(255, 255, 255, 0.8)"
              shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
              overflow="hidden"
            >
              <Tabs colorScheme="purple" variant="soft-rounded" p={4}>
                <TabList gap={2}>
                  <Tab
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _selected={{
                      bg: "primary.base",
                      color: "white",
                    }}
                  >
                    <HStack spacing={2}>
                      <Icon as={FiUsers} boxSize={3.5} />
                      <Text>Student Apps ({studentApplications.length})</Text>
                    </HStack>
                  </Tab>
                  <Tab
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                    _selected={{
                      bg: "primary.base",
                      color: "white",
                    }}
                  >
                    <HStack spacing={2}>
                      <Icon as={FiFileText} boxSize={3.5} />
                      <Text>Bulk Uploads ({bulkCandidates.length})</Text>
                    </HStack>
                  </Tab>
                </TabList>

                <TabPanels>
                  {/* Student Applications */}
                  <TabPanel px={0}>
                    {studentApplications.length === 0 ? (
                      <Box p={8} textAlign="center">
                        <Icon
                          as={FiUsers}
                          boxSize={12}
                          color="text.soft"
                          mb={3}
                        />
                        <Text
                          fontSize="paragraph-sm"
                          color="text.sub"
                          fontFamily="'Inter', sans-serif"
                        >
                          No student applications yet
                        </Text>
                      </Box>
                    ) : (
                      <Box overflowX="auto">
                        <Table size="sm" variant="simple">
                          <Thead>
                            <Tr>
                              <Th
                                fontSize="subheading-xs"
                                fontFamily="'Inter', sans-serif"
                              >
                                Job Title
                              </Th>
                              <Th
                                fontSize="subheading-xs"
                                fontFamily="'Inter', sans-serif"
                              >
                                Date
                              </Th>
                              <Th
                                fontSize="subheading-xs"
                                fontFamily="'Inter', sans-serif"
                              >
                                ATS Score
                              </Th>
                              <Th
                                fontSize="subheading-xs"
                                fontFamily="'Inter', sans-serif"
                              >
                                Status
                              </Th>
                              <Th
                                fontSize="subheading-xs"
                                fontFamily="'Inter', sans-serif"
                              >
                                Actions
                              </Th>
                            </Tr>
                          </Thead>
                          <Tbody>
                            {studentApplications.map((app) => (
                              <Tr key={app.id}>
                                <Td
                                  fontSize="paragraph-xs"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {app.job_title}
                                </Td>
                                <Td
                                  fontSize="paragraph-xs"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {formatDate(app.applied_date)}
                                </Td>
                                <Td>
                                  {app.ats_score ? (
                                    <Badge
                                      colorScheme={getATSScoreColor(
                                        app.ats_score
                                      )}
                                      fontSize="subheading-xs"
                                    >
                                      {app.ats_score.toFixed(1)}%
                                    </Badge>
                                  ) : (
                                    "-"
                                  )}
                                </Td>
                                <Td>
                                  <Badge
                                    colorScheme={STATUS_COLORS[app.status]}
                                    fontSize="subheading-xs"
                                  >
                                    {getStatusLabel(app.status)}
                                  </Badge>
                                </Td>
                                <Td>
                                  <Select
                                    size="xs"
                                    value={app.status}
                                    onChange={(e) =>
                                      handleStatusChange(app.id, e.target.value)
                                    }
                                    fontSize="paragraph-xs"
                                    fontFamily="'Inter', sans-serif"
                                  >
                                    {Object.values(APPLICATION_STATUS).map(
                                      (status) => (
                                        <option key={status} value={status}>
                                          {getStatusLabel(status)}
                                        </option>
                                      )
                                    )}
                                  </Select>
                                </Td>
                              </Tr>
                            ))}
                          </Tbody>
                        </Table>
                      </Box>
                    )}
                  </TabPanel>

                  {/* Bulk Uploads */}
                  <TabPanel px={0}>
                    {bulkCandidates.length === 0 ? (
                      <Box p={8} textAlign="center">
                        <Icon
                          as={FiFileText}
                          boxSize={12}
                          color="text.soft"
                          mb={3}
                        />
                        <Text
                          fontSize="paragraph-sm"
                          color="text.sub"
                          mb={3}
                          fontFamily="'Inter', sans-serif"
                        >
                          No bulk uploaded candidates
                        </Text>
                        <Button
                          size="sm"
                          h={9}
                          bgGradient="linear(135deg, primary.base, feature.base)"
                          color="white"
                          borderRadius="10px"
                          onClick={() => navigate("/hr/bulk-upload")}
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Go to Bulk Upload
                        </Button>
                      </Box>
                    ) : (
                      <VStack spacing={3} align="stretch">
                        {bulkCandidates.map((jobData, index) => (
                          <Box
                            key={index}
                            p={4}
                            bg="rgba(248, 249, 250, 0.8)"
                            borderRadius="12px"
                            transition="all 0.2s"
                            _hover={{ bg: "rgba(125, 82, 244, 0.05)" }}
                          >
                            <Flex justify="space-between" align="center">
                              <VStack align="start" spacing={1}>
                                <Text
                                  fontSize="label-sm"
                                  fontWeight={600}
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {jobData.job_title}
                                </Text>
                                <Text
                                  fontSize="paragraph-xs"
                                  color="text.sub"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {jobData.batches.length} batch •{" "}
                                  {jobData.total_candidates} candidates
                                </Text>
                              </VStack>
                              <Button
                                size="xs"
                                leftIcon={<Icon as={FiEye} boxSize={3} />}
                                onClick={() =>
                                  navigate("/hr/bulk-upload", {
                                    state: { jobId: jobData.job_id },
                                  })
                                }
                                fontSize="label-xs"
                                fontFamily="'Inter', sans-serif"
                              >
                                View
                              </Button>
                            </Flex>
                          </Box>
                        ))}
                      </VStack>
                    )}
                  </TabPanel>
                </TabPanels>
              </Tabs>
            </Box>
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default Applications;
