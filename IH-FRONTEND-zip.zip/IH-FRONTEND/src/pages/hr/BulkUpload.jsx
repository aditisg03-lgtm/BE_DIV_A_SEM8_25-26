import {
  Box,
  Heading,
  VStack,
  HStack,
  Button,
  Select,
  FormControl,
  FormLabel,
  Text,
  useToast,
  SimpleGrid,
  Badge,
  Progress,
  Icon,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
  Stat,
  StatLabel,
  StatNumber,
  Tag,
  Wrap,
  WrapItem,
  Container,
  Flex,
} from "@chakra-ui/react";
import { useState, useEffect, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import {
  FiUpload,
  FiFileText,
  FiX,
  FiUser,
  FiMail,
  FiPhone,
  FiMapPin,
  FiBriefcase,
  FiRefreshCw,
} from "react-icons/fi";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { jobAPI } from "../../api/job";
import { hrResumeAPI } from "../../api/hrResume";
import { getATSScoreColor } from "../../utils/helpers";
import { useLocation, useNavigate } from "react-router-dom";
import { formatDate } from "../../utils/helpers";

const RecommendationBadge = ({ recommendation }) => {
  const colors = {
    "HIGHLY RECOMMENDED": "green",
    RECOMMENDED: "blue",
    CONSIDER: "yellow",
    "NOT RECOMMENDED": "red",
    "PENDING ANALYSIS": "gray",
  };

  return (
    <Badge
      colorScheme={colors[recommendation] || "gray"}
      fontSize="subheading-xs"
      px={2}
      py={1}
    >
      {recommendation}
    </Badge>
  );
};

const CandidateCard = ({ candidate, rank }) => {
  return (
    <AccordionItem
      border="1px"
      borderColor="rgba(229, 231, 235, 0.8)"
      borderRadius="12px"
      mb={3}
      bg="rgba(255, 255, 255, 0.5)"
      backdropFilter="blur(10px)"
    >
      <AccordionButton
        _hover={{ bg: "rgba(125, 82, 244, 0.05)" }}
        borderRadius="12px"
        p={4}
      >
        <HStack flex="1" justify="space-between" textAlign="left">
          <HStack spacing={3}>
            <Badge
              colorScheme="purple"
              fontSize="label-xs"
              px={3}
              py={1}
              borderRadius="full"
            >
              #{rank}
            </Badge>
            <VStack align="start" spacing={0}>
              <Text
                fontWeight={600}
                fontSize="label-sm"
                fontFamily="'Inter', sans-serif"
              >
                {candidate.candidate_name}
              </Text>
              <Text
                fontSize="paragraph-xs"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                {candidate.filename}
              </Text>
            </VStack>
          </HStack>
          <HStack spacing={3}>
            <VStack spacing={0}>
              <Badge
                colorScheme={getATSScoreColor(candidate.ats_score)}
                fontSize="label-md"
                px={3}
                py={1}
              >
                {candidate.ats_score?.toFixed(1)}%
              </Badge>
              <Text
                fontSize="subheading-xs"
                color="text.soft"
                fontFamily="'Inter', sans-serif"
              >
                ATS Score
              </Text>
            </VStack>
            <RecommendationBadge recommendation={candidate.recommendation} />
          </HStack>
        </HStack>
        <AccordionIcon />
      </AccordionButton>

      <AccordionPanel pb={4} bg="rgba(248, 249, 250, 0.5)">
        <VStack align="stretch" spacing={4}>
          {/* Candidate Information */}
          <Box
            bg="rgba(255, 255, 255, 0.7)"
            backdropFilter="blur(10px)"
            p={4}
            borderRadius="10px"
          >
            <Text
              fontSize="label-sm"
              fontWeight={600}
              mb={3}
              fontFamily="'Inter', sans-serif"
            >
              Candidate Information
            </Text>
            <SimpleGrid columns={{ base: 1, md: 2 }} spacing={3}>
              <HStack>
                <Icon as={FiUser} color="primary.base" boxSize={4} />
                <VStack align="start" spacing={0}>
                  <Text
                    fontSize="subheading-xs"
                    color="text.soft"
                    fontFamily="'Inter', sans-serif"
                  >
                    Name
                  </Text>
                  <Text
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                  >
                    {candidate.candidate_name}
                  </Text>
                </VStack>
              </HStack>
              <HStack>
                <Icon as={FiMail} color="primary.base" boxSize={4} />
                <VStack align="start" spacing={0}>
                  <Text
                    fontSize="subheading-xs"
                    color="text.soft"
                    fontFamily="'Inter', sans-serif"
                  >
                    Email
                  </Text>
                  <Text
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                  >
                    {candidate.contact_email}
                  </Text>
                </VStack>
              </HStack>
              <HStack>
                <Icon as={FiPhone} color="primary.base" boxSize={4} />
                <VStack align="start" spacing={0}>
                  <Text
                    fontSize="subheading-xs"
                    color="text.soft"
                    fontFamily="'Inter', sans-serif"
                  >
                    Phone
                  </Text>
                  <Text
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                  >
                    {candidate.contact_phone}
                  </Text>
                </VStack>
              </HStack>
              <HStack>
                <Icon as={FiMapPin} color="primary.base" boxSize={4} />
                <VStack align="start" spacing={0}>
                  <Text
                    fontSize="subheading-xs"
                    color="text.soft"
                    fontFamily="'Inter', sans-serif"
                  >
                    Location
                  </Text>
                  <Text
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                  >
                    {candidate.location}
                  </Text>
                </VStack>
              </HStack>
              {candidate.total_years_experience && (
                <HStack>
                  <Icon as={FiBriefcase} color="primary.base" boxSize={4} />
                  <VStack align="start" spacing={0}>
                    <Text
                      fontSize="subheading-xs"
                      color="text.soft"
                      fontFamily="'Inter', sans-serif"
                    >
                      Experience
                    </Text>
                    <Text
                      fontSize="paragraph-sm"
                      fontFamily="'Inter', sans-serif"
                    >
                      {candidate.total_years_experience} years
                    </Text>
                  </VStack>
                </HStack>
              )}
            </SimpleGrid>
          </Box>

          {/* Scores */}
          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={3}>
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(10px)"
              p={4}
              borderRadius="10px"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={2}
                fontFamily="'Inter', sans-serif"
              >
                ATS Score
              </Text>
              <Progress
                value={candidate.ats_score}
                colorScheme={getATSScoreColor(candidate.ats_score)}
                size="sm"
                borderRadius="full"
                mb={1}
              />
              <Text
                fontSize="paragraph-sm"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                {candidate.ats_score?.toFixed(1)}%
              </Text>
            </Box>

            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(10px)"
              p={4}
              borderRadius="10px"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={2}
                fontFamily="'Inter', sans-serif"
              >
                Keyword Match
              </Text>
              <Progress
                value={candidate.keyword_match}
                colorScheme="purple"
                size="sm"
                borderRadius="full"
                mb={1}
              />
              <Text
                fontSize="paragraph-sm"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                {candidate.keyword_match?.toFixed(1) || 0}%
              </Text>
            </Box>

            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(10px)"
              p={4}
              borderRadius="10px"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={2}
                fontFamily="'Inter', sans-serif"
              >
                Skills Match
              </Text>
              <Progress
                value={candidate.skills_match?.match_percentage || 0}
                colorScheme="blue"
                size="sm"
                borderRadius="full"
                mb={1}
              />
              <Text
                fontSize="paragraph-sm"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                {candidate.skills_match?.match_percentage?.toFixed(1) || 0}%
              </Text>
            </Box>
          </SimpleGrid>

          {/* Skills Match */}
          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={3}>
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(10px)"
              p={4}
              borderRadius="10px"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={2}
                fontFamily="'Inter', sans-serif"
              >
                Skills Analysis
              </Text>
              {candidate.skills_match?.matched_skills?.length > 0 && (
                <Box mb={2}>
                  <Text
                    fontSize="subheading-xs"
                    color="green.600"
                    fontWeight={500}
                    mb={1}
                  >
                    ✓ Matched
                  </Text>
                  <Wrap>
                    {candidate.skills_match.matched_skills.map((skill, i) => (
                      <WrapItem key={i}>
                        <Tag
                          size="sm"
                          colorScheme="green"
                          fontSize="subheading-xs"
                        >
                          {skill}
                        </Tag>
                      </WrapItem>
                    ))}
                  </Wrap>
                </Box>
              )}
              {candidate.skills_match?.missing_skills?.length > 0 && (
                <Box>
                  <Text
                    fontSize="subheading-xs"
                    color="red.600"
                    fontWeight={500}
                    mb={1}
                  >
                    ✗ Missing
                  </Text>
                  <Wrap>
                    {candidate.skills_match.missing_skills.map((skill, i) => (
                      <WrapItem key={i}>
                        <Tag
                          size="sm"
                          colorScheme="red"
                          fontSize="subheading-xs"
                        >
                          {skill}
                        </Tag>
                      </WrapItem>
                    ))}
                  </Wrap>
                </Box>
              )}
            </Box>

            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(10px)"
              p={4}
              borderRadius="10px"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={2}
                fontFamily="'Inter', sans-serif"
              >
                Experience Match
              </Text>
              <Progress
                value={candidate.experience_match?.score || 0}
                colorScheme={getATSScoreColor(
                  candidate.experience_match?.score || 0
                )}
                size="sm"
                borderRadius="full"
                mb={2}
              />
              <Text
                fontSize="paragraph-sm"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                {candidate.experience_match?.feedback}
              </Text>
            </Box>

            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(10px)"
              p={4}
              borderRadius="10px"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={2}
                fontFamily="'Inter', sans-serif"
              >
                Education Match
              </Text>
              <Progress
                value={candidate.education_match?.score || 0}
                colorScheme={getATSScoreColor(
                  candidate.education_match?.score || 0
                )}
                size="sm"
                borderRadius="full"
                mb={2}
              />
              <Text
                fontSize="paragraph-sm"
                color="text.sub"
                fontFamily="'Inter', sans-serif"
              >
                {candidate.education_match?.degree}
              </Text>
            </Box>
          </SimpleGrid>

          {/* Strengths and Weaknesses */}
          <SimpleGrid columns={{ base: 1, md: 2 }} spacing={3}>
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(10px)"
              p={4}
              borderRadius="10px"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={2}
                color="green.600"
                fontFamily="'Inter', sans-serif"
              >
                ✓ Strengths
              </Text>
              <VStack align="stretch" spacing={1}>
                {candidate.strengths?.map((strength, i) => (
                  <Text
                    key={i}
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                  >
                    • {strength}
                  </Text>
                ))}
              </VStack>
            </Box>

            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(10px)"
              p={4}
              borderRadius="10px"
            >
              <Text
                fontSize="label-xs"
                fontWeight={600}
                mb={2}
                color="orange.600"
                fontFamily="'Inter', sans-serif"
              >
                ⚠ Areas for Improvement
              </Text>
              <VStack align="stretch" spacing={1}>
                {candidate.weaknesses?.map((weakness, i) => (
                  <Text
                    key={i}
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                  >
                    • {weakness}
                  </Text>
                ))}
              </VStack>
            </Box>
          </SimpleGrid>

          {/* Overall Feedback */}
          <Box
            bg="rgba(255, 255, 255, 0.7)"
            backdropFilter="blur(10px)"
            p={4}
            borderRadius="10px"
          >
            <Text
              fontSize="label-xs"
              fontWeight={600}
              mb={2}
              fontFamily="'Inter', sans-serif"
            >
              📋 Overall Assessment
            </Text>
            <Text
              fontSize="paragraph-sm"
              color="text.strong"
              fontFamily="'Inter', sans-serif"
            >
              {candidate.overall_feedback}
            </Text>
          </Box>
        </VStack>
      </AccordionPanel>
    </AccordionItem>
  );
};

const BulkUpload = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [jobs, setJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState("");
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [results, setResults] = useState(null);
  const [savedBatches, setSavedBatches] = useState([]);
  const toast = useToast();

  useEffect(() => {
    fetchJobs();
    fetchSavedBatches();
  }, []);

  useEffect(() => {
    if (location.state?.batchId) {
      loadBatchResults(location.state.batchId);
    }
  }, [location.state]);

  const fetchSavedBatches = async () => {
    try {
      const batches = await hrResumeAPI.getBatches();
      setSavedBatches(batches);
    } catch (error) {
      console.error("Failed to fetch saved batches:", error);
    }
  };

  const loadBatchResults = async (batchId) => {
    setLoading(true);
    try {
      const batchData = await hrResumeAPI.getBatchResults(batchId);
      setResults(batchData);
      toast({
        title: "Batch Loaded",
        description: `Loaded analysis for ${batchData.job_title}`,
        status: "success",
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load batch results",
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchJobs = async () => {
    try {
      const data = await jobAPI.getAll();
      const activeJobs = data.filter(
        (job) => job.status === "active" || job.status === "draft"
      );
      setJobs(activeJobs);
    } catch (error) {
      console.error("Failed to fetch jobs:", error);
    } finally {
      setLoading(false);
    }
  };

  const onDrop = useCallback(
    (acceptedFiles) => {
      const pdfFiles = acceptedFiles.filter(
        (file) => file.type === "application/pdf"
      );

      if (pdfFiles.length !== acceptedFiles.length) {
        toast({
          title: "Invalid files",
          description: "Only PDF files are accepted",
          status: "warning",
          duration: 3000,
        });
      }

      if (files.length + pdfFiles.length > 20) {
        toast({
          title: "Too many files",
          description: "Maximum 20 files allowed",
          status: "warning",
          duration: 3000,
        });
        return;
      }

      setFiles((prev) => [...prev, ...pdfFiles]);
    },
    [files, toast]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "application/pdf": [".pdf"] },
    multiple: true,
  });

  const removeFile = (index) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (!selectedJob) {
      toast({
        title: "No job selected",
        description: "Please select a job to analyze against",
        status: "warning",
        duration: 3000,
      });
      return;
    }

    if (files.length === 0) {
      toast({
        title: "No files",
        description: "Please upload at least one resume",
        status: "warning",
        duration: 3000,
      });
      return;
    }

    setUploading(true);
    try {
      const result = await hrResumeAPI.bulkUpload(files, selectedJob);
      setResults(result);
      await fetchSavedBatches();

      toast({
        title: "Analysis complete!",
        description: `Successfully analyzed ${result.successful} out of ${result.total_uploaded} resumes`,
        status: "success",
        duration: 5000,
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description:
          error.response?.data?.detail || "Failed to analyze resumes",
        status: "error",
        duration: 3000,
      });
    } finally {
      setUploading(false);
    }
  };

  const resetUpload = () => {
    setFiles([]);
    setResults(null);
    setSelectedJob("");
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.xl" position="relative" zIndex={1} py={8}>
          <VStack spacing={5} align="stretch">
            {/* Header */}
            <HStack justify="space-between">
              <VStack align="start" spacing={0}>
                <Heading
                  fontSize="title-lg"
                  fontWeight={600}
                  fontFamily="'Inter', sans-serif"
                >
                  AI-Powered Bulk Resume Analysis
                </Heading>
                <Text
                  fontSize="paragraph-sm"
                  color="text.sub"
                  fontFamily="'Inter', sans-serif"
                >
                  Upload multiple resumes and get instant AI analysis
                </Text>
              </VStack>
              {results && (
                <Button
                  size="sm"
                  h={9}
                  leftIcon={<Icon as={FiRefreshCw} />}
                  onClick={resetUpload}
                  borderRadius="10px"
                  fontSize="label-xs"
                  fontFamily="'Inter', sans-serif"
                >
                  New Analysis
                </Button>
              )}
            </HStack>

            {!results ? (
              <>
                {/* Job Selection */}
                <Box
                  bg="rgba(255, 255, 255, 0.7)"
                  backdropFilter="blur(20px)"
                  p={5}
                  borderRadius="14px"
                  border="1px solid rgba(255, 255, 255, 0.8)"
                  shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                >
                  <FormControl isRequired>
                    <FormLabel
                      fontSize="label-sm"
                      fontFamily="'Inter', sans-serif"
                    >
                      Select Job Position
                    </FormLabel>
                    <Select
                      placeholder="Choose a job to analyze against"
                      value={selectedJob}
                      onChange={(e) => setSelectedJob(e.target.value)}
                      h={10}
                      bg="rgba(255, 255, 255, 0.6)"
                      borderRadius="10px"
                      fontSize="paragraph-sm"
                      fontFamily="'Inter', sans-serif"
                    >
                      {jobs.map((job) => (
                        <option key={job.id} value={job.id}>
                          {job.title} - {job.location}
                        </option>
                      ))}
                    </Select>
                  </FormControl>
                </Box>

                {/* Saved Batches */}
                {savedBatches.length > 0 && (
                  <Box
                    bg="rgba(255, 255, 255, 0.7)"
                    backdropFilter="blur(20px)"
                    p={5}
                    borderRadius="14px"
                    border="1px solid rgba(255, 255, 255, 0.8)"
                    shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                  >
                    <HStack justify="space-between" mb={3}>
                      <Text
                        fontSize="label-sm"
                        fontWeight={600}
                        fontFamily="'Inter', sans-serif"
                      >
                        📂 Saved Analyses
                      </Text>
                      <Badge colorScheme="purple" fontSize="subheading-xs">
                        {savedBatches.length} batches
                      </Badge>
                    </HStack>
                    <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={3}>
                      {savedBatches.slice(0, 6).map((batch) => (
                        <Box
                          key={batch.batch_id}
                          p={3}
                          borderWidth={1}
                          borderColor="rgba(229, 231, 235, 0.8)"
                          borderRadius="10px"
                          bg="rgba(248, 249, 250, 0.5)"
                          _hover={{
                            shadow: "md",
                            borderColor: "primary.base",
                            cursor: "pointer",
                          }}
                          onClick={() => loadBatchResults(batch.batch_id)}
                        >
                          <VStack align="start" spacing={2}>
                            <Text
                              fontSize="label-xs"
                              fontWeight={600}
                              noOfLines={1}
                              fontFamily="'Inter', sans-serif"
                            >
                              {batch.job_title}
                            </Text>
                            <HStack spacing={2}>
                              <Badge
                                colorScheme="purple"
                                fontSize="subheading-xs"
                              >
                                {batch.successful_count} candidates
                              </Badge>
                              <Badge
                                colorScheme="blue"
                                fontSize="subheading-xs"
                              >
                                {batch.average_ats_score?.toFixed(1)}%
                              </Badge>
                            </HStack>
                            <Text
                              fontSize="subheading-xs"
                              color="text.sub"
                              fontFamily="'Inter', sans-serif"
                            >
                              {formatDate(batch.upload_date)}
                            </Text>
                          </VStack>
                        </Box>
                      ))}
                    </SimpleGrid>
                  </Box>
                )}

                {/* Upload Area */}
                <Box
                  {...getRootProps()}
                  border="2px dashed"
                  borderColor={
                    isDragActive ? "primary.base" : "rgba(229, 231, 235, 0.8)"
                  }
                  borderRadius="14px"
                  p={10}
                  textAlign="center"
                  cursor="pointer"
                  bg={
                    isDragActive
                      ? "rgba(125, 82, 244, 0.05)"
                      : "rgba(255, 255, 255, 0.7)"
                  }
                  backdropFilter="blur(20px)"
                  transition="all 0.2s"
                  _hover={{
                    borderColor: "primary.base",
                    bg: "rgba(125, 82, 244, 0.05)",
                  }}
                >
                  <input {...getInputProps()} />
                  <VStack spacing={3}>
                    <Icon as={FiUpload} boxSize={10} color="primary.base" />
                    <Text
                      fontWeight={500}
                      fontSize="paragraph-sm"
                      fontFamily="'Inter', sans-serif"
                    >
                      {isDragActive
                        ? "Drop resumes here"
                        : "Drag & drop resumes or click to browse"}
                    </Text>
                    <Text
                      fontSize="paragraph-xs"
                      color="text.sub"
                      fontFamily="'Inter', sans-serif"
                    >
                      PDF files only • Max 20 files • Up to 5MB each
                    </Text>
                  </VStack>
                </Box>

                {/* Selected Files */}
                {files.length > 0 && (
                  <Box
                    bg="rgba(255, 255, 255, 0.7)"
                    backdropFilter="blur(20px)"
                    p={5}
                    borderRadius="14px"
                    border="1px solid rgba(255, 255, 255, 0.8)"
                    shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                  >
                    <VStack align="stretch" spacing={4}>
                      <HStack justify="space-between">
                        <Text
                          fontSize="label-sm"
                          fontWeight={600}
                          fontFamily="'Inter', sans-serif"
                        >
                          Selected Files ({files.length})
                        </Text>
                        <Button
                          size="xs"
                          variant="ghost"
                          onClick={() => setFiles([])}
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Clear All
                        </Button>
                      </HStack>
                      <SimpleGrid
                        columns={{ base: 1, md: 2, lg: 3 }}
                        spacing={2}
                      >
                        {files.map((file, index) => (
                          <HStack
                            key={index}
                            p={3}
                            bg="rgba(248, 249, 250, 0.8)"
                            borderRadius="10px"
                            justify="space-between"
                          >
                            <HStack flex={1} overflow="hidden" spacing={2}>
                              <Icon
                                as={FiFileText}
                                color="primary.base"
                                boxSize={4}
                              />
                              <VStack
                                align="start"
                                spacing={0}
                                overflow="hidden"
                              >
                                <Text
                                  fontSize="paragraph-sm"
                                  fontWeight={500}
                                  noOfLines={1}
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {file.name}
                                </Text>
                                <Text
                                  fontSize="subheading-xs"
                                  color="text.sub"
                                  fontFamily="'Inter', sans-serif"
                                >
                                  {(file.size / 1024).toFixed(2)} KB
                                </Text>
                              </VStack>
                            </HStack>
                            <Button
                              size="xs"
                              variant="ghost"
                              colorScheme="red"
                              onClick={() => removeFile(index)}
                            >
                              <Icon as={FiX} boxSize={3} />
                            </Button>
                          </HStack>
                        ))}
                      </SimpleGrid>
                      <Button
                        size="sm"
                        h={10}
                        bgGradient="linear(135deg, primary.base, feature.base)"
                        color="white"
                        borderRadius="10px"
                        onClick={handleUpload}
                        isLoading={uploading}
                        loadingText="🤖 AI analyzing..."
                        isDisabled={!selectedJob}
                        leftIcon={<Icon as={FiUpload} />}
                        fontSize="label-sm"
                        fontFamily="'Inter', sans-serif"
                      >
                        Analyze {files.length} Resume
                        {files.length !== 1 ? "s" : ""} with AI
                      </Button>
                    </VStack>
                  </Box>
                )}
              </>
            ) : (
              /* Results */
              <VStack spacing={5} align="stretch">
                {/* Summary */}
                <Box
                  bg="rgba(255, 255, 255, 0.7)"
                  backdropFilter="blur(20px)"
                  p={5}
                  borderRadius="14px"
                  border="1px solid rgba(255, 255, 255, 0.8)"
                  shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                >
                  <VStack spacing={4} align="stretch">
                    <Text
                      fontSize="label-md"
                      fontWeight={600}
                      fontFamily="'Inter', sans-serif"
                    >
                      Analysis Results: {results.job_title}
                    </Text>

                    <SimpleGrid columns={{ base: 2, md: 4 }} spacing={3}>
                      <Stat
                        bg="rgba(59, 130, 246, 0.1)"
                        p={3}
                        borderRadius="10px"
                      >
                        <StatLabel
                          fontSize="subheading-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Total
                        </StatLabel>
                        <StatNumber
                          fontSize="title-h5"
                          color="blue.600"
                          fontFamily="'Inter', sans-serif"
                        >
                          {results.total_uploaded}
                        </StatNumber>
                      </Stat>
                      <Stat
                        bg="rgba(16, 185, 129, 0.1)"
                        p={3}
                        borderRadius="10px"
                      >
                        <StatLabel
                          fontSize="subheading-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Analyzed
                        </StatLabel>
                        <StatNumber
                          fontSize="title-h5"
                          color="green.600"
                          fontFamily="'Inter', sans-serif"
                        >
                          {results.successful}
                        </StatNumber>
                      </Stat>
                      <Stat
                        bg="rgba(239, 68, 68, 0.1)"
                        p={3}
                        borderRadius="10px"
                      >
                        <StatLabel
                          fontSize="subheading-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Failed
                        </StatLabel>
                        <StatNumber
                          fontSize="title-h5"
                          color="red.600"
                          fontFamily="'Inter', sans-serif"
                        >
                          {results.failed}
                        </StatNumber>
                      </Stat>
                      <Stat
                        bg="rgba(139, 92, 246, 0.1)"
                        p={3}
                        borderRadius="10px"
                      >
                        <StatLabel
                          fontSize="subheading-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Avg Score
                        </StatLabel>
                        <StatNumber
                          fontSize="title-h5"
                          color="purple.600"
                          fontFamily="'Inter', sans-serif"
                        >
                          {results.statistics?.average_ats_score?.toFixed(1)}%
                        </StatNumber>
                      </Stat>
                    </SimpleGrid>

                    <SimpleGrid columns={{ base: 2, md: 4 }} spacing={3}>
                      <Box
                        p={3}
                        bg="rgba(16, 185, 129, 0.15)"
                        borderRadius="10px"
                        textAlign="center"
                      >
                        <Text
                          fontSize="title-h5"
                          fontWeight={700}
                          color="green.700"
                          fontFamily="'Inter', sans-serif"
                        >
                          {results.statistics?.highly_recommended_count || 0}
                        </Text>
                        <Text
                          fontSize="subheading-xs"
                          color="green.700"
                          fontFamily="'Inter', sans-serif"
                        >
                          Highly Recommended
                        </Text>
                      </Box>
                      <Box
                        p={3}
                        bg="rgba(59, 130, 246, 0.15)"
                        borderRadius="10px"
                        textAlign="center"
                      >
                        <Text
                          fontSize="title-h5"
                          fontWeight={700}
                          color="blue.700"
                          fontFamily="'Inter', sans-serif"
                        >
                          {results.statistics?.recommended_count || 0}
                        </Text>
                        <Text
                          fontSize="subheading-xs"
                          color="blue.700"
                          fontFamily="'Inter', sans-serif"
                        >
                          Recommended
                        </Text>
                      </Box>
                      <Box
                        p={3}
                        bg="rgba(251, 191, 36, 0.15)"
                        borderRadius="10px"
                        textAlign="center"
                      >
                        <Text
                          fontSize="title-h5"
                          fontWeight={700}
                          color="yellow.700"
                          fontFamily="'Inter', sans-serif"
                        >
                          {results.statistics?.consider_count || 0}
                        </Text>
                        <Text
                          fontSize="subheading-xs"
                          color="yellow.700"
                          fontFamily="'Inter', sans-serif"
                        >
                          Consider
                        </Text>
                      </Box>
                      <Box
                        p={3}
                        bg="rgba(239, 68, 68, 0.15)"
                        borderRadius="10px"
                        textAlign="center"
                      >
                        <Text
                          fontSize="title-h5"
                          fontWeight={700}
                          color="red.700"
                          fontFamily="'Inter', sans-serif"
                        >
                          {results.statistics?.not_recommended_count || 0}
                        </Text>
                        <Text
                          fontSize="subheading-xs"
                          color="red.700"
                          fontFamily="'Inter', sans-serif"
                        >
                          Not Recommended
                        </Text>
                      </Box>
                    </SimpleGrid>
                  </VStack>
                </Box>

                {/* Candidates List */}
                <Box
                  bg="rgba(255, 255, 255, 0.7)"
                  backdropFilter="blur(20px)"
                  p={5}
                  borderRadius="14px"
                  border="1px solid rgba(255, 255, 255, 0.8)"
                  shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                >
                  <Text
                    fontSize="label-sm"
                    fontWeight={600}
                    mb={3}
                    fontFamily="'Inter', sans-serif"
                  >
                    Ranked Candidates
                  </Text>
                  <Accordion allowMultiple>
                    {results.results
                      .filter((r) => r.status === "success")
                      .map((candidate, index) => (
                        <CandidateCard
                          key={index}
                          candidate={candidate}
                          rank={index + 1}
                        />
                      ))}
                  </Accordion>
                </Box>
              </VStack>
            )}
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default BulkUpload;
