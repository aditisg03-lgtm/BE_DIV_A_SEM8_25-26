import {
  Box,
  Heading,
  VStack,
  FormControl,
  FormLabel,
  Input,
  Button,
  SimpleGrid,
  useToast,
  Text,
  Container,
  Icon,
  HStack,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { FiSave, FiUser } from "react-icons/fi";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import api from "../../api/axios";

const Profile = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isNewProfile, setIsNewProfile] = useState(false);
  const [formData, setFormData] = useState({
    first_name: "",
    last_name: "",
    company_name: "",
    company_website: "",
    company_size: "",
    industry: "",
    position: "",
    department: "",
    phone: "",
    linkedin_url: "",
  });
  const toast = useToast();

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await api.get("/api/hr/profile");
      setFormData(response.data);
      setIsNewProfile(false);
    } catch (error) {
      if (error.response?.status === 404) {
        setIsNewProfile(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      if (isNewProfile) {
        await api.post("/api/hr/profile", formData);
        toast({
          title: "Profile created successfully",
          description: "You can now start posting jobs!",
          status: "success",
          duration: 3000,
        });
        setIsNewProfile(false);
      } else {
        await api.put("/api/hr/profile", formData);
        toast({
          title: "Profile updated",
          status: "success",
          duration: 2000,
        });
      }
    } catch (error) {
      toast({
        title: isNewProfile ? "Profile creation failed" : "Update failed",
        description: error.response?.data?.detail || "Failed to save profile",
        status: "error",
        duration: 3000,
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)," +
            "radial-gradient(circle at 80% 20%, rgba(254, 242, 242, 0.2) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.lg" position="relative" zIndex={1} py={8}>
          <VStack spacing={6} align="stretch">
            {/* Header */}
            <HStack spacing={3}>
              <Box
                w={12}
                h={12}
                borderRadius="12px"
                bgGradient="linear(135deg, primary.base, feature.base)"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                <Icon as={FiUser} color="white" boxSize={6} />
              </Box>
              <VStack align="start" spacing={0}>
                <Heading
                  fontSize="title-h4"
                  fontWeight={600}
                  fontFamily="'Inter', sans-serif"
                >
                  HR Profile
                </Heading>
                <Text
                  fontSize="paragraph-sm"
                  color="text.sub"
                  fontFamily="'Inter', sans-serif"
                >
                  {isNewProfile
                    ? "Complete your profile to get started"
                    : "Manage your professional information"}
                </Text>
              </VStack>
            </HStack>

            {/* Info Alert */}
            {isNewProfile && (
              <Box
                bg="rgba(255, 255, 255, 0.7)"
                backdropFilter="blur(20px)"
                p={5}
                borderRadius="16px"
                border="1px solid rgba(59, 130, 246, 0.3)"
                shadow="0 4px 16px rgba(59, 130, 246, 0.1)"
              >
                <Text
                  fontSize="paragraph-sm"
                  fontFamily="'Inter', sans-serif"
                  color="text.sub"
                >
                  💡 Complete your profile to unlock job posting and application
                  management features
                </Text>
              </Box>
            )}

            {/* Form */}
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(20px)"
              p={7}
              borderRadius="20px"
              border="1px solid rgba(255, 255, 255, 0.8)"
              shadow="0 8px 32px rgba(0, 0, 0, 0.04)"
            >
              <form onSubmit={handleSubmit}>
                <VStack spacing={5} align="stretch">
                  {/* Personal Info */}
                  <Box>
                    <Text
                      fontSize="label-sm"
                      fontWeight={600}
                      mb={3}
                      fontFamily="'Inter', sans-serif"
                    >
                      Personal Information
                    </Text>
                    <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                      <FormControl isRequired>
                        <FormLabel
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          First Name
                        </FormLabel>
                        <Input
                          name="first_name"
                          value={formData.first_name}
                          onChange={handleChange}
                          h={10}
                          bg="rgba(255, 255, 255, 0.6)"
                          borderRadius="10px"
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        />
                      </FormControl>

                      <FormControl isRequired>
                        <FormLabel
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Last Name
                        </FormLabel>
                        <Input
                          name="last_name"
                          value={formData.last_name}
                          onChange={handleChange}
                          h={10}
                          bg="rgba(255, 255, 255, 0.6)"
                          borderRadius="10px"
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        />
                      </FormControl>
                    </SimpleGrid>
                  </Box>

                  {/* Company Info */}
                  <Box>
                    <Text
                      fontSize="label-sm"
                      fontWeight={600}
                      mb={3}
                      fontFamily="'Inter', sans-serif"
                    >
                      Company Information
                    </Text>
                    <VStack spacing={4}>
                      <FormControl isRequired>
                        <FormLabel
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Company Name
                        </FormLabel>
                        <Input
                          name="company_name"
                          value={formData.company_name}
                          onChange={handleChange}
                          h={10}
                          bg="rgba(255, 255, 255, 0.6)"
                          borderRadius="10px"
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        />
                      </FormControl>

                      <SimpleGrid
                        columns={{ base: 1, md: 2 }}
                        spacing={4}
                        w="full"
                      >
                        <FormControl>
                          <FormLabel
                            fontSize="label-xs"
                            fontFamily="'Inter', sans-serif"
                          >
                            Company Website
                          </FormLabel>
                          <Input
                            name="company_website"
                            value={formData.company_website}
                            onChange={handleChange}
                            placeholder="https://..."
                            h={10}
                            bg="rgba(255, 255, 255, 0.6)"
                            borderRadius="10px"
                            fontSize="paragraph-sm"
                            fontFamily="'Inter', sans-serif"
                          />
                        </FormControl>

                        <FormControl>
                          <FormLabel
                            fontSize="label-xs"
                            fontFamily="'Inter', sans-serif"
                          >
                            Company Size
                          </FormLabel>
                          <Input
                            name="company_size"
                            value={formData.company_size}
                            onChange={handleChange}
                            placeholder="1-50, 51-200, etc."
                            h={10}
                            bg="rgba(255, 255, 255, 0.6)"
                            borderRadius="10px"
                            fontSize="paragraph-sm"
                            fontFamily="'Inter', sans-serif"
                          />
                        </FormControl>
                      </SimpleGrid>

                      <FormControl>
                        <FormLabel
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Industry
                        </FormLabel>
                        <Input
                          name="industry"
                          value={formData.industry}
                          onChange={handleChange}
                          placeholder="Technology, Healthcare, etc."
                          h={10}
                          bg="rgba(255, 255, 255, 0.6)"
                          borderRadius="10px"
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        />
                      </FormControl>
                    </VStack>
                  </Box>

                  {/* Role Info */}
                  <Box>
                    <Text
                      fontSize="label-sm"
                      fontWeight={600}
                      mb={3}
                      fontFamily="'Inter', sans-serif"
                    >
                      Your Role
                    </Text>
                    <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                      <FormControl isRequired>
                        <FormLabel
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Position
                        </FormLabel>
                        <Input
                          name="position"
                          value={formData.position}
                          onChange={handleChange}
                          placeholder="HR Manager, Recruiter, etc."
                          h={10}
                          bg="rgba(255, 255, 255, 0.6)"
                          borderRadius="10px"
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        />
                      </FormControl>

                      <FormControl>
                        <FormLabel
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Department
                        </FormLabel>
                        <Input
                          name="department"
                          value={formData.department}
                          onChange={handleChange}
                          h={10}
                          bg="rgba(255, 255, 255, 0.6)"
                          borderRadius="10px"
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        />
                      </FormControl>
                    </SimpleGrid>
                  </Box>

                  {/* Contact Info */}
                  <Box>
                    <Text
                      fontSize="label-sm"
                      fontWeight={600}
                      mb={3}
                      fontFamily="'Inter', sans-serif"
                    >
                      Contact Information
                    </Text>
                    <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                      <FormControl>
                        <FormLabel
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          Phone
                        </FormLabel>
                        <Input
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          h={10}
                          bg="rgba(255, 255, 255, 0.6)"
                          borderRadius="10px"
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        />
                      </FormControl>

                      <FormControl>
                        <FormLabel
                          fontSize="label-xs"
                          fontFamily="'Inter', sans-serif"
                        >
                          LinkedIn URL
                        </FormLabel>
                        <Input
                          name="linkedin_url"
                          value={formData.linkedin_url}
                          onChange={handleChange}
                          placeholder="https://linkedin.com/in/..."
                          h={10}
                          bg="rgba(255, 255, 255, 0.6)"
                          borderRadius="10px"
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        />
                      </FormControl>
                    </SimpleGrid>
                  </Box>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    size="md"
                    // h={11}
                    bgGradient="linear(135deg, primary.base, feature.base)"
                    color="white"
                    borderRadius="10px"
                    leftIcon={<Icon as={FiSave} />}
                    isLoading={saving}
                    loadingText={isNewProfile ? "Creating..." : "Saving..."}
                    _hover={{
                      transform: "translateY(-2px)",
                      shadow: "0 8px 20px -6px rgba(125, 82, 244, 0.4)",
                    }}
                    transition="all 0.2s"
                    fontFamily="'Inter', sans-serif"
                    fontSize="label-sm"
                  >
                    {isNewProfile ? "Create Profile" : "Save Changes"}
                  </Button>
                </VStack>
              </form>
            </Box>
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default Profile;
