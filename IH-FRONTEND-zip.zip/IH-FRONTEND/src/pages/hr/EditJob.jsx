import {
  Box,
  Heading,
  VStack,
  Container,
  HStack,
  Icon,
  Text,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { FiEdit } from "react-icons/fi";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import EditJobForm from "../../components/hr/EditJobForm";
import { jobAPI } from "../../api/job";

const EditJob = () => {
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchJob();
  }, [jobId]);

  const fetchJob = async () => {
    try {
      const data = await jobAPI.getById(jobId);
      setJob(data);
    } catch (error) {
      navigate("/hr/jobs");
    } finally {
      setLoading(false);
    }
  };

  const handleSuccess = () => {
    navigate(`/hr/jobs/${jobId}`);
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.lg" position="relative" zIndex={1} py={8}>
          <VStack spacing={5} align="stretch">
            {/* Header */}
            <HStack spacing={3}>
              <Box
                w={10}
                h={10}
                borderRadius="10px"
                bgGradient="linear(135deg, primary.base, feature.base)"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                <Icon as={FiEdit} color="white" boxSize={5} />
              </Box>
              <VStack align="start" spacing={0}>
                <Heading
                  fontSize="title-h5"
                  fontWeight={600}
                  fontFamily="'Inter', sans-serif"
                >
                  Edit Job
                </Heading>
                <Text
                  fontSize="paragraph-sm"
                  color="text.sub"
                  fontFamily="'Inter', sans-serif"
                >
                  Update job posting details
                </Text>
              </VStack>
            </HStack>

            {/* Form */}
            <Box
              bg="rgba(255, 255, 255, 0.7)"
              backdropFilter="blur(20px)"
              p={6}
              borderRadius="16px"
              border="1px solid rgba(255, 255, 255, 0.8)"
              shadow="0 8px 32px rgba(0, 0, 0, 0.04)"
            >
              <EditJobForm job={job} onSuccess={handleSuccess} />
            </Box>
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default EditJob;
