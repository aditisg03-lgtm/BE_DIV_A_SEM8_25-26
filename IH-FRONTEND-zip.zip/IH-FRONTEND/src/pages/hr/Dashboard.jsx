import {
  Box,
  SimpleGrid,
  Heading,
  VStack,
  Icon,
  Button,
  HStack,
  Text,
  Progress,
  Badge,
  Flex,
  Container,
  Stat,
  StatLabel,
  StatNumber,
} from "@chakra-ui/react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  FiBriefcase,
  FiUsers,
  FiCheckCircle,
  FiClock,
  FiTrendingUp,
  FiPlus,
  FiArrowUpRight,
  FiArrowDownRight,
} from "react-icons/fi";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { analyticsAPI } from "../../api/analytics";
import api from "../../api/axios";

const COLORS = {
  primary: "#7d52f4",
  success: "#10B981",
  warning: "#F59E0B",
  error: "#EF4444",
  purple: "#8B5CF6",
  blue: "#3B82F6",
  pink: "#EC4899",
  teal: "#14B8A6",
};

// Custom Tooltip Component
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <Box
        bg="rgba(255, 255, 255, 0.95)"
        backdropFilter="blur(20px)"
        p={3}
        borderRadius="10px"
        border="1px solid rgba(229, 231, 235, 0.8)"
        shadow="0 8px 24px rgba(0, 0, 0, 0.12)"
      >
        <Text
          fontSize="label-xs"
          fontWeight={600}
          mb={1}
          fontFamily="'Inter', sans-serif"
        >
          {label}
        </Text>
        {payload.map((entry, index) => (
          <HStack key={index} spacing={2}>
            <Box w={2} h={2} borderRadius="full" bg={entry.color} />
            <Text fontSize="paragraph-xs" fontFamily="'Inter', sans-serif">
              {entry.name}: {entry.value}
            </Text>
          </HStack>
        ))}
      </Box>
    );
  }
  return null;
};

// Modern Stat Card
const ModernStatCard = ({
  title,
  value,
  icon,
  color = COLORS.primary,
  trend,
  trendValue,
}) => {
  const isPositive = trend === "up";

  return (
    <Box
      bg="rgba(255, 255, 255, 0.7)"
      backdropFilter="blur(20px)"
      p={5}
      borderRadius="16px"
      border="1px solid rgba(255, 255, 255, 0.8)"
      shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
      position="relative"
      overflow="hidden"
      transition="all 0.3s"
      _hover={{
        transform: "translateY(-4px)",
        shadow: "0 8px 24px rgba(0, 0, 0, 0.08)",
      }}
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        right: 0,
        width: "100px",
        height: "100px",
        borderRadius: "full",
        bg: `${color}15`,
        filter: "blur(40px)",
        zIndex: 0,
      }}
    >
      <Flex
        justify="space-between"
        align="start"
        position="relative"
        zIndex={1}
      >
        <VStack align="start" spacing={2} flex={1}>
          <HStack spacing={2}>
            <Box
              w={10}
              h={10}
              borderRadius="12px"
              bg={`${color}15`}
              display="flex"
              alignItems="center"
              justifyContent="center"
            >
              <Icon as={icon} boxSize={5} color={color} />
            </Box>
            {trend && (
              <Badge
                colorScheme={isPositive ? "green" : "red"}
                borderRadius="full"
                px={2}
                py={1}
                fontSize="subheading-xs"
                display="flex"
                alignItems="center"
                gap={1}
              >
                <Icon
                  as={isPositive ? FiArrowUpRight : FiArrowDownRight}
                  boxSize={3}
                />
                {trendValue}
              </Badge>
            )}
          </HStack>
          <Text
            fontSize="label-xs"
            color="text.sub"
            fontFamily="'Inter', sans-serif"
          >
            {title}
          </Text>
          <Text
            fontSize="title-h4"
            fontWeight={600}
            color="text.strong"
            fontFamily="'Inter', sans-serif"
          >
            {value}
          </Text>
        </VStack>
      </Flex>
    </Box>
  );
};

// Modern Chart Card
const ChartCard = ({ title, subtitle, children, action }) => {
  return (
    <Box
      bg="rgba(255, 255, 255, 0.7)"
      backdropFilter="blur(20px)"
      p={6}
      borderRadius="16px"
      border="1px solid rgba(255, 255, 255, 0.8)"
      shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
    >
      <Flex justify="space-between" align="start" mb={5}>
        <VStack align="start" spacing={0}>
          <Text
            fontSize="label-md"
            fontWeight={600}
            fontFamily="'Inter', sans-serif"
          >
            {title}
          </Text>
          {subtitle && (
            <Text
              fontSize="paragraph-xs"
              color="text.sub"
              fontFamily="'Inter', sans-serif"
            >
              {subtitle}
            </Text>
          )}
        </VStack>
        {action}
      </Flex>
      {children}
    </Box>
  );
};

const Dashboard = () => {
  const [loading, setLoading] = useState(true);
  const [hasProfile, setHasProfile] = useState(true);
  const [analytics, setAnalytics] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    checkProfileAndFetchAnalytics();
  }, []);

  const checkProfileAndFetchAnalytics = async () => {
    try {
      await api.get("/api/hr/profile");
      setHasProfile(true);
      await fetchAnalytics();
    } catch (error) {
      if (error.response?.status === 404) {
        setHasProfile(false);
      }
      setLoading(false);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const data = await analyticsAPI.getHRDashboard();
      setAnalytics(data);
    } catch (error) {
      console.error("Failed to fetch analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)," +
            "radial-gradient(circle at 80% 20%, rgba(254, 242, 242, 0.2) 0%, transparent 25%)," +
            "radial-gradient(circle at 40% 70%, rgba(219, 234, 254, 0.25) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
        sx={{
          "@keyframes float": {
            "0%, 100%": { transform: "translate(0, 0) rotate(0deg)" },
            "33%": { transform: "translate(30px, -30px) rotate(120deg)" },
            "66%": { transform: "translate(-20px, 20px) rotate(240deg)" },
          },
        }}
      >
        <Container maxW="container.xl" position="relative" zIndex={1} py={8}>
          <VStack spacing={6} align="stretch">
            {/* Header */}
            <Flex justify="space-between" align="center">
              <VStack align="start" spacing={1}>
                <Heading
                  fontSize="title-h4"
                  fontWeight={600}
                  fontFamily="'Inter', sans-serif"
                >
                  Dashboard Overview
                </Heading>
                <Text
                  fontSize="paragraph-sm"
                  color="text.sub"
                  fontFamily="'Inter', sans-serif"
                >
                  Track your recruitment metrics and performance
                </Text>
              </VStack>
              {hasProfile && (
                <Button
                  size="sm"
                  h={10}
                  bgGradient="linear(135deg, primary.base, feature.base)"
                  color="white"
                  borderRadius="10px"
                  leftIcon={<Icon as={FiPlus} boxSize={4} />}
                  onClick={() => navigate("/hr/jobs/new")}
                  _hover={{
                    transform: "translateY(-2px)",
                    shadow: "0 8px 20px -6px rgba(125, 82, 244, 0.4)",
                  }}
                  transition="all 0.2s"
                  fontFamily="'Inter', sans-serif"
                  fontSize="label-sm"
                >
                  Create Job
                </Button>
              )}
            </Flex>

            {/* Profile Alert */}
            {!hasProfile && (
              <Box
                bg="rgba(255, 255, 255, 0.7)"
                backdropFilter="blur(20px)"
                p={5}
                borderRadius="16px"
                border="1px solid rgba(251, 191, 36, 0.3)"
                shadow="0 4px 16px rgba(251, 191, 36, 0.1)"
              >
                <HStack spacing={3}>
                  <Icon as={FiClock} color="warning.base" boxSize={5} />
                  <VStack align="start" spacing={1} flex={1}>
                    <Text
                      fontWeight={600}
                      fontSize="label-sm"
                      fontFamily="'Inter', sans-serif"
                    >
                      Complete Your Profile
                    </Text>
                    <Text
                      fontSize="paragraph-sm"
                      color="text.sub"
                      fontFamily="'Inter', sans-serif"
                    >
                      Set up your HR profile to unlock all features
                    </Text>
                  </VStack>
                  <Button
                    size="sm"
                    h={9}
                    colorScheme="orange"
                    borderRadius="10px"
                    onClick={() => navigate("/hr/profile")}
                    fontFamily="'Inter', sans-serif"
                    fontSize="label-xs"
                  >
                    Complete Now
                  </Button>
                </HStack>
              </Box>
            )}

            {analytics && (
              <>
                {/* Stats Grid */}
                <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={4}>
                  <ModernStatCard
                    title="Total Jobs"
                    value={analytics.overview.total_jobs}
                    icon={FiBriefcase}
                    color={COLORS.primary}
                    trend="up"
                    trendValue="+8%"
                  />
                  <ModernStatCard
                    title="Active Positions"
                    value={analytics.overview.active_jobs}
                    icon={FiCheckCircle}
                    color={COLORS.success}
                    trend="up"
                    trendValue="+12%"
                  />
                  <ModernStatCard
                    title="Total Applications"
                    value={analytics.overview.total_applications}
                    icon={FiUsers}
                    color={COLORS.purple}
                    trend="up"
                    trendValue="+23%"
                  />
                  <ModernStatCard
                    title="Pending Review"
                    value={analytics.overview.pending_review}
                    icon={FiClock}
                    color={COLORS.warning}
                  />
                </SimpleGrid>

                {/* Charts Row 1 */}
                <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={5}>
                  {/* Applications by Job - Area Chart */}
                  <ChartCard
                    title="Application Trends"
                    subtitle="Applications received per job posting"
                  >
                    <Box h="280px">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={analytics.applications_by_job}
                          margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient
                              id="colorApplications"
                              x1="0"
                              y1="0"
                              x2="0"
                              y2="1"
                            >
                              <stop
                                offset="5%"
                                stopColor={COLORS.primary}
                                stopOpacity={0.3}
                              />
                              <stop
                                offset="95%"
                                stopColor={COLORS.primary}
                                stopOpacity={0}
                              />
                            </linearGradient>
                          </defs>
                          <CartesianGrid
                            strokeDasharray="3 3"
                            stroke="rgba(229, 231, 235, 0.5)"
                            vertical={false}
                          />
                          <XAxis
                            dataKey="job"
                            tick={{
                              fontSize: 11,
                              fontFamily: "'Inter', sans-serif",
                              fill: "#6B7280",
                            }}
                            tickLine={false}
                            axisLine={{ stroke: "rgba(229, 231, 235, 0.5)" }}
                          />
                          <YAxis
                            tick={{
                              fontSize: 11,
                              fontFamily: "'Inter', sans-serif",
                              fill: "#6B7280",
                            }}
                            tickLine={false}
                            axisLine={false}
                          />
                          <Tooltip content={<CustomTooltip />} />
                          <Area
                            type="monotone"
                            dataKey="applications"
                            stroke={COLORS.primary}
                            strokeWidth={2}
                            fillOpacity={1}
                            fill="url(#colorApplications)"
                            name="Applications"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </Box>
                  </ChartCard>

                  {/* Application Status - Modern Pie */}
                  <ChartCard
                    title="Application Status"
                    subtitle="Current status distribution"
                  >
                    <Flex h="280px" align="center" justify="center">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={analytics.applications_by_status}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={90}
                            paddingAngle={3}
                            dataKey="count"
                            nameKey="status"
                          >
                            {analytics.applications_by_status.map(
                              (entry, index) => {
                                const colors = [
                                  COLORS.primary,
                                  COLORS.success,
                                  COLORS.warning,
                                  COLORS.error,
                                  COLORS.purple,
                                ];
                                return (
                                  <Cell
                                    key={`cell-${index}`}
                                    fill={colors[index % colors.length]}
                                  />
                                );
                              }
                            )}
                          </Pie>
                          <Tooltip content={<CustomTooltip />} />
                        </PieChart>
                      </ResponsiveContainer>
                      <VStack position="absolute" spacing={0}>
                        <Text
                          fontSize="title-h5"
                          fontWeight={700}
                          fontFamily="'Inter', sans-serif"
                        >
                          {analytics.overview.total_applications}
                        </Text>
                        <Text
                          fontSize="paragraph-xs"
                          color="text.sub"
                          fontFamily="'Inter', sans-serif"
                        >
                          Total
                        </Text>
                      </VStack>
                    </Flex>
                  </ChartCard>
                </SimpleGrid>

                {/* Charts Row 2 */}
                <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={5}>
                  {/* Bulk Upload Stats */}
                  <ChartCard
                    title="Bulk Upload Performance"
                    subtitle="Candidates analyzed via bulk upload"
                  >
                    <Box h="280px">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={analytics.bulk_uploads_by_job}
                          margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                        >
                          <CartesianGrid
                            strokeDasharray="3 3"
                            stroke="rgba(229, 231, 235, 0.5)"
                            vertical={false}
                          />
                          <XAxis
                            dataKey="job"
                            tick={{
                              fontSize: 11,
                              fontFamily: "'Inter', sans-serif",
                              fill: "#6B7280",
                            }}
                            tickLine={false}
                            axisLine={{ stroke: "rgba(229, 231, 235, 0.5)" }}
                          />
                          <YAxis
                            tick={{
                              fontSize: 11,
                              fontFamily: "'Inter', sans-serif",
                              fill: "#6B7280",
                            }}
                            tickLine={false}
                            axisLine={false}
                          />
                          <Tooltip content={<CustomTooltip />} />
                          <Bar
                            dataKey="candidates"
                            fill={COLORS.success}
                            radius={[8, 8, 0, 0]}
                            name="Candidates"
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </Box>
                  </ChartCard>

                  {/* ATS Score Distribution */}
                  <ChartCard
                    title="ATS Score Analysis"
                    subtitle="Quality distribution of applications"
                  >
                    <Box h="280px">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={analytics.ats_score_distribution}
                          margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient
                              id="colorScore"
                              x1="0"
                              y1="0"
                              x2="0"
                              y2="1"
                            >
                              <stop offset="0%" stopColor={COLORS.purple} />
                              <stop offset="100%" stopColor={COLORS.primary} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid
                            strokeDasharray="3 3"
                            stroke="rgba(229, 231, 235, 0.5)"
                            vertical={false}
                          />
                          <XAxis
                            dataKey="range"
                            tick={{
                              fontSize: 11,
                              fontFamily: "'Inter', sans-serif",
                              fill: "#6B7280",
                            }}
                            tickLine={false}
                            axisLine={{ stroke: "rgba(229, 231, 235, 0.5)" }}
                          />
                          <YAxis
                            tick={{
                              fontSize: 11,
                              fontFamily: "'Inter', sans-serif",
                              fill: "#6B7280",
                            }}
                            tickLine={false}
                            axisLine={false}
                          />
                          <Tooltip content={<CustomTooltip />} />
                          <Bar
                            dataKey="count"
                            fill="url(#colorScore)"
                            radius={[8, 8, 0, 0]}
                            name="Candidates"
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </Box>
                  </ChartCard>
                </SimpleGrid>

                {/* Recent Activity */}
                <SimpleGrid columns={{ base: 1, md: 2 }} spacing={5}>
                  {/* Latest Applications */}
                  <ChartCard
                    title="Recent Applications"
                    subtitle="Latest 5 applications received"
                  >
                    <VStack align="stretch" spacing={2}>
                      {analytics.recent_activity.applications
                        .slice(0, 5)
                        .map((app, index) => (
                          <Box
                            key={app.id}
                            p={3}
                            bg="rgba(248, 249, 250, 0.6)"
                            backdropFilter="blur(10px)"
                            borderRadius="10px"
                            border="1px solid rgba(229, 231, 235, 0.5)"
                            transition="all 0.2s"
                            _hover={{
                              bg: "rgba(125, 82, 244, 0.05)",
                              borderColor: "rgba(125, 82, 244, 0.3)",
                              transform: "translateX(4px)",
                            }}
                          >
                            <HStack justify="space-between">
                              <VStack align="start" spacing={1} flex={1}>
                                <Text
                                  fontSize="label-xs"
                                  fontWeight={600}
                                  fontFamily="'Inter', sans-serif"
                                  noOfLines={1}
                                >
                                  {app.job_title}
                                </Text>
                                <HStack
                                  spacing={2}
                                  fontSize="paragraph-xs"
                                  color="text.sub"
                                >
                                  <Text fontFamily="'Inter', sans-serif">
                                    {new Date(app.date).toLocaleDateString()}
                                  </Text>
                                  <Box
                                    w={1}
                                    h={1}
                                    borderRadius="full"
                                    bg="text.soft"
                                  />
                                  <Badge
                                    size="sm"
                                    colorScheme="purple"
                                    fontSize="subheading-xs"
                                  >
                                    {app.status}
                                  </Badge>
                                </HStack>
                              </VStack>
                              <Icon
                                as={FiTrendingUp}
                                color="success.base"
                                boxSize={4}
                              />
                            </HStack>
                          </Box>
                        ))}
                    </VStack>
                  </ChartCard>

                  {/* Latest Bulk Uploads */}
                  <ChartCard
                    title="Recent Bulk Uploads"
                    subtitle="Latest 5 bulk analysis sessions"
                  >
                    <VStack align="stretch" spacing={2}>
                      {analytics.recent_activity.bulk_uploads
                        .slice(0, 5)
                        .map((upload, index) => (
                          <Box
                            key={upload.id}
                            p={3}
                            bg="rgba(248, 249, 250, 0.6)"
                            backdropFilter="blur(10px)"
                            borderRadius="10px"
                            border="1px solid rgba(229, 231, 235, 0.5)"
                            transition="all 0.2s"
                            _hover={{
                              bg: "rgba(16, 185, 129, 0.05)",
                              borderColor: "rgba(16, 185, 129, 0.3)",
                              transform: "translateX(4px)",
                            }}
                          >
                            <HStack justify="space-between">
                              <VStack align="start" spacing={1} flex={1}>
                                <Text
                                  fontSize="label-xs"
                                  fontWeight={600}
                                  fontFamily="'Inter', sans-serif"
                                  noOfLines={1}
                                >
                                  {upload.job_title}
                                </Text>
                                <HStack
                                  spacing={2}
                                  fontSize="paragraph-xs"
                                  color="text.sub"
                                >
                                  <Text fontFamily="'Inter', sans-serif">
                                    {new Date(upload.date).toLocaleDateString()}
                                  </Text>
                                  <Box
                                    w={1}
                                    h={1}
                                    borderRadius="full"
                                    bg="text.soft"
                                  />
                                  <Badge
                                    size="sm"
                                    colorScheme="green"
                                    fontSize="subheading-xs"
                                  >
                                    {upload.candidates} candidates
                                  </Badge>
                                </HStack>
                              </VStack>
                              <Icon
                                as={FiUsers}
                                color="success.base"
                                boxSize={4}
                              />
                            </HStack>
                          </Box>
                        ))}
                    </VStack>
                  </ChartCard>
                </SimpleGrid>
              </>
            )}
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default Dashboard;
