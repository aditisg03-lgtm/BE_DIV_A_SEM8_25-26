import {
  Container,
  VStack,
  HStack,
  Heading,
  Text,
  Badge,
  Button,
  Box,
  SimpleGrid,
  Textarea,
  useToast,
  Icon,
  Select,
  Flex,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  FiArrowLeft,
  FiDownload,
  FiSave,
  FiUser,
  FiCalendar,
} from "react-icons/fi";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { applicationAPI } from "../../api/application";
import { formatDate, getStatusLabel } from "../../utils/helpers";
import { STATUS_COLORS, APPLICATION_STATUS } from "../../utils/constants";

const ApplicationDetails = () => {
  const { applicationId } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [application, setApplication] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchApplication();
  }, [applicationId]);

  const fetchApplication = async () => {
    try {
      const data = await applicationAPI.getById(applicationId);
      setApplication(data);
      setNotes(data.hr_notes || "");
      setStatus(data.status);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load application details",
        status: "error",
        duration: 3000,
      });
      navigate("/hr/applications");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await applicationAPI.updateStatus(applicationId, {
        status,
        hr_notes: notes,
      });
      toast({
        title: "Saved",
        description: "Application updated successfully",
        status: "success",
        duration: 2000,
      });
      fetchApplication();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update application",
        status: "error",
        duration: 3000,
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDownloadResume = async () => {
    if (!application.resume_id) {
      toast({
        title: "No resume",
        description: "This application has no resume",
        status: "warning",
        duration: 2000,
      });
      return;
    }

    try {
      const token = localStorage.getItem("access_token");
      const baseURL = import.meta.env.VITE_API_URL || "http://localhost:8000";
      const downloadUrl = `${baseURL}/api/resumes/${application.resume_id}/download`;

      const response = await fetch(downloadUrl, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) throw new Error("Download failed");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `resume_${application.id}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Downloaded",
        status: "success",
        duration: 2000,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download resume",
        status: "error",
        duration: 3000,
      });
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );
  if (!application) return null;

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.xl" position="relative" zIndex={1} py={8}>
          <VStack spacing={5} align="stretch">
            {/* Header */}
            <HStack justify="space-between">
              <HStack spacing={3}>
                <Button
                  size="sm"
                  h={9}
                  leftIcon={<Icon as={FiArrowLeft} boxSize={3.5} />}
                  variant="ghost"
                  onClick={() => navigate("/hr/applications")}
                  borderRadius="10px"
                  fontSize="label-xs"
                  fontFamily="'Inter', sans-serif"
                >
                  Back
                </Button>
                <Heading
                  fontSize="title-h5"
                  fontWeight={600}
                  fontFamily="'Inter', sans-serif"
                >
                  Application Details
                </Heading>
              </HStack>
              <Badge
                colorScheme={STATUS_COLORS[application.status]}
                fontSize="label-xs"
                px={3}
                py={1}
              >
                {getStatusLabel(application.status)}
              </Badge>
            </HStack>

            <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={5}>
              {/* Left Column */}
              <VStack align="stretch" spacing={4}>
                {/* Candidate Info */}
                <Box
                  bg="rgba(255, 255, 255, 0.7)"
                  backdropFilter="blur(20px)"
                  p={5}
                  borderRadius="14px"
                  border="1px solid rgba(255, 255, 255, 0.8)"
                  shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                >
                  <Text
                    fontSize="label-sm"
                    fontWeight={600}
                    mb={4}
                    fontFamily="'Inter', sans-serif"
                  >
                    Candidate Information
                  </Text>
                  <VStack align="stretch" spacing={3}>
                    <HStack>
                      <Icon as={FiUser} color="primary.base" boxSize={4} />
                      <VStack align="start" spacing={0} flex={1}>
                        <Text
                          fontSize="subheading-xs"
                          color="text.soft"
                          fontFamily="'Inter', sans-serif"
                        >
                          Candidate ID
                        </Text>
                        <Text
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        >
                          #{application.student_profile_id.substring(0, 8)}
                        </Text>
                      </VStack>
                    </HStack>

                    <HStack>
                      <Icon as={FiCalendar} color="primary.base" boxSize={4} />
                      <VStack align="start" spacing={0} flex={1}>
                        <Text
                          fontSize="subheading-xs"
                          color="text.soft"
                          fontFamily="'Inter', sans-serif"
                        >
                          Applied Date
                        </Text>
                        <Text
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        >
                          {formatDate(application.applied_date)}
                        </Text>
                      </VStack>
                    </HStack>

                    <HStack>
                      <Icon as={FiCalendar} color="primary.base" boxSize={4} />
                      <VStack align="start" spacing={0} flex={1}>
                        <Text
                          fontSize="subheading-xs"
                          color="text.soft"
                          fontFamily="'Inter', sans-serif"
                        >
                          Last Updated
                        </Text>
                        <Text
                          fontSize="paragraph-sm"
                          fontFamily="'Inter', sans-serif"
                        >
                          {formatDate(application.last_status_update)}
                        </Text>
                      </VStack>
                    </HStack>

                    {application.ats_score && (
                      <Flex justify="space-between" align="center">
                        <Text
                          fontSize="subheading-xs"
                          color="text.soft"
                          fontFamily="'Inter', sans-serif"
                        >
                          ATS Score
                        </Text>
                        <Badge
                          colorScheme={
                            application.ats_score >= 80
                              ? "green"
                              : application.ats_score >= 60
                              ? "yellow"
                              : "red"
                          }
                          fontSize="label-xs"
                        >
                          {application.ats_score.toFixed(1)}%
                        </Badge>
                      </Flex>
                    )}
                  </VStack>
                </Box>

                {/* Resume */}
                <Box
                  bg="rgba(255, 255, 255, 0.7)"
                  backdropFilter="blur(20px)"
                  p={5}
                  borderRadius="14px"
                  border="1px solid rgba(255, 255, 255, 0.8)"
                  shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                >
                  <Text
                    fontSize="label-sm"
                    fontWeight={600}
                    mb={3}
                    fontFamily="'Inter', sans-serif"
                  >
                    Resume
                  </Text>
                  <Button
                    size="sm"
                    h={9}
                    w="full"
                    bgGradient="linear(135deg, primary.base, feature.base)"
                    color="white"
                    borderRadius="10px"
                    leftIcon={<Icon as={FiDownload} boxSize={3.5} />}
                    onClick={handleDownloadResume}
                    isDisabled={!application.resume_id}
                    fontSize="label-xs"
                    fontFamily="'Inter', sans-serif"
                  >
                    Download Resume
                  </Button>
                </Box>
              </VStack>

              {/* Right Column */}
              <VStack align="stretch" spacing={4}>
                <Box
                  bg="rgba(255, 255, 255, 0.7)"
                  backdropFilter="blur(20px)"
                  p={5}
                  borderRadius="14px"
                  border="1px solid rgba(255, 255, 255, 0.8)"
                  shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
                >
                  <Text
                    fontSize="label-sm"
                    fontWeight={600}
                    mb={4}
                    fontFamily="'Inter', sans-serif"
                  >
                    Update Application
                  </Text>
                  <VStack align="stretch" spacing={4}>
                    <Box>
                      <Text
                        fontSize="label-xs"
                        mb={2}
                        fontFamily="'Inter', sans-serif"
                      >
                        Application Status
                      </Text>
                      <Select
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                        h={10}
                        bg="rgba(255, 255, 255, 0.6)"
                        borderRadius="10px"
                        fontSize="paragraph-sm"
                        fontFamily="'Inter', sans-serif"
                      >
                        {Object.entries(APPLICATION_STATUS).map(
                          ([key, value]) => (
                            <option key={value} value={value}>
                              {getStatusLabel(value)}
                            </option>
                          )
                        )}
                      </Select>
                    </Box>

                    <Box>
                      <Text
                        fontSize="label-xs"
                        mb={2}
                        fontFamily="'Inter', sans-serif"
                      >
                        HR Notes
                      </Text>
                      <Textarea
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Add notes about this candidate..."
                        rows={6}
                        bg="rgba(255, 255, 255, 0.6)"
                        borderRadius="10px"
                        fontSize="paragraph-sm"
                        fontFamily="'Inter', sans-serif"
                      />
                    </Box>

                    <Button
                      size="sm"
                      h={10}
                      bgGradient="linear(135deg, primary.base, feature.base)"
                      color="white"
                      borderRadius="10px"
                      leftIcon={<Icon as={FiSave} boxSize={3.5} />}
                      onClick={handleSave}
                      isLoading={saving}
                      fontSize="label-sm"
                      fontFamily="'Inter', sans-serif"
                    >
                      Save Changes
                    </Button>
                  </VStack>
                </Box>
              </VStack>
            </SimpleGrid>
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default ApplicationDetails;
