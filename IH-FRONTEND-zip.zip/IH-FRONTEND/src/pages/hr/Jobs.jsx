import {
  Box,
  Heading,
  VStack,
  SimpleGrid,
  Button,
  HStack,
  useToast,
  Text,
  Container,
  Icon,
  Badge,
  Flex,
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  FiPlus,
  FiBriefcase,
  FiMapPin,
  FiDollarSign,
  FiClock,
} from "react-icons/fi";
import Layout from "../../components/layout/Layout";
import Loading from "../../components/common/Loading";
import { jobAPI } from "../../api/job";
import api from "../../api/axios";
import { formatDate, formatSalary } from "../../utils/helpers";

const JobCard = ({ job }) => {
  const navigate = useNavigate();

  const statusColors = {
    active: "green",
    draft: "gray",
    closed: "red",
  };

  return (
    <Box
      bg="rgba(255, 255, 255, 0.7)"
      backdropFilter="blur(20px)"
      p={5}
      borderRadius="14px"
      border="1px solid rgba(255, 255, 255, 0.8)"
      shadow="0 4px 16px rgba(0, 0, 0, 0.04)"
      transition="all 0.3s"
      cursor="pointer"
      onClick={() => navigate(`/hr/jobs/${job.id}`)}
      _hover={{
        transform: "translateY(-4px)",
        shadow: "0 8px 24px rgba(0, 0, 0, 0.08)",
        borderColor: "rgba(125, 82, 244, 0.3)",
      }}
    >
      <VStack align="stretch" spacing={3}>
        <Flex justify="space-between" align="start">
          <VStack align="start" spacing={1} flex={1}>
            <Text
              fontSize="label-md"
              fontWeight={600}
              color="text.strong"
              fontFamily="'Inter', sans-serif"
              noOfLines={1}
            >
              {job.title}
            </Text>
            <HStack spacing={2} flexWrap="wrap">
              <Badge
                colorScheme={statusColors[job.status]}
                fontSize="subheading-xs"
                px={2}
                py={0.5}
                borderRadius="full"
              >
                {job.status}
              </Badge>
              {job.employment_type && (
                <Badge
                  fontSize="subheading-xs"
                  px={2}
                  py={0.5}
                  borderRadius="full"
                >
                  {job.employment_type}
                </Badge>
              )}
            </HStack>
          </VStack>
        </Flex>

        <VStack align="stretch" spacing={2}>
          <HStack fontSize="paragraph-xs" color="text.sub">
            <Icon as={FiMapPin} boxSize={3.5} />
            <Text fontFamily="'Inter', sans-serif">{job.location}</Text>
          </HStack>

          {job.salary_min && job.salary_max && (
            <HStack fontSize="paragraph-xs" color="text.sub">
              <Icon as={FiDollarSign} boxSize={3.5} />
              <Text fontFamily="'Inter', sans-serif">
                {formatSalary(job.salary_min, job.salary_max)}
              </Text>
            </HStack>
          )}

          <HStack fontSize="paragraph-xs" color="text.sub">
            <Icon as={FiClock} boxSize={3.5} />
            <Text fontFamily="'Inter', sans-serif">
              {job.posted_date ? formatDate(job.posted_date) : "Draft"}
            </Text>
          </HStack>
        </VStack>

        {job.description && (
          <Text
            fontSize="paragraph-xs"
            color="text.sub"
            noOfLines={2}
            fontFamily="'Inter', sans-serif"
          >
            {job.description}
          </Text>
        )}
      </VStack>
    </Box>
  );
};

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hasProfile, setHasProfile] = useState(true);
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    checkProfileAndFetchJobs();
  }, []);

  const checkProfileAndFetchJobs = async () => {
    try {
      await api.get("/api/hr/profile");
      setHasProfile(true);
      await fetchJobs();
    } catch (error) {
      if (error.response?.status === 404) {
        setHasProfile(false);
      }
      setLoading(false);
    }
  };

  const fetchJobs = async () => {
    try {
      const data = await jobAPI.getAll();
      setJobs(data);
    } catch (error) {
      toast({
        title: "Error loading jobs",
        description: error.message,
        status: "error",
        duration: 3000,
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading)
    return (
      <Layout>
        <Loading />
      </Layout>
    );

  return (
    <Layout>
      <Box
        minH="100vh"
        bg="linear-gradient(135deg, #fdfcfb 0%, #f7f4ff 25%, #fff5f7 50%, #f0f9ff 75%, #fdfbfb 100%)"
        position="relative"
        _before={{
          content: '""',
          position: "fixed",
          top: "-50%",
          left: "-50%",
          width: "200%",
          height: "200%",
          background:
            "radial-gradient(circle at 20% 30%, rgba(237, 233, 254, 0.3) 0%, transparent 25%)," +
            "radial-gradient(circle at 80% 20%, rgba(254, 242, 242, 0.2) 0%, transparent 25%)",
          animation: "float 20s ease-in-out infinite",
          zIndex: 0,
        }}
      >
        <Container maxW="container.xl" position="relative" zIndex={1} py={8}>
          <VStack spacing={6} align="stretch">
            {/* Header */}
            <Flex justify="space-between" align="center">
              <HStack spacing={3}>
                <Box
                  w={10}
                  h={10}
                  borderRadius="10px"
                  bgGradient="linear(135deg, primary.base, feature.base)"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                >
                  <Icon as={FiBriefcase} color="white" boxSize={5} />
                </Box>
                <VStack align="start" spacing={0}>
                  <Heading
                    fontSize="title-h5"
                    fontWeight={600}
                    fontFamily="'Inter', sans-serif"
                  >
                    My Jobs
                  </Heading>
                  <Text
                    fontSize="paragraph-xs"
                    color="text.sub"
                    fontFamily="'Inter', sans-serif"
                  >
                    {jobs.length} total positions
                  </Text>
                </VStack>
              </HStack>
              <Button
                size="sm"
                h={9}
                bgGradient="linear(135deg, primary.base, feature.base)"
                color="white"
                borderRadius="10px"
                leftIcon={<Icon as={FiPlus} boxSize={4} />}
                onClick={() => navigate("/hr/jobs/new")}
                isDisabled={!hasProfile}
                _hover={{
                  transform: "translateY(-2px)",
                  shadow: "0 8px 20px -6px rgba(125, 82, 244, 0.4)",
                }}
                transition="all 0.2s"
                fontFamily="'Inter', sans-serif"
                fontSize="label-xs"
              >
                Create Job
              </Button>
            </Flex>

            {/* Profile Warning */}
            {!hasProfile && (
              <Box
                bg="rgba(255, 255, 255, 0.7)"
                backdropFilter="blur(20px)"
                p={4}
                borderRadius="14px"
                border="1px solid rgba(251, 191, 36, 0.3)"
                shadow="0 4px 16px rgba(251, 191, 36, 0.1)"
              >
                <HStack spacing={3}>
                  <Text
                    fontSize="paragraph-sm"
                    fontFamily="'Inter', sans-serif"
                    flex={1}
                  >
                    ⚠️ Complete your profile to start posting jobs
                  </Text>
                  <Button
                    size="sm"
                    h={8}
                    colorScheme="orange"
                    borderRadius="8px"
                    onClick={() => navigate("/hr/profile")}
                    fontFamily="'Inter', sans-serif"
                    fontSize="label-xs"
                  >
                    Complete Profile
                  </Button>
                </HStack>
              </Box>
            )}

            {/* Jobs Grid */}
            {jobs.length === 0 ? (
              <Box
                bg="rgba(255, 255, 255, 0.7)"
                backdropFilter="blur(20px)"
                p={12}
                borderRadius="16px"
                border="1px solid rgba(255, 255, 255, 0.8)"
                textAlign="center"
              >
                <Icon as={FiBriefcase} boxSize={12} color="text.soft" mb={3} />
                <Heading
                  size="sm"
                  color="text.sub"
                  mb={2}
                  fontFamily="'Inter', sans-serif"
                >
                  No jobs posted yet
                </Heading>
                <Text
                  fontSize="paragraph-sm"
                  color="text.soft"
                  mb={4}
                  fontFamily="'Inter', sans-serif"
                >
                  {hasProfile
                    ? "Create your first job posting"
                    : "Complete your profile to get started"}
                </Text>
                <Button
                  size="sm"
                  h={9}
                  bgGradient="linear(135deg, primary.base, feature.base)"
                  color="white"
                  borderRadius="10px"
                  onClick={() =>
                    navigate(hasProfile ? "/hr/jobs/new" : "/hr/profile")
                  }
                  fontFamily="'Inter', sans-serif"
                  fontSize="label-xs"
                >
                  {hasProfile ? "Create First Job" : "Complete Profile"}
                </Button>
              </Box>
            ) : (
              <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={4}>
                {jobs.map((job) => (
                  <JobCard key={job.id} job={job} />
                ))}
              </SimpleGrid>
            )}
          </VStack>
        </Container>
      </Box>
    </Layout>
  );
};

export default Jobs;
