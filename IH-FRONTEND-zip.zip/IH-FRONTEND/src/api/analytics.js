import api from "./axios";

export const analyticsAPI = {
  getStudentOverview: async () => {
    const response = await api.get("/api/analytics/student/overview");
    return response.data;
  },

  // ✅ NEW: HR Dashboard Analytics
  getHRDashboard: async () => {
    const response = await api.get("/api/analytics/hr/dashboard");
    return response.data;
  },

  // ✅ NEW: HR Applications Summary
  getApplicationsSummary: async () => {
    const response = await api.get("/api/analytics/hr/applications-summary");
    return response.data;
  },
};
