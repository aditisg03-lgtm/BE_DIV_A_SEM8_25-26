import api from "./axios";

export const hrResumeAPI = {
  bulkUpload: async (files, jobId) => {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append("files", file);
    });
    formData.append("job_id", jobId);

    const response = await api.post("/api/hr/resumes/bulk-upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  },

  analyzeSingle: async (file, jobId = null) => {
    const formData = new FormData();
    formData.append("file", file);
    if (jobId) {
      formData.append("job_id", jobId);
    }

    const response = await api.post(
      "/api/hr/resumes/analyze-single",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );
    return response.data;
  },

  // ✅ NEW: Get all bulk upload batches
  getBatches: async () => {
    const response = await api.get("/api/hr/resumes/batches");
    return response.data;
  },

  // ✅ NEW: Get specific batch results
  getBatchResults: async (batchId) => {
    const response = await api.get(`/api/hr/resumes/batches/${batchId}`);
    return response.data;
  },
};
