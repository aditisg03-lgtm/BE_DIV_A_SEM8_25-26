import api from "./axios";

export const resumeAPI = {
  upload: async (file) => {
    const formData = new FormData();
    formData.append("file", file);

    const response = await api.post("/api/resumes/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  },

  getAll: async () => {
    const response = await api.get("/api/resumes");
    return response.data;
  },

  getById: async (id) => {
    const response = await api.get(`/api/resumes/${id}`);
    return response.data;
  },

  delete: async (id) => {
    const response = await api.delete(`/api/resumes/${id}`);
    return response.data;
  },

  analyze: async (id) => {
    const response = await api.post(`/api/resumes/${id}/analyze`);
    return response.data;
  },

  getAnalyses: async (id) => {
    const response = await api.get(`/api/resumes/${id}/analysis`);
    return response.data;
  },
  compareWithJob: async (resumeId, jobId) => {
    const response = await api.post(
      `/api/resumes/${resumeId}/compare-with-job/${jobId}`
    );
    return response.data;
  },
};
