import api from "./axios";

export const studentEnhancementsAPI = {
  // Saved Jobs
  saveJob: async (jobId) => {
    const response = await api.post(`/api/student/jobs/${jobId}/save`);
    return response.data;
  },

  unsaveJob: async (jobId) => {
    const response = await api.delete(`/api/student/jobs/${jobId}/save`);
    return response.data;
  },

  getSavedJobs: async () => {
    const response = await api.get("/api/student/jobs/saved");
    return response.data;
  },

  // Hidden Jobs
  hideJob: async (jobId) => {
    const response = await api.post(`/api/student/jobs/${jobId}/hide`);
    return response.data;
  },

  unhideJob: async (jobId) => {
    const response = await api.delete(`/api/student/jobs/${jobId}/hide`);
    return response.data;
  },

  // Custom Job Comparison
  compareCustomJob: async (data) => {
    const response = await api.post("/api/student/compare-custom-job", data);
    return response.data;
  },

  // Comparison History
  getComparisonHistory: async () => {
    const response = await api.get("/api/student/comparisons/history");
    return response.data;
  },

  getComparisonDetails: async (comparisonId) => {
    const response = await api.get(`/api/student/comparisons/${comparisonId}`);
    return response.data;
  },

  // Course Suggestions
  suggestCourses: async (comparisonId) => {
    const response = await api.post(
      `/api/student/comparisons/${comparisonId}/suggest-courses`
    );
    return response.data;
  },

  // Mock Interview
  generateInterview: async (comparisonId) => {
    const response = await api.post(
      `/api/student/comparisons/${comparisonId}/generate-interview`
    );
    return response.data;
  },

  submitInterview: async (interviewId, answers) => {
    const response = await api.post(
      `/api/student/interviews/${interviewId}/submit`,
      { answers }
    );
    return response.data;
  },

  getInterview: async (interviewId) => {
    const response = await api.get(`/api/student/interviews/${interviewId}`);
    return response.data;
  },

  // Resume Improvement
  improveResume: async (resumeId) => {
    const response = await api.post(`/api/student/resumes/${resumeId}/improve`);
    return response.data;
  },

  getImprovedResume: async (resumeId) => {
    const response = await api.get(`/api/student/resumes/${resumeId}/improved`);
    return response.data;
  },

  downloadImprovedResume: async (improvedId) => {
    const response = await api.get(
      `/api/student/resumes/improved/${improvedId}/download`,
      {
        responseType: "blob",
      }
    );
    return response.data;
  },

  // Analytics History
  getHistory: async () => {
    const response = await api.get("/api/student/analytics/history");
    return response.data;
  },

  // Application Management
  withdrawApplication: async (applicationId) => {
    const response = await api.put(
      `/api/student/applications/${applicationId}/withdraw`
    );
    return response.data;
  },

  deleteApplication: async (applicationId) => {
    const response = await api.delete(
      `/api/student/applications/${applicationId}`
    );
    return response.data;
  },

  // Cache-first approach
  getExistingComparison: async (jobId, resumeId) => {
    const response = await api.get(
      `/api/student/comparisons/job/${jobId}/resume/${resumeId}`
    );
    return response.data;
  },

  getComparisonCourses: async (comparisonId) => {
    const response = await api.get(
      `/api/student/comparisons/${comparisonId}/courses`
    );
    return response.data;
  },

  getComparisonInterviews: async (comparisonId) => {
    const response = await api.get(
      `/api/student/comparisons/${comparisonId}/interviews`
    );
    return response.data;
  },
};
