import api from "./axios";

export const studentAPI = {
  // Profile
  getProfile: async () => {
    const response = await api.get("/api/student/profile");
    return response.data;
  },

  createProfile: async (data) => {
    const response = await api.post("/api/student/profile", data);
    return response.data;
  },

  updateProfile: async (data) => {
    const response = await api.put("/api/student/profile", data);
    return response.data;
  },

  // Education
  getEducation: async () => {
    const response = await api.get("/api/student/education");
    return response.data;
  },

  createEducation: async (data) => {
    const response = await api.post("/api/student/education", data);
    return response.data;
  },

  updateEducation: async (id, data) => {
    const response = await api.put(`/api/student/education/${id}`, data);
    return response.data;
  },

  deleteEducation: async (id) => {
    const response = await api.delete(`/api/student/education/${id}`);
    return response.data;
  },

  // Experience
  getExperience: async () => {
    const response = await api.get("/api/student/experience");
    return response.data;
  },

  createExperience: async (data) => {
    const response = await api.post("/api/student/experience", data);
    return response.data;
  },

  updateExperience: async (id, data) => {
    const response = await api.put(`/api/student/experience/${id}`, data);
    return response.data;
  },

  deleteExperience: async (id) => {
    const response = await api.delete(`/api/student/experience/${id}`);
    return response.data;
  },

  // Skills
  getSkills: async () => {
    const response = await api.get("/api/student/skills");
    return response.data;
  },

  createSkill: async (data) => {
    const response = await api.post("/api/student/skills", data);
    return response.data;
  },

  updateSkill: async (id, data) => {
    const response = await api.put(`/api/student/skills/${id}`, data);
    return response.data;
  },

  deleteSkill: async (id) => {
    const response = await api.delete(`/api/student/skills/${id}`);
    return response.data;
  },
};
