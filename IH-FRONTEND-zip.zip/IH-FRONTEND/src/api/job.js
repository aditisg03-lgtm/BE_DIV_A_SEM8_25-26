import api from "./axios";

export const jobAPI = {
  getAll: async (params = {}) => {
    const response = await api.get("/api/jobs", { params });
    return response.data;
  },

  getById: async (id) => {
    const response = await api.get(`/api/jobs/${id}`);
    return response.data;
  },

  create: async (data) => {
    const response = await api.post("/api/jobs", data);
    return response.data;
  },

  update: async (id, data) => {
    const response = await api.put(`/api/jobs/${id}`, data);
    return response.data;
  },

  delete: async (id) => {
    const response = await api.delete(`/api/jobs/${id}`);
    return response.data;
  },

  publish: async (id) => {
    const response = await api.post(`/api/jobs/${id}/publish`);
    return response.data;
  },

  close: async (id) => {
    const response = await api.post(`/api/jobs/${id}/close`);
    return response.data;
  },
};
