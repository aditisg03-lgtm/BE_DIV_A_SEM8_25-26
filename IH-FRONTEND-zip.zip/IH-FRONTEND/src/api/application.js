import api from "./axios";

export const applicationAPI = {
  apply: async (data) => {
    const response = await api.post("/api/applications/apply", data);
    return response.data;
  },

  getAll: async () => {
    const response = await api.get("/api/applications");
    return response.data;
  },

  getById: async (id) => {
    const response = await api.get(`/api/applications/${id}`);
    return response.data;
  },

  updateStatus: async (id, data) => {
    const response = await api.put(`/api/applications/${id}/status`, data);
    return response.data;
  },
};
