import { extendTheme } from "@chakra-ui/react";

const theme = extendTheme({
  colors: {
    primary: {
      base: "#7d52f4",
      darker: "#6941d9",
      lighter: "#C0D5FF",
      alpha: {
        10: "rgba(125, 82, 244, 0.1)",
        16: "rgba(125, 82, 244, 0.16)",
      },
    },
    bg: {
      white: "#FFFFFF",
      weak: "#F8F9FA",
      soft: "#F0F2F5",
    },
    text: {
      strong: "#1B1C1D",
      sub: "#6B7280",
      soft: "#9CA3AF",
      disabled: "#D1D5DB",
    },
    stroke: {
      soft: "#E5E7EB",
      white: "#FFFFFF",
      strong: "#1B1C1D",
    },
    success: {
      base: "#10B981",
      lighter: "#D1FAE5",
    },
    warning: {
      base: "#F59E0B",
      lighter: "#FEF3C7",
      light: "#FDE68A",
      dark: "#92400E",
    },
    error: {
      base: "#EF4444",
      lighter: "#FEE2E2",
    },
    information: {
      base: "#7d52f4",
      light: "#DBEAFE",
      dark: "#1E40AF",
    },
    feature: {
      base: "#8B5CF6",
      light: "#EDE9FE",
      dark: "#5B21B6",
    },
    verified: {
      base: "#06B6D4",
      lighter: "#CFFAFE",
    },
  },
  fonts: {
    body: "Inter, system-ui, sans-serif",
    heading: "Inter, system-ui, sans-serif",
  },
  fontSizes: {
    "title-h3": "2.5rem",
    "title-h4": "1.875rem",
    "title-h5": "1.5rem",
    "label-lg": "1.125rem",
    "label-md": "1rem",
    "label-sm": "0.875rem",
    "label-xs": "0.75rem",
    "paragraph-sm": "0.875rem",
    "paragraph-xs": "0.75rem",
    "subheading-xs": "0.625rem",
    "subheading-2xs": "0.5625rem",
  },
  shadows: {
    "regular-xs": "0px 1px 2px 0px rgba(27, 28, 29, 0.03)",
    "regular-sm": "0px 1px 3px 0px rgba(27, 28, 29, 0.04)",
    "button-important-focus": "0 0 0 4px rgba(125, 82, 244, 0.1)",
    "button-primary-focus": "0 0 0 4px rgba(125, 82, 244, 0.2)",
    "toggle-switch": "0px 1px 3px rgba(0, 0, 0, 0.1)",
  },
  components: {
    Button: {
      baseStyle: {
        borderRadius: "10px",
        fontWeight: 500,
        transition: "all 0.2s ease-out",
      },
      variants: {
        solid: {
          bg: "primary.base",
          color: "white",
          _hover: {
            bg: "primary.darker",
            transform: "translateY(-1px)",
            shadow: "md",
          },
          _active: {
            transform: "translateY(0)",
          },
        },
        outline: {
          borderColor: "stroke.soft",
          color: "text.sub",
          _hover: {
            bg: "bg.weak",
            borderColor: "primary.base",
            color: "primary.base",
          },
        },
        ghost: {
          color: "text.sub",
          _hover: {
            bg: "bg.weak",
          },
        },
      },
    },
    Input: {
      defaultProps: {
        focusBorderColor: "primary.base",
      },
      variants: {
        outline: {
          field: {
            borderColor: "stroke.soft",
            borderRadius: "10px",
            _hover: {
              borderColor: "primary.lighter",
            },
            _focus: {
              borderColor: "primary.base",
              boxShadow: "button-primary-focus",
            },
          },
        },
      },
    },
    Select: {
      defaultProps: {
        focusBorderColor: "primary.base",
      },
      variants: {
        outline: {
          field: {
            borderColor: "stroke.soft",
            borderRadius: "10px",
            _hover: {
              borderColor: "primary.lighter",
            },
          },
        },
      },
    },
    Textarea: {
      defaultProps: {
        focusBorderColor: "primary.base",
      },
      variants: {
        outline: {
          borderColor: "stroke.soft",
          borderRadius: "10px",
          _hover: {
            borderColor: "primary.lighter",
          },
        },
      },
    },
    Tabs: {
      variants: {
        line: {
          tab: {
            color: "text.sub",
            borderColor: "transparent",
            _selected: {
              color: "primary.base",
              borderColor: "primary.base",
              fontWeight: 600,
            },
            _hover: {
              color: "primary.base",
            },
          },
        },
      },
    },
  },
  styles: {
    global: {
      body: {
        bg: "bg.weak",
        color: "text.strong",
      },
    },
  },
});

export default theme;
