# IntelizenHire Frontend

React-based frontend for the IntelizenHire ATS system.

## Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

## Installation and Run Instructions

### Backend Setup:

```bash
cd IntelizenHire-Backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run the server
python run.py
```

Register as Student:

Go to http://localhost:5173/register
Email: student@test.com
Password: password123
Role: Student
Register as HR:

Email: hr@test.com
Password: password123
Role: HR
Test Student Flow:

Complete profile
Upload resume (PDF)
Browse jobs
Apply to jobs
Test HR Flow:

Complete company profile
Create job posting
View applications
Update application status
