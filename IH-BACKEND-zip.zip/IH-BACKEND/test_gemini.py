import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()

# Configure Gemini
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# Test the API
model = genai.GenerativeModel("gemini-2.5-flash")
response = model.generate_content("Say hello!")

print("✅ Gemini API is working!")
print(f"Response: {response.text}")
