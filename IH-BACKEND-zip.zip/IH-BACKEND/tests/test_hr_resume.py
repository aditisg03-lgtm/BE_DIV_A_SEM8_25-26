"""
HR Resume Management Tests
Tests for bulk resume upload and analysis
"""

import pytest
from fastapi import status
from io import BytesIO


class TestBulkResumeUpload:
    """Test bulk resume upload functionality"""

    def test_bulk_upload_success(
        self,
        client,
        hr_profile,
        job_description,
        hr_auth_headers,
        sample_resume_file,
        mock_gemini_service,
    ):
        """Test successful bulk resume upload"""

        # Create multiple resume files
        files = [
            (
                "files",
                ("resume1.pdf", BytesIO(sample_resume_file.read()), "application/pdf"),
            ),
            (
                "files",
                (
                    "resume2.pdf",
                    BytesIO(sample_resume_file.getvalue()),
                    "application/pdf",
                ),
            ),
            (
                "files",
                (
                    "resume3.pdf",
                    BytesIO(sample_resume_file.getvalue()),
                    "application/pdf",
                ),
            ),
        ]

        data = {"job_id": job_description.id}

        response = client.post(
            "/api/hr/resumes/bulk-upload",
            files=files,
            data=data,
            headers=hr_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        result = response.json()

        # Verify response structure
        assert "batch_id" in result
        assert "job_id" in result
        assert "job_title" in result
        assert "total_uploaded" in result
        assert "successful" in result
        assert "statistics" in result
        assert "results" in result

        # Verify counts
        assert result["total_uploaded"] == 3
        assert result["successful"] <= 3

        # Verify statistics
        stats = result["statistics"]
        assert "average_ats_score" in stats
        assert "highest_score" in stats
        assert "lowest_score" in stats

        # Verify categorization
        assert "highly_recommended" in result
        assert "recommended" in result
        assert "consider" in result
        assert "not_recommended" in result

    def test_bulk_upload_without_profile(
        self, client, job_description, hr_auth_headers
    ):
        """Test bulk upload without HR profile"""
        files = [("files", ("resume.pdf", BytesIO(b"PDF content"), "application/pdf"))]
        data = {"job_id": job_description.id}

        response = client.post(
            "/api/hr/resumes/bulk-upload",
            files=files,
            data=data,
            headers=hr_auth_headers,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_bulk_upload_nonexistent_job(
        self, client, hr_profile, hr_auth_headers, sample_resume_file
    ):
        """Test bulk upload with non-existent job"""
        files = [("files", ("resume.pdf", sample_resume_file, "application/pdf"))]
        data = {"job_id": "fake-job-id"}

        response = client.post(
            "/api/hr/resumes/bulk-upload",
            files=files,
            data=data,
            headers=hr_auth_headers,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert "job" in response.json()["detail"].lower()

    def test_bulk_upload_exceeds_file_limit(
        self, client, hr_profile, job_description, hr_auth_headers
    ):
        """Test bulk upload exceeding 20 file limit"""
        files = [
            ("files", (f"resume{i}.pdf", BytesIO(b"PDF"), "application/pdf"))
            for i in range(21)
        ]
        data = {"job_id": job_description.id}

        response = client.post(
            "/api/hr/resumes/bulk-upload",
            files=files,
            data=data,
            headers=hr_auth_headers,
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "20" in response.json()["detail"]

    def test_bulk_upload_non_pdf_files(
        self, client, hr_profile, job_description, hr_auth_headers, mock_gemini_service
    ):
        """Test bulk upload with non-PDF files"""
        files = [
            ("files", ("resume.pdf", BytesIO(b"PDF content"), "application/pdf")),
            ("files", ("resume.txt", BytesIO(b"Text content"), "text/plain")),
        ]
        data = {"job_id": job_description.id}

        response = client.post(
            "/api/hr/resumes/bulk-upload",
            files=files,
            data=data,
            headers=hr_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        result = response.json()

        # Should have one error for non-PDF
        assert result["failed"] >= 1

        # Check results for error message
        error_results = [r for r in result["results"] if r["status"] == "error"]
        assert any("PDF" in r["message"] for r in error_results)

    def test_student_cannot_bulk_upload(
        self, client, job_description, student_auth_headers, sample_resume_file
    ):
        """Test student cannot access bulk upload"""
        files = [("files", ("resume.pdf", sample_resume_file, "application/pdf"))]
        data = {"job_id": job_description.id}

        response = client.post(
            "/api/hr/resumes/bulk-upload",
            files=files,
            data=data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN


class TestBulkUploadBatches:
    """Test bulk upload batch retrieval"""

    def test_get_batches(self, client, hr_profile, hr_auth_headers, db_session):
        """Test getting all bulk upload batches"""
        from app.models.bulk_upload import BulkUploadBatch
        from app.models.job import (
            JobDescription,
            JobStatus,
            EmploymentType,
            ExperienceLevel,
        )

        # Create a job
        job = JobDescription(
            hr_profile_id=hr_profile.id,
            title="Test Job",
            location="Remote",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.MID,
            description="Test",
            status=JobStatus.ACTIVE,
        )
        db_session.add(job)
        db_session.flush()

        # Create batch
        batch = BulkUploadBatch(
            hr_profile_id=hr_profile.id,
            job_description_id=job.id,
            total_uploaded=5,
            successful_count=4,
            failed_count=1,
            average_ats_score=75.5,
        )
        db_session.add(batch)
        db_session.commit()

        response = client.get("/api/hr/resumes/batches", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

        batch_data = data[0]
        assert "batch_id" in batch_data
        assert "job_title" in batch_data
        assert "upload_date" in batch_data
        assert "total_uploaded" in batch_data
        assert "successful_count" in batch_data

    def test_get_batches_empty(self, client, hr_profile, hr_auth_headers):
        """Test getting batches when none exist"""
        response = client.get("/api/hr/resumes/batches", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        assert response.json() == []

    def test_get_specific_batch(self, client, hr_profile, hr_auth_headers, db_session):
        """Test getting specific batch details"""
        from app.models.bulk_upload import BulkUploadBatch, BulkCandidateAnalysis
        from app.models.job import (
            JobDescription,
            JobStatus,
            EmploymentType,
            ExperienceLevel,
        )

        # Create job and batch
        job = JobDescription(
            hr_profile_id=hr_profile.id,
            title="Software Engineer",
            location="Remote",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.SENIOR,
            description="Test job",
            status=JobStatus.ACTIVE,
        )
        db_session.add(job)
        db_session.flush()

        batch = BulkUploadBatch(
            hr_profile_id=hr_profile.id,
            job_description_id=job.id,
            total_uploaded=3,
            successful_count=3,
            failed_count=0,
            average_ats_score=80.0,
            highest_score=90.0,
            lowest_score=70.0,
        )
        db_session.add(batch)
        db_session.flush()

        # Create candidate analyses
        candidate = BulkCandidateAnalysis(
            batch_id=batch.id,
            filename="resume1.pdf",
            rank=1,
            candidate_name="John Doe",
            contact_email="john@example.com",
            ats_score=90.0,
            recommendation="HIGHLY RECOMMENDED",
        )
        db_session.add(candidate)
        db_session.commit()

        response = client.get(
            f"/api/hr/resumes/batches/{batch.id}", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert data["batch_id"] == batch.id
        assert data["total_uploaded"] == 3
        assert "results" in data
        assert len(data["results"]) >= 1

        # Verify categorization
        assert "highly_recommended" in data
        assert "recommended" in data
        assert "consider" in data
        assert "not_recommended" in data

    def test_get_batch_not_found(self, client, hr_profile, hr_auth_headers):
        """Test getting non-existent batch"""
        response = client.get(
            "/api/hr/resumes/batches/fake-batch-id", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestSingleResumeAnalysis:
    """Test single resume analysis"""

    def test_analyze_single_resume(
        self,
        client,
        hr_profile,
        job_description,
        hr_auth_headers,
        sample_resume_file,
        mock_gemini_service,
    ):
        """Test analyzing single resume"""
        files = {"file": ("resume.pdf", sample_resume_file, "application/pdf")}
        data = {"job_id": job_description.id}

        response = client.post(
            "/api/hr/resumes/analyze-single",
            files=files,
            data=data,
            headers=hr_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        result = response.json()

        assert "filename" in result
        assert "job_title" in result
        assert "analysis" in result
        assert result["filename"] == "resume.pdf"

        analysis = result["analysis"]
        assert "ats_score" in analysis
        assert "strengths" in analysis
        assert "weaknesses" in analysis

    def test_analyze_without_job(
        self,
        client,
        hr_profile,
        hr_auth_headers,
        sample_resume_file,
        mock_gemini_service,
    ):
        """Test analyzing resume without job context"""
        files = {"file": ("resume.pdf", sample_resume_file, "application/pdf")}

        response = client.post(
            "/api/hr/resumes/analyze-single", files=files, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        result = response.json()
        assert result["job_title"] == "General Analysis"

    def test_analyze_non_pdf(self, client, hr_profile, hr_auth_headers):
        """Test analyzing non-PDF file"""
        files = {"file": ("resume.txt", BytesIO(b"Text"), "text/plain")}

        response = client.post(
            "/api/hr/resumes/analyze-single", files=files, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
