"""
Analytics Tests
Tests for student and HR analytics endpoints
"""

import pytest
from fastapi import status


class TestStudentAnalytics:
    """Test student analytics endpoints"""

    def test_get_student_overview(
        self,
        client,
        student_profile,
        resume_record,
        application_record,
        student_auth_headers,
    ):
        """Test getting student analytics overview"""
        response = client.get(
            "/api/analytics/student/overview", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        # Verify structure
        assert "total_applications" in data
        assert "average_ats_score" in data
        assert "total_resumes" in data
        assert "application_status_breakdown" in data

        # Verify data
        assert data["total_applications"] >= 1
        assert data["total_resumes"] >= 1
        assert data["average_ats_score"] > 0
        assert isinstance(data["application_status_breakdown"], dict)

    def test_get_overview_without_profile(self, client, student_auth_headers):
        """Test getting overview without profile returns empty data"""
        response = client.get(
            "/api/analytics/student/overview", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["total_applications"] == 0
        assert data["total_resumes"] == 0

    def test_hr_cannot_access_student_overview(self, client, hr_auth_headers):
        """Test HR cannot access student overview"""
        response = client.get(
            "/api/analytics/student/overview", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN


class TestHRDashboardAnalytics:
    """Test HR dashboard analytics"""

    def test_get_hr_dashboard(
        self, client, hr_profile, job_description, application_record, hr_auth_headers
    ):
        """Test comprehensive HR dashboard analytics"""
        response = client.get("/api/analytics/hr/dashboard", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        # Verify main sections
        assert "overview" in data
        assert "applications_by_job" in data
        assert "applications_by_status" in data
        assert "bulk_uploads_by_job" in data
        assert "ats_score_distribution" in data
        assert "recent_activity" in data

        # Verify overview structure
        overview = data["overview"]
        assert "total_jobs" in overview
        assert "active_jobs" in overview
        assert "total_applications" in overview
        assert "pending_review" in overview

        # Verify data types
        assert isinstance(data["applications_by_job"], list)
        assert isinstance(data["applications_by_status"], list)
        assert isinstance(data["ats_score_distribution"], list)

    def test_dashboard_applications_by_job(
        self,
        client,
        hr_profile,
        job_description,
        application_record,
        hr_auth_headers,
        db_session,
    ):
        """Test applications grouped by job"""
        response = client.get("/api/analytics/hr/dashboard", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        apps_by_job = data["applications_by_job"]
        assert len(apps_by_job) >= 1

        # Check structure of each item
        for item in apps_by_job:
            assert "job" in item
            assert "applications" in item
            assert isinstance(item["applications"], int)

    def test_dashboard_applications_by_status(
        self, client, hr_profile, job_description, application_record, hr_auth_headers
    ):
        """Test applications grouped by status"""
        response = client.get("/api/analytics/hr/dashboard", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        apps_by_status = data["applications_by_status"]
        assert len(apps_by_status) >= 1

        for item in apps_by_status:
            assert "status" in item
            assert "count" in item
            assert item["status"] in [
                "submitted",
                "under_review",
                "shortlisted",
                "interview_scheduled",
                "offer_extended",
                "rejected",
                "withdrawn",
            ]

    def test_dashboard_recent_activity(
        self, client, hr_profile, job_description, application_record, hr_auth_headers
    ):
        """Test recent activity section"""
        response = client.get("/api/analytics/hr/dashboard", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        recent = data["recent_activity"]
        assert "applications" in recent
        assert "bulk_uploads" in recent

        # Verify applications structure
        if recent["applications"]:
            app = recent["applications"][0]
            assert "id" in app
            assert "job_title" in app
            assert "date" in app
            assert "status" in app

    def test_dashboard_without_profile(self, client, hr_auth_headers):
        """Test dashboard without HR profile returns empty data"""
        response = client.get("/api/analytics/hr/dashboard", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["overview"] == {}

    def test_student_cannot_access_hr_dashboard(self, client, student_auth_headers):
        """Test student cannot access HR dashboard"""
        response = client.get(
            "/api/analytics/hr/dashboard", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN


class TestApplicationsSummary:
    """Test applications summary endpoint"""

    def test_get_applications_summary(
        self, client, hr_profile, job_description, application_record, hr_auth_headers
    ):
        """Test getting applications summary"""
        response = client.get(
            "/api/analytics/hr/applications-summary", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert "student_applications" in data
        assert "bulk_uploaded_candidates" in data

        # Verify student applications structure
        student_apps = data["student_applications"]
        assert isinstance(student_apps, list)

        if student_apps:
            app = student_apps[0]
            assert "id" in app
            assert "job_id" in app
            assert "job_title" in app
            assert "applied_date" in app
            assert "status" in app

    def test_summary_with_multiple_jobs(
        self, client, hr_profile, hr_auth_headers, db_session
    ):
        """Test summary with applications to multiple jobs"""
        from app.models.job import (
            JobDescription,
            JobStatus,
            EmploymentType,
            ExperienceLevel,
        )
        from app.models.student import StudentProfile
        from app.models.application import Application, ApplicationStatus
        from app.models.user import User, UserRole
        from app.utils.security import get_password_hash

        # Create another job
        job2 = JobDescription(
            hr_profile_id=hr_profile.id,
            title="Backend Developer",
            location="Remote",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.MID,
            description="Backend role",
            status=JobStatus.ACTIVE,
        )
        db_session.add(job2)

        # Create another student and application
        student2 = User(
            email="student2@test.com",
            password_hash=get_password_hash("password"),
            role=UserRole.STUDENT,
        )
        db_session.add(student2)
        db_session.flush()

        profile2 = StudentProfile(
            user_id=student2.id, first_name="Jane", last_name="Smith"
        )
        db_session.add(profile2)
        db_session.flush()

        app2 = Application(
            job_description_id=job2.id,
            student_profile_id=profile2.id,
            status=ApplicationStatus.SUBMITTED,
        )
        db_session.add(app2)
        db_session.commit()

        response = client.get(
            "/api/analytics/hr/applications-summary", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data["student_applications"]) >= 2
