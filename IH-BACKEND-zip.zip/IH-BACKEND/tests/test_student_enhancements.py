"""
Student Enhancements Tests
Tests for advanced student features: saved jobs, comparisons, interviews, etc.
"""

import pytest
from fastapi import status
import json


class TestSavedJobs:
    """Test saved jobs functionality"""

    def test_save_job_success(
        self, client, student_profile, job_description, student_auth_headers
    ):
        """Test saving a job"""
        response = client.post(
            f"/api/student/jobs/{job_description.id}/save", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        assert "saved successfully" in response.json()["message"].lower()

    def test_save_already_saved_job(
        self, client, student_profile, job_description, student_auth_headers, db_session
    ):
        """Test saving already saved job"""
        from app.models.student_enhancements import SavedJob

        # Save job first
        saved = SavedJob(
            student_profile_id=student_profile.id, job_description_id=job_description.id
        )
        db_session.add(saved)
        db_session.commit()

        # Try to save again
        response = client.post(
            f"/api/student/jobs/{job_description.id}/save", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "already saved" in response.json()["detail"].lower()

    def test_get_saved_jobs(
        self, client, student_profile, job_description, student_auth_headers, db_session
    ):
        """Test getting all saved jobs"""
        from app.models.student_enhancements import SavedJob

        saved = SavedJob(
            student_profile_id=student_profile.id, job_description_id=job_description.id
        )
        db_session.add(saved)
        db_session.commit()

        response = client.get("/api/student/jobs/saved", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

        saved_job = data[0]
        assert "saved_id" in saved_job
        assert "saved_at" in saved_job
        assert "job" in saved_job
        assert saved_job["job"]["id"] == job_description.id

    def test_unsave_job(
        self, client, student_profile, job_description, student_auth_headers, db_session
    ):
        """Test removing saved job"""
        from app.models.student_enhancements import SavedJob

        saved = SavedJob(
            student_profile_id=student_profile.id, job_description_id=job_description.id
        )
        db_session.add(saved)
        db_session.commit()

        response = client.delete(
            f"/api/student/jobs/{job_description.id}/save", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify removed
        get_response = client.get(
            "/api/student/jobs/saved", headers=student_auth_headers
        )
        assert len(get_response.json()) == 0


class TestHiddenJobs:
    """Test hidden jobs functionality"""

    def test_hide_job(
        self, client, student_profile, job_description, student_auth_headers
    ):
        """Test hiding a job"""
        response = client.post(
            f"/api/student/jobs/{job_description.id}/hide", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        assert "hidden" in response.json()["message"].lower()

    def test_hide_already_hidden_job(
        self, client, student_profile, job_description, student_auth_headers, db_session
    ):
        """Test hiding already hidden job"""
        from app.models.student_enhancements import HiddenJob

        hidden = HiddenJob(
            student_profile_id=student_profile.id, job_description_id=job_description.id
        )
        db_session.add(hidden)
        db_session.commit()

        response = client.post(
            f"/api/student/jobs/{job_description.id}/hide", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_unhide_job(
        self, client, student_profile, job_description, student_auth_headers, db_session
    ):
        """Test unhiding a job"""
        from app.models.student_enhancements import HiddenJob

        hidden = HiddenJob(
            student_profile_id=student_profile.id, job_description_id=job_description.id
        )
        db_session.add(hidden)
        db_session.commit()

        response = client.delete(
            f"/api/student/jobs/{job_description.id}/hide", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK


class TestJobComparison:
    """Test job comparison features"""

    def test_compare_with_custom_job(
        self,
        client,
        student_profile,
        resume_record,
        student_auth_headers,
        mock_gemini_service,
    ):
        """Test comparing resume with custom job description"""
        comparison_data = {
            "resume_id": resume_record.id,
            "job_title": "Software Engineer",
            "job_description": "Looking for a Python developer with React experience",
            "company_name": "Tech Corp",
            "required_skills": ["Python", "React", "PostgreSQL"],
        }

        response = client.post(
            "/api/student/compare-custom-job",
            json=comparison_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert "comparison_id" in data
        assert "success_probability" in data
        assert "success_level" in data
        assert "scores" in data
        assert "analysis" in data
        assert "next_steps" in data

        # Verify success levels
        assert data["success_level"] in ["EXCELLENT", "GOOD", "MODERATE", "LOW"]

    def test_get_comparison_history(
        self, client, student_profile, student_auth_headers, db_session
    ):
        """Test getting comparison history"""
        from app.models.student_enhancements import JobComparison
        from app.models.resume import Resume

        resume = Resume(
            student_profile_id=student_profile.id,
            file_name="test.pdf",
            file_path="/tmp/test.pdf",
            file_size=1000,
            extracted_text="test",
        )
        db_session.add(resume)
        db_session.flush()

        comparison = JobComparison(
            student_profile_id=student_profile.id,
            resume_id=resume.id,
            custom_job_description="Test job",
            success_probability=75.0,
            success_level="GOOD",
            success_message="Good match",
        )
        db_session.add(comparison)
        db_session.commit()

        response = client.get(
            "/api/student/comparisons/history", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    def test_get_existing_comparison(
        self,
        client,
        student_profile,
        job_description,
        resume_record,
        student_auth_headers,
        db_session,
    ):
        """Test getting cached comparison"""
        from app.models.student_enhancements import JobComparison

        comparison = JobComparison(
            student_profile_id=student_profile.id,
            resume_id=resume_record.id,
            job_description_id=job_description.id,
            success_probability=80.0,
            success_level="GOOD",
            success_message="Good match",
        )
        db_session.add(comparison)
        db_session.commit()

        response = client.get(
            f"/api/student/comparisons/job/{job_description.id}/resume/{resume_record.id}",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["exists"] is True
        assert "comparison" in data


class TestCourseSuggestions:
    """Test course suggestion features"""

    def test_suggest_courses(
        self,
        client,
        student_profile,
        student_auth_headers,
        db_session,
        mock_gemini_service,
    ):
        """Test generating course suggestions"""
        from app.models.student_enhancements import JobComparison
        from app.models.resume import Resume

        resume = Resume(
            student_profile_id=student_profile.id,
            file_name="test.pdf",
            file_path="/tmp/test.pdf",
            file_size=1000,
            extracted_text="test",
        )
        db_session.add(resume)
        db_session.flush()

        comparison = JobComparison(
            student_profile_id=student_profile.id,
            resume_id=resume.id,
            custom_job_description="Test",
            success_probability=60.0,
            success_level="MODERATE",
            success_message="Test",
            analysis={"skills_match": {"missing_skills": ["AWS", "Docker"]}},
            next_steps={"critical_gaps": ["AWS", "Docker"]},
        )
        db_session.add(comparison)
        db_session.commit()

        # Mock Gemini response for course generation
        import json as json_module

        mock_response = {
            "courses": [
                {
                    "name": "AWS Certified Solutions Architect",
                    "platform": "Udemy",
                    "skill_gap": "AWS",
                    "reason": "Learn cloud fundamentals",
                    "relevance_score": 95,
                    "estimated_duration": "20 hours",
                    "level": "Beginner",
                }
            ]
        }

        response = client.post(
            f"/api/student/comparisons/{comparison.id}/suggest-courses",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "courses" in data
        assert len(data["courses"]) > 0

        # Verify course structure
        course = data["courses"][0]
        assert "name" in course
        assert "platform" in course
        assert "url" in course

    def test_get_comparison_courses(
        self, client, student_profile, student_auth_headers, db_session
    ):
        """Test getting existing course suggestions"""
        from app.models.student_enhancements import JobComparison, CourseSuggestion
        from app.models.resume import Resume

        resume = Resume(
            student_profile_id=student_profile.id,
            file_name="test.pdf",
            file_path="/tmp/test.pdf",
            file_size=1000,
            extracted_text="test",
        )
        db_session.add(resume)
        db_session.flush()

        comparison = JobComparison(
            student_profile_id=student_profile.id,
            resume_id=resume.id,
            custom_job_description="Test",
            success_probability=70.0,
            success_level="GOOD",
            success_message="Test",
        )
        db_session.add(comparison)
        db_session.flush()

        course = CourseSuggestion(
            job_comparison_id=comparison.id,
            course_name="AWS Course",
            platform="Udemy",
            url="https://udemy.com/aws",
            skill_gap="AWS",
            reason="Learn cloud",
            relevance_score=90,
        )
        db_session.add(course)
        db_session.commit()

        response = client.get(
            f"/api/student/comparisons/{comparison.id}/courses",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["exists"] is True
        assert len(data["courses"]) >= 1


class TestMockInterview:
    """Test mock interview features"""

    def test_generate_interview(
        self,
        client,
        student_profile,
        student_auth_headers,
        db_session,
        mock_gemini_service,
    ):
        """Test generating mock interview questions"""
        from app.models.student_enhancements import JobComparison
        from app.models.resume import Resume

        resume = Resume(
            student_profile_id=student_profile.id,
            file_name="test.pdf",
            file_path="/tmp/test.pdf",
            file_size=1000,
            extracted_text="test",
        )
        db_session.add(resume)
        db_session.flush()

        comparison = JobComparison(
            student_profile_id=student_profile.id,
            resume_id=resume.id,
            custom_job_description="Software Engineer role",
            success_probability=75.0,
            success_level="GOOD",
            success_message="Good match",
            analysis={"strengths": ["Python", "React"]},
            next_steps={"critical_gaps": ["AWS"]},
        )
        db_session.add(comparison)
        db_session.commit()

        response = client.post(
            f"/api/student/comparisons/{comparison.id}/generate-interview",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert "interview_id" in data
        assert "questions" in data
        assert len(data["questions"]) > 0

        # Verify question structure
        question = data["questions"][0]
        assert "id" in question
        assert "type" in question
        assert "question" in question

    def test_submit_interview_answers(
        self,
        client,
        student_profile,
        student_auth_headers,
        db_session,
        mock_gemini_service,
    ):
        """Test submitting interview answers"""
        from app.models.student_enhancements import MockInterview, JobComparison
        from app.models.resume import Resume

        resume = Resume(
            student_profile_id=student_profile.id,
            file_name="test.pdf",
            file_path="/tmp/test.pdf",
            file_size=1000,
            extracted_text="test",
        )
        db_session.add(resume)
        db_session.flush()

        comparison = JobComparison(
            student_profile_id=student_profile.id,
            resume_id=resume.id,
            custom_job_description="Test",
            success_probability=70.0,
            success_level="GOOD",
            success_message="Test",
            analysis={"strengths": ["Python"]},
        )
        db_session.add(comparison)
        db_session.flush()

        interview = MockInterview(
            student_profile_id=student_profile.id,
            job_comparison_id=comparison.id,
            questions=[
                {"id": 1, "type": "behavioral", "question": "Tell me about yourself"}
            ],
            status="pending",
        )
        db_session.add(interview)
        db_session.commit()

        answers = {
            "answers": {"1": "I am a passionate developer with 3 years experience..."}
        }

        response = client.post(
            f"/api/student/interviews/{interview.id}/submit",
            json=answers,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert "overall_score" in data
        assert "feedback" in data
        assert "strengths" in data
        assert "improvements" in data

    def test_get_interview(
        self, client, student_profile, student_auth_headers, db_session
    ):
        """Test getting interview details"""
        from app.models.student_enhancements import MockInterview, JobComparison
        from app.models.resume import Resume

        resume = Resume(
            student_profile_id=student_profile.id,
            file_name="test.pdf",
            file_path="/tmp/test.pdf",
            file_size=1000,
            extracted_text="test",
        )
        db_session.add(resume)
        db_session.flush()

        comparison = JobComparison(
            student_profile_id=student_profile.id,
            resume_id=resume.id,
            custom_job_description="Test",
            success_probability=70.0,
            success_level="GOOD",
            success_message="Test",
        )
        db_session.add(comparison)
        db_session.flush()

        interview = MockInterview(
            student_profile_id=student_profile.id,
            job_comparison_id=comparison.id,
            questions=[{"id": 1, "question": "Test?"}],
            status="completed",
            overall_score=85,
        )
        db_session.add(interview)
        db_session.commit()

        response = client.get(
            f"/api/student/interviews/{interview.id}", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == interview.id
        assert data["status"] == "completed"


class TestResumeImprovement:
    """Test AI resume improvement"""

    def test_improve_resume(
        self,
        client,
        student_profile,
        resume_record,
        student_auth_headers,
        mock_gemini_service,
        tmp_path,
    ):
        """Test improving resume with AI"""
        response = client.post(
            f"/api/student/resumes/{resume_record.id}/improve",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert "improved_resume_id" in data
        assert "file_name" in data
        assert "ats_score_before" in data
        assert "ats_score_after" in data
        assert "improvements_made" in data
        assert data["download_available"] is True

    def test_get_improved_resume(
        self,
        client,
        student_profile,
        resume_record,
        student_auth_headers,
        db_session,
        tmp_path,
    ):
        """Test getting improved resume details"""
        from app.models.student_enhancements import ImprovedResume

        improved = ImprovedResume(
            original_resume_id=resume_record.id,
            student_profile_id=student_profile.id,
            file_name="improved_resume.pdf",
            file_path=str(tmp_path / "improved.pdf"),
            ats_score_before=75.0,
            ats_score_after=92.0,
        )
        db_session.add(improved)
        db_session.commit()

        response = client.get(
            f"/api/student/resumes/{resume_record.id}/improved",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == improved.id


class TestStudentApplicationManagement:
    """Test student application management"""

    def test_withdraw_application(
        self, client, application_record, student_auth_headers, db_session
    ):
        """Test withdrawing an application"""
        response = client.put(
            f"/api/student/applications/{application_record.id}/withdraw",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify status changed
        db_session.refresh(application_record)
        assert application_record.status.value == "withdrawn"

    def test_delete_application(self, client, application_record, student_auth_headers):
        """Test deleting an application"""
        response = client.delete(
            f"/api/student/applications/{application_record.id}",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK


class TestStudentHistory:
    """Test student activity history"""

    def test_get_student_history(
        self,
        client,
        student_profile,
        resume_record,
        application_record,
        student_auth_headers,
    ):
        """Test getting complete student history"""
        response = client.get(
            "/api/student/analytics/history", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()

        assert "statistics" in data
        assert "resume_history" in data
        assert "application_history" in data
        assert "comparison_history" in data
        assert "interview_history" in data

        # Verify statistics
        stats = data["statistics"]
        assert "total_resumes" in stats
        assert "total_applications" in stats
        assert "average_ats_score" in stats
