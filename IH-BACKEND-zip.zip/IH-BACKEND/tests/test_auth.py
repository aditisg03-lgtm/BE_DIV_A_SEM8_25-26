"""
Authentication Endpoint Tests
Tests for user registration, login, and token refresh
"""

import pytest
from fastapi import status
from tests.factories import UserFactory


class TestUserRegistration:
    """Test user registration endpoint"""

    def test_register_student_success(self, client):
        """Test successful student registration"""
        user_data = UserFactory.create_student_data()

        response = client.post("/api/auth/register", json=user_data)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["email"] == user_data["email"]
        assert data["role"] == "student"
        assert data["is_active"] is True
        assert "id" in data
        assert "hashed_password" not in data

    def test_register_hr_success(self, client):
        """Test successful HR registration"""
        user_data = UserFactory.create_hr_data()

        response = client.post("/api/auth/register", json=user_data)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["email"] == user_data["email"]
        assert data["role"] == "hr"

    def test_register_duplicate_email(self, client, student_user):
        """Test registration with duplicate email fails"""
        user_data = UserFactory.create_student_data(email=student_user.email)

        response = client.post("/api/auth/register", json=user_data)

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "already registered" in response.json()["detail"].lower()

    @pytest.mark.parametrize(
        "invalid_email",
        ["notanemail", "@example.com", "user@", "user name@example.com"],
    )
    def test_register_invalid_email(self, client, invalid_email):
        """Test registration with invalid email format"""
        user_data = UserFactory.create_student_data(email=invalid_email)

        response = client.post("/api/auth/register", json=user_data)

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    @pytest.mark.parametrize("invalid_role", ["admin", "superuser", ""])
    def test_register_invalid_role(self, client, invalid_role):
        """Test registration with invalid role"""
        user_data = UserFactory.create_student_data()
        user_data["role"] = invalid_role

        response = client.post("/api/auth/register", json=user_data)

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    def test_register_missing_required_fields(self, client):
        """Test registration with missing required fields"""
        response = client.post("/api/auth/register", json={})

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestUserLogin:
    """Test user login endpoint"""

    def test_login_student_success(self, client, student_user, student_user_data):
        """Test successful student login"""
        credentials = {
            "email": student_user_data["email"],
            "password": student_user_data["password"],
        }

        response = client.post("/api/auth/login", json=credentials)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"
        assert data["user"]["email"] == credentials["email"]
        assert data["user"]["role"] == "student"

    def test_login_hr_success(self, client, hr_user, hr_user_data):
        """Test successful HR login"""
        credentials = {
            "email": hr_user_data["email"],
            "password": hr_user_data["password"],
        }

        response = client.post("/api/auth/login", json=credentials)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["user"]["role"] == "hr"

    def test_login_wrong_password(self, client, student_user):
        """Test login with incorrect password"""
        credentials = {"email": student_user.email, "password": "WrongPassword123!"}

        response = client.post("/api/auth/login", json=credentials)

        assert response.status_code == status.HTTP_401_UNAUTHORIZED
        assert "incorrect" in response.json()["detail"].lower()

    def test_login_nonexistent_user(self, client):
        """Test login with non-existent user"""
        credentials = {"email": "nonexistent@example.com", "password": "Password123!"}

        response = client.post("/api/auth/login", json=credentials)

        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_login_inactive_user(self, client, db_session, student_user_data):
        """Test login with inactive user account"""
        from app.models.user import User, UserRole
        from app.utils.security import get_password_hash

        # Create inactive user
        inactive_user = User(
            email="inactive@test.com",
            password_hash=get_password_hash(student_user_data["password"]),
            role=UserRole.STUDENT,
            is_active=False,
        )
        db_session.add(inactive_user)
        db_session.commit()

        credentials = {
            "email": "inactive@test.com",
            "password": student_user_data["password"],
        }

        response = client.post("/api/auth/login", json=credentials)

        assert response.status_code == status.HTTP_401_UNAUTHORIZED


class TestRefreshToken:
    """Test token refresh endpoint"""

    def test_refresh_token_not_implemented(self, client, student_auth_headers):
        """Test that refresh token returns not implemented"""
        response = client.post("/api/auth/refresh-token", headers=student_auth_headers)

        assert response.status_code == status.HTTP_501_NOT_IMPLEMENTED
