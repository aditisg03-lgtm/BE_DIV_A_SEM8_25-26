"""
Student Profile Tests
Tests for student profile, education, experience, and skills management
"""

import pytest
from fastapi import status
from tests.factories import (
    StudentProfileFactory,
    EducationFactory,
    WorkExperienceFactory,
    SkillFactory,
)


class TestStudentProfile:
    """Test student profile CRUD operations"""

    def test_create_profile_success(self, client, student_auth_headers):
        """Test creating student profile"""
        profile_data = StudentProfileFactory.create_data()

        response = client.post(
            "/api/student/profile", json=profile_data, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["first_name"] == profile_data["first_name"]
        assert data["last_name"] == profile_data["last_name"]
        assert "id" in data

    def test_create_profile_duplicate(
        self, client, student_profile, student_auth_headers
    ):
        """Test creating profile when one already exists"""
        profile_data = StudentProfileFactory.create_data()

        response = client.post(
            "/api/student/profile", json=profile_data, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_get_profile_success(self, client, student_profile, student_auth_headers):
        """Test getting student profile"""
        response = client.get("/api/student/profile", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == student_profile.id
        assert data["first_name"] == student_profile.first_name

    def test_get_profile_not_found(self, client, student_auth_headers):
        """Test getting profile when none exists"""
        response = client.get("/api/student/profile", headers=student_auth_headers)

        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_update_profile_success(
        self, client, student_profile, student_auth_headers
    ):
        """Test updating student profile"""
        update_data = {
            "first_name": "Updated",
            "bio": "Updated bio",
            "expected_salary": 120000,
        }

        response = client.put(
            "/api/student/profile", json=update_data, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["first_name"] == "Updated"
        assert data["bio"] == "Updated bio"
        assert data["expected_salary"] == 120000

    def test_hr_cannot_access_student_profile(self, client, hr_auth_headers):
        """Test HR user cannot access student profile endpoints"""
        response = client.get("/api/student/profile", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_403_FORBIDDEN


class TestEducation:
    """Test education CRUD operations"""

    def test_create_education_success(
        self, client, student_profile, student_auth_headers
    ):
        """Test creating education record"""
        education_data = EducationFactory.create_data()

        response = client.post(
            "/api/student/education", json=education_data, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["institution"] == education_data["institution"]
        assert data["degree"] == education_data["degree"]

    def test_get_all_education(
        self, client, education_record, student_profile, student_auth_headers
    ):
        """Test getting all education records"""
        response = client.get("/api/student/education", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        assert data[0]["id"] == education_record.id

    def test_update_education_success(
        self, client, education_record, student_auth_headers
    ):
        """Test updating education record"""
        update_data = {"grade": "4.0 GPA", "description": "Updated description"}

        response = client.put(
            f"/api/student/education/{education_record.id}",
            json=update_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["grade"] == "4.0 GPA"

    def test_delete_education_success(
        self, client, education_record, student_auth_headers
    ):
        """Test deleting education record"""
        response = client.delete(
            f"/api/student/education/{education_record.id}",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify deleted
        get_response = client.get(
            "/api/student/education", headers=student_auth_headers
        )
        assert education_record.id not in [e["id"] for e in get_response.json()]


class TestWorkExperience:
    """Test work experience CRUD operations"""

    def test_create_experience_success(
        self, client, student_profile, student_auth_headers
    ):
        """Test creating work experience"""
        experience_data = WorkExperienceFactory.create_data()

        response = client.post(
            "/api/student/experience",
            json=experience_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["company"] == experience_data["company"]
        assert data["position"] == experience_data["position"]

    def test_get_all_experience(self, client, work_experience, student_auth_headers):
        """Test getting all work experience records"""
        response = client.get("/api/student/experience", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    def test_update_experience_success(
        self, client, work_experience, student_auth_headers
    ):
        """Test updating work experience"""
        update_data = {
            "position": "Senior Software Engineer",
            "is_current": False,
            "end_date": "2023-12-31",
        }

        response = client.put(
            f"/api/student/experience/{work_experience.id}",
            json=update_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["position"] == "Senior Software Engineer"

    def test_delete_experience_success(
        self, client, work_experience, student_auth_headers
    ):
        """Test deleting work experience"""
        response = client.delete(
            f"/api/student/experience/{work_experience.id}",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK


class TestSkills:
    """Test skills CRUD operations"""

    def test_create_skill_success(self, client, student_profile, student_auth_headers):
        """Test creating skill"""
        skill_data = SkillFactory.create_data()

        response = client.post(
            "/api/student/skills", json=skill_data, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["skill_name"] == skill_data["skill_name"]

    def test_get_all_skills(self, client, skill_record, student_auth_headers):
        """Test getting all skills"""
        response = client.get("/api/student/skills", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    @pytest.mark.parametrize("proficiency_level", [1, 2, 3, 4, 5])
    def test_create_skill_various_proficiency(
        self, client, student_profile, student_auth_headers, proficiency_level
    ):
        """Test creating skills with different proficiency levels"""
        skill_data = SkillFactory.create_data(
            skill_name=f"Skill{proficiency_level}", proficiency_level=proficiency_level
        )

        response = client.post(
            "/api/student/skills", json=skill_data, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.json()["proficiency_level"] == proficiency_level
