"""
HR Profile Tests
Tests for HR profile CRUD operations
"""

import pytest
from fastapi import status
from tests.factories import HRProfileFactory


class TestHRProfile:
    """Test HR profile CRUD operations"""

    def test_create_profile_success(self, client, hr_auth_headers):
        """Test creating HR profile"""
        profile_data = HRProfileFactory.create_data()

        response = client.post(
            "/api/hr/profile", json=profile_data, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["first_name"] == profile_data["first_name"]
        assert data["company_name"] == profile_data["company_name"]
        assert "id" in data

    def test_create_profile_duplicate(self, client, hr_profile, hr_auth_headers):
        """Test creating profile when one already exists"""
        profile_data = HRProfileFactory.create_data()

        response = client.post(
            "/api/hr/profile", json=profile_data, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "already exists" in response.json()["detail"].lower()

    def test_get_profile_success(self, client, hr_profile, hr_auth_headers):
        """Test getting HR profile"""
        response = client.get("/api/hr/profile", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == hr_profile.id
        assert data["company_name"] == hr_profile.company_name

    def test_get_profile_not_found(self, client, hr_auth_headers):
        """Test getting profile when none exists"""
        response = client.get("/api/hr/profile", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_update_profile_success(self, client, hr_profile, hr_auth_headers):
        """Test updating HR profile"""
        update_data = {
            "company_name": "Updated Corp",
            "position": "Head of Talent Acquisition",
            "company_size": "500-1000",
        }

        response = client.put(
            "/api/hr/profile", json=update_data, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["company_name"] == "Updated Corp"
        assert data["position"] == "Head of Talent Acquisition"

    def test_student_cannot_access_hr_profile(self, client, student_auth_headers):
        """Test student user cannot access HR profile endpoints"""
        response = client.get("/api/hr/profile", headers=student_auth_headers)

        assert response.status_code == status.HTTP_403_FORBIDDEN


class TestHRProfileValidation:
    """Test HR profile validation"""

    def test_create_profile_missing_required_fields(self, client, hr_auth_headers):
        """Test creating profile with missing required fields"""
        incomplete_data = {
            "first_name": "Jane"
            # Missing last_name, company_name, position
        }

        response = client.post(
            "/api/hr/profile", json=incomplete_data, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    @pytest.mark.parametrize(
        "company_size", ["1-10", "11-50", "51-200", "201-500", "501-1000", "1000+"]
    )
    def test_valid_company_sizes(self, client, hr_auth_headers, company_size):
        """Test various valid company sizes"""
        profile_data = HRProfileFactory.create_data(company_size=company_size)

        response = client.post(
            "/api/hr/profile", json=profile_data, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.json()["company_size"] == company_size
