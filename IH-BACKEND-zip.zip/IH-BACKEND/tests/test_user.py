"""
User Management Tests
Tests for user profile and password management
"""

import pytest
from fastapi import status


class TestGetCurrentUserProfile:
    """Test get current user profile endpoint"""

    def test_get_profile_student(self, client, student_user, student_auth_headers):
        """Test getting student user profile"""
        response = client.get("/api/users/me", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["email"] == student_user.email
        assert data["role"] == "student"
        assert data["id"] == student_user.id

    def test_get_profile_hr(self, client, hr_user, hr_auth_headers):
        """Test getting HR user profile"""
        response = client.get("/api/users/me", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["email"] == hr_user.email
        assert data["role"] == "hr"

    def test_get_profile_without_auth(self, client):
        """Test getting profile without authentication fails"""
        response = client.get("/api/users/me")

        assert response.status_code == status.HTTP_403_FORBIDDEN

    def test_get_profile_invalid_token(self, client):
        """Test getting profile with invalid token"""
        headers = {"Authorization": "Bearer invalid_token"}
        response = client.get("/api/users/me", headers=headers)

        assert response.status_code == status.HTTP_401_UNAUTHORIZED


class TestChangePassword:
    """Test password change endpoint"""

    def test_change_password_success(
        self, client, student_user, student_auth_headers, student_user_data
    ):
        """Test successful password change"""
        password_data = {
            "current_password": student_user_data["password"],
            "new_password": "NewSecurePass456!",
        }

        response = client.put(
            "/api/users/change-password",
            json=password_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify can login with new password
        login_response = client.post(
            "/api/auth/login",
            json={
                "email": student_user.email,
                "password": password_data["new_password"],
            },
        )
        assert login_response.status_code == status.HTTP_200_OK

    def test_change_password_wrong_current(self, client, student_auth_headers):
        """Test password change with incorrect current password"""
        password_data = {
            "current_password": "WrongPassword123!",
            "new_password": "NewSecurePass456!",
        }

        response = client.put(
            "/api/users/change-password",
            json=password_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_change_password_without_auth(self, client):
        """Test password change without authentication"""
        password_data = {
            "current_password": "OldPass123!",
            "new_password": "NewPass456!",
        }

        response = client.put("/api/users/change-password", json=password_data)

        assert response.status_code == status.HTTP_403_FORBIDDEN
