"""
Pytest Configuration and Fixtures
Provides test database, client, authentication tokens, and common fixtures
"""

import sys
import os
from pathlib import Path

# Add parent directory to Python path
ROOT_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT_DIR))

import pytest
import tempfile
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from fastapi.testclient import TestClient
from typing import Generator, Dict
from datetime import datetime, timedelta

from app.main import app
from app.database import Base, get_db
from app.models.user import User, UserRole
from app.models.student import StudentProfile, Education, WorkExperience, Skill
from app.models.hr import HRProfile
from app.models.job import JobDescription, JobStatus, EmploymentType, ExperienceLevel
from app.models.resume import Resume, ResumeAnalysis
from app.models.application import Application, ApplicationStatus
from app.utils.security import get_password_hash, create_access_token
from app.config import settings


# Test Database Setup
@pytest.fixture(scope="session")
def test_db_file():
    """Create temporary database file for testing"""
    db_fd, db_path = tempfile.mkstemp(suffix=".db")
    yield db_path
    os.close(db_fd)
    try:
        os.unlink(db_path)
    except PermissionError:
        pass  # File will be cleaned up eventually


@pytest.fixture(scope="session")
def test_engine(test_db_file):
    """Create test database engine"""
    engine = create_engine(
        f"sqlite:///{test_db_file}", connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(bind=engine)
    yield engine
    Base.metadata.drop_all(bind=engine)
    engine.dispose()


@pytest.fixture(scope="function")
def db_session(test_engine) -> Generator[Session, None, None]:
    """Create a fresh database session for each test"""
    TestingSessionLocal = sessionmaker(
        autocommit=False, autoflush=False, bind=test_engine
    )
    session = TestingSessionLocal()

    yield session

    # Rollback and cleanup after test
    session.rollback()

    # Clean all tables
    for table in reversed(Base.metadata.sorted_tables):
        session.execute(table.delete())
    session.commit()
    session.close()


@pytest.fixture(scope="function")
def client(db_session) -> Generator[TestClient, None, None]:
    """Create test client with overridden database dependency"""

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()


# User Fixtures
@pytest.fixture
def student_user_data() -> Dict:
    """Student user registration data"""
    return {
        "email": "student@test.com",
        "password": "SecurePass123!",
        "role": "student",
    }


@pytest.fixture
def hr_user_data() -> Dict:
    """HR user registration data"""
    return {"email": "hr@company.com", "password": "SecurePass123!", "role": "hr"}


@pytest.fixture
def student_user(db_session, student_user_data) -> User:
    """Create a student user in database"""
    user = User(
        email=student_user_data["email"],
        password_hash=get_password_hash(student_user_data["password"]),  # FIXED
        role=UserRole.STUDENT,
        is_active=True,
        is_verified=True,
    )
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user


@pytest.fixture
def hr_user(db_session, hr_user_data) -> User:
    """Create an HR user in database"""
    user = User(
        email=hr_user_data["email"],
        password_hash=get_password_hash(hr_user_data["password"]),  # FIXED
        role=UserRole.HR,
        is_active=True,
        is_verified=True,
    )
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user


@pytest.fixture
def student_token(student_user) -> str:
    """Generate JWT token for student user"""
    return create_access_token({"sub": student_user.id})


@pytest.fixture
def hr_token(hr_user) -> str:
    """Generate JWT token for HR user"""
    return create_access_token({"sub": hr_user.id})


@pytest.fixture
def student_auth_headers(student_token) -> Dict[str, str]:
    """Authorization headers for student"""
    return {"Authorization": f"Bearer {student_token}"}


@pytest.fixture
def hr_auth_headers(hr_token) -> Dict[str, str]:
    """Authorization headers for HR"""
    return {"Authorization": f"Bearer {hr_token}"}


# Profile Fixtures
@pytest.fixture
def student_profile(db_session, student_user) -> StudentProfile:
    """Create student profile"""
    profile = StudentProfile(
        user_id=student_user.id,
        first_name="John",
        last_name="Doe",
        phone="+1234567890",
        location="New York, NY",
        linkedin_url="https://linkedin.com/in/johndoe",
        github_url="https://github.com/johndoe",
        bio="Passionate software developer",
        preferred_job_types=["full-time", "remote"],
        expected_salary=100000,
        availability="Immediately",
    )
    db_session.add(profile)
    db_session.commit()
    db_session.refresh(profile)
    return profile


@pytest.fixture
def hr_profile(db_session, hr_user) -> HRProfile:
    """Create HR profile"""
    profile = HRProfile(
        user_id=hr_user.id,
        first_name="Jane",
        last_name="Smith",
        company_name="Tech Corp",
        company_website="https://techcorp.com",
        company_size="100-500",
        industry="Technology",
        position="Senior Recruiter",
        department="Human Resources",
        phone="+1987654321",
        linkedin_url="https://linkedin.com/in/janesmith",
    )
    db_session.add(profile)
    db_session.commit()
    db_session.refresh(profile)
    return profile


# Education Fixture
@pytest.fixture
def education_record(db_session, student_profile) -> Education:
    """Create education record"""
    education = Education(
        student_profile_id=student_profile.id,
        institution="MIT",
        degree="Bachelor of Science",
        field_of_study="Computer Science",
        start_date=datetime(2018, 9, 1).date(),
        end_date=datetime(2022, 5, 30).date(),
        grade="3.8 GPA",
        description="Focused on AI and Machine Learning",
        is_current=False,
    )
    db_session.add(education)
    db_session.commit()
    db_session.refresh(education)
    return education


# Work Experience Fixture
@pytest.fixture
def work_experience(db_session, student_profile) -> WorkExperience:
    """Create work experience record"""
    experience = WorkExperience(
        student_profile_id=student_profile.id,
        company="Tech Startup",
        position="Software Engineer",
        location="San Francisco, CA",
        start_date=datetime(2022, 6, 1).date(),
        end_date=None,
        is_current=True,
        description="Developing scalable web applications",
        technologies_used=["Python", "React", "PostgreSQL"],
    )
    db_session.add(experience)
    db_session.commit()
    db_session.refresh(experience)
    return experience


# Skill Fixture
@pytest.fixture
def skill_record(db_session, student_profile) -> Skill:
    """Create skill record"""
    skill = Skill(
        student_profile_id=student_profile.id,
        skill_name="Python",
        skill_category="Programming Language",
        proficiency_level=4,
        years_of_experience=3.0,
    )
    db_session.add(skill)
    db_session.commit()
    db_session.refresh(skill)
    return skill


# Job Fixtures
@pytest.fixture
def job_description(db_session, hr_profile) -> JobDescription:
    """Create job description"""
    job = JobDescription(
        hr_profile_id=hr_profile.id,
        title="Senior Python Developer",
        department="Engineering",
        location="Remote",
        employment_type=EmploymentType.FULL_TIME,
        experience_level=ExperienceLevel.SENIOR,
        salary_min=120000,
        salary_max=160000,
        description="Looking for an experienced Python developer...",
        requirements=[
            "5+ years Python experience",
            "Experience with FastAPI/Django",
            "Strong SQL skills",
        ],
        responsibilities=[
            "Design and develop backend services",
            "Mentor junior developers",
            "Code reviews",
        ],
        preferred_qualifications=["AWS experience", "Docker/Kubernetes"],
        benefits=["Health insurance", "401k matching", "Remote work"],
        required_skills=[
            {"name": "Python", "level": "Expert"},
            {"name": "FastAPI", "level": "Advanced"},
            {"name": "PostgreSQL", "level": "Intermediate"},
        ],
        status=JobStatus.ACTIVE,
        posted_date=datetime.utcnow(),
    )
    db_session.add(job)
    db_session.commit()
    db_session.refresh(job)
    return job


# Resume Fixtures
@pytest.fixture
def sample_resume_file():
    """Create a sample PDF file in memory"""
    from io import BytesIO
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import letter

    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=letter)

    # Add content
    pdf.setFont("Helvetica", 12)
    pdf.drawString(100, 750, "John Doe")
    pdf.drawString(100, 730, "Email: john@example.com")
    pdf.drawString(100, 710, "Phone: +1234567890")
    pdf.drawString(100, 680, "EXPERIENCE:")
    pdf.drawString(100, 660, "Software Engineer at Tech Corp (2020-2023)")
    pdf.drawString(100, 640, "- Developed Python applications")
    pdf.drawString(100, 620, "- Worked with FastAPI and PostgreSQL")
    pdf.drawString(100, 590, "EDUCATION:")
    pdf.drawString(100, 570, "BS Computer Science, MIT (2016-2020)")
    pdf.drawString(100, 540, "SKILLS:")
    pdf.drawString(100, 520, "Python, FastAPI, PostgreSQL, React, AWS")

    pdf.save()
    buffer.seek(0)
    return buffer


@pytest.fixture
def resume_record(db_session, student_profile, tmp_path) -> Resume:
    """Create resume record"""
    resume_path = tmp_path / "test_resume.pdf"
    resume_path.write_bytes(b"PDF content")

    resume = Resume(
        student_profile_id=student_profile.id,
        file_name="resume.pdf",
        file_path=str(resume_path),
        file_size=1024,
        extracted_text="Sample resume text with Python, FastAPI, PostgreSQL",
        ats_score=75.5,
    )
    db_session.add(resume)
    db_session.commit()
    db_session.refresh(resume)
    return resume


# Application Fixture
@pytest.fixture
def application_record(
    db_session, student_profile, job_description, resume_record
) -> Application:
    """Create application record"""
    application = Application(
        job_description_id=job_description.id,
        student_profile_id=student_profile.id,
        resume_id=resume_record.id,
        status=ApplicationStatus.SUBMITTED,
        ats_score=75.5,
    )
    db_session.add(application)
    db_session.commit()
    db_session.refresh(application)
    return application


# Mock External Services
@pytest.fixture
def mock_gemini_service(monkeypatch):
    """Mock Gemini AI service"""

    async def mock_analyze_resume(resume_text, job_description=None):
        return {
            "ats_score": 78.5,
            "keyword_match_percentage": 72.0,
            "candidate_name": "John Doe",
            "contact_email": "john@example.com",
            "contact_phone": "+1234567890",
            "location": "New York, NY",
            "total_years_experience": 3,
            "skills_match": {
                "matched_skills": ["Python", "FastAPI", "PostgreSQL"],
                "missing_skills": ["AWS", "Docker"],
                "match_percentage": 75.0,
            },
            "experience_match": {
                "meets_requirement": True,
                "years_found": 3,
                "years_required": 2,
                "score": 85.0,
            },
            "education_match": {
                "meets_requirement": True,
                "degree_found": "Bachelor of Science",
                "score": 90.0,
            },
            "strengths": [
                "Strong Python experience",
                "Relevant tech stack",
                "Good educational background",
            ],
            "weaknesses": [
                "Limited cloud experience",
                "No container orchestration experience",
            ],
            "improvement_suggestions": [
                "Add AWS certifications",
                "Learn Docker/Kubernetes",
                "Highlight project achievements",
            ],
            "key_achievements": ["Built scalable APIs", "Improved performance by 40%"],
            "overall_feedback": "Strong candidate with relevant experience.",
            "recommendation": "RECOMMENDED",
        }

    from app.services import gemini_service

    monkeypatch.setattr(gemini_service, "analyze_resume", mock_analyze_resume)
    return mock_analyze_resume


@pytest.fixture
def mock_ats_service(monkeypatch):
    """Mock ATS service"""

    def mock_calculate_ats_score(text):
        return 75.0

    from app.services import ats_service

    monkeypatch.setattr(ats_service, "calculate_ats_score", mock_calculate_ats_score)
    return mock_calculate_ats_score


@pytest.fixture
def mock_pdf_service(monkeypatch):
    """Mock PDF service for resume generation"""
    from io import BytesIO

    class MockPDFGenerator:
        def generate_resume(self, resume_data, output_path=None):
            # Create empty file
            if output_path:
                with open(output_path, "wb") as f:
                    f.write(b"Mock PDF content")
            return BytesIO(b"Mock PDF content")

    def create_mock_generator():
        return MockPDFGenerator()

    from app.services import pdf_service

    monkeypatch.setattr(pdf_service, "create_pdf_generator", create_mock_generator)
    return create_mock_generator


@pytest.fixture
def bulk_upload_batch(db_session, hr_profile, job_description):
    """Create bulk upload batch for testing"""
    from app.models.bulk_upload import BulkUploadBatch

    batch = BulkUploadBatch(
        hr_profile_id=hr_profile.id,
        job_description_id=job_description.id,
        total_uploaded=5,
        successful_count=4,
        failed_count=1,
        average_ats_score=78.5,
        highest_score=92.0,
        lowest_score=65.0,
    )
    db_session.add(batch)
    db_session.commit()
    db_session.refresh(batch)
    return batch


# Cleanup
@pytest.fixture(autouse=True)
def cleanup_uploads(tmp_path):
    """Clean up uploaded files after tests"""
    yield
    # Cleanup logic if needed
