"""
Test Data Factories
Provides factory functions for creating test data
"""

from datetime import datetime, timedelta
from typing import Dict, Any
from app.models.user import UserRole


class UserFactory:
    """Factory for creating user test data"""

    @staticmethod
    def create_student_data(email: str = "student@test.com") -> Dict[str, Any]:
        return {"email": email, "password": "SecurePass123!", "role": "student"}

    @staticmethod
    def create_hr_data(email: str = "hr@test.com") -> Dict[str, Any]:
        return {"email": email, "password": "SecurePass123!", "role": "hr"}


class StudentProfileFactory:
    """Factory for creating student profile data"""

    @staticmethod
    def create_data(**kwargs) -> Dict[str, Any]:
        default = {
            "first_name": "John",
            "last_name": "Doe",
            "phone": "+1234567890",
            "date_of_birth": "1998-05-15",
            "location": "New York, NY",
            "linkedin_url": "https://linkedin.com/in/johndoe",
            "github_url": "https://github.com/johndoe",
            "portfolio_url": "https://johndoe.com",
            "bio": "Passionate software developer",
            "preferred_job_types": ["full-time", "remote"],
            "expected_salary": 100000,
            "availability": "Immediately",
        }
        default.update(kwargs)
        return default


class HRProfileFactory:
    """Factory for creating HR profile data"""

    @staticmethod
    def create_data(**kwargs) -> Dict[str, Any]:
        default = {
            "first_name": "Jane",
            "last_name": "Smith",
            "company_name": "Tech Corp",
            "company_website": "https://techcorp.com",
            "company_size": "100-500",
            "industry": "Technology",
            "position": "Senior Recruiter",
            "department": "Human Resources",
            "phone": "+1987654321",
            "linkedin_url": "https://linkedin.com/in/janesmith",
        }
        default.update(kwargs)
        return default


class EducationFactory:
    """Factory for creating education data"""

    @staticmethod
    def create_data(**kwargs) -> Dict[str, Any]:
        default = {
            "institution": "MIT",
            "degree": "Bachelor of Science",
            "field_of_study": "Computer Science",
            "start_date": "2018-09-01",
            "end_date": "2022-05-30",
            "grade": "3.8 GPA",
            "description": "Focused on AI and Machine Learning",
            "is_current": False,
        }
        default.update(kwargs)
        return default


class WorkExperienceFactory:
    """Factory for creating work experience data"""

    @staticmethod
    def create_data(**kwargs) -> Dict[str, Any]:
        default = {
            "company": "Tech Startup",
            "position": "Software Engineer",
            "location": "San Francisco, CA",
            "start_date": "2022-06-01",
            "end_date": None,
            "is_current": True,
            "description": "Developing scalable web applications using Python and React",
            "technologies_used": ["Python", "React", "PostgreSQL", "Docker"],
        }
        default.update(kwargs)
        return default


class SkillFactory:
    """Factory for creating skill data"""

    @staticmethod
    def create_data(**kwargs) -> Dict[str, Any]:
        default = {
            "skill_name": "Python",
            "skill_category": "Programming Language",
            "proficiency_level": 4,
            "years_of_experience": 3.0,
        }
        default.update(kwargs)
        return default


class JobDescriptionFactory:
    """Factory for creating job description data"""

    @staticmethod
    def create_data(**kwargs) -> Dict[str, Any]:
        default = {
            "title": "Senior Python Developer",
            "department": "Engineering",
            "location": "Remote",
            "employment_type": "full-time",
            "experience_level": "senior",
            "salary_min": 120000,
            "salary_max": 160000,
            "description": "We are looking for an experienced Python developer to join our team...",
            "requirements": [
                "5+ years of Python experience",
                "Experience with FastAPI or Django",
                "Strong understanding of SQL databases",
                "Experience with RESTful APIs",
            ],
            "responsibilities": [
                "Design and develop backend services",
                "Write clean, maintainable code",
                "Mentor junior developers",
                "Participate in code reviews",
            ],
            "preferred_qualifications": [
                "AWS experience",
                "Docker and Kubernetes knowledge",
                "Experience with microservices",
            ],
            "benefits": [
                "Comprehensive health insurance",
                "401k matching",
                "Flexible remote work",
                "Professional development budget",
            ],
            "required_skills": [
                {"name": "Python", "level": "Expert"},
                {"name": "FastAPI", "level": "Advanced"},
                {"name": "PostgreSQL", "level": "Intermediate"},
            ],
        }
        default.update(kwargs)
        return default


class ApplicationFactory:
    """Factory for creating application data"""

    @staticmethod
    def create_data(job_id: str, resume_id: str, **kwargs) -> Dict[str, Any]:
        default = {"job_description_id": job_id, "resume_id": resume_id}
        default.update(kwargs)
        return default
