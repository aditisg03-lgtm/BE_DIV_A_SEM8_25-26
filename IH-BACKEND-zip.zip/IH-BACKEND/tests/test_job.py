"""
Job Description Tests
Tests for job CRUD operations, publishing, and filtering
"""

import pytest
from fastapi import status
from tests.factories import JobDescriptionFactory


class TestJobCreation:
    """Test job creation endpoint"""

    def test_create_job_success(self, client, hr_profile, hr_auth_headers):
        """Test successful job creation"""
        job_data = JobDescriptionFactory.create_data()

        response = client.post("/api/jobs", json=job_data, headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["title"] == job_data["title"]
        assert data["status"] == "draft"
        assert "id" in data

    def test_create_job_without_profile(self, client, hr_auth_headers):
        """Test creating job without HR profile"""
        job_data = JobDescriptionFactory.create_data()

        response = client.post("/api/jobs", json=job_data, headers=hr_auth_headers)

        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert "profile" in response.json()["detail"].lower()

    def test_student_cannot_create_job(self, client, student_auth_headers):
        """Test student cannot create jobs"""
        job_data = JobDescriptionFactory.create_data()

        response = client.post("/api/jobs", json=job_data, headers=student_auth_headers)

        assert response.status_code == status.HTTP_403_FORBIDDEN

    @pytest.mark.parametrize(
        "employment_type,experience_level",
        [
            ("full-time", "entry"),
            ("part-time", "mid"),
            ("contract", "senior"),
            ("internship", "executive"),
        ],
    )
    def test_create_job_various_types(
        self, client, hr_profile, hr_auth_headers, employment_type, experience_level
    ):
        """Test creating jobs with various employment types and levels"""
        job_data = JobDescriptionFactory.create_data(
            employment_type=employment_type, experience_level=experience_level
        )

        response = client.post("/api/jobs", json=job_data, headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["employment_type"] == employment_type
        assert data["experience_level"] == experience_level


class TestJobRetrieval:
    """Test job retrieval endpoints"""

    def test_get_all_jobs_as_hr(self, client, job_description, hr_auth_headers):
        """Test HR getting all their jobs"""
        response = client.get("/api/jobs", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    def test_get_all_jobs_as_student(
        self, client, job_description, student_auth_headers
    ):
        """Test student seeing only active jobs"""
        response = client.get("/api/jobs", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        # All jobs should be active for students
        for job in data:
            assert job["status"] == "active"

    def test_get_jobs_with_pagination(
        self, client, hr_profile, hr_auth_headers, db_session
    ):
        """Test job listing with pagination"""
        from app.models.job import (
            JobDescription,
            JobStatus,
            EmploymentType,
            ExperienceLevel,
        )

        # Create multiple jobs
        for i in range(15):
            job = JobDescription(
                hr_profile_id=hr_profile.id,
                title=f"Job {i}",
                location="Remote",
                employment_type=EmploymentType.FULL_TIME,
                experience_level=ExperienceLevel.MID,
                description=f"Description {i}",
                status=JobStatus.ACTIVE,
            )
            db_session.add(job)
        db_session.commit()

        # Get first page
        response = client.get("/api/jobs?skip=0&limit=10", headers=hr_auth_headers)
        assert response.status_code == status.HTTP_200_OK
        assert len(response.json()) == 10

        # Get second page
        response = client.get("/api/jobs?skip=10&limit=10", headers=hr_auth_headers)
        assert len(response.json()) >= 5

    def test_get_jobs_by_status(self, client, hr_profile, hr_auth_headers, db_session):
        """Test filtering jobs by status"""
        from app.models.job import (
            JobDescription,
            JobStatus,
            EmploymentType,
            ExperienceLevel,
        )

        # Create jobs with different statuses
        statuses = [JobStatus.DRAFT, JobStatus.ACTIVE, JobStatus.CLOSED]
        for status in statuses:
            job = JobDescription(
                hr_profile_id=hr_profile.id,
                title=f"Job {status.value}",
                location="Remote",
                employment_type=EmploymentType.FULL_TIME,
                experience_level=ExperienceLevel.MID,
                description="Description",
                status=status,
            )
            db_session.add(job)
        db_session.commit()

        # Filter by active status
        response = client.get("/api/jobs?status_filter=active", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        for job in data:
            assert job["status"] == "active"

    def test_get_specific_job(self, client, job_description, hr_auth_headers):
        """Test getting a specific job"""
        response = client.get(
            f"/api/jobs/{job_description.id}", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == job_description.id
        assert data["title"] == job_description.title


class TestJobUpdate:
    """Test job update operations"""

    def test_update_job_success(self, client, job_description, hr_auth_headers):
        """Test successful job update"""
        update_data = {
            "title": "Updated Job Title",
            "salary_min": 140000,
            "salary_max": 180000,
        }

        response = client.put(
            f"/api/jobs/{job_description.id}", json=update_data, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["title"] == "Updated Job Title"
        assert data["salary_min"] == 140000

    def test_update_nonexistent_job(self, client, hr_auth_headers):
        """Test updating non-existent job"""
        update_data = {"title": "New Title"}

        response = client.put(
            "/api/jobs/fake-id", json=update_data, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_hr_cannot_update_other_hr_job(
        self, client, job_description, db_session, hr_user_data
    ):
        """Test HR cannot update another HR's job"""
        from app.models.user import User, UserRole
        from app.models.hr import HRProfile
        from app.utils.security import get_password_hash, create_access_token

        # Create another HR user
        other_hr = User(
            email="other_hr@test.com",
            password_hash=get_password_hash("password"),
            role=UserRole.HR,
        )
        db_session.add(other_hr)
        db_session.commit()

        other_hr_profile = HRProfile(
            user_id=other_hr.id,
            first_name="Other",
            last_name="HR",
            company_name="Other Company",
            position="Recruiter",
        )
        db_session.add(other_hr_profile)
        db_session.commit()

        # Get token for other HR
        token = create_access_token({"sub": other_hr.id})
        headers = {"Authorization": f"Bearer {token}"}

        # Try to update original HR's job
        response = client.put(
            f"/api/jobs/{job_description.id}",
            json={"title": "Hacked Title"},
            headers=headers,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestJobPublishAndClose:
    """Test job publishing and closing"""

    def test_publish_job_success(self, client, db_session, hr_profile, hr_auth_headers):
        """Test publishing a draft job"""
        from app.models.job import (
            JobDescription,
            JobStatus,
            EmploymentType,
            ExperienceLevel,
        )

        draft_job = JobDescription(
            hr_profile_id=hr_profile.id,
            title="Draft Job",
            location="Remote",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.MID,
            description="Description",
            status=JobStatus.DRAFT,
        )
        db_session.add(draft_job)
        db_session.commit()

        response = client.post(
            f"/api/jobs/{draft_job.id}/publish", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify status changed
        db_session.refresh(draft_job)
        assert draft_job.status == JobStatus.ACTIVE
        assert draft_job.posted_date is not None

    def test_close_job_success(
        self, client, job_description, hr_auth_headers, db_session
    ):
        """Test closing an active job"""
        response = client.post(
            f"/api/jobs/{job_description.id}/close", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify status changed
        db_session.refresh(job_description)
        assert job_description.status.value == "closed"


class TestJobDelete:
    """Test job deletion"""

    def test_delete_job_success(self, client, job_description, hr_auth_headers):
        """Test successful job deletion"""
        response = client.delete(
            f"/api/jobs/{job_description.id}", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify deleted
        get_response = client.get(
            f"/api/jobs/{job_description.id}", headers=hr_auth_headers
        )
        assert get_response.status_code == status.HTTP_404_NOT_FOUND

    def test_student_cannot_delete_job(
        self, client, job_description, student_auth_headers
    ):
        """Test student cannot delete jobs"""
        response = client.delete(
            f"/api/jobs/{job_description.id}", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN
