"""
Resume Management Tests
Tests for resume upload, analysis, and job comparison
"""

import pytest
from fastapi import status
from io import BytesIO


class TestResumeUpload:
    """Test resume upload functionality"""

    def test_upload_resume_success(
        self, client, student_profile, student_auth_headers, sample_resume_file
    ):
        """Test successful resume upload"""
        files = {"file": ("resume.pdf", sample_resume_file, "application/pdf")}

        response = client.post(
            "/api/resumes/upload", files=files, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "id" in data
        assert data["file_name"] == "resume.pdf"
        assert "upload_date" in data
        assert "Resume uploaded successfully" in data["message"]

    def test_upload_resume_without_profile(
        self, client, student_auth_headers, sample_resume_file
    ):
        """Test uploading resume without creating profile first"""
        files = {"file": ("resume.pdf", sample_resume_file, "application/pdf")}

        response = client.post(
            "/api/resumes/upload", files=files, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert "profile" in response.json()["detail"].lower()

    def test_upload_non_pdf_file(self, client, student_profile, student_auth_headers):
        """Test uploading non-PDF file fails"""
        fake_file = BytesIO(b"Not a PDF file")
        files = {"file": ("resume.txt", fake_file, "text/plain")}

        response = client.post(
            "/api/resumes/upload", files=files, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "pdf" in response.json()["detail"].lower()

    def test_upload_oversized_file(self, client, student_profile, student_auth_headers):
        """Test uploading file exceeding size limit"""
        # Create a large fake PDF (> 5MB)
        large_file = BytesIO(b"0" * (6 * 1024 * 1024))  # 6MB
        files = {"file": ("large_resume.pdf", large_file, "application/pdf")}

        response = client.post(
            "/api/resumes/upload", files=files, headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "size" in response.json()["detail"].lower()


class TestResumeRetrieval:
    """Test resume retrieval endpoints"""

    def test_get_all_resumes(self, client, resume_record, student_auth_headers):
        """Test getting all resumes for current user"""
        response = client.get("/api/resumes", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        assert data[0]["id"] == resume_record.id

    def test_get_all_resumes_empty(self, client, student_profile, student_auth_headers):
        """Test getting resumes when none exist"""
        response = client.get("/api/resumes", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        assert response.json() == []

    def test_get_specific_resume(self, client, resume_record, student_auth_headers):
        """Test getting a specific resume"""
        response = client.get(
            f"/api/resumes/{resume_record.id}", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == resume_record.id
        assert data["file_name"] == resume_record.file_name

    def test_get_nonexistent_resume(
        self, client, student_profile, student_auth_headers
    ):
        """Test getting resume that doesn't exist"""
        response = client.get(
            "/api/resumes/nonexistent-id", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestResumeAnalysis:
    """Test AI-powered resume analysis"""

    def test_analyze_resume_success(
        self, client, resume_record, student_auth_headers, mock_gemini_service
    ):
        """Test successful resume analysis"""
        response = client.post(
            f"/api/resumes/{resume_record.id}/analyze", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "ats_score" in data
        assert "strengths" in data
        assert "weaknesses" in data
        assert "improvement_suggestions" in data
        assert data["ats_score"] > 0

    def test_analyze_resume_without_text(
        self, client, db_session, student_profile, student_auth_headers
    ):
        """Test analyzing resume without extracted text"""
        from app.models.resume import Resume

        resume = Resume(
            student_profile_id=student_profile.id,
            file_name="empty.pdf",
            file_path="/tmp/empty.pdf",
            file_size=100,
            extracted_text=None,  # No text extracted
        )
        db_session.add(resume)
        db_session.commit()

        response = client.post(
            f"/api/resumes/{resume.id}/analyze", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_get_resume_analyses(
        self, client, resume_record, student_auth_headers, mock_gemini_service
    ):
        """Test getting all analyses for a resume"""
        # First create an analysis
        client.post(
            f"/api/resumes/{resume_record.id}/analyze", headers=student_auth_headers
        )

        # Get all analyses
        response = client.get(
            f"/api/resumes/{resume_record.id}/analysis", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1


class TestResumeJobComparison:
    """Test resume comparison with job descriptions"""

    def test_compare_resume_with_job(
        self,
        client,
        resume_record,
        job_description,
        student_auth_headers,
        mock_gemini_service,
    ):
        """Test comparing resume with specific job"""
        response = client.post(
            f"/api/resumes/{resume_record.id}/compare-with-job/{job_description.id}",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "comparison_id" in data
        assert "success_probability" in data
        assert "success_level" in data
        assert "scores" in data
        assert data["job_id"] == job_description.id

    def test_compare_nonexistent_resume(
        self, client, job_description, student_auth_headers
    ):
        """Test comparing non-existent resume"""
        response = client.post(
            f"/api/resumes/fake-id/compare-with-job/{job_description.id}",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_compare_with_nonexistent_job(
        self, client, resume_record, student_auth_headers
    ):
        """Test comparing with non-existent job"""
        response = client.post(
            f"/api/resumes/{resume_record.id}/compare-with-job/fake-job-id",
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestResumeDelete:
    """Test resume deletion"""

    def test_delete_resume_success(self, client, resume_record, student_auth_headers):
        """Test successful resume deletion"""
        response = client.delete(
            f"/api/resumes/{resume_record.id}", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify deleted
        get_response = client.get(
            f"/api/resumes/{resume_record.id}", headers=student_auth_headers
        )
        assert get_response.status_code == status.HTTP_404_NOT_FOUND

    def test_delete_nonexistent_resume(
        self, client, student_profile, student_auth_headers
    ):
        """Test deleting non-existent resume"""
        response = client.delete("/api/resumes/fake-id", headers=student_auth_headers)

        assert response.status_code == status.HTTP_404_NOT_FOUND
