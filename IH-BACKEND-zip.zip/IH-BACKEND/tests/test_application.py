"""
Application Tests
Tests for job application creation, retrieval, and status updates
"""

import pytest
from fastapi import status
from tests.factories import ApplicationFactory


class TestApplicationCreation:
    """Test job application creation"""

    def test_apply_to_job_success(
        self,
        client,
        student_profile,
        job_description,
        resume_record,
        student_auth_headers,
    ):
        """Test successful job application"""
        application_data = ApplicationFactory.create_data(
            job_id=job_description.id, resume_id=resume_record.id
        )

        response = client.post(
            "/api/applications/apply",
            json=application_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["job_description_id"] == job_description.id
        assert data["resume_id"] == resume_record.id
        assert data["status"] == "submitted"
        assert "id" in data

    def test_apply_without_profile(self, client, job_description, student_auth_headers):
        """Test applying without student profile"""
        application_data = {
            "job_description_id": job_description.id,
            "resume_id": "fake-resume-id",
        }

        response = client.post(
            "/api/applications/apply",
            json=application_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert "profile" in response.json()["detail"].lower()

    def test_apply_to_nonexistent_job(
        self, client, student_profile, resume_record, student_auth_headers
    ):
        """Test applying to non-existent job"""
        application_data = ApplicationFactory.create_data(
            job_id="fake-job-id", resume_id=resume_record.id
        )

        response = client.post(
            "/api/applications/apply",
            json=application_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert "job" in response.json()["detail"].lower()

    def test_apply_with_nonexistent_resume(
        self, client, student_profile, job_description, student_auth_headers
    ):
        """Test applying with non-existent resume"""
        application_data = ApplicationFactory.create_data(
            job_id=job_description.id, resume_id="fake-resume-id"
        )

        response = client.post(
            "/api/applications/apply",
            json=application_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert "resume" in response.json()["detail"].lower()

    def test_duplicate_application(
        self, client, application_record, student_auth_headers
    ):
        """Test applying to same job twice"""
        application_data = ApplicationFactory.create_data(
            job_id=application_record.job_description_id,
            resume_id=application_record.resume_id,
        )

        response = client.post(
            "/api/applications/apply",
            json=application_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "already applied" in response.json()["detail"].lower()

    def test_hr_cannot_apply_to_jobs(self, client, job_description, hr_auth_headers):
        """Test HR user cannot apply to jobs"""
        application_data = {
            "job_description_id": job_description.id,
            "resume_id": "some-resume-id",
        }

        response = client.post(
            "/api/applications/apply", json=application_data, headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN


class TestApplicationRetrieval:
    """Test application retrieval endpoints"""

    def test_student_get_applications(
        self, client, application_record, student_auth_headers
    ):
        """Test student getting their applications"""
        response = client.get("/api/applications", headers=student_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        assert data[0]["id"] == application_record.id

    def test_hr_get_applications(self, client, application_record, hr_auth_headers):
        """Test HR getting applications to their jobs"""
        response = client.get("/api/applications", headers=hr_auth_headers)

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)
        assert len(data) >= 1

    def test_get_specific_application_as_student(
        self, client, application_record, student_auth_headers
    ):
        """Test student getting specific application"""
        response = client.get(
            f"/api/applications/{application_record.id}", headers=student_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == application_record.id

    def test_get_specific_application_as_hr(
        self, client, application_record, hr_auth_headers
    ):
        """Test HR getting specific application to their job"""
        response = client.get(
            f"/api/applications/{application_record.id}", headers=hr_auth_headers
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == application_record.id

    def test_student_cannot_see_other_applications(
        self, client, application_record, db_session, student_user_data
    ):
        """Test student cannot see other students' applications"""
        from app.models.user import User, UserRole
        from app.utils.security import get_password_hash, create_access_token

        # Create another student
        other_student = User(
            email="other@test.com",
            password_hash=get_password_hash("password"),
            role=UserRole.STUDENT,
        )
        db_session.add(other_student)
        db_session.commit()

        token = create_access_token({"sub": other_student.id})
        headers = {"Authorization": f"Bearer {token}"}

        response = client.get(
            f"/api/applications/{application_record.id}", headers=headers
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN


class TestApplicationStatusUpdate:
    """Test application status updates by HR"""

    @pytest.mark.parametrize(
        "new_status",
        [
            "under_review",
            "shortlisted",
            "interview_scheduled",
            "offer_extended",
            "rejected",
        ],
    )
    def test_hr_update_application_status(
        self, client, application_record, hr_auth_headers, new_status
    ):
        """Test HR updating application status"""
        update_data = {"status": new_status}

        response = client.put(
            f"/api/applications/{application_record.id}/status",
            json=update_data,
            headers=hr_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["status"] == new_status

    def test_hr_add_notes(self, client, application_record, hr_auth_headers):
        """Test HR adding notes to application"""
        update_data = {"hr_notes": "Strong candidate, proceed to next round"}

        response = client.put(
            f"/api/applications/{application_record.id}/status",
            json=update_data,
            headers=hr_auth_headers,
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "Strong candidate" in data["hr_notes"]

    def test_student_cannot_update_status(
        self, client, application_record, student_auth_headers
    ):
        """Test student cannot update application status"""
        update_data = {"status": "shortlisted"}

        response = client.put(
            f"/api/applications/{application_record.id}/status",
            json=update_data,
            headers=student_auth_headers,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN

    def test_hr_cannot_update_other_hr_applications(
        self, client, application_record, db_session
    ):
        """Test HR cannot update applications for other HR's jobs"""
        from app.models.user import User, UserRole
        from app.models.hr import HRProfile
        from app.utils.security import get_password_hash, create_access_token

        # Create another HR
        other_hr = User(
            email="other_hr@test.com",
            password_hash=get_password_hash("password"),
            role=UserRole.HR,
        )
        db_session.add(other_hr)
        db_session.commit()

        other_hr_profile = HRProfile(
            user_id=other_hr.id,
            first_name="Other",
            last_name="HR",
            company_name="Other Corp",
            position="Recruiter",
        )
        db_session.add(other_hr_profile)
        db_session.commit()

        token = create_access_token({"sub": other_hr.id})
        headers = {"Authorization": f"Bearer {token}"}

        update_data = {"status": "rejected"}
        response = client.put(
            f"/api/applications/{application_record.id}/status",
            json=update_data,
            headers=headers,
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN
