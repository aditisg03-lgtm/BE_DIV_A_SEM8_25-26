from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.database import init_db
from app.routers import (
    auth,
    user,
    student,
    hr,
    resume,
    job,
    application,
    analytics,
    hr_resume,
    student_enhancements,
)
import os

app = FastAPI(
    title=settings.APP_NAME,
    description="AI-Powered Applicant Tracking System",
    version="1.0.0",
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router)
app.include_router(user.router)
app.include_router(student.router)
app.include_router(hr.router)
app.include_router(resume.router)
app.include_router(job.router)
app.include_router(application.router)
app.include_router(analytics.router)
app.include_router(hr_resume.router)
app.include_router(student_enhancements.router)


@app.on_event("startup")
def on_startup():
    """Initialize database on startup (no bootstrapping)."""
    db_url = settings.DATABASE_URL

    if "sqlite:///" in db_url:
        db_path = db_url.replace("sqlite:///", "").replace("./", "")
        print(f"\n{'=' * 80}")
        print(f"🔍 Database path: {db_path}")

        # Only create parent directories if the path includes a folder
        db_dir = os.path.dirname(db_path)
        if db_dir:  # non-empty string
            os.makedirs(db_dir, exist_ok=True)

        if not os.path.exists(db_path):
            print("🆕 Database file does not exist. It will be created on first write.")
        else:
            print("✅ Database file already exists.")

    else:
        print(f"📊 Using non-SQLite database: {db_url}")

    # Always initialize DB schema (safe to run repeatedly)
    init_db()
    print("Intialized database tables (if not already present).\n")


@app.get("/")
def root():
    return {
        "message": "Welcome to IntelizenHire API",
        "version": "1.0.0",
        "docs": "/docs",
        "bootstrap": "Database bootstrapped with sample data on first run",
    }


@app.get("/api/health")
def health_check():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
