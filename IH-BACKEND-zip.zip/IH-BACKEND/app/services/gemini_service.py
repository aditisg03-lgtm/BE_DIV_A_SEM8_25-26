import google.generativeai as genai
import json
from typing import Dict, Any, Optional, List
from app.config import settings


class GeminiService:
    def __init__(self):
        # Configure the Gemini API
        genai.configure(api_key=settings.GEMINI_API_KEY)

        # Initialize the model with proper safety settings
        self.model = genai.GenerativeModel("gemini-2.5-flash")

        # Configure generation settings
        self.generation_config = genai.types.GenerationConfig(
            temperature=0.4,
            top_p=0.8,
            top_k=40,
            max_output_tokens=16384,
        )

        # Define safety settings using proper format
        self.safety_settings = [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
        ]

    async def analyze_resume(
        self, resume_text: str, job_description: Optional[str] = None
    ) -> Dict[str, Any]:
        """Analyze resume using Gemini AI"""

        prompt = self._create_analysis_prompt(resume_text, job_description)

        try:
            print(f"📤 Sending request to Gemini API...")
            print(f"   Resume length: {len(resume_text)} characters")
            print(f"   Prompt length: {len(prompt)} characters")
            print(f"   Has job description: {bool(job_description)}")

            # Generate content using Gemini
            response = self.model.generate_content(
                prompt,
                generation_config=self.generation_config,
                safety_settings=self.safety_settings,
            )

            # Check if response was blocked
            if not response.candidates:
                print(f"⚠️ No candidates in response")
                return self._get_fallback_analysis()

            # Check finish reason
            candidate = response.candidates[0]
            print(f"   Finish reason: {candidate.finish_reason}")

            if candidate.finish_reason != 1:  # 1 = STOP (normal completion)
                finish_reasons = {
                    0: "FINISH_REASON_UNSPECIFIED",
                    1: "STOP (Success)",
                    2: "MAX_TOKENS",
                    3: "SAFETY",
                    4: "RECITATION",
                    5: "OTHER",
                }
                reason = finish_reasons.get(candidate.finish_reason, "Unknown")
                print(f"⚠️ Response incomplete: {reason}")

                # Try to get partial response
                if candidate.content and candidate.content.parts:
                    response_text = candidate.content.parts[0].text
                    print(f"   Got partial response: {len(response_text)} characters")
                else:
                    print(f"   No response text available, trying simpler prompt")
                    return await self._analyze_with_simple_prompt(
                        resume_text, job_description
                    )
            else:
                # Normal completion
                response_text = response.text

            print(f"✅ Received response from Gemini")
            print(f"   Response length: {len(response_text)} characters")

            # Parse the response
            analysis = self._parse_gemini_response(response_text)

            print(f"✅ Analysis parsed successfully")
            print(f"   ATS Score: {analysis.get('ats_score', 0)}")

            return analysis

        except ValueError as e:
            print(f"❌ ValueError: {str(e)}")
            # Try alternative approach with simpler prompt
            return await self._analyze_with_simple_prompt(resume_text, job_description)

        except Exception as e:
            print(f"❌ Gemini API Error: {str(e)}")
            print(f"   Error type: {type(e).__name__}")
            return self._get_fallback_analysis()

    async def _analyze_with_simple_prompt(
        self, resume_text: str, job_description: Optional[str]
    ) -> Dict[str, Any]:
        """Fallback analysis with simpler, shorter prompt"""
        try:
            print(f"🔄 Trying with simplified prompt...")

            # Create much simpler prompt
            simple_prompt = f"""Analyze this resume and give scores as JSON.

Resume (first 1500 chars):
{resume_text[:1500]}

Respond with this exact JSON format:
{{
  "ats_score": 75,
  "keyword_match_percentage": 70,
  "candidate_name": "Name from resume",
  "contact_email": "email@example.com",
  "strengths": ["strength1", "strength2", "strength3"],
  "weaknesses": ["weakness1", "weakness2"],
  "overall_feedback": "Brief summary",
  "recommendation": "RECOMMENDED"
}}

Only return valid JSON, nothing else."""

            response = self.model.generate_content(
                simple_prompt,
                generation_config=self.generation_config,
                safety_settings=self.safety_settings,
            )

            if response.candidates and response.candidates[0].finish_reason == 1:
                analysis = self._parse_gemini_response(response.text)
                print(f"✅ Simplified analysis successful")
                return analysis
            else:
                return self._get_fallback_analysis()

        except Exception as e:
            print(f"❌ Simplified prompt also failed: {str(e)}")
            return self._get_fallback_analysis()

    async def analyze_bulk_resumes(
        self, resumes_data: List[Dict[str, str]], job_description: str
    ) -> List[Dict[str, Any]]:
        """Analyze multiple resumes and rank them"""

        results = []

        for resume in resumes_data:
            analysis = await self.analyze_resume(resume["text"], job_description)
            results.append({"filename": resume["filename"], "analysis": analysis})

        # Rank by ATS score
        results.sort(key=lambda x: x["analysis"].get("ats_score", 0), reverse=True)

        return results

    def _create_analysis_prompt(
        self, resume_text: str, job_description: Optional[str]
    ) -> str:
        """Create optimized prompt for Gemini"""

        # Limit text lengths to avoid token limits and safety issues
        resume_sample = resume_text[:2500]  # Reduced from 3000
        job_sample = job_description[:1200] if job_description else ""

        if job_description:
            prompt = f"""Analyze this resume against the job requirements and respond with JSON only.

RESUME:
{resume_sample}

JOB:
{job_sample}

Rate the candidate and respond with this JSON structure:
{{
  "ats_score": 85,
  "keyword_match_percentage": 75,
  "candidate_name": "Full Name",
  "contact_email": "email@domain.com",
  "contact_phone": "+1234567890",
  "location": "City, State",
  "total_years_experience": 5,
  "strengths": ["specific strength 1", "specific strength 2", "specific strength 3"],
  "weaknesses": ["specific gap 1", "specific gap 2"],
  "improvement_suggestions": ["suggestion 1", "suggestion 2"],
  "overall_feedback": "2-3 sentence assessment",
  "skills_match": {{
    "matched_skills": ["skill1", "skill2"],
    "missing_skills": ["skill3", "skill4"],
    "match_percentage": 70
  }},
  "experience_match": {{
    "score": 80,
    "years_of_experience": 5,
    "relevant_experience": "Brief description",
    "feedback": "Brief assessment"
  }},
  "education_match": {{
    "score": 90,
    "degree": "Bachelor's",
    "field": "Computer Science",
    "feedback": "Brief assessment"
  }},
  "key_achievements": ["achievement 1", "achievement 2"],
  "recommendation": "HIGHLY RECOMMENDED"
}}

Return only valid JSON. No markdown, no explanation."""

        else:
            prompt = f"""Analyze this resume and respond with JSON only.

RESUME:
{resume_sample}

Evaluate the resume and respond with this JSON:
{{
  "ats_score": 75,
  "keyword_match_percentage": 70,
  "candidate_name": "Full Name",
  "contact_email": "email@domain.com",
  "contact_phone": "phone",
  "location": "location",
  "total_years_experience": 3,
  "strengths": ["strength 1", "strength 2", "strength 3"],
  "weaknesses": ["weakness 1", "weakness 2"],
  "improvement_suggestions": ["tip 1", "tip 2", "tip 3"],
  "overall_feedback": "Brief assessment",
  "skills_match": {{"matched_skills": [], "missing_skills": [], "match_percentage": 0}},
  "experience_match": {{"score": 70, "feedback": "Assessment"}},
  "education_match": {{"score": 70, "degree": "Degree", "field": "Field", "feedback": "Assessment"}},
  "key_achievements": ["achievement 1", "achievement 2"],
  "recommendation": "RECOMMENDED"
}}

Return only valid JSON."""

        return prompt

    def _parse_gemini_response(self, response_text: str) -> Dict[str, Any]:
        """Parse Gemini API response"""
        try:
            # Clean up the response text
            text = response_text.strip()

            # Remove markdown code blocks if present
            if "```json" in text:
                start = text.find("```json") + 7
                end = text.find("```", start)
                text = text[start:end].strip()
            elif "```" in text:
                start = text.find("```") + 3
                end = text.find("```", start)
                text = text[start:end].strip()

            # Find JSON object
            start = text.find("{")
            end = text.rfind("}")
            if start != -1 and end != -1:
                text = text[start : end + 1]

            # Parse JSON
            analysis = json.loads(text)

            # Validate and set defaults for required fields
            analysis.setdefault("ats_score", 70)
            analysis.setdefault("keyword_match_percentage", 65)
            analysis.setdefault("strengths", ["Resume processed successfully"])
            analysis.setdefault("weaknesses", ["No specific issues found"])
            analysis.setdefault("improvement_suggestions", ["Continue refining resume"])
            analysis.setdefault("overall_feedback", "Candidate reviewed")

            # Ensure nested objects exist
            if "skills_match" not in analysis:
                analysis["skills_match"] = {
                    "matched_skills": [],
                    "missing_skills": [],
                    "match_percentage": 0,
                }

            if "experience_match" not in analysis:
                analysis["experience_match"] = {
                    "score": 70,
                    "years_of_experience": None,
                    "relevant_experience": "Not specified",
                    "feedback": "Review manually",
                }

            if "education_match" not in analysis:
                analysis["education_match"] = {
                    "score": 70,
                    "degree": "Not specified",
                    "field": "Not specified",
                    "feedback": "Review manually",
                }

            # Set candidate info defaults
            analysis.setdefault("candidate_name", "Not extracted")
            analysis.setdefault("contact_email", "Not extracted")
            analysis.setdefault("contact_phone", "Not extracted")
            analysis.setdefault("location", "Not specified")
            analysis.setdefault("total_years_experience", None)
            analysis.setdefault("key_achievements", [])
            analysis.setdefault("recommendation", "CONSIDER")

            return analysis

        except json.JSONDecodeError as e:
            print(f"❌ JSON parsing error: {str(e)}")
            print(f"   Response (first 500 chars): {response_text[:500]}")
            return self._get_fallback_analysis()

        except Exception as e:
            print(f"❌ Unexpected parsing error: {str(e)}")
            return self._get_fallback_analysis()

    def _get_fallback_analysis(self) -> Dict[str, Any]:
        """Return fallback analysis when Gemini fails"""
        return {
            "ats_score": 70.0,
            "keyword_match_percentage": 65.0,
            "strengths": [
                "Resume successfully uploaded and processed",
                "Text extraction completed",
                "Basic formatting is readable",
            ],
            "weaknesses": [
                "AI analysis encountered technical limitations",
                "Manual review recommended for detailed assessment",
            ],
            "improvement_suggestions": [
                "Use clear section headers (Education, Experience, Skills)",
                "Include relevant keywords from job descriptions",
                "Quantify achievements with specific metrics",
                "Keep formatting simple and ATS-friendly",
            ],
            "overall_feedback": "Resume uploaded successfully. AI analysis encountered technical limitations. The document is readable and basic processing completed. Manual review recommended for comprehensive evaluation.",
            "skills_match": {
                "matched_skills": [],
                "missing_skills": [],
                "match_percentage": 0,
            },
            "experience_match": {
                "score": 70.0,
                "years_of_experience": None,
                "relevant_experience": "Pending detailed analysis",
                "feedback": "Manual review recommended",
            },
            "education_match": {
                "score": 70.0,
                "degree": "Not analyzed",
                "field": "Not analyzed",
                "feedback": "Manual review recommended",
            },
            "candidate_name": "Not extracted",
            "contact_email": "Not extracted",
            "contact_phone": "Not extracted",
            "location": "Not specified",
            "total_years_experience": None,
            "key_achievements": [],
            "recommendation": "MANUAL REVIEW REQUIRED",
        }

    async def improve_resume_structured(self, resume_text: str) -> Dict[str, Any]:
        """
        Generate improved, structured resume data for PDF generation

        Returns properly formatted JSON with all resume sections
        """

        prompt = f"""You are an expert resume writer and ATS optimization specialist. 

    Analyze this resume and create an IMPROVED, ATS-OPTIMIZED version with proper structure.

    ORIGINAL RESUME:
    {resume_text[:4000]}

    Create a professional, ATS-friendly resume with these improvements:
    1. Strong action verbs (Led, Developed, Implemented, Achieved)
    2. Quantified achievements with metrics and numbers
    3. Clear section organization
    4. Keyword optimization for ATS systems
    5. Professional tone and formatting
    6. Remove fluff, focus on impact

    Respond with ONLY valid JSON in this exact structure:

    {{
    "name": "Full Name",
    "email": "email@example.com",
    "phone": "+1234567890",
    "location": "City, State",
    "linkedin": "linkedin.com/in/username (if found)",
    "summary": "A powerful 3-4 sentence professional summary highlighting key achievements and value proposition",
    "experience": [
        {{
        "title": "Job Title",
        "company": "Company Name",
        "location": "City, State",
        "start_date": "Jan 2020",
        "end_date": "Present",
        "responsibilities": [
            "Led team of X engineers to deliver Y, resulting in Z% improvement",
            "Developed and implemented X system that reduced costs by $Y",
            "Each bullet should start with strong action verb and include metrics"
        ]
        }}
    ],
    "education": [
        {{
        "degree": "Bachelor of Science",
        "field": "Computer Science",
        "institution": "University Name",
        "location": "City, State",
        "graduation_date": "May 2020",
        "gpa": "3.8/4.0 (if notable)",
        "honors": "Cum Laude, Dean's List (if applicable)"
        }}
    ],
    "skills": {{
        "Technical Skills": ["Python", "JavaScript", "React", "AWS"],
        "Soft Skills": ["Leadership", "Communication", "Problem Solving"],
        "Tools": ["Git", "Docker", "Jenkins"]
    }},
    "certifications": [
        {{
        "name": "AWS Certified Solutions Architect",
        "issuer": "Amazon Web Services",
        "date": "2023"
        }}
    ],
    "achievements": [
        "Won company-wide hackathon with innovative solution",
        "Published research paper in IEEE conference"
    ],
    "improvements_made": [
        "Added quantified metrics to all achievements",
        "Replaced weak verbs with strong action verbs",
        "Optimized keywords for ATS systems"
    ],
    "estimated_ats_score": 95
    }}

    IMPORTANT: Return ONLY the JSON. No markdown, no explanation, no code blocks.
    """

        try:
            print(f"📤 Requesting structured resume improvement from Gemini...")

            response = self.model.generate_content(
                prompt,
                generation_config=self.generation_config,
                safety_settings=self.safety_settings,
            )

            if not response.candidates or response.candidates[0].finish_reason != 1:
                print(f"⚠️ Gemini response incomplete")
                return self._get_fallback_resume_structure()

            result_text = response.text.strip()

            # Clean up response
            if "```json" in result_text:
                start = result_text.find("```json") + 7
                end = result_text.find("```", start)
                result_text = result_text[start:end].strip()
            elif "```" in result_text:
                start = result_text.find("```") + 3
                end = result_text.find("```", start)
                result_text = result_text[start:end].strip()

            # Find JSON object
            start = result_text.find("{")
            end = result_text.rfind("}")
            if start != -1 and end != -1:
                result_text = result_text[start : end + 1]

            import json

            resume_data = json.loads(result_text)

            print(f"✅ Successfully parsed structured resume data")
            return resume_data

        except Exception as e:
            print(f"❌ Error improving resume: {str(e)}")
            return self._get_fallback_resume_structure()

    def _get_fallback_resume_structure(self) -> Dict[str, Any]:
        """Fallback structure if AI fails"""
        return {
            "name": "Candidate Name",
            "email": "contact@email.com",
            "phone": "",
            "location": "Location",
            "summary": "Experienced professional with a track record of success in various domains. Skilled in problem-solving, teamwork, and delivering results.",
            "experience": [
                {
                    "title": "Professional Role",
                    "company": "Company Name",
                    "location": "Location",
                    "start_date": "Year",
                    "end_date": "Present",
                    "responsibilities": [
                        "Managed projects and delivered results",
                        "Collaborated with cross-functional teams",
                        "Improved processes and efficiency",
                    ],
                }
            ],
            "education": [
                {
                    "degree": "Degree",
                    "field": "Field of Study",
                    "institution": "Institution",
                    "location": "Location",
                    "graduation_date": "Year",
                }
            ],
            "skills": {
                "Technical Skills": ["Skill 1", "Skill 2", "Skill 3"],
                "Soft Skills": ["Communication", "Leadership", "Problem Solving"],
            },
            "improvements_made": [
                "Resume structure organized for ATS compatibility",
                "Content formatted for professional presentation",
            ],
            "estimated_ats_score": 75,
        }


gemini_service = GeminiService()
