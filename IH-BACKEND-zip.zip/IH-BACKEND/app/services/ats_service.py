from typing import Dict, Any, List
import re


class ATSService:
    @staticmethod
    def calculate_ats_score(resume_text: str, job_description: str = None) -> float:
        """Calculate basic ATS score based on resume content"""
        score = 0
        max_score = 100

        # Check for contact information (20 points)
        if re.search(
            r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", resume_text
        ):
            score += 10
        if re.search(r"\b\d{10}\b|\b\d{3}[-.]?\d{3}[-.]?\d{4}\b", resume_text):
            score += 10

        # Check for section headers (20 points)
        sections = ["experience", "education", "skills", "projects"]
        section_count = sum(
            1 for section in sections if section.lower() in resume_text.lower()
        )
        score += (section_count / len(sections)) * 20

        # Check for keywords (30 points)
        keywords = [
            "developed",
            "managed",
            "led",
            "created",
            "implemented",
            "achieved",
            "improved",
            "designed",
            "analyzed",
            "coordinated",
        ]
        keyword_count = sum(
            1 for keyword in keywords if keyword.lower() in resume_text.lower()
        )
        score += (keyword_count / len(keywords)) * 30

        # Length check (15 points)
        word_count = len(resume_text.split())
        if 300 <= word_count <= 1000:
            score += 15
        elif word_count > 200:
            score += 10

        # Formatting (15 points)
        if "\n" in resume_text:  # Has line breaks
            score += 8
        if re.search(r"•|·|\*|-", resume_text):  # Has bullet points
            score += 7

        return min(score, max_score)

    @staticmethod
    def extract_keywords(text: str) -> List[str]:
        """Extract potential keywords from text"""
        # Remove common words
        common_words = {
            "the",
            "a",
            "an",
            "and",
            "or",
            "but",
            "in",
            "on",
            "at",
            "to",
            "for",
            "of",
            "with",
            "by",
            "from",
            "as",
            "is",
            "was",
            "are",
            "were",
            "been",
            "be",
            "have",
            "has",
            "had",
            "do",
            "does",
            "did",
            "will",
            "would",
            "could",
            "should",
            "may",
            "might",
            "must",
            "can",
            "this",
            "that",
            "these",
            "those",
        }

        words = re.findall(r"\b[a-zA-Z]{3,}\b", text.lower())
        keywords = [word for word in words if word not in common_words]

        # Get unique keywords with frequency
        keyword_freq = {}
        for keyword in keywords:
            keyword_freq[keyword] = keyword_freq.get(keyword, 0) + 1

        # Sort by frequency and return top keywords
        sorted_keywords = sorted(keyword_freq.items(), key=lambda x: x[1], reverse=True)
        return [kw[0] for kw in sorted_keywords[:20]]


ats_service = ATSService()
