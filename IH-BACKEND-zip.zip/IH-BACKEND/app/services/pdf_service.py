from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    PageBreak,
    KeepTogether,
)
from reportlab.lib import colors
from io import BytesIO
from typing import Dict, Any, List


class ATSResumePDFGenerator:
    """Generate ATS-optimized PDF resumes"""

    def __init__(self):
        # Create buffer for PDF
        self.buffer = BytesIO()

        # Use letter size (standard in US) or A4 (international)
        self.page_size = letter

        # Initialize styles
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()

    def _setup_custom_styles(self):
        """Setup custom paragraph styles for ATS optimization"""

        # Helper to add style only if it doesn't exist
        def add_style_safe(name, style):
            if name not in self.styles:
                self.styles.add(style)

        # Name/Header style
        add_style_safe(
            "ResumeName",
            ParagraphStyle(
                name="ResumeName",
                parent=self.styles["Heading1"],
                fontSize=24,
                textColor=colors.HexColor("#1a202c"),
                spaceAfter=6,
                alignment=TA_CENTER,
                fontName="Helvetica-Bold",
            ),
        )

        # Contact info style
        add_style_safe(
            "ResumeContact",
            ParagraphStyle(
                name="ResumeContact",
                parent=self.styles["Normal"],
                fontSize=10,
                textColor=colors.HexColor("#4a5568"),
                alignment=TA_CENTER,
                spaceAfter=12,
            ),
        )

        # Section header style
        add_style_safe(
            "ResumeSection",
            ParagraphStyle(
                name="ResumeSection",
                parent=self.styles["Heading2"],
                fontSize=14,
                textColor=colors.HexColor("#2d3748"),
                spaceAfter=8,
                spaceBefore=12,
                fontName="Helvetica-Bold",
            ),
        )

        # Job title style
        add_style_safe(
            "ResumeJobTitle",
            ParagraphStyle(
                name="ResumeJobTitle",
                parent=self.styles["Normal"],
                fontSize=12,
                textColor=colors.HexColor("#2d3748"),
                fontName="Helvetica-Bold",
                spaceAfter=4,
            ),
        )

        # Company/Institution style
        add_style_safe(
            "ResumeCompany",
            ParagraphStyle(
                name="ResumeCompany",
                parent=self.styles["Normal"],
                fontSize=11,
                textColor=colors.HexColor("#4a5568"),
                fontName="Helvetica-Oblique",
                spaceAfter=2,
            ),
        )

        # Date range style
        add_style_safe(
            "ResumeDateRange",
            ParagraphStyle(
                name="ResumeDateRange",
                parent=self.styles["Normal"],
                fontSize=10,
                textColor=colors.HexColor("#718096"),
                spaceAfter=6,
            ),
        )

        # Bullet point style
        add_style_safe(
            "ResumeBullet",
            ParagraphStyle(
                name="ResumeBullet",
                parent=self.styles["Normal"],
                fontSize=10,
                textColor=colors.HexColor("#2d3748"),
                leftIndent=20,
                spaceAfter=4,
                alignment=TA_JUSTIFY,
            ),
        )

        # Skills style
        add_style_safe(
            "ResumeSkills",
            ParagraphStyle(
                name="ResumeSkills",
                parent=self.styles["Normal"],
                fontSize=10,
                textColor=colors.HexColor("#2d3748"),
                spaceAfter=4,
            ),
        )

    def generate_resume(
        self, resume_data: Dict[str, Any], output_path: str = None
    ) -> BytesIO:
        """
        Generate ATS-optimized PDF resume

        Args:
            resume_data: Structured resume data from AI
            output_path: Optional file path to save PDF

        Returns:
            BytesIO buffer containing PDF
        """

        # Create document
        if output_path:
            doc = SimpleDocTemplate(
                output_path,
                pagesize=self.page_size,
                rightMargin=0.75 * inch,
                leftMargin=0.75 * inch,
                topMargin=0.75 * inch,
                bottomMargin=0.75 * inch,
            )
        else:
            doc = SimpleDocTemplate(
                self.buffer,
                pagesize=self.page_size,
                rightMargin=0.75 * inch,
                leftMargin=0.75 * inch,
                topMargin=0.75 * inch,
                bottomMargin=0.75 * inch,
            )

        # Build story (content)
        story = []

        # Add header (name and contact)
        story.extend(self._build_header(resume_data))

        # Add professional summary
        if resume_data.get("summary"):
            story.extend(self._build_summary(resume_data["summary"]))

        # Add experience section
        if resume_data.get("experience"):
            story.extend(self._build_experience(resume_data["experience"]))

        # Add education section
        if resume_data.get("education"):
            story.extend(self._build_education(resume_data["education"]))

        # Add skills section
        if resume_data.get("skills"):
            story.extend(self._build_skills(resume_data["skills"]))

        # Add certifications
        if resume_data.get("certifications"):
            story.extend(self._build_certifications(resume_data["certifications"]))

        # Add achievements/awards
        if resume_data.get("achievements"):
            story.extend(self._build_achievements(resume_data["achievements"]))

        # Build PDF
        doc.build(story)

        if not output_path:
            self.buffer.seek(0)

        return self.buffer

    def _build_header(self, data: Dict) -> List:
        """Build resume header with name and contact info"""
        elements = []

        # Name
        name = data.get("name", "Your Name")
        elements.append(Paragraph(name, self.styles["ResumeName"]))

        # Contact info
        contact_parts = []
        if data.get("email"):
            contact_parts.append(data["email"])
        if data.get("phone"):
            contact_parts.append(data["phone"])
        if data.get("location"):
            contact_parts.append(data["location"])
        if data.get("linkedin"):
            contact_parts.append(data["linkedin"])

        contact_text = " | ".join(contact_parts)
        elements.append(Paragraph(contact_text, self.styles["ResumeContact"]))
        elements.append(Spacer(1, 0.2 * inch))

        return elements

    def _build_summary(self, summary: str) -> List:
        """Build professional summary section"""
        elements = []

        # Section header with line
        elements.append(Paragraph("PROFESSIONAL SUMMARY", self.styles["ResumeSection"]))
        elements.append(Spacer(1, 0.05 * inch))

        # Horizontal line
        line = Table([[""]], colWidths=[6.5 * inch])
        line.setStyle(
            TableStyle(
                [
                    ("LINEABOVE", (0, 0), (-1, 0), 1, colors.HexColor("#3182ce")),
                ]
            )
        )
        elements.append(line)
        elements.append(Spacer(1, 0.1 * inch))

        # Summary text
        elements.append(Paragraph(summary, self.styles["Normal"]))
        elements.append(Spacer(1, 0.15 * inch))

        return elements

    def _build_experience(self, experiences: List[Dict]) -> List:
        """Build work experience section"""
        elements = []

        # Section header
        elements.append(
            Paragraph("PROFESSIONAL EXPERIENCE", self.styles["ResumeSection"])
        )
        elements.append(Spacer(1, 0.05 * inch))

        # Horizontal line
        line = Table([[""]], colWidths=[6.5 * inch])
        line.setStyle(
            TableStyle(
                [
                    ("LINEABOVE", (0, 0), (-1, 0), 1, colors.HexColor("#3182ce")),
                ]
            )
        )
        elements.append(line)
        elements.append(Spacer(1, 0.1 * inch))

        for exp in experiences:
            # Job title
            elements.append(
                Paragraph(exp.get("title", "Job Title"), self.styles["ResumeJobTitle"])
            )

            # Company and location
            company_location = exp.get("company", "Company")
            if exp.get("location"):
                company_location += f" - {exp['location']}"
            elements.append(Paragraph(company_location, self.styles["ResumeCompany"]))

            # Date range
            date_range = (
                f"{exp.get('start_date', 'Start')} - {exp.get('end_date', 'Present')}"
            )
            elements.append(Paragraph(date_range, self.styles["ResumeDateRange"]))

            # Responsibilities/achievements
            for responsibility in exp.get("responsibilities", []):
                bullet = f"• {responsibility}"
                elements.append(Paragraph(bullet, self.styles["ResumeBullet"]))

            elements.append(Spacer(1, 0.15 * inch))

        return elements

    def _build_education(self, education: List[Dict]) -> List:
        """Build education section"""
        elements = []

        # Section header
        elements.append(Paragraph("EDUCATION", self.styles["ResumeSection"]))
        elements.append(Spacer(1, 0.05 * inch))

        # Horizontal line
        line = Table([[""]], colWidths=[6.5 * inch])
        line.setStyle(
            TableStyle(
                [
                    ("LINEABOVE", (0, 0), (-1, 0), 1, colors.HexColor("#3182ce")),
                ]
            )
        )
        elements.append(line)
        elements.append(Spacer(1, 0.1 * inch))

        for edu in education:
            # Degree
            degree = (
                f"{edu.get('degree', 'Degree')} in {edu.get('field', 'Field of Study')}"
            )
            elements.append(Paragraph(degree, self.styles["ResumeJobTitle"]))

            # Institution and location
            institution = edu.get("institution", "Institution")
            if edu.get("location"):
                institution += f" - {edu['location']}"
            elements.append(Paragraph(institution, self.styles["ResumeCompany"]))

            # Date
            if edu.get("graduation_date"):
                elements.append(
                    Paragraph(
                        f"Graduated: {edu['graduation_date']}",
                        self.styles["ResumeDateRange"],
                    )
                )

            # GPA or honors
            if edu.get("gpa"):
                elements.append(
                    Paragraph(f"GPA: {edu['gpa']}", self.styles["ResumeBullet"])
                )
            if edu.get("honors"):
                elements.append(
                    Paragraph(f"Honors: {edu['honors']}", self.styles["ResumeBullet"])
                )

            elements.append(Spacer(1, 0.15 * inch))

        return elements

    def _build_skills(self, skills: Dict[str, List[str]]) -> List:
        """Build skills section with categories"""
        elements = []

        # Section header
        elements.append(Paragraph("SKILLS", self.styles["ResumeSection"]))
        elements.append(Spacer(1, 0.05 * inch))

        # Horizontal line
        line = Table([[""]], colWidths=[6.5 * inch])
        line.setStyle(
            TableStyle(
                [
                    ("LINEABOVE", (0, 0), (-1, 0), 1, colors.HexColor("#3182ce")),
                ]
            )
        )
        elements.append(line)
        elements.append(Spacer(1, 0.1 * inch))

        # If skills is a list, convert to dict
        if isinstance(skills, list):
            skills = {"Skills": skills}

        for category, skill_list in skills.items():
            if skill_list:
                skill_text = f"<b>{category}:</b> {', '.join(skill_list)}"
                elements.append(Paragraph(skill_text, self.styles["ResumeSkills"]))
                elements.append(Spacer(1, 0.05 * inch))

        elements.append(Spacer(1, 0.1 * inch))
        return elements

    def _build_certifications(self, certifications: List[Dict]) -> List:
        """Build certifications section"""
        elements = []

        # Section header
        elements.append(Paragraph("CERTIFICATIONS", self.styles["ResumeSection"]))
        elements.append(Spacer(1, 0.05 * inch))

        # Horizontal line
        line = Table([[""]], colWidths=[6.5 * inch])
        line.setStyle(
            TableStyle(
                [
                    ("LINEABOVE", (0, 0), (-1, 0), 1, colors.HexColor("#3182ce")),
                ]
            )
        )
        elements.append(line)
        elements.append(Spacer(1, 0.1 * inch))

        for cert in certifications:
            cert_text = f"• {cert.get('name', 'Certification')}"
            if cert.get("issuer"):
                cert_text += f" - {cert['issuer']}"
            if cert.get("date"):
                cert_text += f" ({cert['date']})"

            elements.append(Paragraph(cert_text, self.styles["ResumeBullet"]))

        elements.append(Spacer(1, 0.1 * inch))
        return elements

    def _build_achievements(self, achievements: List[str]) -> List:
        """Build achievements/awards section"""
        elements = []

        # Section header
        elements.append(
            Paragraph("ACHIEVEMENTS & AWARDS", self.styles["ResumeSection"])
        )
        elements.append(Spacer(1, 0.05 * inch))

        # Horizontal line
        line = Table([[""]], colWidths=[6.5 * inch])
        line.setStyle(
            TableStyle(
                [
                    ("LINEABOVE", (0, 0), (-1, 0), 1, colors.HexColor("#3182ce")),
                ]
            )
        )
        elements.append(line)
        elements.append(Spacer(1, 0.1 * inch))

        for achievement in achievements:
            elements.append(Paragraph(f"• {achievement}", self.styles["ResumeBullet"]))

        elements.append(Spacer(1, 0.1 * inch))
        return elements


# Don't instantiate globally - create on demand
def create_pdf_generator():
    """Factory function to create PDF generator"""
    return ATSResumePDFGenerator()
