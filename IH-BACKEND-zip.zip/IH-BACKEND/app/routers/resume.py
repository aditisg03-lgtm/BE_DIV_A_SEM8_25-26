from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List
import os
import uuid
from PyPDF2 import PdfReader
from io import BytesIO

from app.database import get_db
from app.models.user import User, UserRole  # ✅ Added UserRole
from app.models.student import StudentProfile
from app.models.hr import HRProfile  # ✅ Added HRProfile
from app.models.resume import Resume, ResumeAnalysis
from app.models.job import JobDescription
from app.models.application import Application  # ✅ Added Application
from app.schemas.resume import (
    ResumeUploadResponse,
    ResumeResponse,
    ResumeAnalysisResponse,
)
from app.utils.dependencies import (
    get_current_student,
    get_current_user,
)  # ✅ Added get_current_user
from app.services.gemini_service import gemini_service
from app.services.ats_service import ats_service
from app.config import settings

router = APIRouter(prefix="/api/resumes", tags=["Resumes"])


def format_skills(skills):
    """Format skills list to string, handling both str and dict formats"""
    if not skills:
        return "Not specified"

    formatted = []
    for skill in skills:
        if isinstance(skill, str):
            formatted.append(skill)
        elif isinstance(skill, dict):
            # Try common keys
            formatted.append(
                skill.get("name")
                or skill.get("skill")
                or skill.get("title")
                or str(skill)
            )
        else:
            formatted.append(str(skill))

    return ", ".join(formatted)


def extract_text_from_pdf(file_content: bytes) -> str:
    """Extract text from PDF file"""
    try:
        pdf_file = BytesIO(file_content)
        pdf_reader = PdfReader(pdf_file)
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text()
        return text
    except Exception as e:
        print(f"Error extracting PDF text: {str(e)}")
        return ""


@router.post("/upload", response_model=ResumeUploadResponse)
async def upload_resume(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Upload a resume"""
    # Check file type
    if not file.filename.endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Only PDF files are allowed"
        )

    # Get student profile
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(
            status_code=404, detail="Profile not found. Create profile first."
        )

    # Read file content
    content = await file.read()
    file_size = len(content)

    # Check file size
    if file_size > settings.MAX_FILE_SIZE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File size exceeds maximum limit of {settings.MAX_FILE_SIZE} bytes",
        )

    # Generate unique filename
    file_id = str(uuid.uuid4())
    file_extension = os.path.splitext(file.filename)[1]
    unique_filename = f"{file_id}{file_extension}"
    file_path = os.path.join(settings.UPLOAD_DIR, unique_filename)

    # Save file
    with open(file_path, "wb") as f:
        f.write(content)

    # Extract text
    extracted_text = extract_text_from_pdf(content)

    # Calculate basic ATS score
    ats_score = ats_service.calculate_ats_score(extracted_text)

    # Create resume record
    resume = Resume(
        student_profile_id=profile.id,
        file_name=file.filename,
        file_path=file_path,
        file_size=file_size,
        extracted_text=extracted_text,
        ats_score=ats_score,
    )

    db.add(resume)
    db.commit()
    db.refresh(resume)

    return ResumeUploadResponse(
        id=resume.id,
        file_name=resume.file_name,
        file_size=resume.file_size,
        upload_date=resume.upload_date,
        message="Resume uploaded successfully",
    )


@router.get("", response_model=List[ResumeResponse])
def get_resumes(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get all resumes for current student"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        return []

    resumes = db.query(Resume).filter(Resume.student_profile_id == profile.id).all()
    return resumes


@router.get("/{resume_id}", response_model=ResumeResponse)
def get_resume(
    resume_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Get a specific resume"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    resume = (
        db.query(Resume)
        .filter(Resume.id == resume_id, Resume.student_profile_id == profile.id)
        .first()
    )

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    return resume


@router.delete("/{resume_id}")
def delete_resume(
    resume_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Delete a resume"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    resume = (
        db.query(Resume)
        .filter(Resume.id == resume_id, Resume.student_profile_id == profile.id)
        .first()
    )

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    # Delete file
    try:
        if os.path.exists(resume.file_path):
            os.remove(resume.file_path)
    except Exception as e:
        print(f"Error deleting file: {str(e)}")

    db.delete(resume)
    db.commit()

    return {"message": "Resume deleted successfully"}


@router.post("/{resume_id}/analyze", response_model=ResumeAnalysisResponse)
async def analyze_resume(
    resume_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Analyze resume using AI"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    resume = (
        db.query(Resume)
        .filter(Resume.id == resume_id, Resume.student_profile_id == profile.id)
        .first()
    )

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    if not resume.extracted_text:
        raise HTTPException(status_code=400, detail="Resume text not available")

    # Get AI analysis
    analysis_result = await gemini_service.analyze_resume(resume.extracted_text)

    # Create analysis record
    analysis = ResumeAnalysis(
        resume_id=resume.id,
        ats_score=analysis_result.get("ats_score", 0),
        keyword_match_percentage=analysis_result.get("keyword_match_percentage", 0),
        skills_match=analysis_result.get("skills_match"),
        experience_match=analysis_result.get("experience_match"),
        education_match=analysis_result.get("education_match"),
        strengths=analysis_result.get("strengths", []),
        weaknesses=analysis_result.get("weaknesses", []),
        improvement_suggestions=analysis_result.get("improvement_suggestions", []),
        overall_feedback=analysis_result.get("overall_feedback"),
        gemini_raw_response=analysis_result,
    )

    db.add(analysis)

    # Update resume ATS score
    resume.ats_score = analysis.ats_score

    db.commit()
    db.refresh(analysis)

    return analysis


@router.get("/{resume_id}/analysis", response_model=List[ResumeAnalysisResponse])
def get_resume_analyses(
    resume_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Get all analyses for a resume"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    resume = (
        db.query(Resume)
        .filter(Resume.id == resume_id, Resume.student_profile_id == profile.id)
        .first()
    )

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    analyses = (
        db.query(ResumeAnalysis).filter(ResumeAnalysis.resume_id == resume_id).all()
    )
    return analyses


@router.post("/{resume_id}/compare-with-job/{job_id}")
async def compare_resume_with_job(
    resume_id: str,
    job_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Compare resume with a specific job description"""

    # Get student profile
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Get resume
    resume = (
        db.query(Resume)
        .filter(Resume.id == resume_id, Resume.student_profile_id == profile.id)
        .first()
    )
    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    # Get job description
    from app.models.job import JobDescription
    from app.models.student_enhancements import JobComparison  # Add this import

    job = db.query(JobDescription).filter(JobDescription.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    if not resume.extracted_text:
        raise HTTPException(status_code=400, detail="Resume text not available")

    # Create job description text
    job_text = f"""
    Job Title: {job.title}
    Department: {job.department or "N/A"}
    Location: {job.location}
    Employment Type: {job.employment_type.value}
    Experience Level: {job.experience_level.value}

    Description:
    {job.description}

    Requirements:
    {chr(10).join(f"- {req}" for req in job.requirements) if job.requirements else "Not specified"}

    Responsibilities:
    {chr(10).join(f"- {resp}" for resp in job.responsibilities) if job.responsibilities else "Not specified"}

    Required Skills:
    {format_skills(job.required_skills)}

    Preferred Qualifications:
    {chr(10).join(f"- {qual}" for qual in job.preferred_qualifications) if job.preferred_qualifications else "Not specified"}
    """

    # Get AI analysis comparing resume with job
    analysis = await gemini_service.analyze_resume(resume.extracted_text, job_text)

    # Calculate success probability
    ats_score = analysis.get("ats_score", 0)
    keyword_match = analysis.get("keyword_match_percentage", 0)
    skills_match_pct = analysis.get("skills_match", {}).get("match_percentage", 0)
    experience_score = analysis.get("experience_match", {}).get("score", 0)
    education_score = analysis.get("education_match", {}).get("score", 0)

    success_probability = (
        ats_score * 0.30
        + keyword_match * 0.25
        + skills_match_pct * 0.25
        + experience_score * 0.15
        + education_score * 0.05
    )

    if success_probability >= 85:
        success_level = "EXCELLENT"
        success_message = "You are an excellent match for this position!"
    elif success_probability >= 70:
        success_level = "GOOD"
        success_message = "You have a good chance of success."
    elif success_probability >= 55:
        success_level = "MODERATE"
        success_message = "You meet some requirements but have gaps."
    else:
        success_level = "LOW"
        success_message = "This position may be challenging."

    # Create ResumeAnalysis record (for history/tracking)
    analysis_record = ResumeAnalysis(
        resume_id=resume.id,
        job_description_id=job.id,
        ats_score=ats_score,
        keyword_match_percentage=keyword_match,
        skills_match=analysis.get("skills_match"),
        experience_match=analysis.get("experience_match"),
        education_match=analysis.get("education_match"),
        strengths=analysis.get("strengths", []),
        weaknesses=analysis.get("weaknesses", []),
        improvement_suggestions=analysis.get("improvement_suggestions", []),
        overall_feedback=analysis.get("overall_feedback"),
        gemini_raw_response=analysis,
    )
    db.add(analysis_record)

    # Create JobComparison record (for courses/interviews)
    comparison = JobComparison(
        student_profile_id=profile.id,
        resume_id=resume.id,
        job_description_id=job.id,
        custom_job_description=None,  # Not custom, it's from database
        success_probability=success_probability,
        success_level=success_level,
        success_message=success_message,
        scores={
            "ats_score": ats_score,
            "keyword_match": keyword_match,
            "skills_match": skills_match_pct,
            "experience_match": experience_score,
            "education_match": education_score,
        },
        analysis=analysis,
        next_steps={
            "should_apply": success_probability >= 55,
            "recommended_actions": analysis.get("improvement_suggestions", [])[:5],
            "critical_gaps": analysis.get("skills_match", {}).get("missing_skills", [])[
                :5
            ],
        },
    )
    db.add(comparison)

    db.commit()
    db.refresh(analysis_record)
    db.refresh(comparison)

    # Return response matching frontend expectations
    return {
        "comparison_id": comparison.id,  # Use JobComparison ID, not ResumeAnalysis ID
        "job_id": job.id,
        "job_title": job.title,
        "success_probability": round(success_probability, 2),
        "success_level": success_level,
        "success_message": success_message,
        "scores": {
            "ats_score": ats_score,
            "keyword_match": keyword_match,
            "skills_match": skills_match_pct,
            "experience_match": experience_score,
            "education_match": education_score,
        },
        "analysis": analysis,
        "next_steps": {
            "should_apply": success_probability >= 55,
            "recommended_actions": analysis.get("improvement_suggestions", [])[:5],
            "critical_gaps": analysis.get("skills_match", {}).get("missing_skills", [])[
                :5
            ],
        },
    }


from fastapi.responses import FileResponse
import os


@router.get("/{resume_id}/download")
def download_resume(
    resume_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Download resume file"""

    resume = db.query(Resume).filter(Resume.id == resume_id).first()

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    # Authorization check
    if current_user.role == UserRole.STUDENT:
        # Students can only download their own resumes
        profile = (
            db.query(StudentProfile)
            .filter(StudentProfile.user_id == current_user.id)
            .first()
        )
        if not profile or resume.student_profile_id != profile.id:
            raise HTTPException(status_code=403, detail="Not authorized")

    elif current_user.role == UserRole.HR:
        # HR can download resumes from applications to their jobs
        hr_profile = (
            db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
        )

        if not hr_profile:
            raise HTTPException(status_code=403, detail="HR profile not found")

        # Check if resume is from application to HR's job
        application = (
            db.query(Application).filter(Application.resume_id == resume_id).first()
        )

        if application:
            job = (
                db.query(JobDescription)
                .filter(
                    JobDescription.id == application.job_description_id,
                    JobDescription.hr_profile_id == hr_profile.id,
                )
                .first()
            )

            if not job:
                raise HTTPException(status_code=403, detail="Not authorized")

    # Check if file exists
    if not os.path.exists(resume.file_path):
        raise HTTPException(status_code=404, detail="Resume file not found")

    # Return file
    return FileResponse(
        path=resume.file_path, media_type="application/pdf", filename=resume.file_name
    )
