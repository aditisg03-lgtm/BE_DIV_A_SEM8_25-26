from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
    UploadFile,
    File,
    Response,
)
from sqlalchemy.orm import Session
from sqlalchemy import desc, func  # <-- 'func' was missing
from typing import List, Optional
from datetime import datetime
import json  # <-- Missing: used in multiple endpoints
import os  # <-- Missing: used in resume improvement download

from app.database import get_db
from app.models.user import User
from app.models.student import StudentProfile
from app.models.job import JobDescription
from app.models.resume import Resume
from app.models.application import Application, ApplicationStatus
from app.models.student_enhancements import (
    SavedJob,
    HiddenJob,
    JobComparison,
    MockInterview,
    ImprovedResume,
    CourseSuggestion,
)
from app.models.resume import ResumeAnalysis  # <-- Missing model import
from app.utils.dependencies import get_current_student
from app.services.gemini_service import gemini_service
from app.config import settings  # <-- Missing: used in resume improvement
from pydantic import BaseModel

from fastapi.responses import FileResponse

router = APIRouter(prefix="/api/student", tags=["Student Enhancements"])

# ==================== SAVED JOBS ====================


@router.post("/jobs/{job_id}/save")
def save_job(
    job_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Bookmark a job"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Check if already saved
    existing = (
        db.query(SavedJob)
        .filter(
            SavedJob.student_profile_id == profile.id,
            SavedJob.job_description_id == job_id,
        )
        .first()
    )

    if existing:
        raise HTTPException(status_code=400, detail="Job already saved")

    saved_job = SavedJob(student_profile_id=profile.id, job_description_id=job_id)
    db.add(saved_job)
    db.commit()

    return {"message": "Job saved successfully"}


@router.delete("/jobs/{job_id}/save")
def unsave_job(
    job_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Remove bookmark from a job"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    saved_job = (
        db.query(SavedJob)
        .filter(
            SavedJob.student_profile_id == profile.id,
            SavedJob.job_description_id == job_id,
        )
        .first()
    )

    if not saved_job:
        raise HTTPException(status_code=404, detail="Saved job not found")

    db.delete(saved_job)
    db.commit()

    return {"message": "Job removed from saved"}


@router.get("/jobs/saved")
def get_saved_jobs(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get all saved jobs"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        return []

    saved_jobs = (
        db.query(SavedJob).filter(SavedJob.student_profile_id == profile.id).all()
    )

    result = []
    for saved in saved_jobs:
        job = saved.job_description
        result.append(
            {
                "saved_id": saved.id,
                "saved_at": saved.created_at,
                "job": {
                    "id": job.id,
                    "title": job.title,
                    "location": job.location,
                    "employment_type": job.employment_type,
                    "description": job.description,
                    "status": job.status,
                },
            }
        )

    return result


# ==================== HIDDEN JOBS ====================


@router.post("/jobs/{job_id}/hide")
def hide_job(
    job_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Hide a job (mark as not relevant)"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    existing = (
        db.query(HiddenJob)
        .filter(
            HiddenJob.student_profile_id == profile.id,
            HiddenJob.job_description_id == job_id,
        )
        .first()
    )

    if existing:
        raise HTTPException(status_code=400, detail="Job already hidden")

    hidden_job = HiddenJob(student_profile_id=profile.id, job_description_id=job_id)
    db.add(hidden_job)
    db.commit()

    return {"message": "Job hidden successfully"}


@router.delete("/jobs/{job_id}/hide")
def unhide_job(
    job_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Unhide a job"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    hidden_job = (
        db.query(HiddenJob)
        .filter(
            HiddenJob.student_profile_id == profile.id,
            HiddenJob.job_description_id == job_id,
        )
        .first()
    )

    if not hidden_job:
        raise HTTPException(status_code=404, detail="Hidden job not found")

    db.delete(hidden_job)
    db.commit()

    return {"message": "Job unhidden"}


# ==================== JOB COMPARISON WITH CUSTOM JD ====================


class CustomJobComparison(BaseModel):
    resume_id: str
    job_title: str
    job_description: str
    company_name: Optional[str] = None
    required_skills: Optional[List[str]] = []


@router.post("/compare-custom-job")
async def compare_with_custom_job(
    data: CustomJobComparison,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Compare resume with custom job description (student input)"""

    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    resume = (
        db.query(Resume)
        .filter(Resume.id == data.resume_id, Resume.student_profile_id == profile.id)
        .first()
    )

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    # Create custom JD text
    custom_jd_text = f"""
JOB TITLE: {data.job_title}

COMPANY: {data.company_name or "Not specified"}

JOB DESCRIPTION:
{data.job_description}

REQUIRED SKILLS:
{", ".join(data.required_skills) if data.required_skills else "Not specified"}
"""

    # Analyze with AI
    analysis = await gemini_service.analyze_resume(
        resume.extracted_text, custom_jd_text
    )

    # Calculate success probability
    ats_score = analysis.get("ats_score", 0)
    keyword_match = analysis.get("keyword_match_percentage", 0)
    skills_match_pct = analysis.get("skills_match", {}).get("match_percentage", 0)
    experience_score = analysis.get("experience_match", {}).get("score", 0)
    education_score = analysis.get("education_match", {}).get("score", 0)

    success_probability = (
        ats_score * 0.30
        + keyword_match * 0.25
        + skills_match_pct * 0.25
        + experience_score * 0.15
        + education_score * 0.05
    )

    if success_probability >= 85:
        success_level = "EXCELLENT"
        success_message = "You are an excellent match for this position!"
    elif success_probability >= 70:
        success_level = "GOOD"
        success_message = "You have a good chance of success."
    elif success_probability >= 55:
        success_level = "MODERATE"
        success_message = "You meet some requirements but have gaps."
    else:
        success_level = "LOW"
        success_message = "This position may be challenging."

    # Save to database
    comparison = JobComparison(
        student_profile_id=profile.id,
        resume_id=resume.id,
        custom_job_description=custom_jd_text,
        success_probability=success_probability,
        success_level=success_level,
        success_message=success_message,
        scores={
            "ats_score": ats_score,
            "keyword_match": keyword_match,
            "skills_match": skills_match_pct,
            "experience_match": experience_score,
            "education_match": education_score,
        },
        analysis=analysis,
        next_steps={
            "should_apply": success_probability >= 55,
            "recommended_actions": analysis.get("improvement_suggestions", [])[:5],
            "critical_gaps": analysis.get("skills_match", {}).get("missing_skills", [])[
                :5
            ],
        },
    )

    db.add(comparison)
    db.commit()
    db.refresh(comparison)

    return {
        "comparison_id": comparison.id,
        "job_title": data.job_title,
        "success_probability": round(success_probability, 2),
        "success_level": success_level,
        "success_message": success_message,
        "scores": comparison.scores,
        "analysis": analysis,
        "next_steps": comparison.next_steps,
    }


@router.get("/comparisons/history")
def get_comparison_history(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get all saved comparisons"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        return []

    comparisons = (
        db.query(JobComparison)
        .filter(JobComparison.student_profile_id == profile.id)
        .order_by(desc(JobComparison.created_at))
        .all()
    )

    return comparisons


@router.get("/comparisons/{comparison_id}")
def get_comparison_details(
    comparison_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Get specific comparison details"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    comparison = (
        db.query(JobComparison)
        .filter(
            JobComparison.id == comparison_id,
            JobComparison.student_profile_id == profile.id,
        )
        .first()
    )

    if not comparison:
        raise HTTPException(status_code=404, detail="Comparison not found")

    return comparison


# ==================== COURSE SUGGESTIONS ====================


@router.post("/comparisons/{comparison_id}/suggest-courses")
async def suggest_courses(
    comparison_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Generate course suggestions based on skill gaps"""

    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    comparison = (
        db.query(JobComparison)
        .filter(
            JobComparison.id == comparison_id,
            JobComparison.student_profile_id == profile.id,
        )
        .first()
    )

    if not comparison:
        raise HTTPException(status_code=404, detail="Comparison not found")

    # Get missing skills
    missing_skills = comparison.next_steps.get("critical_gaps", [])
    matched_skills = comparison.analysis.get("skills_match", {}).get(
        "matched_skills", []
    )

    # Generate course suggestions using AI
    prompt = f"""Based on the following skill analysis for a job position, suggest relevant online courses.

MISSING/NEEDED SKILLS:
{", ".join(missing_skills) if missing_skills else "None"}

CURRENT SKILLS TO ENHANCE:
{", ".join(matched_skills[:5]) if matched_skills else "None"}

Suggest 6-8 courses from platforms like Udemy, Coursera, edX, LinkedIn Learning that would help.

For each course, provide a searchable course name that exists on the platform.

Respond with JSON:
{{
  "courses": [
    {{
      "name": "Complete Python Bootcamp",
      "platform": "Udemy",
      "skill_gap": "Python Programming",
      "reason": "Comprehensive coverage from basics to advanced",
      "relevance_score": 95,
      "estimated_duration": "40 hours",
      "level": "Beginner to Advanced"
    }}
  ]
}}

Only return valid JSON."""

    try:
        response = gemini_service.model.generate_content(
            prompt, generation_config=gemini_service.generation_config
        )

        result_text = response.text.strip()
        if "```json" in result_text:
            start = result_text.find("```json") + 7
            end = result_text.find("```", start)
            result_text = result_text[start:end].strip()

        courses_data = json.loads(result_text)

        # Generate real URLs for each course
        platform_urls = {
            "udemy": "https://www.udemy.com/courses/search/?q=",
            "coursera": "https://www.coursera.org/search?query=",
            "edx": "https://www.edx.org/search?q=",
            "linkedin learning": "https://www.linkedin.com/learning/search?keywords=",
            "pluralsight": "https://www.pluralsight.com/search?q=",
            "skillshare": "https://www.skillshare.com/search?query=",
        }

        # Add URLs and images to each course
        for course in courses_data.get("courses", []):
            platform_lower = course["platform"].lower()
            platform_key = None

            # Find matching platform
            for key in platform_urls.keys():
                if key in platform_lower:
                    platform_key = key
                    break

            if platform_key:
                # Generate search URL
                course_name_encoded = course["name"].replace(" ", "+")
                course["url"] = platform_urls[platform_key] + course_name_encoded

                # Add platform logo/image
                course["platform_logo"] = (
                    f"https://logo.clearbit.com/{platform_key.replace(' ', '')}.com"
                )
            else:
                # Fallback to Google search
                course["url"] = (
                    f"https://www.google.com/search?q={course['name'].replace(' ', '+')}+course"
                )
                course["platform_logo"] = (
                    "https://via.placeholder.com/100x100?text=Course"
                )

            # Add default values
            course.setdefault("estimated_duration", "20-30 hours")
            course.setdefault("level", "All Levels")

        # Save suggestions to database
        for course in courses_data.get("courses", []):
            suggestion = CourseSuggestion(
                job_comparison_id=comparison_id,
                course_name=course["name"],
                platform=course["platform"],
                url=course["url"],
                relevance_score=course["relevance_score"],
                reason=course["reason"],
                skill_gap=course["skill_gap"],
            )
            db.add(suggestion)

        db.commit()

        return courses_data

    except Exception as e:
        print(f"Error generating courses: {e}")
        # Fallback suggestions with real links
        fallback_courses = []
        platform_urls = {
            "Udemy": "https://www.udemy.com/courses/search/?q=",
            "Coursera": "https://www.coursera.org/search?query=",
            "edX": "https://www.edx.org/search?q=",
        }

        for i, skill in enumerate(missing_skills[:6]):
            platform = ["Udemy", "Coursera", "edX"][i % 3]
            course_name = f"Complete {skill} Course"
            fallback_courses.append(
                {
                    "name": course_name,
                    "platform": platform,
                    "skill_gap": skill,
                    "reason": "Comprehensive course covering fundamentals to advanced topics",
                    "relevance_score": 80,
                    "url": platform_urls[platform] + skill.replace(" ", "+"),
                    "platform_logo": f"https://logo.clearbit.com/{platform.lower()}.com",
                    "estimated_duration": "25 hours",
                    "level": "All Levels",
                }
            )

        return {"courses": fallback_courses}


# Will continue with Mock Interview, Resume Improvement, and Analytics endpoints...

# ==================== MOCK INTERVIEW ====================


@router.post("/comparisons/{comparison_id}/generate-interview")
async def generate_mock_interview(
    comparison_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Generate mock interview questions based on job comparison"""

    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    comparison = (
        db.query(JobComparison)
        .filter(
            JobComparison.id == comparison_id,
            JobComparison.student_profile_id == profile.id,
        )
        .first()
    )

    if not comparison:
        raise HTTPException(status_code=404, detail="Comparison not found")

    # Get job details
    job_title = ""
    job_description = ""

    if comparison.job_description_id:
        job = comparison.job_description
        job_title = job.title
        job_description = job.description
    else:
        # Parse custom job description
        job_description = comparison.custom_job_description
        lines = job_description.split("\n")
        for line in lines:
            if line.startswith("JOB TITLE:"):
                job_title = line.replace("JOB TITLE:", "").strip()
                break

    # Generate interview questions using AI
    prompt = f"""Generate a comprehensive mock interview for the following position.

JOB TITLE: {job_title}

JOB DESCRIPTION:
{job_description[:1000]}

CANDIDATE STRENGTHS:
{", ".join(comparison.analysis.get("strengths", [])[:3])}

CANDIDATE GAPS:
{", ".join(comparison.next_steps.get("critical_gaps", [])[:3])}

Generate 10 interview questions covering:
- 3 behavioral questions
- 4 technical/role-specific questions
- 2 situational questions
- 1 closing question about candidate's questions

Respond with JSON:
{{
  "questions": [
    {{
      "id": 1,
      "type": "behavioral",
      "question": "Question text here",
      "tips": "What interviewer is looking for"
    }}
  ]
}}

Only return valid JSON."""

    try:
        response = gemini_service.model.generate_content(
            prompt, generation_config=gemini_service.generation_config
        )

        import json

        result_text = response.text.strip()
        if "```json" in result_text:
            start = result_text.find("```json") + 7
            end = result_text.find("```", start)
            result_text = result_text[start:end].strip()

        questions_data = json.loads(result_text)

        # Create mock interview
        interview = MockInterview(
            student_profile_id=profile.id,
            job_comparison_id=comparison_id,
            questions=questions_data["questions"],
            answers={},
            status="pending",
        )

        db.add(interview)
        db.commit()
        db.refresh(interview)

        return {"interview_id": interview.id, "questions": questions_data["questions"]}

    except Exception as e:
        print(f"Error generating interview: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate interview")


@router.post("/interviews/{interview_id}/submit")
async def submit_interview_answers(
    interview_id: str,
    answers: dict,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Submit answers to mock interview and get evaluation"""

    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    interview = (
        db.query(MockInterview)
        .filter(
            MockInterview.id == interview_id,
            MockInterview.student_profile_id == profile.id,
        )
        .first()
    )

    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found")

    # Save answers
    interview.answers = answers.get("answers", {})
    interview.status = "in_progress"

    # Evaluate answers using AI
    comparison = interview.job_comparison

    evaluation_prompt = f"""Evaluate the following mock interview responses.

QUESTIONS AND ANSWERS:
{
        json.dumps(
            [
                {
                    "question": q["question"],
                    "answer": interview.answers.get(str(q["id"]), "No answer provided"),
                    "type": q["type"],
                }
                for q in interview.questions
            ],
            indent=2,
        )
    }

CANDIDATE BACKGROUND:
Strengths: {", ".join(comparison.analysis.get("strengths", [])[:3])}
Experience Match: {comparison.scores.get("experience_match", 0)}%
Skills Match: {comparison.scores.get("skills_match", 0)}%

Evaluate and respond with JSON:
{{
  "overall_score": 75,
  "feedback": "Overall assessment",
  "strengths": ["Strong point 1", "Strong point 2"],
  "improvements": ["Area to improve 1", "Area to improve 2"],
  "question_evaluations": [
    {{
      "question_id": 1,
      "score": 80,
      "feedback": "Detailed feedback"
    }}
  ],
  "success_rate": 78,
  "tips_to_improve": ["Tip 1", "Tip 2", "Tip 3"]
}}

Only return valid JSON."""

    try:
        response = gemini_service.model.generate_content(
            evaluation_prompt, generation_config=gemini_service.generation_config
        )

        result_text = response.text.strip()
        if "```json" in result_text:
            start = result_text.find("```json") + 7
            end = result_text.find("```", start)
            result_text = result_text[start:end].strip()

        evaluation = json.loads(result_text)

        # Update interview
        interview.evaluation = evaluation
        interview.overall_score = evaluation["overall_score"]
        interview.feedback = evaluation["feedback"]
        interview.strengths = evaluation["strengths"]
        interview.improvements = evaluation["improvements"]
        interview.status = "completed"
        interview.completed_at = datetime.utcnow()

        db.commit()

        return evaluation

    except Exception as e:
        print(f"Error evaluating interview: {e}")
        raise HTTPException(status_code=500, detail="Failed to evaluate interview")


@router.get("/interviews/{interview_id}")
def get_interview(
    interview_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Get mock interview details"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    interview = (
        db.query(MockInterview)
        .filter(
            MockInterview.id == interview_id,
            MockInterview.student_profile_id == profile.id,
        )
        .first()
    )

    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found")

    return interview


# ==================== RESUME IMPROVEMENT ====================


@router.post("/resumes/{resume_id}/improve")
async def improve_resume(
    resume_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """AI-powered resume improvement - generates professional PDF"""

    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    resume = (
        db.query(Resume)
        .filter(Resume.id == resume_id, Resume.student_profile_id == profile.id)
        .first()
    )

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    if not resume.extracted_text:
        raise HTTPException(
            status_code=400, detail="Resume text not available for improvement"
        )

    # Get AI-improved structured resume data
    print(f"🤖 Improving resume with AI...")
    resume_data = await gemini_service.improve_resume_structured(resume.extracted_text)

    # Generate professional PDF - CHANGED: Use factory function
    from app.services.pdf_service import create_pdf_generator

    pdf_generator = create_pdf_generator()  # Changed from ATSResumePDFGenerator()

    # Create file path
    file_name = f"improved_{resume.file_name.replace('.pdf', '_ATS_Optimized.pdf')}"
    file_path = os.path.join(settings.UPLOAD_DIR, f"{resume_id}_improved.pdf")

    print(f"📄 Generating PDF: {file_path}")

    # Generate PDF
    pdf_generator.generate_resume(resume_data, output_path=file_path)

    # Get file size
    file_size = os.path.getsize(file_path)

    # Save improved resume record
    improved_resume = ImprovedResume(
        original_resume_id=resume_id,
        student_profile_id=profile.id,
        file_name=file_name,
        file_path=file_path,
        improvement_notes=resume_data,  # Store structured data
        ats_score_before=resume.ats_score or 0,
        ats_score_after=resume_data.get("estimated_ats_score", 90),
    )

    db.add(improved_resume)
    db.commit()
    db.refresh(improved_resume)

    print(f"✅ Improved resume created successfully")
    print(f"   File: {file_name}")
    print(f"   Size: {file_size / 1024:.2f} KB")
    print(
        f"   ATS Score: {improved_resume.ats_score_before} → {improved_resume.ats_score_after}"
    )

    return {
        "improved_resume_id": improved_resume.id,
        "file_name": file_name,
        "file_size": file_size,
        "improvements_made": resume_data.get("improvements_made", []),
        "ats_score_before": improved_resume.ats_score_before,
        "ats_score_after": improved_resume.ats_score_after,
        "download_available": True,
    }


@router.get("/resumes/{resume_id}/improved")
def get_improved_resume(
    resume_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Get improved resume details"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    improved = (
        db.query(ImprovedResume)
        .filter(
            ImprovedResume.original_resume_id == resume_id,
            ImprovedResume.student_profile_id == profile.id,
        )
        .order_by(desc(ImprovedResume.created_at))
        .first()
    )

    if not improved:
        raise HTTPException(status_code=404, detail="No improved version found")

    return improved


@router.get("/resumes/improved/{improved_id}/download")
def download_improved_resume(
    improved_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Download improved resume PDF"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    improved = (
        db.query(ImprovedResume)
        .filter(
            ImprovedResume.id == improved_id,
            ImprovedResume.student_profile_id == profile.id,
        )
        .first()
    )

    if not improved:
        raise HTTPException(status_code=404, detail="Improved resume not found")

    if not os.path.exists(improved.file_path):
        raise HTTPException(status_code=404, detail="File not found")

    # Determine media type based on file extension
    media_type = (
        "application/pdf" if improved.file_path.endswith(".pdf") else "text/plain"
    )

    return FileResponse(
        improved.file_path,
        media_type=media_type,
        filename=improved.file_name,
        headers={"Content-Disposition": f"attachment; filename={improved.file_name}"},
    )


# ==================== ANALYTICS & HISTORY ====================


@router.get("/analytics/history")
def get_student_history(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get complete student activity history"""

    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Get all resumes with analyses
    resumes = (
        db.query(Resume)
        .filter(Resume.student_profile_id == profile.id)
        .order_by(desc(Resume.upload_date))
        .all()
    )

    resume_history = []
    for resume in resumes:
        analyses = (
            db.query(ResumeAnalysis)
            .filter(ResumeAnalysis.resume_id == resume.id)
            .order_by(desc(ResumeAnalysis.analysis_date))
            .all()
        )

        resume_history.append(
            {
                "resume_id": resume.id,
                "file_name": resume.file_name,
                "upload_date": resume.upload_date,
                "ats_score": resume.ats_score,
                "file_size": resume.file_size,
                "analyses_count": len(analyses),
                "latest_analysis": analyses[0] if analyses else None,
            }
        )

    # Get all applications
    applications = (
        db.query(Application)
        .filter(Application.student_profile_id == profile.id)
        .order_by(desc(Application.applied_date))
        .all()
    )

    application_history = []
    for app in applications:
        job = app.job_description
        application_history.append(
            {
                "application_id": app.id,
                "job_title": job.title if job else "Unknown",
                "company": job.hr_profile.company_name
                if job and job.hr_profile
                else "Unknown",
                "applied_date": app.applied_date,
                "status": app.status,
                "ats_score": app.ats_score,
                "last_update": app.last_status_update,
            }
        )

    # Get all job comparisons
    comparisons = (
        db.query(JobComparison)
        .filter(JobComparison.student_profile_id == profile.id)
        .order_by(desc(JobComparison.created_at))
        .all()
    )

    comparison_history = []
    for comp in comparisons:
        job_title = "Custom Job"
        if comp.job_description:
            job_title = comp.job_description.title

        comparison_history.append(
            {
                "comparison_id": comp.id,
                "job_title": job_title,
                "created_at": comp.created_at,
                "success_probability": comp.success_probability,
                "success_level": comp.success_level,
            }
        )

    # Get all mock interviews
    interviews = (
        db.query(MockInterview)
        .filter(MockInterview.student_profile_id == profile.id)
        .order_by(desc(MockInterview.created_at))
        .all()
    )

    interview_history = []
    for interview in interviews:
        interview_history.append(
            {
                "interview_id": interview.id,
                "status": interview.status,
                "overall_score": interview.overall_score,
                "created_at": interview.created_at,
                "completed_at": interview.completed_at,
            }
        )

    # Overall statistics
    from sqlalchemy import func

    stats = {
        "total_resumes": len(resumes),
        "total_applications": len(applications),
        "total_comparisons": len(comparisons),
        "total_interviews": len(interviews),
        "average_ats_score": db.query(func.avg(Resume.ats_score))
        .filter(Resume.student_profile_id == profile.id)
        .scalar()
        or 0,
        "applications_by_status": {},
    }

    # Count applications by status
    for app in applications:
        status = app.status.value
        stats["applications_by_status"][status] = (
            stats["applications_by_status"].get(status, 0) + 1
        )

    return {
        "statistics": stats,
        "resume_history": resume_history,
        "application_history": application_history,
        "comparison_history": comparison_history,
        "interview_history": interview_history,
    }


# ==================== APPLICATION MANAGEMENT ====================


@router.delete("/applications/{application_id}")
def delete_application(
    application_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Delete an application"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    application = (
        db.query(Application)
        .filter(
            Application.id == application_id,
            Application.student_profile_id == profile.id,
        )
        .first()
    )

    if not application:
        raise HTTPException(status_code=404, detail="Application not found")

    db.delete(application)
    db.commit()

    return {"message": "Application deleted successfully"}


@router.put("/applications/{application_id}/withdraw")
def withdraw_application(
    application_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Withdraw an application"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    application = (
        db.query(Application)
        .filter(
            Application.id == application_id,
            Application.student_profile_id == profile.id,
        )
        .first()
    )

    if not application:
        raise HTTPException(status_code=404, detail="Application not found")

    application.status = ApplicationStatus.WITHDRAWN
    application.last_status_update = datetime.utcnow()
    db.commit()

    return {"message": "Application withdrawn successfully"}


# ==================== GET EXISTING DATA (CACHE FIRST) ====================


@router.get("/comparisons/job/{job_id}/resume/{resume_id}")
def get_existing_comparison(
    job_id: str,
    resume_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Get existing comparison if it exists (cache-first approach)"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Check if comparison already exists
    comparison = (
        db.query(JobComparison)
        .filter(
            JobComparison.student_profile_id == profile.id,
            JobComparison.resume_id == resume_id,
            JobComparison.job_description_id == job_id,
        )
        .order_by(desc(JobComparison.created_at))
        .first()
    )

    if not comparison:
        return {"exists": False, "comparison": None}

    # Get associated courses if they exist
    courses = (
        db.query(CourseSuggestion)
        .filter(CourseSuggestion.job_comparison_id == comparison.id)
        .all()
    )

    # Get associated interview if it exists
    interview = (
        db.query(MockInterview)
        .filter(MockInterview.job_comparison_id == comparison.id)
        .order_by(desc(MockInterview.created_at))
        .first()
    )

    return {
        "exists": True,
        "comparison": {
            "comparison_id": comparison.id,
            "job_id": comparison.job_description_id,
            "job_title": comparison.job_description.title
            if comparison.job_description
            else "Custom Job",
            "success_probability": comparison.success_probability,
            "success_level": comparison.success_level,
            "success_message": comparison.success_message,
            "scores": comparison.scores,
            "analysis": comparison.analysis,
            "next_steps": comparison.next_steps,
            "created_at": comparison.created_at,
        },
        "courses": [
            {
                "name": c.course_name,
                "platform": c.platform,
                "url": c.url,
                "skill_gap": c.skill_gap,
                "reason": c.reason,
                "relevance_score": c.relevance_score,
                "platform_logo": f"https://logo.clearbit.com/{c.platform.split()[0].lower()}.com",
            }
            for c in courses
        ]
        if courses
        else None,
        "interview": {
            "interview_id": interview.id,
            "status": interview.status,
            "overall_score": interview.overall_score,
            "created_at": interview.created_at,
        }
        if interview
        else None,
    }


@router.get("/comparisons/{comparison_id}/courses")
def get_comparison_courses(
    comparison_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Get existing course suggestions for a comparison"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Verify comparison belongs to user
    comparison = (
        db.query(JobComparison)
        .filter(
            JobComparison.id == comparison_id,
            JobComparison.student_profile_id == profile.id,
        )
        .first()
    )

    if not comparison:
        raise HTTPException(status_code=404, detail="Comparison not found")

    courses = (
        db.query(CourseSuggestion)
        .filter(CourseSuggestion.job_comparison_id == comparison_id)
        .all()
    )

    if not courses:
        return {"exists": False, "courses": []}

    return {
        "exists": True,
        "courses": [
            {
                "name": c.course_name,
                "platform": c.platform,
                "url": c.url,
                "skill_gap": c.skill_gap,
                "reason": c.reason,
                "relevance_score": c.relevance_score,
                "platform_logo": f"https://logo.clearbit.com/{c.platform.split()[0].lower()}.com",
                "estimated_duration": "Self-paced",
                "level": "All Levels",
            }
            for c in courses
        ],
    }


@router.get("/comparisons/{comparison_id}/interviews")
def get_comparison_interviews(
    comparison_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Get existing interviews for a comparison"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Verify comparison belongs to user
    comparison = (
        db.query(JobComparison)
        .filter(
            JobComparison.id == comparison_id,
            JobComparison.student_profile_id == profile.id,
        )
        .first()
    )

    if not comparison:
        raise HTTPException(status_code=404, detail="Comparison not found")

    interviews = (
        db.query(MockInterview)
        .filter(MockInterview.job_comparison_id == comparison_id)
        .order_by(desc(MockInterview.created_at))
        .all()
    )

    return {
        "exists": len(interviews) > 0,
        "interviews": [
            {
                "interview_id": i.id,
                "status": i.status,
                "overall_score": i.overall_score,
                "created_at": i.created_at,
                "completed_at": i.completed_at,
            }
            for i in interviews
        ],
    }
