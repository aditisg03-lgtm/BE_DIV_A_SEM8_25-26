from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from app.database import get_db
from app.models.user import User
from app.models.hr import HRProfile
from app.models.job import JobDescription, JobStatus
from app.schemas.job import (
    JobDescriptionCreate,
    JobDescriptionUpdate,
    JobDescriptionResponse,
)
from app.utils.dependencies import get_current_hr, get_current_user

router = APIRouter(prefix="/api/jobs", tags=["Jobs"])


@router.post("", response_model=JobDescriptionResponse)
def create_job(
    job_data: JobDescriptionCreate,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Create a new job description"""
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(
            status_code=404, detail="HR profile not found. Create profile first."
        )

    job = JobDescription(**job_data.model_dump(), hr_profile_id=hr_profile.id)
    db.add(job)
    db.commit()
    db.refresh(job)

    # Add applications count
    job_dict = JobDescriptionResponse.model_validate(job).model_dump()
    job_dict["applications_count"] = 0
    return job_dict


@router.get("", response_model=List[JobDescriptionResponse])
def get_jobs(
    status_filter: Optional[JobStatus] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get all jobs (filtered for HR, all active for students)"""
    query = db.query(JobDescription)

    # If HR, show only their jobs
    if current_user.role.value == "hr":
        hr_profile = (
            db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
        )
        if hr_profile:
            query = query.filter(JobDescription.hr_profile_id == hr_profile.id)
    else:
        # For students, show only active jobs
        query = query.filter(JobDescription.status == JobStatus.ACTIVE)

    if status_filter:
        query = query.filter(JobDescription.status == status_filter)

    jobs = query.offset(skip).limit(limit).all()

    # Add applications count
    result = []
    for job in jobs:
        job_dict = JobDescriptionResponse.model_validate(job).model_dump()
        job_dict["applications_count"] = len(job.applications)
        result.append(job_dict)

    return result


@router.get("/{job_id}", response_model=JobDescriptionResponse)
def get_job(
    job_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get a specific job"""
    job = db.query(JobDescription).filter(JobDescription.id == job_id).first()

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # If HR, check ownership
    if current_user.role.value == "hr":
        hr_profile = (
            db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
        )
        if hr_profile and job.hr_profile_id != hr_profile.id:
            raise HTTPException(
                status_code=403, detail="Not authorized to view this job"
            )

    job_dict = JobDescriptionResponse.model_validate(job).model_dump()
    job_dict["applications_count"] = len(job.applications)
    return job_dict


@router.put("/{job_id}", response_model=JobDescriptionResponse)
def update_job(
    job_id: str,
    job_data: JobDescriptionUpdate,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Update a job description"""
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    job = (
        db.query(JobDescription)
        .filter(
            JobDescription.id == job_id, JobDescription.hr_profile_id == hr_profile.id
        )
        .first()
    )

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    for field, value in job_data.model_dump(exclude_unset=True).items():
        setattr(job, field, value)

    db.commit()
    db.refresh(job)

    job_dict = JobDescriptionResponse.model_validate(job).model_dump()
    job_dict["applications_count"] = len(job.applications)
    return job_dict


@router.delete("/{job_id}")
def delete_job(
    job_id: str,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Delete a job description"""
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    job = (
        db.query(JobDescription)
        .filter(
            JobDescription.id == job_id, JobDescription.hr_profile_id == hr_profile.id
        )
        .first()
    )

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    db.delete(job)
    db.commit()

    return {"message": "Job deleted successfully"}


@router.post("/{job_id}/publish")
def publish_job(
    job_id: str,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Publish a job"""
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    job = (
        db.query(JobDescription)
        .filter(
            JobDescription.id == job_id, JobDescription.hr_profile_id == hr_profile.id
        )
        .first()
    )

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    job.status = JobStatus.ACTIVE
    job.posted_date = datetime.utcnow()
    db.commit()

    return {"message": "Job published successfully"}


@router.post("/{job_id}/close")
def close_job(
    job_id: str,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Close a job"""
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    job = (
        db.query(JobDescription)
        .filter(
            JobDescription.id == job_id, JobDescription.hr_profile_id == hr_profile.id
        )
        .first()
    )

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    job.status = JobStatus.CLOSED
    db.commit()

    return {"message": "Job closed successfully"}
