from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.user import User
from app.models.student import StudentProfile, Education, WorkExperience, Skill
from app.schemas.student import (
    StudentProfileCreate,
    StudentProfileUpdate,
    StudentProfileResponse,
    EducationCreate,
    EducationUpdate,
    EducationResponse,
    WorkExperienceCreate,
    WorkExperienceUpdate,
    WorkExperienceResponse,
    SkillCreate,
    SkillUpdate,
    SkillResponse,
)
from app.utils.dependencies import get_current_student

router = APIRouter(prefix="/api/student", tags=["Student"])


# Profile endpoints
@router.get("/profile", response_model=StudentProfileResponse)
def get_profile(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get student profile"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile


@router.post("/profile", response_model=StudentProfileResponse)
def create_profile(
    profile_data: StudentProfileCreate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Create student profile"""
    existing = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Profile already exists")

    profile = StudentProfile(**profile_data.model_dump(), user_id=current_user.id)
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile


@router.put("/profile", response_model=StudentProfileResponse)
def update_profile(
    profile_data: StudentProfileUpdate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Update student profile"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    for field, value in profile_data.model_dump(exclude_unset=True).items():
        setattr(profile, field, value)

    db.commit()
    db.refresh(profile)
    return profile


# Education endpoints
@router.get("/education", response_model=List[EducationResponse])
def get_education(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get all education records"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        return []
    return profile.education


@router.post("/education", response_model=EducationResponse)
def create_education(
    education_data: EducationCreate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Create education record"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(
            status_code=404, detail="Profile not found. Create profile first."
        )

    education = Education(**education_data.model_dump(), student_profile_id=profile.id)
    db.add(education)
    db.commit()
    db.refresh(education)
    return education


@router.put("/education/{education_id}", response_model=EducationResponse)
def update_education(
    education_id: str,
    education_data: EducationUpdate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Update education record"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    education = (
        db.query(Education)
        .filter(
            Education.id == education_id, Education.student_profile_id == profile.id
        )
        .first()
    )

    if not education:
        raise HTTPException(status_code=404, detail="Education record not found")

    for field, value in education_data.model_dump(exclude_unset=True).items():
        setattr(education, field, value)

    db.commit()
    db.refresh(education)
    return education


@router.delete("/education/{education_id}")
def delete_education(
    education_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Delete education record"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    education = (
        db.query(Education)
        .filter(
            Education.id == education_id, Education.student_profile_id == profile.id
        )
        .first()
    )

    if not education:
        raise HTTPException(status_code=404, detail="Education record not found")

    db.delete(education)
    db.commit()
    return {"message": "Education record deleted successfully"}


# Work Experience endpoints
@router.get("/experience", response_model=List[WorkExperienceResponse])
def get_experience(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get all work experience records"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        return []
    return profile.work_experiences


@router.post("/experience", response_model=WorkExperienceResponse)
def create_experience(
    experience_data: WorkExperienceCreate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Create work experience record"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(
            status_code=404, detail="Profile not found. Create profile first."
        )

    experience = WorkExperience(
        **experience_data.model_dump(), student_profile_id=profile.id
    )
    db.add(experience)
    db.commit()
    db.refresh(experience)
    return experience


@router.put("/experience/{experience_id}", response_model=WorkExperienceResponse)
def update_experience(
    experience_id: str,
    experience_data: WorkExperienceUpdate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Update work experience record"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    experience = (
        db.query(WorkExperience)
        .filter(
            WorkExperience.id == experience_id,
            WorkExperience.student_profile_id == profile.id,
        )
        .first()
    )

    if not experience:
        raise HTTPException(status_code=404, detail="Work experience record not found")

    for field, value in experience_data.model_dump(exclude_unset=True).items():
        setattr(experience, field, value)

    db.commit()
    db.refresh(experience)
    return experience


@router.delete("/experience/{experience_id}")
def delete_experience(
    experience_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Delete work experience record"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    experience = (
        db.query(WorkExperience)
        .filter(
            WorkExperience.id == experience_id,
            WorkExperience.student_profile_id == profile.id,
        )
        .first()
    )

    if not experience:
        raise HTTPException(status_code=404, detail="Work experience record not found")

    db.delete(experience)
    db.commit()
    return {"message": "Work experience record deleted successfully"}


# Skills endpoints
@router.get("/skills", response_model=List[SkillResponse])
def get_skills(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get all skills"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        return []
    return profile.skills


@router.post("/skills", response_model=SkillResponse)
def create_skill(
    skill_data: SkillCreate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Create skill"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(
            status_code=404, detail="Profile not found. Create profile first."
        )

    skill = Skill(**skill_data.model_dump(), student_profile_id=profile.id)
    db.add(skill)
    db.commit()
    db.refresh(skill)
    return skill


@router.put("/skills/{skill_id}", response_model=SkillResponse)
def update_skill(
    skill_id: str,
    skill_data: SkillUpdate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Update skill"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    skill = (
        db.query(Skill)
        .filter(Skill.id == skill_id, Skill.student_profile_id == profile.id)
        .first()
    )

    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")

    for field, value in skill_data.model_dump(exclude_unset=True).items():
        setattr(skill, field, value)

    db.commit()
    db.refresh(skill)
    return skill


@router.delete("/skills/{skill_id}")
def delete_skill(
    skill_id: str,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Delete skill"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    skill = (
        db.query(Skill)
        .filter(Skill.id == skill_id, Skill.student_profile_id == profile.id)
        .first()
    )

    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")

    db.delete(skill)
    db.commit()
    return {"message": "Skill deleted successfully"}
