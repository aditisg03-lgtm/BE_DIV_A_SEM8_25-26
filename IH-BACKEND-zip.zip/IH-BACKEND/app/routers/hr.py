from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.user import User
from app.models.hr import HRProfile
from app.schemas.hr import HRProfileCreate, HRProfileUpdate, HRProfileResponse
from app.utils.dependencies import get_current_hr

router = APIRouter(prefix="/api/hr", tags=["HR"])


@router.get("/profile", response_model=HRProfileResponse)
def get_profile(
    current_user: User = Depends(get_current_hr), db: Session = Depends(get_db)
):
    """Get HR profile"""
    profile = db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile


@router.post("/profile", response_model=HRProfileResponse)
def create_profile(
    profile_data: HRProfileCreate,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Create HR profile"""
    existing = db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Profile already exists")

    profile = HRProfile(**profile_data.model_dump(), user_id=current_user.id)
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile


@router.put("/profile", response_model=HRProfileResponse)
def update_profile(
    profile_data: HRProfileUpdate,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Update HR profile"""
    profile = db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    for field, value in profile_data.model_dump(exclude_unset=True).items():
        setattr(profile, field, value)

    db.commit()
    db.refresh(profile)
    return profile
