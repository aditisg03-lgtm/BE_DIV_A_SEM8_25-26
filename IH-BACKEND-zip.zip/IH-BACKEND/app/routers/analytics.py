from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from app.database import get_db
from app.models.user import User
from app.models.student import StudentProfile
from app.models.hr import HRProfile
from app.models.application import Application, ApplicationStatus
from app.models.resume import Resume
from app.models.job import JobDescription
from app.models.bulk_upload import BulkUploadBatch, BulkCandidateAnalysis
from app.utils.dependencies import get_current_student, get_current_hr

router = APIRouter(prefix="/api/analytics", tags=["Analytics"])


@router.get("/student/overview")
def get_student_overview(
    current_user: User = Depends(get_current_student), db: Session = Depends(get_db)
):
    """Get student analytics overview"""
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )

    if not profile:
        return {
            "total_applications": 0,
            "average_ats_score": 0,
            "total_resumes": 0,
            "application_status_breakdown": {},
        }

    # Get statistics
    total_applications = (
        db.query(Application)
        .filter(Application.student_profile_id == profile.id)
        .count()
    )

    avg_ats_score = (
        db.query(func.avg(Resume.ats_score))
        .filter(Resume.student_profile_id == profile.id)
        .scalar()
        or 0
    )

    total_resumes = (
        db.query(Resume).filter(Resume.student_profile_id == profile.id).count()
    )

    # Application status breakdown
    status_breakdown = (
        db.query(Application.status, func.count(Application.id))
        .filter(Application.student_profile_id == profile.id)
        .group_by(Application.status)
        .all()
    )

    status_dict = {status.value: count for status, count in status_breakdown}

    return {
        "total_applications": total_applications,
        "average_ats_score": round(float(avg_ats_score), 2),
        "total_resumes": total_resumes,
        "application_status_breakdown": status_dict,
    }


# ✅ NEW: HR Dashboard Analytics
@router.get("/hr/dashboard")
def get_hr_dashboard_analytics(
    current_user: User = Depends(get_current_hr), db: Session = Depends(get_db)
):
    """Get comprehensive HR dashboard analytics for Recharts"""

    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )

    if not hr_profile:
        return {
            "overview": {},
            "applications_by_job": [],
            "applications_by_status": [],
            "bulk_uploads_by_job": [],
            "ats_score_distribution": [],
            "recent_activity": [],
        }

    # Get all job IDs for this HR
    job_ids = [job.id for job in hr_profile.job_descriptions]

    # Overview Stats
    total_jobs = len(hr_profile.job_descriptions)
    active_jobs = len(
        [j for j in hr_profile.job_descriptions if j.status.value == "active"]
    )

    total_applications = (
        db.query(Application)
        .filter(Application.job_description_id.in_(job_ids))
        .count()
    )

    pending_review = (
        db.query(Application)
        .filter(
            Application.job_description_id.in_(job_ids),
            Application.status == ApplicationStatus.SUBMITTED,
        )
        .count()
    )

    # Applications by Job (for bar chart)
    applications_by_job = (
        db.query(JobDescription.title, func.count(Application.id).label("count"))
        .join(
            Application,
            Application.job_description_id == JobDescription.id,
            isouter=True,
        )
        .filter(JobDescription.hr_profile_id == hr_profile.id)
        .group_by(JobDescription.id, JobDescription.title)
        .all()
    )

    # Applications by Status (for pie chart)
    applications_by_status = (
        db.query(Application.status, func.count(Application.id).label("count"))
        .filter(Application.job_description_id.in_(job_ids))
        .group_by(Application.status)
        .all()
    )

    # Bulk Uploads by Job
    bulk_uploads_by_job = (
        db.query(
            JobDescription.title,
            func.count(BulkUploadBatch.id).label("batches"),
            func.sum(BulkUploadBatch.successful_count).label("total_candidates"),
        )
        .join(
            BulkUploadBatch,
            BulkUploadBatch.job_description_id == JobDescription.id,
            isouter=True,
        )
        .filter(JobDescription.hr_profile_id == hr_profile.id)
        .group_by(JobDescription.id, JobDescription.title)
        .all()
    )

    # ATS Score Distribution (from bulk uploads)
    ats_scores = (
        db.query(BulkCandidateAnalysis.ats_score)
        .join(BulkUploadBatch)
        .filter(BulkUploadBatch.hr_profile_id == hr_profile.id)
        .all()
    )

    # Categorize ATS scores for distribution chart
    score_ranges = {
        "0-20": 0,
        "21-40": 0,
        "41-60": 0,
        "61-80": 0,
        "81-100": 0,
    }

    for (score,) in ats_scores:
        if score <= 20:
            score_ranges["0-20"] += 1
        elif score <= 40:
            score_ranges["21-40"] += 1
        elif score <= 60:
            score_ranges["41-60"] += 1
        elif score <= 80:
            score_ranges["61-80"] += 1
        else:
            score_ranges["81-100"] += 1

    # Recent Activity
    recent_applications = (
        db.query(Application)
        .filter(Application.job_description_id.in_(job_ids))
        .order_by(desc(Application.applied_date))
        .limit(5)
        .all()
    )

    recent_bulk_uploads = (
        db.query(BulkUploadBatch)
        .filter(BulkUploadBatch.hr_profile_id == hr_profile.id)
        .order_by(desc(BulkUploadBatch.upload_date))
        .limit(5)
        .all()
    )

    return {
        "overview": {
            "total_jobs": total_jobs,
            "active_jobs": active_jobs,
            "total_applications": total_applications,
            "pending_review": pending_review,
        },
        "applications_by_job": [
            {"job": title, "applications": count}
            for title, count in applications_by_job
        ],
        "applications_by_status": [
            {"status": status.value, "count": count}
            for status, count in applications_by_status
        ],
        "bulk_uploads_by_job": [
            {
                "job": title,
                "batches": batches or 0,
                "candidates": int(total_candidates or 0),
            }
            for title, batches, total_candidates in bulk_uploads_by_job
        ],
        "ats_score_distribution": [
            {"range": range_name, "count": count}
            for range_name, count in score_ranges.items()
        ],
        "recent_activity": {
            "applications": [
                {
                    "id": app.id,
                    "job_title": app.job_description.title,
                    "date": app.applied_date,
                    "status": app.status.value,
                }
                for app in recent_applications
            ],
            "bulk_uploads": [
                {
                    "id": batch.id,
                    "job_title": batch.job_description.title
                    if batch.job_description
                    else "Deleted",
                    "date": batch.upload_date,
                    "candidates": batch.successful_count,
                }
                for batch in recent_bulk_uploads
            ],
        },
    }


# ✅ NEW: Get applications grouped by source (student vs HR bulk)
@router.get("/hr/applications-summary")
def get_applications_summary(
    current_user: User = Depends(get_current_hr), db: Session = Depends(get_db)
):
    """Get applications summary separated by source"""

    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )

    if not hr_profile:
        return {
            "student_applications": [],
            "bulk_uploaded_candidates": [],
        }

    job_ids = [job.id for job in hr_profile.job_descriptions]

    # Student Applications (from students applying)
    student_applications = (
        db.query(Application)
        .filter(Application.job_description_id.in_(job_ids))
        .order_by(desc(Application.applied_date))
        .all()
    )

    # Bulk Uploaded Candidates (grouped by job)
    bulk_batches = (
        db.query(BulkUploadBatch)
        .filter(BulkUploadBatch.hr_profile_id == hr_profile.id)
        .order_by(desc(BulkUploadBatch.upload_date))
        .all()
    )

    bulk_by_job = {}
    for batch in bulk_batches:
        job_id = batch.job_description_id
        if job_id not in bulk_by_job:
            bulk_by_job[job_id] = {
                "job_id": job_id,
                "job_title": batch.job_description.title
                if batch.job_description
                else "Deleted",
                "batches": [],
                "total_candidates": 0,
                "average_ats_score": 0,
            }

        bulk_by_job[job_id]["batches"].append(
            {
                "batch_id": batch.id,
                "upload_date": batch.upload_date,
                "candidates_count": batch.successful_count,
                "average_score": batch.average_ats_score,
            }
        )
        bulk_by_job[job_id]["total_candidates"] += batch.successful_count

    return {
        "student_applications": [
            {
                "id": app.id,
                "job_id": app.job_description_id,
                "job_title": app.job_description.title,
                "applied_date": app.applied_date,
                "status": app.status.value,
                "ats_score": app.ats_score,
            }
            for app in student_applications
        ],
        "bulk_uploaded_candidates": list(bulk_by_job.values()),
    }
