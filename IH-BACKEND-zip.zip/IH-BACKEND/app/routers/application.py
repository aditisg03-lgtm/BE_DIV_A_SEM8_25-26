from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime
from app.database import get_db
from app.models.user import User
from app.models.student import StudentProfile
from app.models.hr import HRProfile
from app.models.application import Application, ApplicationStatus
from app.models.resume import Resume
from app.models.job import JobDescription
from app.schemas.application import (
    ApplicationCreate,
    ApplicationUpdate,
    ApplicationResponse,
    InterviewScheduleCreate,
    InterviewScheduleResponse,
)
from app.utils.dependencies import get_current_user, get_current_student, get_current_hr

router = APIRouter(prefix="/api/applications", tags=["Applications"])


@router.post("/apply", response_model=ApplicationResponse)
def apply_to_job(
    application_data: ApplicationCreate,
    current_user: User = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    """Apply to a job"""
    # Get student profile
    profile = (
        db.query(StudentProfile)
        .filter(StudentProfile.user_id == current_user.id)
        .first()
    )
    if not profile:
        raise HTTPException(
            status_code=404, detail="Profile not found. Create profile first."
        )

    # Check if job exists
    job = (
        db.query(JobDescription)
        .filter(JobDescription.id == application_data.job_description_id)
        .first()
    )
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Check if resume exists
    resume = (
        db.query(Resume)
        .filter(
            Resume.id == application_data.resume_id,
            Resume.student_profile_id == profile.id,
        )
        .first()
    )
    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    # Check if already applied
    existing = (
        db.query(Application)
        .filter(
            Application.job_description_id == application_data.job_description_id,
            Application.student_profile_id == profile.id,
        )
        .first()
    )

    if existing:
        raise HTTPException(status_code=400, detail="Already applied to this job")

    # Create application
    application = Application(
        job_description_id=application_data.job_description_id,
        student_profile_id=profile.id,
        resume_id=application_data.resume_id,
        ats_score=resume.ats_score,
    )

    db.add(application)
    db.commit()
    db.refresh(application)

    return application


@router.get("", response_model=List[ApplicationResponse])
def get_applications(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    """Get applications (student: their applications, HR: applications to their jobs)"""
    if current_user.role.value == "student":
        profile = (
            db.query(StudentProfile)
            .filter(StudentProfile.user_id == current_user.id)
            .first()
        )
        if not profile:
            return []
        applications = (
            db.query(Application)
            .filter(Application.student_profile_id == profile.id)
            .all()
        )
    else:  # HR
        hr_profile = (
            db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
        )
        if not hr_profile:
            return []

        # Get all applications to HR's jobs
        job_ids = [job.id for job in hr_profile.job_descriptions]
        applications = (
            db.query(Application)
            .filter(Application.job_description_id.in_(job_ids))
            .all()
        )

    return applications


@router.get("/{application_id}", response_model=ApplicationResponse)
def get_application(
    application_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get a specific application"""
    application = db.query(Application).filter(Application.id == application_id).first()

    if not application:
        raise HTTPException(status_code=404, detail="Application not found")

    # Check authorization
    if current_user.role.value == "student":
        profile = (
            db.query(StudentProfile)
            .filter(StudentProfile.user_id == current_user.id)
            .first()
        )
        if not profile or application.student_profile_id != profile.id:
            raise HTTPException(status_code=403, detail="Not authorized")
    else:  # HR
        hr_profile = (
            db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
        )
        if not hr_profile:
            raise HTTPException(status_code=403, detail="Not authorized")

        job = (
            db.query(JobDescription)
            .filter(JobDescription.id == application.job_description_id)
            .first()
        )
        if not job or job.hr_profile_id != hr_profile.id:
            raise HTTPException(status_code=403, detail="Not authorized")

    return application


@router.put("/{application_id}/status", response_model=ApplicationResponse)
def update_application_status(
    application_id: str,
    application_data: ApplicationUpdate,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Update application status (HR only)"""
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    application = db.query(Application).filter(Application.id == application_id).first()
    if not application:
        raise HTTPException(status_code=404, detail="Application not found")

    # Check if job belongs to HR
    job = (
        db.query(JobDescription)
        .filter(JobDescription.id == application.job_description_id)
        .first()
    )
    if not job or job.hr_profile_id != hr_profile.id:
        raise HTTPException(status_code=403, detail="Not authorized")

    # Update application
    if application_data.status:
        application.status = application_data.status
        application.last_status_update = datetime.utcnow()

    if application_data.hr_notes is not None:
        application.hr_notes = application_data.hr_notes

    db.commit()
    db.refresh(application)

    return application
