from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List
import os
import uuid
from PyPDF2 import PdfReader
from io import BytesIO
from datetime import datetime
from app.database import get_db
from app.models.user import User
from app.models.hr import HRProfile
from app.models.job import JobDescription
from app.models.bulk_upload import BulkUploadBatch, BulkCandidateAnalysis
from app.utils.dependencies import get_current_hr
from app.services.gemini_service import gemini_service
from app.services.ats_service import ats_service
from app.config import settings

router = APIRouter(prefix="/api/hr/resumes", tags=["HR Resume Management"])


def extract_text_from_pdf(file_content: bytes) -> str:
    """Extract text from PDF file"""
    try:
        pdf_file = BytesIO(file_content)
        pdf_reader = PdfReader(pdf_file)
        text = ""
        for page in pdf_reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        return text.strip()
    except Exception as e:
        print(f"Error extracting PDF text: {str(e)}")
        return ""


@router.post("/bulk-upload")
async def bulk_upload_resumes(
    files: List[UploadFile] = File(...),
    job_id: str = Form(...),
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Bulk upload and analyze resumes for a specific job using Gemini AI - SAVES TO DATABASE"""

    # Verify HR profile
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    # Verify job exists and belongs to HR
    job = (
        db.query(JobDescription)
        .filter(
            JobDescription.id == job_id, JobDescription.hr_profile_id == hr_profile.id
        )
        .first()
    )

    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Check file count
    if len(files) > 20:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Maximum 20 files allowed per upload",
        )

    # Create comprehensive job description for AI analysis
    job_description_text = f"""
JOB TITLE: {job.title}
DEPARTMENT: {job.department or "Not specified"}
LOCATION: {job.location}
EMPLOYMENT TYPE: {job.employment_type}
EXPERIENCE LEVEL: {job.experience_level}

JOB DESCRIPTION:
{job.description}

REQUIRED QUALIFICATIONS:
{chr(10).join(["- " + req for req in job.requirements]) if job.requirements else "None specified"}

KEY RESPONSIBILITIES:
{chr(10).join(["- " + resp for resp in job.responsibilities]) if job.responsibilities else "None specified"}

REQUIRED SKILLS:
{", ".join([skill.get("name", str(skill)) if isinstance(skill, dict) else str(skill) for skill in job.required_skills]) if job.required_skills else "None specified"}

PREFERRED QUALIFICATIONS:
{chr(10).join(["- " + qual for qual in job.preferred_qualifications]) if job.preferred_qualifications else "None specified"}

SALARY RANGE: ${job.salary_min or "Not specified"} - ${job.salary_max or "Not specified"}
"""

    results = []
    successful_analyses = []

    print(f"\n{'=' * 80}")
    print(f"BULK RESUME ANALYSIS STARTED")
    print(f"Job: {job.title}")
    print(f"Total Files: {len(files)}")
    print(f"{'=' * 80}\n")

    for idx, file in enumerate(files, 1):
        print(f"\n[{idx}/{len(files)}] Processing: {file.filename}")

        # Validate file type
        if not file.filename.endswith(".pdf"):
            result = {
                "filename": file.filename,
                "status": "error",
                "message": "Only PDF files are allowed",
                "ats_score": 0,
            }
            results.append(result)
            print(f"❌ Error: Not a PDF file")
            continue

        try:
            # Read file content
            content = await file.read()
            file_size = len(content)

            # Check file size
            if file_size > settings.MAX_FILE_SIZE:
                result = {
                    "filename": file.filename,
                    "status": "error",
                    "message": f"File size exceeds {settings.MAX_FILE_SIZE} bytes",
                    "ats_score": 0,
                }
                results.append(result)
                print(f"❌ Error: File too large ({file_size} bytes)")
                continue

            # Extract text from PDF
            print(f"📄 Extracting text from PDF...")
            extracted_text = extract_text_from_pdf(content)

            if not extracted_text or len(extracted_text) < 50:
                result = {
                    "filename": file.filename,
                    "status": "error",
                    "message": "Could not extract sufficient text from PDF. File may be image-based or corrupted.",
                    "ats_score": 0,
                }
                results.append(result)
                print(
                    f"❌ Error: Insufficient text extracted ({len(extracted_text)} chars)"
                )
                continue

            print(f"✓ Extracted {len(extracted_text)} characters")

            # Send to Gemini AI for analysis
            print(f"🤖 Sending to Gemini AI for analysis...")
            analysis = await gemini_service.analyze_resume(
                extracted_text, job_description_text
            )

            print(
                f"✓ Analysis complete - ATS Score: {analysis.get('ats_score', 0):.1f}%"
            )

            # Prepare result with comprehensive analysis
            result = {
                "filename": file.filename,
                "status": "success",
                "file_size": file_size,
                "extracted_text_length": len(extracted_text),
                # Scores
                "ats_score": analysis.get("ats_score", 0),
                "keyword_match": analysis.get("keyword_match_percentage", 0),
                # Candidate Info
                "candidate_name": analysis.get("candidate_name", "Not found"),
                "contact_email": analysis.get("contact_email", "Not found"),
                "contact_phone": analysis.get("contact_phone", "Not found"),
                "location": analysis.get("location", "Not specified"),
                "total_years_experience": analysis.get("total_years_experience"),
                # Analysis
                "strengths": analysis.get("strengths", []),
                "weaknesses": analysis.get("weaknesses", []),
                "improvement_suggestions": analysis.get("improvement_suggestions", []),
                "key_achievements": analysis.get("key_achievements", []),
                # Matches
                "skills_match": analysis.get("skills_match", {}),
                "experience_match": analysis.get("experience_match", {}),
                "education_match": analysis.get("education_match", {}),
                # Summary
                "overall_feedback": analysis.get("overall_feedback", ""),
                "recommendation": analysis.get("recommendation", "PENDING"),
                # Raw data for detailed view
                "extracted_text_preview": extracted_text[:500],
                "full_analysis": analysis,
            }

            results.append(result)
            successful_analyses.append(result)

        except Exception as e:
            print(f"❌ Error processing {file.filename}: {str(e)}")
            result = {
                "filename": file.filename,
                "status": "error",
                "message": f"Processing error: {str(e)}",
                "ats_score": 0,
            }
            results.append(result)

    # Sort successful results by ATS score (highest first)
    successful_analyses.sort(key=lambda x: x.get("ats_score", 0), reverse=True)

    # Calculate aggregate statistics
    total_uploaded = len(files)
    successful_count = len([r for r in results if r["status"] == "success"])
    failed_count = total_uploaded - successful_count

    avg_ats_score = (
        sum(r.get("ats_score", 0) for r in successful_analyses) / successful_count
        if successful_count > 0
        else 0
    )

    highest_score = (
        successful_analyses[0].get("ats_score", 0) if successful_analyses else 0
    )
    lowest_score = (
        successful_analyses[-1].get("ats_score", 0) if successful_analyses else 0
    )

    # Categorize candidates
    highly_recommended = [r for r in successful_analyses if r.get("ats_score", 0) >= 80]
    recommended = [r for r in successful_analyses if 60 <= r.get("ats_score", 0) < 80]
    consider = [r for r in successful_analyses if 40 <= r.get("ats_score", 0) < 60]
    not_recommended = [r for r in successful_analyses if r.get("ats_score", 0) < 40]

    # ✅ SAVE TO DATABASE
    print(f"\n💾 Saving results to database...")

    # Create batch record
    batch = BulkUploadBatch(
        hr_profile_id=hr_profile.id,
        job_description_id=job_id,
        total_uploaded=total_uploaded,
        successful_count=successful_count,
        failed_count=failed_count,
        average_ats_score=avg_ats_score,
        highest_score=highest_score,
        lowest_score=lowest_score,
        statistics={
            "highly_recommended_count": len(highly_recommended),
            "recommended_count": len(recommended),
            "consider_count": len(consider),
            "not_recommended_count": len(not_recommended),
        },
    )
    db.add(batch)
    db.flush()  # Get batch ID

    # Save individual candidate analyses
    for rank, candidate in enumerate(successful_analyses, 1):
        candidate_record = BulkCandidateAnalysis(
            batch_id=batch.id,
            filename=candidate["filename"],
            rank=rank,
            candidate_name=candidate.get("candidate_name"),
            contact_email=candidate.get("contact_email"),
            contact_phone=candidate.get("contact_phone"),
            location=candidate.get("location"),
            total_years_experience=candidate.get("total_years_experience"),
            ats_score=candidate["ats_score"],
            keyword_match=candidate.get("keyword_match"),
            skills_match=candidate.get("skills_match"),
            experience_match=candidate.get("experience_match"),
            education_match=candidate.get("education_match"),
            strengths=candidate.get("strengths"),
            weaknesses=candidate.get("weaknesses"),
            improvement_suggestions=candidate.get("improvement_suggestions"),
            key_achievements=candidate.get("key_achievements"),
            overall_feedback=candidate.get("overall_feedback"),
            recommendation=candidate.get("recommendation"),
            full_analysis=candidate.get("full_analysis"),
            extracted_text_preview=candidate.get("extracted_text_preview"),
        )
        db.add(candidate_record)

    db.commit()
    db.refresh(batch)

    print(f"✅ Saved batch ID: {batch.id}")
    print(f"✅ Saved {len(successful_analyses)} candidate analyses")

    print(f"\n{'=' * 80}")
    print(f"ANALYSIS COMPLETE")
    print(f"✓ Successful: {successful_count}/{total_uploaded}")
    print(f"✗ Failed: {failed_count}")
    print(f"📊 Average ATS Score: {avg_ats_score:.1f}%")
    print(f"{'=' * 80}\n")

    return {
        "batch_id": batch.id,  # ✅ NEW: Return batch ID
        "job_id": job_id,
        "job_title": job.title,
        "timestamp": datetime.utcnow().isoformat(),
        # Upload summary
        "total_uploaded": total_uploaded,
        "successful": successful_count,
        "failed": failed_count,
        # Statistics
        "statistics": {
            "average_ats_score": round(avg_ats_score, 2),
            "highest_score": highest_score,
            "lowest_score": lowest_score,
            "highly_recommended_count": len(highly_recommended),
            "recommended_count": len(recommended),
            "consider_count": len(consider),
            "not_recommended_count": len(not_recommended),
        },
        # Categorized results
        "highly_recommended": highly_recommended,
        "recommended": recommended,
        "consider": consider,
        "not_recommended": not_recommended,
        # All results (sorted by score)
        "results": results,
    }


# ✅ NEW ENDPOINT: Get saved batch results
@router.get("/batches")
def get_bulk_upload_batches(
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Get all bulk upload batches for current HR"""
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    batches = (
        db.query(BulkUploadBatch)
        .filter(BulkUploadBatch.hr_profile_id == hr_profile.id)
        .order_by(BulkUploadBatch.upload_date.desc())
        .all()
    )

    return [
        {
            "batch_id": batch.id,
            "job_title": batch.job_description.title
            if batch.job_description
            else "Deleted Job",
            "job_id": batch.job_description_id,
            "upload_date": batch.upload_date,
            "total_uploaded": batch.total_uploaded,
            "successful_count": batch.successful_count,
            "average_ats_score": batch.average_ats_score,
            "statistics": batch.statistics,
        }
        for batch in batches
    ]


# ✅ NEW ENDPOINT: Get specific batch results
@router.get("/batches/{batch_id}")
def get_batch_results(
    batch_id: str,
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Get detailed results for a specific batch"""
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    batch = (
        db.query(BulkUploadBatch)
        .filter(
            BulkUploadBatch.id == batch_id,
            BulkUploadBatch.hr_profile_id == hr_profile.id,
        )
        .first()
    )

    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")

    # Get all candidates for this batch
    candidates = (
        db.query(BulkCandidateAnalysis)
        .filter(BulkCandidateAnalysis.batch_id == batch_id)
        .order_by(BulkCandidateAnalysis.rank)
        .all()
    )

    # Format candidates
    formatted_candidates = [
        {
            "filename": c.filename,
            "rank": c.rank,
            "status": "success",
            "candidate_name": c.candidate_name,
            "contact_email": c.contact_email,
            "contact_phone": c.contact_phone,
            "location": c.location,
            "total_years_experience": c.total_years_experience,
            "ats_score": c.ats_score,
            "keyword_match": c.keyword_match,
            "skills_match": c.skills_match,
            "experience_match": c.experience_match,
            "education_match": c.education_match,
            "strengths": c.strengths,
            "weaknesses": c.weaknesses,
            "improvement_suggestions": c.improvement_suggestions,
            "key_achievements": c.key_achievements,
            "overall_feedback": c.overall_feedback,
            "recommendation": c.recommendation,
            "full_analysis": c.full_analysis,
            "extracted_text_preview": c.extracted_text_preview,
        }
        for c in candidates
    ]

    # Categorize
    highly_recommended = [c for c in formatted_candidates if c["ats_score"] >= 80]
    recommended = [c for c in formatted_candidates if 60 <= c["ats_score"] < 80]
    consider = [c for c in formatted_candidates if 40 <= c["ats_score"] < 60]
    not_recommended = [c for c in formatted_candidates if c["ats_score"] < 40]

    return {
        "batch_id": batch.id,
        "job_id": batch.job_description_id,
        "job_title": batch.job_description.title
        if batch.job_description
        else "Deleted Job",
        "upload_date": batch.upload_date,
        "total_uploaded": batch.total_uploaded,
        "successful": batch.successful_count,
        "failed": batch.failed_count,
        "statistics": {
            "average_ats_score": batch.average_ats_score,
            "highest_score": batch.highest_score,
            "lowest_score": batch.lowest_score,
            **batch.statistics,
        },
        "highly_recommended": highly_recommended,
        "recommended": recommended,
        "consider": consider,
        "not_recommended": not_recommended,
        "results": formatted_candidates,
    }


@router.post("/analyze-single")
async def analyze_single_resume(
    file: UploadFile = File(...),
    job_id: str = Form(None),
    current_user: User = Depends(get_current_hr),
    db: Session = Depends(get_db),
):
    """Analyze a single resume with Gemini AI"""

    # Verify HR profile
    hr_profile = (
        db.query(HRProfile).filter(HRProfile.user_id == current_user.id).first()
    )
    if not hr_profile:
        raise HTTPException(status_code=404, detail="HR profile not found")

    job_text = None
    job_title = "General Analysis"

    if job_id:
        job = (
            db.query(JobDescription)
            .filter(
                JobDescription.id == job_id,
                JobDescription.hr_profile_id == hr_profile.id,
            )
            .first()
        )

        if job:
            job_title = job.title
            job_text = f"""
Title: {job.title}
Description: {job.description}
Requirements: {", ".join(job.requirements) if job.requirements else "None"}
Required Skills: {", ".join([str(s) for s in job.required_skills]) if job.required_skills else "None"}
"""

    # Validate file
    if not file.filename.endswith(".pdf"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Only PDF files are allowed"
        )

    # Read and extract
    content = await file.read()
    extracted_text = extract_text_from_pdf(content)

    if not extracted_text:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Could not extract text from PDF",
        )

    # Analyze with Gemini
    analysis = await gemini_service.analyze_resume(extracted_text, job_text)

    return {
        "filename": file.filename,
        "job_title": job_title,
        "analysis": analysis,
        "extracted_text_length": len(extracted_text),
    }
