from sqlalchemy import (
    Column,
    String,
    DateTime,
    Integer,
    Float,
    Boolean,
    ForeignKey,
    Text,
    JSON,
)
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base
from app.models.user import generate_uuid


class SavedJob(Base):
    """Jobs bookmarked by students"""

    __tablename__ = "saved_jobs"

    id = Column(String, primary_key=True, default=generate_uuid)
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    job_description_id = Column(
        String, ForeignKey("job_descriptions.id", ondelete="CASCADE")
    )
    created_at = Column(DateTime, default=datetime.utcnow)

    student_profile = relationship("StudentProfile")
    job_description = relationship("JobDescription")


class HiddenJob(Base):
    """Jobs hidden by students"""

    __tablename__ = "hidden_jobs"

    id = Column(String, primary_key=True, default=generate_uuid)
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    job_description_id = Column(
        String, ForeignKey("job_descriptions.id", ondelete="CASCADE")
    )
    created_at = Column(DateTime, default=datetime.utcnow)

    student_profile = relationship("StudentProfile")
    job_description = relationship("JobDescription")


class JobComparison(Base):
    """Saved job comparison results"""

    __tablename__ = "job_comparisons"

    id = Column(String, primary_key=True, default=generate_uuid)
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    resume_id = Column(String, ForeignKey("resumes.id", ondelete="CASCADE"))
    job_description_id = Column(
        String, ForeignKey("job_descriptions.id", ondelete="CASCADE"), nullable=True
    )
    custom_job_description = Column(Text, nullable=True)

    success_probability = Column(Float)
    success_level = Column(String)
    success_message = Column(Text)

    scores = Column(JSON)
    analysis = Column(JSON)
    next_steps = Column(JSON)

    created_at = Column(DateTime, default=datetime.utcnow)

    student_profile = relationship("StudentProfile")
    resume = relationship("Resume")
    job_description = relationship("JobDescription")


class MockInterview(Base):
    """Mock interviews for job positions"""

    __tablename__ = "mock_interviews"

    id = Column(String, primary_key=True, default=generate_uuid)
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    job_comparison_id = Column(
        String, ForeignKey("job_comparisons.id", ondelete="CASCADE")
    )

    questions = Column(JSON)  # List of questions
    answers = Column(JSON)  # Student's answers
    evaluation = Column(JSON)  # AI evaluation

    overall_score = Column(Float)
    feedback = Column(Text)
    strengths = Column(JSON)
    improvements = Column(JSON)

    status = Column(String, default="pending")  # pending, in_progress, completed
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

    student_profile = relationship("StudentProfile")
    job_comparison = relationship("JobComparison")


class ImprovedResume(Base):
    """AI-improved resumes"""

    __tablename__ = "improved_resumes"

    id = Column(String, primary_key=True, default=generate_uuid)
    original_resume_id = Column(String, ForeignKey("resumes.id", ondelete="CASCADE"))
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )

    file_name = Column(String)
    file_path = Column(String)
    improvement_notes = Column(JSON)
    ats_score_before = Column(Float)
    ats_score_after = Column(Float)

    created_at = Column(DateTime, default=datetime.utcnow)

    original_resume = relationship("Resume")
    student_profile = relationship("StudentProfile")


class CourseSuggestion(Base):
    """AI-suggested courses"""

    __tablename__ = "course_suggestions"

    id = Column(String, primary_key=True, default=generate_uuid)
    job_comparison_id = Column(
        String, ForeignKey("job_comparisons.id", ondelete="CASCADE")
    )

    course_name = Column(String)
    platform = Column(String)  # Udemy, Coursera, etc.
    url = Column(String)
    relevance_score = Column(Float)
    reason = Column(Text)
    skill_gap = Column(String)

    created_at = Column(DateTime, default=datetime.utcnow)

    job_comparison = relationship("JobComparison")
