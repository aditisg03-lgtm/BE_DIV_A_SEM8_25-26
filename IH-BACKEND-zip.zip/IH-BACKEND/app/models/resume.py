from sqlalchemy import (
    Column,
    String,
    DateTime,
    Integer,
    Float,
    Boolean,
    ForeignKey,
    Text,
    JSON,
)
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base
from app.models.user import generate_uuid


class Resume(Base):
    __tablename__ = "resumes"

    id = Column(String, primary_key=True, default=generate_uuid)
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    file_name = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    file_size = Column(Integer, nullable=False)
    upload_date = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    extracted_text = Column(Text, nullable=True)
    parsed_data = Column(JSON, nullable=True)
    ats_score = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    student_profile = relationship("StudentProfile", back_populates="resumes")
    analyses = relationship(
        "ResumeAnalysis", back_populates="resume", cascade="all, delete-orphan"
    )
    applications = relationship("Application", back_populates="resume")


class ResumeAnalysis(Base):
    __tablename__ = "resume_analyses"

    id = Column(String, primary_key=True, default=generate_uuid)
    resume_id = Column(String, ForeignKey("resumes.id", ondelete="CASCADE"))
    job_description_id = Column(
        String, ForeignKey("job_descriptions.id", ondelete="SET NULL"), nullable=True
    )
    ats_score = Column(Float, nullable=False)
    keyword_match_percentage = Column(Float, nullable=True)
    skills_match = Column(JSON, nullable=True)
    experience_match = Column(JSON, nullable=True)
    education_match = Column(JSON, nullable=True)
    strengths = Column(JSON, default=list)
    weaknesses = Column(JSON, default=list)
    improvement_suggestions = Column(JSON, default=list)
    overall_feedback = Column(Text, nullable=True)
    gemini_raw_response = Column(JSON, nullable=True)
    analysis_date = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    resume = relationship("Resume", back_populates="analyses")
    job_description = relationship("JobDescription")
