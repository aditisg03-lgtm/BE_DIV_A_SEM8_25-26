from sqlalchemy import (
    Column,
    String,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    JSON,
)
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base
from app.models.user import generate_uuid


class BulkUploadBatch(Base):
    """Track bulk resume upload sessions"""

    __tablename__ = "bulk_upload_batches"

    id = Column(String, primary_key=True, default=generate_uuid)
    hr_profile_id = Column(String, ForeignKey("hr_profiles.id", ondelete="CASCADE"))
    job_description_id = Column(
        String, ForeignKey("job_descriptions.id", ondelete="CASCADE")
    )

    total_uploaded = Column(Integer, nullable=False)
    successful_count = Column(Integer, nullable=False)
    failed_count = Column(Integer, nullable=False)

    average_ats_score = Column(Float, nullable=True)
    highest_score = Column(Float, nullable=True)
    lowest_score = Column(Float, nullable=True)

    statistics = Column(JSON, nullable=True)
    upload_date = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    hr_profile = relationship("HRProfile")
    job_description = relationship("JobDescription")
    candidates = relationship(
        "BulkCandidateAnalysis", back_populates="batch", cascade="all, delete-orphan"
    )


class BulkCandidateAnalysis(Base):
    """Store individual candidate analysis from bulk upload"""

    __tablename__ = "bulk_candidate_analyses"

    id = Column(String, primary_key=True, default=generate_uuid)
    batch_id = Column(String, ForeignKey("bulk_upload_batches.id", ondelete="CASCADE"))

    filename = Column(String, nullable=False)
    rank = Column(Integer, nullable=True)

    # Candidate Info
    candidate_name = Column(String, nullable=True)
    contact_email = Column(String, nullable=True)
    contact_phone = Column(String, nullable=True)
    location = Column(String, nullable=True)
    total_years_experience = Column(Float, nullable=True)

    # Scores
    ats_score = Column(Float, nullable=False)
    keyword_match = Column(Float, nullable=True)

    # Analysis Data
    skills_match = Column(JSON, nullable=True)
    experience_match = Column(JSON, nullable=True)
    education_match = Column(JSON, nullable=True)

    strengths = Column(JSON, nullable=True)
    weaknesses = Column(JSON, nullable=True)
    improvement_suggestions = Column(JSON, nullable=True)
    key_achievements = Column(JSON, nullable=True)

    overall_feedback = Column(String, nullable=True)
    recommendation = Column(String, nullable=True)

    full_analysis = Column(JSON, nullable=True)
    extracted_text_preview = Column(String, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    batch = relationship("BulkUploadBatch", back_populates="candidates")
