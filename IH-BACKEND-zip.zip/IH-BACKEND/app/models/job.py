from sqlalchemy import (
    Column,
    String,
    DateTime,
    Integer,
    ForeignKey,
    Text,
    JSON,
    Enum as SQLEnum,
)
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.database import Base
from app.models.user import generate_uuid


class EmploymentType(str, enum.Enum):
    FULL_TIME = "full-time"
    PART_TIME = "part-time"
    CONTRACT = "contract"
    INTERNSHIP = "internship"


class ExperienceLevel(str, enum.Enum):
    ENTRY = "entry"
    MID = "mid"
    SENIOR = "senior"
    EXECUTIVE = "executive"


class JobStatus(str, enum.Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    CLOSED = "closed"
    ARCHIVED = "archived"


class JobDescription(Base):
    __tablename__ = "job_descriptions"

    id = Column(String, primary_key=True, default=generate_uuid)
    hr_profile_id = Column(String, ForeignKey("hr_profiles.id", ondelete="CASCADE"))
    title = Column(String, nullable=False)
    department = Column(String, nullable=True)
    location = Column(String, nullable=False)
    employment_type = Column(SQLEnum(EmploymentType), nullable=False)
    experience_level = Column(SQLEnum(ExperienceLevel), nullable=False)
    salary_min = Column(Integer, nullable=True)
    salary_max = Column(Integer, nullable=True)
    description = Column(Text, nullable=False)
    requirements = Column(JSON, default=list)
    responsibilities = Column(JSON, default=list)
    preferred_qualifications = Column(JSON, default=list)
    benefits = Column(JSON, default=list)
    required_skills = Column(JSON, default=list)
    status = Column(SQLEnum(JobStatus), default=JobStatus.DRAFT)
    posted_date = Column(DateTime, nullable=True)
    closing_date = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    hr_profile = relationship("HRProfile", back_populates="job_descriptions")
    applications = relationship(
        "Application", back_populates="job_description", cascade="all, delete-orphan"
    )
