from sqlalchemy import (
    Column,
    String,
    DateTime,
    Float,
    ForeignKey,
    Text,
    JSON,
    Enum as SQLEnum,
    Integer,
)
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.database import Base
from app.models.user import generate_uuid


class ApplicationStatus(str, enum.Enum):
    SUBMITTED = "submitted"
    UNDER_REVIEW = "under_review"
    SHORTLISTED = "shortlisted"
    INTERVIEW_SCHEDULED = "interview_scheduled"
    OFFER_EXTENDED = "offer_extended"
    REJECTED = "rejected"
    WITHDRAWN = "withdrawn"


class InterviewType(str, enum.Enum):
    PHONE = "phone"
    VIDEO = "video"
    ONSITE = "onsite"
    TECHNICAL = "technical"
    BEHAVIORAL = "behavioral"


class InterviewStatus(str, enum.Enum):
    SCHEDULED = "scheduled"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    RESCHEDULED = "rescheduled"


class Application(Base):
    __tablename__ = "applications"

    id = Column(String, primary_key=True, default=generate_uuid)
    job_description_id = Column(
        String, ForeignKey("job_descriptions.id", ondelete="CASCADE")
    )
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    resume_id = Column(
        String, ForeignKey("resumes.id", ondelete="SET NULL"), nullable=True
    )
    status = Column(SQLEnum(ApplicationStatus), default=ApplicationStatus.SUBMITTED)
    ats_score = Column(Float, nullable=True)
    ranking_score = Column(Float, nullable=True)
    ai_analysis = Column(JSON, nullable=True)
    hr_notes = Column(Text, nullable=True)
    applied_date = Column(DateTime, default=datetime.utcnow)
    last_status_update = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    job_description = relationship("JobDescription", back_populates="applications")
    student_profile = relationship("StudentProfile", back_populates="applications")
    resume = relationship("Resume", back_populates="applications")
    interviews = relationship(
        "InterviewSchedule", back_populates="application", cascade="all, delete-orphan"
    )


class InterviewSchedule(Base):
    __tablename__ = "interview_schedules"

    id = Column(String, primary_key=True, default=generate_uuid)
    application_id = Column(String, ForeignKey("applications.id", ondelete="CASCADE"))
    interview_type = Column(SQLEnum(InterviewType), nullable=False)
    scheduled_date = Column(DateTime, nullable=False)
    duration_minutes = Column(Integer, nullable=False)
    location_or_link = Column(String, nullable=False)
    interviewer_names = Column(JSON, default=list)
    notes = Column(Text, nullable=True)
    status = Column(SQLEnum(InterviewStatus), default=InterviewStatus.SCHEDULED)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    application = relationship("Application", back_populates="interviews")
