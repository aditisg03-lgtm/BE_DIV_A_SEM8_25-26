# from sqlalchemy import Column, String, Integer, Float, DateTime, JSON, ForeignKey, Text
# from sqlalchemy.orm import relationship
# from app.database import Base
# from datetime import datetime
# import uuid


# def generate_uuid():
#     return str(uuid.uuid4())


# class ResumeAnalysis(Base):
#     __tablename__ = "resume_analyses"

#     id = Column(String, primary_key=True, default=generate_uuid)
#     resume_id = Column(String, ForeignKey("resumes.id"), nullable=False)
#     job_description_id = Column(
#         String, ForeignKey("job_descriptions.id"), nullable=True
#     )

#     # Analysis metrics
#     ats_score = Column(Float, default=0.0)
#     keyword_match_percentage = Column(Float, default=0.0)
#     analysis_date = Column(DateTime, default=datetime.utcnow)

#     # Detailed analysis results (JSON)
#     skills_match = Column(
#         JSON, default=dict
#     )  # matched_skills, missing_skills, match_percentage
#     experience_match = Column(JSON, default=dict)  # score, feedback
#     education_match = Column(JSON, default=dict)  # score, feedback
#     strengths = Column(JSON, default=list)
#     weaknesses = Column(JSON, default=list)
#     improvement_suggestions = Column(JSON, default=list)

#     # Full analysis data
#     full_analysis = Column(JSON, default=dict)

#     # Timestamps
#     created_at = Column(DateTime, default=datetime.utcnow)
#     updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

#     # Relationships
#     resume = relationship("Resume", back_populates="analyses")
#     job_description = relationship("JobDescription", backref="resume_analyses")
