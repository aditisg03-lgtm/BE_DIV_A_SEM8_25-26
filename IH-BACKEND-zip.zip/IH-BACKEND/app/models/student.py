from sqlalchemy import (
    Column,
    String,
    DateTime,
    Integer,
    Float,
    Boolean,
    ForeignKey,
    Date,
    Text,
    JSON,
)
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base
from app.models.user import generate_uuid


class StudentProfile(Base):
    __tablename__ = "student_profiles"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    phone = Column(String, nullable=True)
    date_of_birth = Column(Date, nullable=True)
    location = Column(String, nullable=True)
    linkedin_url = Column(String, nullable=True)
    github_url = Column(String, nullable=True)
    portfolio_url = Column(String, nullable=True)
    bio = Column(Text, nullable=True)
    preferred_job_types = Column(JSON, default=list)
    expected_salary = Column(Integer, nullable=True)
    availability = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship("User", back_populates="student_profile")
    education = relationship(
        "Education", back_populates="student_profile", cascade="all, delete-orphan"
    )
    work_experiences = relationship(
        "WorkExperience", back_populates="student_profile", cascade="all, delete-orphan"
    )
    skills = relationship(
        "Skill", back_populates="student_profile", cascade="all, delete-orphan"
    )
    resumes = relationship(
        "Resume", back_populates="student_profile", cascade="all, delete-orphan"
    )
    applications = relationship(
        "Application", back_populates="student_profile", cascade="all, delete-orphan"
    )


class Education(Base):
    __tablename__ = "education"

    id = Column(String, primary_key=True, default=generate_uuid)
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    institution = Column(String, nullable=False)
    degree = Column(String, nullable=False)
    field_of_study = Column(String, nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=True)
    grade = Column(String, nullable=True)
    description = Column(Text, nullable=True)
    is_current = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    student_profile = relationship("StudentProfile", back_populates="education")


class WorkExperience(Base):
    __tablename__ = "work_experiences"

    id = Column(String, primary_key=True, default=generate_uuid)
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    company = Column(String, nullable=False)
    position = Column(String, nullable=False)
    location = Column(String, nullable=True)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=True)
    is_current = Column(Boolean, default=False)
    description = Column(Text, nullable=False)
    technologies_used = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    student_profile = relationship("StudentProfile", back_populates="work_experiences")


class Skill(Base):
    __tablename__ = "skills"

    id = Column(String, primary_key=True, default=generate_uuid)
    student_profile_id = Column(
        String, ForeignKey("student_profiles.id", ondelete="CASCADE")
    )
    skill_name = Column(String, nullable=False)
    skill_category = Column(String, nullable=False)  # technical, soft, language
    proficiency_level = Column(Integer, nullable=False)  # 1-5
    years_of_experience = Column(Float, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    student_profile = relationship("StudentProfile", back_populates="skills")
