from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.models.application import ApplicationStatus, InterviewType, InterviewStatus


class ApplicationCreate(BaseModel):
    job_description_id: str
    resume_id: str


class ApplicationUpdate(BaseModel):
    status: Optional[ApplicationStatus] = None
    hr_notes: Optional[str] = None


class ApplicationResponse(BaseModel):
    id: str
    job_description_id: str
    student_profile_id: str
    resume_id: Optional[str] = None
    status: ApplicationStatus
    ats_score: Optional[float] = None
    ranking_score: Optional[float] = None
    ai_analysis: Optional[Dict[str, Any]] = None
    hr_notes: Optional[str] = None
    applied_date: datetime
    last_status_update: datetime

    class Config:
        from_attributes = True


class InterviewScheduleCreate(BaseModel):
    application_id: str
    interview_type: InterviewType
    scheduled_date: datetime
    duration_minutes: int
    location_or_link: str
    interviewer_names: List[str] = []
    notes: Optional[str] = None


class InterviewScheduleResponse(BaseModel):
    id: str
    application_id: str
    interview_type: InterviewType
    scheduled_date: datetime
    duration_minutes: int
    location_or_link: str
    interviewer_names: List[str]
    notes: Optional[str] = None
    status: InterviewStatus
    created_at: datetime

    class Config:
        from_attributes = True
