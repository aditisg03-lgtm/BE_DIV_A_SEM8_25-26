from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
from app.models.job import EmploymentType, ExperienceLevel, JobStatus


class JobDescriptionBase(BaseModel):
    title: str
    department: Optional[str] = None
    location: str
    employment_type: EmploymentType
    experience_level: ExperienceLevel
    salary_min: Optional[int] = None
    salary_max: Optional[int] = None
    description: str
    requirements: List[str] = []
    responsibilities: List[str] = []
    preferred_qualifications: List[str] = []
    benefits: List[str] = []
    required_skills: List[Dict[str, Any]] = []
    closing_date: Optional[datetime] = None


class JobDescriptionCreate(JobDescriptionBase):
    pass


class JobDescriptionUpdate(BaseModel):
    title: Optional[str] = None
    department: Optional[str] = None
    location: Optional[str] = None
    employment_type: Optional[EmploymentType] = None
    experience_level: Optional[ExperienceLevel] = None
    salary_min: Optional[int] = None
    salary_max: Optional[int] = None
    description: Optional[str] = None
    requirements: Optional[List[str]] = None
    responsibilities: Optional[List[str]] = None
    preferred_qualifications: Optional[List[str]] = None
    benefits: Optional[List[str]] = None
    required_skills: Optional[List[Dict[str, Any]]] = None
    status: Optional[JobStatus] = None
    closing_date: Optional[datetime] = None


class JobDescriptionResponse(JobDescriptionBase):
    id: str
    hr_profile_id: str
    status: JobStatus
    posted_date: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    applications_count: int = 0

    class Config:
        from_attributes = True
