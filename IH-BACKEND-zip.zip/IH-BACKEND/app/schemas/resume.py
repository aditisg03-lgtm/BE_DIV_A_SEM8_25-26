from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime


class ResumeUploadResponse(BaseModel):
    id: str
    file_name: str
    file_size: int
    upload_date: datetime
    message: str


class ResumeResponse(BaseModel):
    id: str
    student_profile_id: str
    file_name: str
    file_path: str
    file_size: int
    upload_date: datetime
    is_active: bool
    ats_score: Optional[float] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ResumeAnalysisResponse(BaseModel):
    id: str
    resume_id: str
    job_description_id: Optional[str] = None
    ats_score: float
    keyword_match_percentage: Optional[float] = None
    skills_match: Optional[Dict[str, Any]] = None
    experience_match: Optional[Dict[str, Any]] = None
    education_match: Optional[Dict[str, Any]] = None
    strengths: List[str] = []
    weaknesses: List[str] = []
    improvement_suggestions: List[str] = []
    overall_feedback: Optional[str] = None
    analysis_date: datetime

    class Config:
        from_attributes = True
