from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class HRProfileBase(BaseModel):
    first_name: str
    last_name: str
    company_name: str
    company_website: Optional[str] = None
    company_size: Optional[str] = None
    industry: Optional[str] = None
    position: str
    department: Optional[str] = None
    phone: Optional[str] = None
    linkedin_url: Optional[str] = None


class HRProfileCreate(HRProfileBase):
    pass


class HRProfileUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    company_name: Optional[str] = None
    company_website: Optional[str] = None
    company_size: Optional[str] = None
    industry: Optional[str] = None
    position: Optional[str] = None
    department: Optional[str] = None
    phone: Optional[str] = None
    linkedin_url: Optional[str] = None


class HRProfileResponse(HRProfileBase):
    id: str
    user_id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
