from pydantic import BaseModel, HttpUrl
from typing import Optional, List
from datetime import date, datetime


class EducationBase(BaseModel):
    institution: str
    degree: str
    field_of_study: str
    start_date: date
    end_date: Optional[date] = None
    grade: Optional[str] = None
    description: Optional[str] = None
    is_current: bool = False


class EducationCreate(EducationBase):
    pass


class EducationUpdate(BaseModel):
    institution: Optional[str] = None
    degree: Optional[str] = None
    field_of_study: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    grade: Optional[str] = None
    description: Optional[str] = None
    is_current: Optional[bool] = None


class EducationResponse(EducationBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True


class WorkExperienceBase(BaseModel):
    company: str
    position: str
    location: Optional[str] = None
    start_date: date
    end_date: Optional[date] = None
    is_current: bool = False
    description: str
    technologies_used: List[str] = []


class WorkExperienceCreate(WorkExperienceBase):
    pass


class WorkExperienceUpdate(BaseModel):
    company: Optional[str] = None
    position: Optional[str] = None
    location: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    is_current: Optional[bool] = None
    description: Optional[str] = None
    technologies_used: Optional[List[str]] = None


class WorkExperienceResponse(WorkExperienceBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True


class SkillBase(BaseModel):
    skill_name: str
    skill_category: str
    proficiency_level: int
    years_of_experience: Optional[float] = None


class SkillCreate(SkillBase):
    pass


class SkillUpdate(BaseModel):
    skill_name: Optional[str] = None
    skill_category: Optional[str] = None
    proficiency_level: Optional[int] = None
    years_of_experience: Optional[float] = None


class SkillResponse(SkillBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True


class StudentProfileBase(BaseModel):
    first_name: str
    last_name: str
    phone: Optional[str] = None
    date_of_birth: Optional[date] = None
    location: Optional[str] = None
    linkedin_url: Optional[str] = None
    github_url: Optional[str] = None
    portfolio_url: Optional[str] = None
    bio: Optional[str] = None
    preferred_job_types: List[str] = []
    expected_salary: Optional[int] = None
    availability: Optional[str] = None


class StudentProfileCreate(StudentProfileBase):
    pass


class StudentProfileUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[date] = None
    location: Optional[str] = None
    linkedin_url: Optional[str] = None
    github_url: Optional[str] = None
    portfolio_url: Optional[str] = None
    bio: Optional[str] = None
    preferred_job_types: Optional[List[str]] = None
    expected_salary: Optional[int] = None
    availability: Optional[str] = None


class StudentProfileResponse(StudentProfileBase):
    id: str
    user_id: str
    created_at: datetime
    updated_at: datetime
    education: List[EducationResponse] = []
    work_experiences: List[WorkExperienceResponse] = []
    skills: List[SkillResponse] = []

    class Config:
        from_attributes = True
