from app.schemas.user import *
from app.schemas.student import *
from app.schemas.hr import *
from app.schemas.resume import *
from app.schemas.job import *
from app.schemas.application import *
