"""
Bootstrap script to populate database with comprehensive sample data
Creates complete profiles for testing and development
"""

from sqlalchemy.orm import Session
from datetime import datetime, timedelta, date
from app.database import SessionLocal, engine, Base
from app.models.user import User, UserRole
from app.models.student import StudentProfile
from app.models.hr import HRProfile
from app.models.job import JobDescription, JobStatus, EmploymentType, ExperienceLevel
from app.models.resume import Resume
from app.models.application import Application, ApplicationStatus
from app.services.auth_service import get_password_hash
import os


def bootstrap_database():
    """Create all tables and populate with sample data"""

    print("\n" + "=" * 80)
    print("🚀 BOOTSTRAPPING DATABASE - IntelizenHire")
    print("=" * 80 + "\n")

    # Create all tables
    print("📋 Creating database tables...")
    Base.metadata.create_all(bind=engine)
    print("✅ All tables created successfully\n")

    db = SessionLocal()

    try:
        # Check if data already exists
        existing_users = db.query(User).count()
        if existing_users > 0:
            print("⚠️  Database already contains data. Skipping bootstrap.")
            print(f"   Found {existing_users} existing users\n")
            return

        print("👤 Creating Sample Users and Profiles...\n")

        # ==================== CREATE STUDENT USER ====================
        print("1️⃣  Creating Student User: John Doe")
        student_user = User(
            email="john.doe@student.com",
            password_hash=get_password_hash("Student@123"),
            role=UserRole.STUDENT,
            is_active=True,
            is_verified=True,
        )
        db.add(student_user)
        db.flush()
        print(f"   ✅ Student user created (ID: {student_user.id})")
        print(f"   📧 Email: john.doe@student.com")
        print(f"   🔑 Password: Student@123\n")

        # Create Comprehensive Student Profile
        print("   📝 Creating Comprehensive Student Profile...")

        # Prepare complex nested data
        education_data = [
            {
                "degree": "Bachelor of Science",
                "field": "Computer Science",
                "institution": "University of California, Berkeley",
                "location": "Berkeley, CA",
                "start_date": "2016-09",
                "end_date": "2020-05",
                "gpa": "3.8",
                "honors": "Magna Cum Laude, Dean's List (All Semesters)",
            },
            {
                "degree": "Associate",
                "field": "Web Development",
                "institution": "City College of San Francisco",
                "location": "San Francisco, CA",
                "start_date": "2014-09",
                "end_date": "2016-05",
                "gpa": "3.9",
                "honors": "Valedictorian",
            },
        ]

        experience_data = [
            {
                "title": "Senior Full-Stack Developer",
                "company": "TechCorp Solutions",
                "location": "San Francisco, CA",
                "employment_type": "Full-time",
                "start_date": "2022-01",
                "end_date": "Present",
                "current": True,
                "description": "Leading development of cloud-based SaaS platform serving 50K+ users",
                "responsibilities": [
                    "Architected and implemented microservices using Node.js and Docker, reducing deployment time by 60%",
                    "Led a team of 5 developers in an Agile environment, delivering features 30% faster",
                    "Implemented CI/CD pipeline using GitHub Actions, achieving 95% test coverage",
                    "Optimized database queries reducing API response time by 40%",
                    "Mentored junior developers and conducted code reviews",
                ],
            },
            {
                "title": "Full-Stack Developer",
                "company": "StartupHub Inc",
                "location": "San Jose, CA",
                "employment_type": "Full-time",
                "start_date": "2020-06",
                "end_date": "2021-12",
                "current": False,
                "description": "Developed e-commerce platform handling 10K+ daily transactions",
                "responsibilities": [
                    "Built RESTful APIs using Express.js and MongoDB",
                    "Developed responsive frontend using React and Redux",
                    "Integrated payment gateways (Stripe, PayPal) processing $2M+ annually",
                    "Implemented real-time chat using Socket.io",
                    "Collaborated with UX team to improve conversion rate by 25%",
                ],
            },
            {
                "title": "Junior Web Developer (Intern)",
                "company": "Digital Media Agency",
                "location": "Oakland, CA",
                "employment_type": "Internship",
                "start_date": "2019-06",
                "end_date": "2019-08",
                "current": False,
                "description": "Developed client websites and marketing campaigns",
                "responsibilities": [
                    "Created 5+ responsive WordPress websites for clients",
                    "Improved site loading speed by 50% through optimization",
                    "Assisted in SEO optimization increasing organic traffic by 30%",
                ],
            },
        ]

        skills_data = [
            # Frontend
            {"name": "React", "level": "Expert", "years": 3},
            {"name": "JavaScript", "level": "Expert", "years": 4},
            {"name": "TypeScript", "level": "Advanced", "years": 2},
            {"name": "HTML5", "level": "Expert", "years": 5},
            {"name": "CSS3", "level": "Expert", "years": 5},
            {"name": "Redux", "level": "Advanced", "years": 2},
            {"name": "Next.js", "level": "Intermediate", "years": 1},
            {"name": "Vue.js", "level": "Intermediate", "years": 1},
            # Backend
            {"name": "Node.js", "level": "Expert", "years": 3},
            {"name": "Express.js", "level": "Expert", "years": 3},
            {"name": "Python", "level": "Advanced", "years": 2},
            {"name": "Django", "level": "Intermediate", "years": 1},
            {"name": "FastAPI", "level": "Advanced", "years": 1},
            {"name": "RESTful APIs", "level": "Expert", "years": 3},
            {"name": "GraphQL", "level": "Intermediate", "years": 1},
            # Databases
            {"name": "MongoDB", "level": "Advanced", "years": 3},
            {"name": "PostgreSQL", "level": "Advanced", "years": 2},
            {"name": "MySQL", "level": "Intermediate", "years": 2},
            {"name": "Redis", "level": "Intermediate", "years": 1},
            # DevOps & Tools
            {"name": "Docker", "level": "Advanced", "years": 2},
            {"name": "Kubernetes", "level": "Intermediate", "years": 1},
            {"name": "AWS", "level": "Advanced", "years": 2},
            {"name": "Git", "level": "Expert", "years": 4},
            {"name": "CI/CD", "level": "Advanced", "years": 2},
            {"name": "GitHub Actions", "level": "Advanced", "years": 1},
            # Other
            {"name": "Agile/Scrum", "level": "Advanced", "years": 3},
            {"name": "Test-Driven Development", "level": "Advanced", "years": 2},
            {"name": "Microservices", "level": "Advanced", "years": 2},
        ]

        certifications_data = [
            {
                "name": "AWS Certified Solutions Architect - Associate",
                "issuer": "Amazon Web Services",
                "issue_date": "2022-03",
                "expiry_date": "2025-03",
                "credential_id": "AWS-SA-12345",
            },
            {
                "name": "Professional Scrum Master I (PSM I)",
                "issuer": "Scrum.org",
                "issue_date": "2021-06",
                "credential_id": "PSM-67890",
            },
            {
                "name": "MongoDB Certified Developer",
                "issuer": "MongoDB University",
                "issue_date": "2021-02",
                "credential_id": "MDB-11223",
            },
        ]

        projects_data = [
            {
                "title": "E-Commerce Platform",
                "description": "Full-stack e-commerce platform with real-time inventory management",
                "technologies": ["React", "Node.js", "MongoDB", "Stripe", "AWS"],
                "url": "https://github.com/johndoe/ecommerce",
                "start_date": "2022-01",
                "end_date": "2022-06",
            },
            {
                "title": "AI Task Manager",
                "description": "Smart task management app with AI-powered prioritization",
                "technologies": [
                    "React",
                    "Python",
                    "FastAPI",
                    "TensorFlow",
                    "PostgreSQL",
                ],
                "url": "https://github.com/johndoe/ai-tasks",
                "start_date": "2023-01",
                "end_date": "2023-04",
            },
            {
                "title": "Real-time Chat Application",
                "description": "Scalable chat app supporting 1000+ concurrent users",
                "technologies": ["React", "Socket.io", "Node.js", "Redis", "Docker"],
                "url": "https://github.com/johndoe/chat-app",
                "start_date": "2021-08",
                "end_date": "2021-12",
            },
        ]

        languages_data = [
            {"name": "English", "proficiency": "Native"},
            {"name": "Spanish", "proficiency": "Intermediate"},
            {"name": "Mandarin", "proficiency": "Basic"},
        ]

        student_profile = StudentProfile(
            user_id=student_user.id,
            first_name="John",
            last_name="Doe",
            phone="+1-555-0123",
            date_of_birth=date(1998, 5, 15),
            location="San Francisco, CA, USA",
            linkedin_url="https://linkedin.com/in/johndoe",
            github_url="https://github.com/johndoe",
            portfolio_url="https://johndoe.dev",
            bio="Passionate Full-Stack Developer with 3+ years of experience in building scalable web applications using React, Node.js, and Python. Strong problem-solving skills and keen interest in AI/ML technologies. Proven track record of delivering high-quality solutions that improve user experience and business metrics.",
            preferred_job_types=[
                "Full-Stack Developer",
                "Senior Software Engineer",
                "Backend Developer",
                "Frontend Developer",
            ],
            expected_salary=140000,
            availability="Available with 2 weeks notice",
        )
        db.add(student_profile)
        db.flush()
        print(f"   ✅ Student profile created (ID: {student_profile.id})")

        # Create Sample Resume with realistic content
        print("   📄 Creating Sample Resume...")
        resume_text = """JOHN DOE
Full-Stack Developer

Email: john.doe@student.com | Phone: +1-555-0123
LinkedIn: linkedin.com/in/johndoe | GitHub: github.com/johndoe
Portfolio: johndoe.dev | Location: San Francisco, CA

PROFESSIONAL SUMMARY
Passionate Full-Stack Developer with 3+ years of experience building scalable web applications using React, Node.js, and Python. Proven track record of delivering high-quality solutions that improve user experience and business metrics by up to 40%. Strong expertise in cloud technologies, microservices architecture, and agile methodologies. Seeking challenging opportunities to leverage technical skills and drive innovation.

TECHNICAL SKILLS
Frontend: React, JavaScript, TypeScript, Redux, Next.js, Vue.js, HTML5, CSS3, Responsive Design
Backend: Node.js, Express.js, Python, Django, FastAPI, RESTful APIs, GraphQL, Microservices
Databases: MongoDB, PostgreSQL, MySQL, Redis, Database Optimization, Query Tuning
DevOps & Cloud: Docker, Kubernetes, AWS (EC2, S3, Lambda, RDS), CI/CD, GitHub Actions, Git
Methodologies: Agile/Scrum, Test-Driven Development, Code Reviews, Pair Programming

PROFESSIONAL EXPERIENCE

Senior Full-Stack Developer | TechCorp Solutions | San Francisco, CA
January 2022 - Present
• Architected and implemented microservices architecture using Node.js and Docker, reducing deployment time by 60% and improving system scalability
• Led cross-functional team of 5 developers in Agile environment, consistently delivering sprint goals 30% faster than previous quarters
• Implemented comprehensive CI/CD pipeline using GitHub Actions, achieving 95% test coverage and reducing production bugs by 45%
• Optimized critical database queries and implemented caching strategies, reducing API response time by 40% and improving user satisfaction scores
• Mentored 3 junior developers through code reviews, pair programming sessions, and technical workshops
• Collaborated with product managers and designers using Figma and Jira to deliver customer-centric features

Full-Stack Developer | StartupHub Inc | San Jose, CA  
June 2020 - December 2021
• Developed and maintained e-commerce platform handling 10,000+ daily transactions and $2M+ annual revenue using React, Express.js, and MongoDB
• Built RESTful APIs serving 50+ endpoints with comprehensive documentation using Swagger/OpenAPI
• Integrated payment gateways (Stripe, PayPal) with PCI compliance, processing $2M+ in transactions annually
• Implemented real-time chat functionality using Socket.io, supporting 500+ concurrent users
• Collaborated with UX team to redesign checkout flow, improving conversion rate by 25% and reducing cart abandonment by 15%
• Participated in on-call rotation, maintaining 99.9% uptime and responding to production incidents within 15 minutes

Junior Web Developer (Intern) | Digital Media Agency | Oakland, CA
June 2019 - August 2019
• Created 5+ responsive WordPress websites for small business clients using HTML, CSS, JavaScript, and PHP
• Improved average site loading speed by 50% through image optimization, lazy loading, and code minification
• Assisted in SEO optimization campaigns, increasing organic traffic by 30% for key clients
• Collaborated with design team to implement pixel-perfect layouts from Adobe XD mockups

EDUCATION

Bachelor of Science in Computer Science | University of California, Berkeley
September 2016 - May 2020
• GPA: 3.8/4.0 | Magna Cum Laude, Dean's List (All Semesters)
• Relevant Coursework: Data Structures, Algorithms, Database Systems, Software Engineering, Web Development, Machine Learning
• Senior Project: Built distributed task scheduler using Python and Kubernetes (Grade: A+)

Associate in Web Development | City College of San Francisco  
September 2014 - May 2016
• GPA: 3.9/4.0 | Valedictorian, President's Honor Roll
• Completed intensive program covering HTML, CSS, JavaScript, PHP, MySQL, and responsive design

CERTIFICATIONS
• AWS Certified Solutions Architect - Associate (Amazon Web Services, 2022)
• Professional Scrum Master I (PSM I) (Scrum.org, 2021)
• MongoDB Certified Developer (MongoDB University, 2021)

KEY PROJECTS
• E-Commerce Platform: Full-stack platform with real-time inventory, payment processing, and admin dashboard (React, Node.js, MongoDB, Stripe, AWS)
  - Deployed on AWS with auto-scaling, serving 1000+ daily active users
  
• AI Task Manager: Smart task management application with ML-powered task prioritization (React, Python, FastAPI, TensorFlow, PostgreSQL)
  - Implemented natural language processing for smart task categorization
  
• Real-time Chat Application: Scalable chat application supporting 1000+ concurrent users (React, Socket.io, Node.js, Redis, Docker)
  - Designed horizontal scaling architecture with Redis pub/sub

LANGUAGES
• English (Native)
• Spanish (Intermediate - Conversational)
• Mandarin (Basic)

ADDITIONAL INFORMATION
• Open-source contributor: 15+ pull requests accepted to popular JavaScript libraries
• Hackathon winner: 1st place at SF Tech Hackathon 2022 (Team of 4, built AI-powered code review tool)
• Technical blog: Published 10+ articles on Medium about React, Node.js, and software architecture (1000+ followers)
• Volunteer: Code mentor at local coding bootcamp, teaching web development to career changers (2020-Present)
"""

        sample_resume = Resume(
            student_profile_id=student_profile.id,
            file_name="John_Doe_Resume_2024.pdf",
            file_path=os.path.join("uploads", "resumes", "sample_john_doe.pdf"),
            file_size=245680,
            extracted_text=resume_text,
            ats_score=88.5,
            is_active=True,
            parsed_data={
                "education": education_data,
                "experience": experience_data,
                "skills": skills_data,
                "certifications": certifications_data,
                "projects": projects_data,
                "languages": languages_data,
            },
        )
        db.add(sample_resume)
        db.flush()
        print(f"   ✅ Resume created (ID: {sample_resume.id})")
        print(f"   📈 ATS Score: {sample_resume.ats_score}%")
        print(
            f"   📊 Contains: {len(education_data)} education, {len(experience_data)} experiences, {len(skills_data)} skills\n"
        )

        # ==================== CREATE HR USER ====================
        print("2️⃣  Creating HR User: Sarah Johnson")
        hr_user = User(
            email="sarah.johnson@techcorp.com",
            password_hash=get_password_hash("HR@123"),
            role=UserRole.HR,
            is_active=True,
            is_verified=True,
        )
        db.add(hr_user)
        db.flush()
        print(f"   ✅ HR user created (ID: {hr_user.id})")
        print(f"   📧 Email: sarah.johnson@techcorp.com")
        print(f"   🔑 Password: HR@123\n")

        # Create HR Profile
        print("   📝 Creating HR Profile...")
        hr_profile = HRProfile(
            user_id=hr_user.id,
            first_name="Sarah",
            last_name="Johnson",
            company_name="TechCorp Solutions Inc.",
            company_website="https://techcorpsolutions.com",
            company_size="500-1000",
            industry="Technology / Software Development",
            position="Senior Technical Recruiter",
            department="Human Resources - Talent Acquisition",
            phone="+1-555-0199",
            linkedin_url="https://linkedin.com/in/sarahjohnson-hr",
        )
        db.add(hr_profile)
        db.flush()
        print(f"   ✅ HR profile created (ID: {hr_profile.id})")
        print(f"   🏢 Company: {hr_profile.company_name}\n")

        # ==================== CREATE JOBS ====================
        print("3️⃣  Creating Job Postings...\n")

        jobs_created = []

        # Job 1: Senior Full-Stack Developer (Active)
        print("   Job 1: Senior Full-Stack Developer (Active)")
        job1 = JobDescription(
            hr_profile_id=hr_profile.id,
            title="Senior Full-Stack Developer",
            department="Engineering",
            location="San Francisco, CA (Hybrid)",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.SENIOR,
            salary_min=140000,
            salary_max=180000,
            description="""We are seeking an experienced Senior Full-Stack Developer to join our growing engineering team. You will be responsible for designing, developing, and maintaining our cloud-based SaaS platform that serves over 100,000 users worldwide.

In this role, you'll work with cutting-edge technologies, lead technical initiatives, and mentor junior developers. You'll have the opportunity to make significant architectural decisions and shape the future of our products.

Our tech stack includes React, Node.js, TypeScript, PostgreSQL, AWS, Docker, and Kubernetes. We follow agile methodologies and emphasize clean code, testing, and continuous improvement.""",
            requirements=[
                "5+ years of professional software development experience",
                "Strong expertise in React and modern JavaScript/TypeScript",
                "Extensive experience with Node.js and Express.js",
                "Proficiency in SQL and NoSQL databases",
                "Experience with cloud platforms (AWS, GCP, or Azure)",
                "Strong understanding of RESTful API design and microservices",
                "Experience with containerization (Docker) and orchestration (Kubernetes)",
                "Excellent problem-solving and debugging skills",
                "Bachelor's degree in Computer Science or equivalent experience",
            ],
            responsibilities=[
                "Design and develop scalable, high-performance web applications",
                "Lead technical projects from conception to deployment",
                "Write clean, maintainable, and well-tested code",
                "Conduct code reviews and provide mentorship to junior developers",
                "Collaborate with product managers and designers to deliver features",
                "Optimize application performance and database queries",
                "Participate in architectural decisions and technical planning",
                "Stay current with emerging technologies and industry trends",
            ],
            preferred_qualifications=[
                "Experience with GraphQL",
                "Knowledge of CI/CD pipelines and DevOps practices",
                "Contributions to open-source projects",
                "Experience with agile/scrum methodologies",
                "AWS certifications",
                "Experience with microservices architecture",
                "Strong communication and leadership skills",
            ],
            benefits=[
                "Competitive salary ($140K - $180K based on experience)",
                "Comprehensive health, dental, and vision insurance",
                "401(k) with company matching",
                "Flexible work arrangements (hybrid/remote options)",
                "Unlimited PTO policy",
                "Professional development budget ($3,000/year)",
                "Latest MacBook Pro and equipment",
                "Stock options",
                "Gym membership reimbursement",
                "Catered lunches and snacks",
            ],
            required_skills=[
                {"name": "React", "required": True},
                {"name": "Node.js", "required": True},
                {"name": "TypeScript", "required": True},
                {"name": "JavaScript", "required": True},
                {"name": "PostgreSQL", "required": True},
                {"name": "AWS", "required": True},
                {"name": "Docker", "required": True},
                {"name": "RESTful APIs", "required": True},
                {"name": "Git", "required": True},
                {"name": "Agile/Scrum", "required": False},
                {"name": "GraphQL", "required": False},
                {"name": "Kubernetes", "required": False},
            ],
            status=JobStatus.ACTIVE,
            posted_date=datetime.utcnow() - timedelta(days=7),
            closing_date=datetime.utcnow() + timedelta(days=30),
        )
        db.add(job1)
        db.flush()
        jobs_created.append(job1)
        print(f"   ✅ Created (ID: {job1.id[:8]}...) - {job1.status.value}")

        # Job 2: Backend Engineer - Python (Active)
        print("   Job 2: Backend Engineer - Python (Active)")
        job2 = JobDescription(
            hr_profile_id=hr_profile.id,
            title="Backend Engineer (Python)",
            department="Engineering",
            location="Remote (US Only)",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.MID,
            salary_min=110000,
            salary_max=140000,
            description="""Join our backend team to build robust, scalable APIs that power our mission-critical applications. We're looking for a talented Python developer who is passionate about clean code, performance optimization, and building systems that can handle millions of requests per day.""",
            requirements=[
                "3+ years of backend development experience with Python",
                "Strong experience with FastAPI, Django, or Flask",
                "Proficiency in SQL databases (PostgreSQL preferred)",
                "Experience with RESTful API design and development",
                "Understanding of asynchronous programming",
                "Experience with version control (Git)",
                "Strong problem-solving and analytical skills",
                "Excellent written and verbal communication",
            ],
            responsibilities=[
                "Design and implement RESTful APIs using Python frameworks",
                "Optimize database queries and improve application performance",
                "Write comprehensive unit and integration tests",
                "Collaborate with frontend developers to integrate APIs",
                "Monitor and debug production issues",
                "Participate in code reviews and technical discussions",
                "Document APIs and system architecture",
            ],
            preferred_qualifications=[
                "Experience with async frameworks (FastAPI, aiohttp)",
                "Knowledge of caching strategies (Redis, Memcached)",
                "Experience with message queues (RabbitMQ, Kafka)",
                "Familiarity with containerization (Docker)",
                "Experience with cloud platforms (AWS, GCP)",
                "Understanding of microservices architecture",
            ],
            benefits=[
                "Competitive salary ($110K - $140K)",
                "100% remote work with flexible hours",
                "Health, dental, and vision insurance",
                "401(k) with 4% company match",
                "Generous PTO (20 days + holidays)",
                "Home office setup budget ($1,500)",
                "Learning and development budget ($2,000/year)",
            ],
            required_skills=[
                {"name": "Python", "required": True},
                {"name": "FastAPI", "required": True},
                {"name": "PostgreSQL", "required": True},
                {"name": "RESTful APIs", "required": True},
                {"name": "Git", "required": True},
                {"name": "Redis", "required": False},
                {"name": "Docker", "required": False},
            ],
            status=JobStatus.ACTIVE,
            posted_date=datetime.utcnow() - timedelta(days=3),
            closing_date=datetime.utcnow() + timedelta(days=45),
        )
        db.add(job2)
        db.flush()
        jobs_created.append(job2)
        print(f"   ✅ Created (ID: {job2.id[:8]}...) - {job2.status.value}")

        # Job 3: Frontend Developer - React (Active)
        print("   Job 3: Frontend Developer - React (Active)")
        job3 = JobDescription(
            hr_profile_id=hr_profile.id,
            title="Frontend Developer (React)",
            department="Product",
            location="New York, NY",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.MID,
            salary_min=100000,
            salary_max=130000,
            description="""We're looking for a talented Frontend Developer to create beautiful, performant user interfaces that delight our customers. You'll work closely with our design team to bring mockups to life and collaborate with backend engineers to integrate APIs.""",
            requirements=[
                "3+ years of frontend development experience",
                "Expert-level knowledge of React and modern JavaScript",
                "Strong understanding of HTML5, CSS3, and responsive design",
                "Experience with state management (Redux, Context API)",
                "Proficiency in version control with Git",
                "Understanding of web performance optimization",
                "Experience with RESTful API integration",
            ],
            responsibilities=[
                "Build responsive, accessible web applications using React",
                "Collaborate with UX designers to implement pixel-perfect designs",
                "Optimize components for maximum performance",
                "Write reusable, maintainable component libraries",
                "Implement comprehensive testing (unit, integration, E2E)",
                "Participate in design reviews and provide technical feedback",
            ],
            preferred_qualifications=[
                "Experience with TypeScript",
                "Knowledge of Next.js or similar SSR frameworks",
                "Familiarity with design systems (Material-UI, Chakra UI)",
                "Understanding of accessibility standards (WCAG)",
                "Experience with testing libraries (Jest, React Testing Library)",
            ],
            benefits=[
                "Competitive salary ($100K - $130K)",
                "Health, dental, and vision insurance",
                "401(k) matching",
                "Hybrid work model (3 days in office)",
                "Unlimited PTO",
                "Learning budget ($2,500/year)",
            ],
            required_skills=[
                {"name": "React", "required": True},
                {"name": "JavaScript", "required": True},
                {"name": "HTML5", "required": True},
                {"name": "CSS3", "required": True},
                {"name": "Redux", "required": True},
                {"name": "TypeScript", "required": False},
            ],
            status=JobStatus.ACTIVE,
            posted_date=datetime.utcnow() - timedelta(days=5),
            closing_date=datetime.utcnow() + timedelta(days=60),
        )
        db.add(job3)
        db.flush()
        jobs_created.append(job3)
        print(f"   ✅ Created (ID: {job3.id[:8]}...) - {job3.status.value}")

        # Job 4: DevOps Engineer (Active)
        print("   Job 4: DevOps Engineer (Active)")
        job4 = JobDescription(
            hr_profile_id=hr_profile.id,
            title="DevOps Engineer",
            department="Infrastructure",
            location="Remote",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.SENIOR,
            salary_min=130000,
            salary_max=170000,
            description="""We're seeking an experienced DevOps Engineer to help us scale our infrastructure and improve our deployment processes. You'll work on automating everything, optimizing cloud costs, and ensuring our systems are reliable, secure, and performant.""",
            requirements=[
                "5+ years of DevOps/Infrastructure experience",
                "Strong expertise in AWS services (EC2, ECS, RDS, Lambda, S3)",
                "Expert-level knowledge of Docker and Kubernetes",
                "Experience with Infrastructure as Code (Terraform, CloudFormation)",
                "Proficiency in scripting languages (Python, Bash)",
                "Strong understanding of networking and security",
            ],
            responsibilities=[
                "Design and maintain scalable cloud infrastructure on AWS",
                "Implement and optimize CI/CD pipelines",
                "Manage Kubernetes clusters and containerized applications",
                "Automate infrastructure provisioning using Terraform",
                "Implement monitoring, alerting, and logging solutions",
            ],
            preferred_qualifications=[
                "AWS certifications (Solutions Architect, DevOps Engineer)",
                "Experience with service mesh (Istio, Linkerd)",
                "Knowledge of GitOps practices (ArgoCD, Flux)",
            ],
            benefits=[
                "Competitive salary ($130K - $170K)",
                "100% remote with flexible hours",
                "Comprehensive health benefits",
                "Professional certification reimbursement",
            ],
            required_skills=[
                {"name": "AWS", "required": True},
                {"name": "Docker", "required": True},
                {"name": "Kubernetes", "required": True},
                {"name": "Terraform", "required": True},
                {"name": "Python", "required": True},
            ],
            status=JobStatus.ACTIVE,
            posted_date=datetime.utcnow() - timedelta(days=2),
            closing_date=datetime.utcnow() + timedelta(days=30),
        )
        db.add(job4)
        db.flush()
        jobs_created.append(job4)
        print(f"   ✅ Created (ID: {job4.id[:8]}...) - {job4.status.value}")

        # Job 5: Junior Software Engineer (Draft)
        print("   Job 5: Junior Software Engineer (Draft)")
        job5 = JobDescription(
            hr_profile_id=hr_profile.id,
            title="Junior Software Engineer",
            department="Engineering",
            location="Austin, TX",
            employment_type=EmploymentType.FULL_TIME,
            experience_level=ExperienceLevel.ENTRY,
            salary_min=70000,
            salary_max=90000,
            description="""Great opportunity for recent graduates or early-career developers to join our team and grow their skills.""",
            requirements=[
                "Bachelor's degree in Computer Science or related field",
                "0-2 years of professional experience",
                "Basic knowledge of programming languages",
                "Understanding of data structures and algorithms",
            ],
            responsibilities=[
                "Write clean, maintainable code under supervision",
                "Participate in code reviews",
                "Collaborate with team members",
                "Learn company's tech stack",
            ],
            preferred_qualifications=[
                "Internship experience",
                "Personal projects or open-source contributions",
            ],
            benefits=[
                "Competitive entry-level salary ($70K - $90K)",
                "Comprehensive benefits package",
                "Mentorship program",
            ],
            required_skills=[
                {"name": "JavaScript", "required": False},
                {"name": "Python", "required": False},
                {"name": "Git", "required": True},
            ],
            status=JobStatus.DRAFT,
            posted_date=None,
            closing_date=None,
        )
        db.add(job5)
        db.flush()
        jobs_created.append(job5)
        print(
            f"   ✅ Created (ID: {job5.id[:8]}...) - {job5.status.value} (Not Published)"
        )

        print(f"\n   📋 Total Jobs Created: {len(jobs_created)}\n")

        # ==================== CREATE APPLICATION ====================
        print("4️⃣  Creating Sample Application...\n")

        application = Application(
            job_description_id=job1.id,
            student_profile_id=student_profile.id,
            resume_id=sample_resume.id,
            status=ApplicationStatus.SUBMITTED,
            ats_score=88.5,
            applied_date=datetime.utcnow() - timedelta(days=2),
        )
        db.add(application)
        db.flush()
        print(f"   ✅ Application created (ID: {application.id[:8]}...)")
        print(f"   📋 John Doe → {job1.title}")
        print(f"   📊 ATS Score: {application.ats_score}%")
        print(f"   📅 Applied: {application.applied_date.strftime('%Y-%m-%d')}\n")

        # Commit all changes
        db.commit()

        # ==================== SUMMARY ====================
        print("=" * 80)
        print("✅ BOOTSTRAP COMPLETE!")
        print("=" * 80)
        print("\n📊 Summary:")
        print(f"   👤 Users: 2 (1 Student, 1 HR)")
        print(
            f"   🎓 Student Profiles: 1 (Complete with education, experience, skills)"
        )
        print(f"   🏢 HR Profiles: 1")
        print(f"   💼 Jobs: {len(jobs_created)} (4 Active, 1 Draft)")
        print(f"   📄 Resumes: 1 (88.5% ATS Score)")
        print(f"   📝 Applications: 1")

        print("\n🔑 Login Credentials:")
        print("\n   STUDENT ACCOUNT:")
        print("   ─────────────────")
        print("   Email:    john.doe@student.com")
        print("   Password: Student@123")
        print("   Role:     Student")

        print("\n   HR ACCOUNT:")
        print("   ───────────")
        print("   Email:    sarah.johnson@techcorp.com")
        print("   Password: HR@123")
        print("   Role:     HR")

        print("\n🎯 Quick Start:")
        print("   1. Login as student to browse jobs and apply")
        print("   2. Login as HR to manage jobs and applications")
        print("   3. Use bulk upload feature to test AI resume ranking")
        print("   4. Try Smart Job Match Analyzer for resume-job comparison")

        print("\n📚 Database Location:")
        print(f"   {os.path.abspath('intellizenhire.db')}")

        print("\n" + "=" * 80 + "\n")

    except Exception as e:
        db.rollback()
        print(f"\n❌ BOOTSTRAP ERROR!")
        print(f"{'=' * 80}")
        print(f"Error: {str(e)}")
        print(f"{'=' * 80}\n")
        import traceback

        traceback.print_exc()
        raise

    finally:
        db.close()


if __name__ == "__main__":
    bootstrap_database()
