# IntelizenHire Backend

AI-Powered Applicant Tracking System - Backend API

## Setup Instructions

### 1. Create Virtual Environment

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

1. remove pycache : `Get-ChildItem -Path . -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force`

## Installation and Run Instructions

### Backend Setup:

```bash
cd IntelizenHire-Backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run the server
python run.py
```

Register as Student:

Go to http://localhost:5173/register
Email: student@test.com
Password: password123
Role: Student
Register as HR:

Email: hr@test.com
Password: password123
Role: HR
Test Student Flow:

Complete profile
Upload resume (PDF)
Browse jobs
Apply to jobs
Test HR Flow:

Complete company profile
Create job posting
View applications
Update application status

# ==================

# TESTS

---

# Install dependencies

pip install -r requirements.txt
pip install -r requirements-dev.txt

# Run all tests

pytest

# Run with coverage

pytest --cov=app --cov-report=html

# Run specific test file

pytest tests/test_auth.py -v

# Run specific test class

pytest tests/test_auth.py::TestUserRegistration -v

# Run specific test

pytest tests/test_auth.py::TestUserRegistration::test_register_student_success -v

# Open coverage report

open htmlcov/index.html
