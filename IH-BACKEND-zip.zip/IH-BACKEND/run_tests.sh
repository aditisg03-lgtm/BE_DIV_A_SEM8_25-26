#!/bin/bash

echo "🧪 Running IntelizenHire Test Suite"
echo "====================================="

# Activate virtual environment if needed
# source venv/bin/activate

# Run all tests with coverage
echo "Running all tests..."
pytest tests/ -v --cov=app --cov-report=html --cov-report=term-missing

# Run specific test categories
echo -e "\n📊 Test Categories Available:"
echo "  pytest tests/test_auth.py              # Authentication tests"
echo "  pytest tests/test_user.py              # User management tests"
echo "  pytest tests/test_student.py           # Student profile tests"
echo "  pytest tests/test_hr.py                # HR profile tests"
echo "  pytest tests/test_resume.py            # Resume tests"
echo "  pytest tests/test_job.py               # Job tests"
echo "  pytest tests/test_application.py       # Application tests"
echo "  pytest tests/test_analytics.py         # Analytics tests"
echo "  pytest tests/test_hr_resume.py         # Bulk upload tests"
echo "  pytest tests/test_student_enhancements.py  # Student features tests"

echo -e "\n✅ Tests complete! Coverage report generated in htmlcov/index.html"